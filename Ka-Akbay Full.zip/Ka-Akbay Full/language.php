<?php
require_once __DIR__ . "/app/security.php";
require_once __DIR__ . "/app/auth.php";
require_once __DIR__ . "/app/layout.php";

require_login();

$user = current_user();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (verify_csrf($_POST["csrf_token"] ?? "")) {
        $lang = $_POST["lang"] ?? "en";

        if (in_array($lang, ["en", "tl", "tg"], true)) {
            $_SESSION["lang"] = $lang;
        }
    }

    header("Location: language.php");
    exit;
}

$current = current_lang();

page_head("Language Mode");
sidebar("language", $user);
?>

<main class="main page-enter language-page">
    <section class="topbar">
        <div>
            <h1>Language Mode</h1>
            <p>Select the display language used for system guidance.</p>
        </div>
        <div class="date"><?= e(language_label($current)) ?></div>
    </section>

    <section class="language-hero">
        <div>
            <span>DISPLAY LANGUAGE</span>
            <h2><?= e(language_label($current)) ?> Mode</h2>
        </div>
    </section>

    <section class="language-mode-grid">
        <form method="POST" class="language-mode-card <?= $current === "en" ? "active" : "" ?>">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="lang" value="en">

            <div class="language-mode-top">
                <div class="language-mark">EN</div>
                <div>
                    <h3>English</h3>
                    <p>Use English labels and advisory text.</p>
                </div>
            </div>

            <button class="btn btn-primary" type="submit"><?= $current === "en" ? "Current Mode" : "Use English" ?></button>
        </form>

        <form method="POST" class="language-mode-card <?= $current === "tl" ? "active" : "" ?>">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="lang" value="tl">

            <div class="language-mode-top">
                <div class="language-mark">TL</div>
                <div>
                    <h3>Tagalog</h3>
                    <p>Use Tagalog labels and advisory text.</p>
                </div>
            </div>

            <button class="btn btn-primary" type="submit"><?= $current === "tl" ? "Current Mode" : "Use Tagalog" ?></button>
        </form>

        <form method="POST" class="language-mode-card <?= $current === "tg" ? "active" : "" ?>">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="lang" value="tg">

            <div class="language-mode-top">
                <div class="language-mark">TG</div>
                <div>
                    <h3>Taglish</h3>
                    <p>Use mixed English and Filipino guidance text.</p>
                </div>
            </div>

            <button class="btn btn-primary" type="submit"><?= $current === "tg" ? "Current Mode" : "Use Taglish" ?></button>
        </form>
    </section>
</main>

<?php page_foot(); ?>