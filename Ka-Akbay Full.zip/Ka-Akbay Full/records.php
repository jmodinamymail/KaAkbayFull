<?php
require_once __DIR__ . "/app/security.php";
require_once __DIR__ . "/app/auth.php";
require_once __DIR__ . "/app/page_actions.php";
require_once __DIR__ . "/app/page_data.php";
require_once __DIR__ . "/app/layout.php";

require_role(["student"]);

$user = current_user();

$flashError = trim((string)($_SESSION["recordsFlashError"] ?? ""));
unset($_SESSION["recordsFlashError"]);

$actionError = handle_page_action("records", $user);
$error = $actionError !== "" ? $actionError : $flashError;

$data = get_page_data("records", $user);
$edit = $data["editRecord"] ?? null;
$subjects = $data["subjects"] ?? [];
$records = $data["records"] ?? [];
$assessmentRecords = $data["assessmentRecords"] ?? array_values(array_filter($records, fn($record) => ($record["recordMode"] ?? "assessment") === "assessment"));
$quarterlySummaries = $data["quarterlySummaries"] ?? [];
$recordValidationMap = $data["recordValidationMap"] ?? [];
$deleteRequestMap = $data["deleteRequestMap"] ?? [];
$assignedStrand = $user["strand"] ?? "ABM";
$assignedGradeLevel = $user["gradeLevel"] ?? "Grade 12";
$assessmentMinDate = function_exists("kaakbay_assessment_min_date")
    ? kaakbay_assessment_min_date()
    : date("Y-m-d", strtotime("-1 year", strtotime(date("Y-m-d"))));
$assessmentMaxDate = date("Y-m-d");

if (!count($quarterlySummaries) && function_exists("computed_quarterly_summaries")) {
    $quarterlySummaries = computed_quarterly_summaries($user["id"]);
}

if (!count($quarterlySummaries)) {
    $quarterlySummaries = $data["quarterlyRecords"] ?? [];
}

$editMode = $edit ? ($edit["recordMode"] ?? "assessment") : "assessment";

if ($editMode !== "assessment") {
    $edit = null;
    $editMode = "assessment";
}

$editRecordId = $edit["id"] ?? "";
$editIsChecked = $edit && isset($recordValidationMap[$editRecordId]);
$editDeleteRequest = $editRecordId !== "" ? ($deleteRequestMap[$editRecordId] ?? null) : null;
$editHasPendingDeleteRequest = $editDeleteRequest && (($editDeleteRequest["status"] ?? "") === "Pending");

if ($editIsChecked || $editHasPendingDeleteRequest) {
    $edit = null;
    $editMode = "assessment";
}

page_head(msg("Academic Records", "Talaang Akademiko", "Academic Records"));
sidebar("records", $user);
?>

<main class="main page-enter records-page">
    <section class="topbar">
        <div>
            <h1><?= e(msg("Academic Records", "Talaang Akademiko", "Academic Records")) ?></h1>
        </div>
        <div class="date"><?= e(date("M d, Y")) ?></div>
    </section>

    <div class="error <?= $error ? "show" : "" ?>"><?= e($error) ?></div>

    <section class="card clean-panel record-form-card" id="assessment-entry">
        <div class="clean-panel-head">
            <div>
                <h2><?= e($edit ? msg("Edit Assessment Entry", "I-edit ang Tala ng Pagtataya", "Edit Assessment Entry") : msg("Assessment Entry", "Tala ng Pagtataya", "Assessment Entry")) ?></h2>
            </div>
        </div>

        <form method="POST" class="forms record-entry-form">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="recordId" value="<?= e($edit["id"] ?? "") ?>">
            <input type="hidden" name="recordMode" value="assessment">
            <input type="hidden" name="strand" value="<?= e($assignedStrand) ?>">
            <input type="hidden" name="gradeLevel" value="<?= e($assignedGradeLevel) ?>">

            <div class="field">
                <label><?= e(msg("Subject", "Asignatura", "Subject")) ?></label>
                <?php if (count($subjects)): ?>
                    <select name="subject" required>
                        <option value=""><?= e(msg("Select Subject", "Pumili ng Asignatura", "Select Subject")) ?></option>
                        <?php foreach ($subjects as $subject): ?>
                            <option value="<?= e($subject) ?>" <?= (($edit["subject"] ?? "") === $subject) ? "selected" : "" ?>><?= e($subject) ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php else: ?>
                    <input name="subject" value="<?= e($edit["subject"] ?? "") ?>" placeholder="<?= e(msg("Subject", "Asignatura", "Subject")) ?>" maxlength="100" required>
                <?php endif; ?>
            </div>

            <div class="field">
                <label><?= e(msg("Strand", "Strand", "Strand")) ?></label>
                <input value="<?= e($assignedStrand) ?>" readonly>
            </div>

            <div class="field">
                <label><?= e(msg("Grade Level", "Baitang", "Grade Level")) ?></label>
                <input value="<?= e($assignedGradeLevel) ?>" readonly>
            </div>

            <div class="field">
                <label><?= e(msg("Grading Period", "Markahan", "Grading Period")) ?></label>
                <select name="gradingPeriod" required>
                    <?php foreach (["Quarter 1", "Quarter 2", "Quarter 3", "Quarter 4"] as $period): ?>
                        <option value="<?= e($period) ?>" <?= (($edit["gradingPeriod"] ?? "Quarter 1") === $period) ? "selected" : "" ?>><?= e($period) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="field">
                <label><?= e(msg("Assessment Type", "Uri ng Pagtataya", "Assessment Type")) ?></label>
                <select name="assessmentType" required data-assessment-type>
                    <?php foreach (["Written Work", "Performance Task", "Quarterly Assessment", "Competency Check"] as $type): ?>
                        <option value="<?= e($type) ?>" <?= (($edit["assessmentType"] ?? "Written Work") === $type) ? "selected" : "" ?>><?= e(function_exists("tv") ? tv($type) : $type) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="field">
                <label><?= e(msg("Assessment Title", "Pamagat ng Pagtataya", "Assessment Title")) ?></label>
                <input name="assessmentTitle" value="<?= e($edit["assessmentTitle"] ?? "") ?>" maxlength="120" required>
            </div>

            <div class="field">
                <label><?= e(msg("Score", "Iskor", "Score")) ?></label>
                <input type="number" step="0.01" min="0" max="200" name="score" value="<?= e($edit["score"] ?? "") ?>" inputmode="decimal" required>
            </div>

            <div class="field">
                <label><?= e(msg("Total Score", "Kabuuang Iskor", "Total Score")) ?></label>
                <input type="number" step="0.01" min="1" max="200" name="totalScore" value="<?= e($edit["totalScore"] ?? "") ?>" inputmode="decimal" required>
            </div>

            <div class="field">
                <label><?= e(msg("Submission Status", "Kalagayan ng Pagpapasa", "Submission Status")) ?></label>
                <select name="submissionStatus" required>
                    <?php foreach (["Submitted", "Missing"] as $status): ?>
                        <option value="<?= e($status) ?>" <?= (($edit["submissionStatus"] ?? "Submitted") === $status) ? "selected" : "" ?>><?= e(function_exists("tv") ? tv($status) : $status) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="field">
                <label><?= e(msg("Assessment Date", "Petsa ng Pagtataya", "Assessment Date")) ?></label>
                <input type="date" name="assessmentDate" value="<?= e($edit["assessmentDate"] ?? $assessmentMaxDate) ?>" min="<?= e($assessmentMinDate) ?>" max="<?= e($assessmentMaxDate) ?>" required>
            </div>

            <div class="field full competency-field" data-competency-field>
                <label><?= e(msg("Competency Area", "Bahagi ng Kakayahan", "Competency Area")) ?></label>
                <input name="competencyName" value="<?= e($edit["competencyName"] ?? "") ?>" maxlength="120">
            </div>

            <div class="button-row full">
                <button class="btn btn-primary" type="submit"><?= e($edit ? msg("Save Changes", "I-save ang Pagbabago", "Save Changes") : msg("Save Assessment", "I-save ang Pagtataya", "Save Assessment")) ?></button>
                <a class="btn btn-ghost" href="records.php"><?= e(msg("Cancel", "Kanselahin", "Cancel")) ?></a>
            </div>
        </form>
    </section>

    <section class="card clean-panel section-space compact-record-section" id="assessment-history">
        <div class="clean-panel-head">
            <div>
                <h2><?= e(msg("Assessment History", "Kasaysayan ng Pagtataya", "Assessment History")) ?></h2>
            </div>

            <div class="tab-buttons">
                <button class="tab-button active" type="button" data-record-filter="all"><?= e(msg("All", "Lahat", "All")) ?></button>
                <button class="tab-button" type="button" data-record-filter="Written Work"><?= e(function_exists("tv") ? tv("Written Work") : "Written Work") ?></button>
                <button class="tab-button" type="button" data-record-filter="Performance Task"><?= e(function_exists("tv") ? tv("Performance Task") : "Performance Task") ?></button>
                <button class="tab-button" type="button" data-record-filter="Quarterly Assessment"><?= e(function_exists("tv") ? tv("Quarterly Assessment") : "Quarterly Assessment") ?></button>
                <button class="tab-button" type="button" data-record-filter="Competency Check"><?= e(function_exists("tv") ? tv("Competency Check") : "Competency Check") ?></button>
            </div>
        </div>

        <div class="record-history-grid">
            <?php foreach ($assessmentRecords as $index => $record): ?>
                <?php
                    $evaluated = evaluate_record($record);
                    $guidanceOutput = $evaluated["guidanceOutput"] ?? ["status" => "", "advisory" => "", "guidance" => ""];
                    $assessmentType = $evaluated["assessmentType"] ?? "--";
                    $isCompetencyCheck = $assessmentType === "Competency Check";
                    $recordId = $evaluated["id"] ?? "";
                    $validation = $recordValidationMap[$recordId] ?? null;
                    $deleteRequest = $deleteRequestMap[$recordId] ?? null;
                    $validationStatus = $validation ? msg("Checked by Teacher", "Na-check ng Guro", "Checked by Teacher") : msg("Pending Teacher Check", "Nakahintay sa Check ng Guro", "Pending Teacher Check");
                    $deleteRequestStatus = $deleteRequest["status"] ?? "";
                    $deleteRequestPending = $deleteRequestStatus === "Pending";
                    $directDeleteRemaining = function_exists("academic_record_direct_delete_remaining_seconds")
                        ? academic_record_direct_delete_remaining_seconds($record)
                        : 0;
                    $canDirectDelete = !$validation && $directDeleteRemaining > 0;
                    $canRequestDelete = !$canDirectDelete && !$deleteRequestPending && $deleteRequestStatus !== "Approved";
                    $canEdit = !$validation && !$deleteRequestPending;
                ?>

                <article class="record-history-card compact-record-card <?= e(view_state_class(($validation ? "Checked by Teacher" : "Pending Teacher Check") . " " . $deleteRequestStatus)) ?>" data-record-card data-record-mode="<?= e($assessmentType) ?>">
                    <div class="record-history-top">
                        <div>
                            <span><?= e(($evaluated["gradingPeriod"] ?? "--") . " · " . (function_exists("tv") ? tv($assessmentType) : $assessmentType)) ?></span>
                            <h3><?= e($evaluated["subject"] ?? "--") ?></h3>
                            <p><?= e(($evaluated["assessmentTitle"] ?? "--") . " · " . ($evaluated["assessmentDate"] ?? "--")) ?></p>
                        </div>

                        <?php if ($canEdit): ?>
                            <a class="btn btn-outline" href="records.php?edit=<?= e($recordId) ?>#assessment-entry"><?= e(msg("Edit", "I-edit", "Edit")) ?></a>
                        <?php elseif ($deleteRequestPending): ?>
                            <span class="btn btn-ghost disabled"><?= e(msg("Deletion Pending", "Pending ang Deletion", "Deletion Pending")) ?></span>
                        <?php else: ?>
                            <span class="btn btn-ghost disabled"><?= e(msg("Teacher Checked", "Na-check ng Guro", "Teacher Checked")) ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="meta-row">
                        <?= badge($validationStatus) ?>
                        <?= badge($evaluated["submissionStatus"] ?? "Submitted") ?>
                        <?php if ($canDirectDelete): ?>
                            <?= badge(msg("5-Minute Delete Window", "5-Minute Delete Window", "5-Minute Delete Window")) ?>
                        <?php endif; ?>
                        <?php if ($deleteRequest): ?>
                            <?= badge(msg("Delete Request: ", "Delete Request: ", "Delete Request: ") . $deleteRequestStatus) ?>
                        <?php endif; ?>
                    </div>

                    <div class="record-score-row">
                        <div>
                            <small><?= e(msg("Score", "Iskor", "Score")) ?></small>
                            <strong><?= e(($evaluated["score"] ?? "--") . " / " . ($evaluated["totalScore"] ?? "--")) ?></strong>
                        </div>
                        <div>
                            <small><?= e(msg("Percent", "Porsyento", "Percent")) ?></small>
                            <strong><?= e($evaluated["assessmentPercentage"] ?? "--") ?>%</strong>
                        </div>
                        <div>
                            <small><?= e(msg("Status", "Kalagayan", "Status")) ?></small>
                            <strong><?= e(function_exists("tv") ? tv($evaluated["academicStatus"] ?? "No Record") : ($evaluated["academicStatus"] ?? "No Record")) ?></strong>
                        </div>
                    </div>

                    <?php if ($isCompetencyCheck): ?>
                        <div class="record-score-row">
                            <div>
                                <small><?= e(msg("Competency", "Kakayahan", "Competency")) ?></small>
                                <strong><?= e($evaluated["competencyName"] ?? "--") ?></strong>
                            </div>
                            <div>
                                <small><?= e(msg("Mastery", "Mastery", "Mastery")) ?></small>
                                <strong><?= e($evaluated["competencyMastery"] ?? "--") ?>%</strong>
                            </div>
                            <div>
                                <small><?= e(msg("Status", "Kalagayan", "Status")) ?></small>
                                <strong><?= e(function_exists("tv") ? tv($evaluated["competencyStatus"] ?? "No Record") : ($evaluated["competencyStatus"] ?? "No Record")) ?></strong>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="meta-row">
                        <?= badge($evaluated["academicStatus"] ?? "No Record") ?>
                        <?php if ($isCompetencyCheck): ?>
                            <?= badge($evaluated["competencyStatus"] ?? "No Record") ?>
                        <?php endif; ?>
                        <?= badge($evaluated["requirementStatus"] ?? "Complete Requirements") ?>
                        <?= badge($evaluated["trendStatus"] ?? "Insufficient Trend Data") ?>
                    </div>

                    <?php if ($validation): ?>
                        <div class="record-guidance-strip compact-guidance">
                            <div><strong><?= e(msg("Teacher Check", "Check ng Guro", "Teacher Check")) ?></strong><br><?= e(msg("Checked", "Na-check", "Checked")) ?></div>
                            <div><strong><?= e(msg("Note", "Tala", "Note")) ?></strong><br><?= e(($validation["note"] ?? "") !== "" ? $validation["note"] : "--") ?></div>
                            <div><strong><?= e(msg("Follow-up Plan", "Plano ng Follow-up", "Follow-up Plan")) ?></strong><br><?= e(($validation["followUpPlan"] ?? "") !== "" ? $validation["followUpPlan"] : "--") ?></div>
                        </div>
                    <?php else: ?>
                        <div class="record-guidance-strip compact-guidance">
                            <div><strong><?= e(msg("Teacher Check", "Check ng Guro", "Teacher Check")) ?></strong><br><?= e(msg("Pending Teacher Check", "Nakahintay sa Check ng Guro", "Pending Teacher Check")) ?></div>
                            <div><strong><?= e(msg("Status", "Kalagayan", "Status")) ?></strong><br><?= e($guidanceOutput["status"] ?? "") ?></div>
                            <div><strong><?= e(msg("Guidance", "Gabay", "Guidance")) ?></strong><br><?= e($guidanceOutput["guidance"] ?? "") ?></div>
                        </div>
                    <?php endif; ?>

                    <?php if ($deleteRequest): ?>
                        <div class="record-guidance-strip compact-guidance">
                            <div><strong><?= e(msg("Deletion Request", "Deletion Request", "Deletion Request")) ?></strong><br><?= e(function_exists("tv") ? tv($deleteRequestStatus) : $deleteRequestStatus) ?></div>
                            <div><strong><?= e(msg("Reason", "Dahilan", "Reason")) ?></strong><br><?= e(($deleteRequest["reason"] ?? "") !== "" ? $deleteRequest["reason"] : "--") ?></div>
                            <div><strong><?= e(msg("Review Note", "Review Note", "Review Note")) ?></strong><br><?= e(($deleteRequest["reviewNote"] ?? "") !== "" ? $deleteRequest["reviewNote"] : "--") ?></div>
                        </div>
                    <?php endif; ?>

                    <?php if ($canDirectDelete): ?>
                        <div class="notice">
                            <?= e(msg(
                                "You may permanently delete this record only within 5 minutes of creating it. After that, teacher approval is required.",
                                "Maaari mo lamang permanenteng burahin ang record na ito sa loob ng 5 minuto mula nang ginawa ito. Pagkatapos nito, kailangan ng approval ng guro.",
                                "You may permanently delete this record only within 5 minutes of creating it. After that, teacher approval is required."
                            )) ?>
                        </div>

                        <form method="POST" class="button-row record-delete-actions">
                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="recordId" value="<?= e($recordId) ?>">
                            <button class="btn btn-danger record-delete-btn" type="submit"><?= e(msg("Delete Permanently", "Permanenteng Tanggalin", "Delete Permanently")) ?></button>
                        </form>
                    <?php elseif ($canRequestDelete): ?>
                        <details class="record-delete-request">
                            <summary class="btn btn-outline"><?= e(msg("Request Deletion", "Humiling ng Pag-delete", "Request Deletion")) ?></summary>

                            <form method="POST" class="forms compact-request-form">
                                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="action" value="requestDelete">
                                <input type="hidden" name="recordId" value="<?= e($recordId) ?>">

                                <div class="field full">
                                    <label><?= e(msg("Reason for Deletion Request", "Dahilan ng Pag-delete Request", "Reason for Deletion Request")) ?></label>
                                    <textarea name="reason" maxlength="700" required></textarea>
                                </div>

                                <div class="button-row full">
                                    <button class="btn btn-primary" type="submit"><?= e(msg("Submit for Teacher Approval", "I-submit para sa Approval ng Guro", "Submit for Teacher Approval")) ?></button>
                                </div>
                            </form>
                        </details>
                    <?php else: ?>
                        <div class="notice">
                            <?= e($deleteRequestPending
                                ? msg(
                                    "Deletion request is pending teacher/admin review. Editing and additional deletion requests are temporarily disabled.",
                                    "Pending ang deletion request sa teacher/admin review. Pansamantalang naka-disable ang pag-edit at panibagong deletion request.",
                                    "Deletion request is pending teacher/admin review. Editing and additional deletion requests are temporarily disabled."
                                )
                                : msg(
                                    "This deletion request has already been approved.",
                                    "Na-approve na ang deletion request na ito.",
                                    "This deletion request has already been approved."
                                )) ?>
                        </div>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>

            <?php if (!count($assessmentRecords)): ?>
                <div class="compact-empty">
                    <strong><?= e(msg("No assessment entries yet", "Wala pang tala ng pagtataya", "No assessment entries yet")) ?></strong>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <section class="card clean-panel section-space compact-record-section" id="quarterly-summary">
        <div class="clean-panel-head">
            <div>
                <h2><?= e(msg("Computed Quarterly Summary", "Nakalkulang Buod ng Markahan", "Computed Quarterly Summary")) ?></h2>
            </div>
        </div>

        <div class="record-history-grid">
            <?php foreach ($quarterlySummaries as $summary): ?>
                <?php
                    $evaluated = evaluate_record($summary);
                    $guidanceOutput = $evaluated["guidanceOutput"] ?? ["status" => "", "advisory" => "", "guidance" => ""];
                    $writtenPercent = $evaluated["writtenWorksPercentage"] ?? $evaluated["writtenPercentage"] ?? $evaluated["writtenWorks"] ?? 0;
                    $performancePercent = $evaluated["performanceTasksPercentage"] ?? $evaluated["performancePercentage"] ?? $evaluated["performanceTasks"] ?? 0;
                    $assessmentPercent = $evaluated["quarterlyAssessmentPercentage"] ?? $evaluated["assessmentPercentage"] ?? $evaluated["quarterlyAssessment"] ?? 0;
                    $attendanceSummary = $evaluated["attendanceSummary"] ?? [];
                    $absenceRate = $evaluated["absenceRate"] ?? ($attendanceSummary["absenceRate"] ?? "--");
                    $consecutiveAbsences = $evaluated["consecutiveAbsences"] ?? ($attendanceSummary["consecutiveAbsences"] ?? "--");
                    $competencyStatus = $evaluated["competencyStatus"] ?? "No Record";
                ?>

                <article class="record-history-card compact-record-card" data-record-card data-record-mode="quarterly">
                    <div class="record-history-top">
                        <div>
                            <span><?= e(($evaluated["gradingPeriod"] ?? "--") . " · " . msg("Quarterly", "Markahan", "Quarterly")) ?></span>
                            <h3><?= e($evaluated["subject"] ?? "--") ?></h3>
                            <p><?= e(($evaluated["strand"] ?? "--") . " · " . ($evaluated["gradeLevel"] ?? "--")) ?></p>
                        </div>
                    </div>

                    <div class="record-score-row">
                        <div>
                            <small><?= e(msg("Grade", "Marka", "Grade")) ?></small>
                            <strong><?= e($evaluated["computedGrade"] ?? "--") ?></strong>
                        </div>
                        <div>
                            <small><?= e(msg("Mastery", "Mastery", "Mastery")) ?></small>
                            <strong><?= e(($evaluated["competencyMastery"] ?? 0) > 0 ? ($evaluated["competencyMastery"] . "%") : "--") ?></strong>
                        </div>
                        <div>
                            <small><?= e(msg("Absence", "Pagliban", "Absence")) ?></small>
                            <strong><?= e($absenceRate) ?>%</strong>
                        </div>
                    </div>

                    <div class="record-score-row">
                        <div>
                            <small><?= e(msg("Written", "Written", "Written")) ?></small>
                            <strong><?= e($writtenPercent) ?>%</strong>
                        </div>
                        <div>
                            <small><?= e(msg("Performance", "Performance", "Performance")) ?></small>
                            <strong><?= e($performancePercent) ?>%</strong>
                        </div>
                        <div>
                            <small><?= e(msg("Quarterly", "Markahan", "Quarterly")) ?></small>
                            <strong><?= e($assessmentPercent) ?>%</strong>
                        </div>
                    </div>

                    <div class="record-score-row">
                        <div>
                            <small><?= e(msg("Absence Streak", "Sunod-sunod na Pagliban", "Absence Streak")) ?></small>
                            <strong><?= e($consecutiveAbsences) ?></strong>
                        </div>
                        <div>
                            <small><?= e(msg("Records Used", "Tala na Ginamit", "Records Used")) ?></small>
                            <strong><?= e($evaluated["assessmentCount"] ?? $evaluated["recordsUsed"] ?? "--") ?></strong>
                        </div>
                        <div>
                            <small><?= e(msg("Mode", "Paraan", "Mode")) ?></small>
                            <strong><?= e(msg("Computed", "Nakalkula", "Computed")) ?></strong>
                        </div>
                    </div>

                    <div class="meta-row">
                        <?= badge($evaluated["academicStatus"] ?? "No Record") ?>
                        <?= badge($competencyStatus) ?>
                        <?= badge($evaluated["attendanceStatus"] ?? "No Record") ?>
                        <?= badge($evaluated["requirementStatus"] ?? "Complete Requirements") ?>
                        <?= badge($evaluated["trendStatus"] ?? "Insufficient Trend Data") ?>
                    </div>

                    <div class="record-guidance-strip compact-guidance">
                        <div><strong><?= e(msg("Status", "Kalagayan", "Status")) ?></strong><br><?= e($guidanceOutput["status"] ?? "") ?></div>
                        <div><strong><?= e(msg("Advisory", "Paalaala", "Advisory")) ?></strong><br><?= e($guidanceOutput["advisory"] ?? "") ?></div>
                        <div><strong><?= e(msg("Guidance", "Gabay", "Guidance")) ?></strong><br><?= e($guidanceOutput["guidance"] ?? "") ?></div>
                    </div>

                    <?php if (!empty($evaluated["missingRequirements"])): ?>
                        <div class="notice warning"><?= e(msg("Missing / Incomplete", "Kulang / Hindi Kumpleto", "Missing / Incomplete")) ?>: <?= e(implode(", ", $evaluated["missingRequirements"])) ?></div>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>

            <?php if (!count($quarterlySummaries)): ?>
                <div class="compact-empty">
                    <strong><?= e(msg("No computed quarterly summary yet", "Wala pang nakalkulang buod ng markahan", "No computed quarterly summary yet")) ?></strong>
                </div>
            <?php endif; ?>
        </div>
    </section>
</main>

<?php page_foot(); ?>