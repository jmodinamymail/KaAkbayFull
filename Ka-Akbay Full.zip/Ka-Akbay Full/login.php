<?php
require_once __DIR__ . "/app/security.php";
require_once __DIR__ . "/app/auth.php";
require_once __DIR__ . "/app/layout.php";

function login_security_email_delivery($type, $recipient, $token, $expiresAt, $userId = "") {
    $recipient = strtolower(trim((string)$recipient));
    $token = trim((string)$token);

    if ($recipient === "" || !filter_var($recipient, FILTER_VALIDATE_EMAIL) || $token === "") {
        return [
            "ok" => false,
            "sent" => false,
            "queued" => false,
            "message" => msg(
                "Unable to prepare the security email.",
                "Hindi maihanda ang security email.",
                "Unable to prepare the security email."
            )
        ];
    }

    $payload = [
        "type" => (string)$type,
        "recipient" => $recipient,
        "token" => $token,
        "expiresAt" => (string)$expiresAt,
        "userId" => (string)$userId,
        "createdAt" => date("c")
    ];

    if (function_exists("send_security_email_message")) {
        $delivery = send_security_email_message($payload);

        if (is_array($delivery)) {
            return array_merge(
                [
                    "ok" => false,
                    "sent" => false,
                    "queued" => false,
                    "message" => ""
                ],
                $delivery
            );
        }

        if ($delivery === true) {
            return [
                "ok" => true,
                "sent" => true,
                "queued" => false,
                "message" => ""
            ];
        }

        return [
            "ok" => false,
            "sent" => false,
            "queued" => false,
            "message" => msg(
                "The security email could not be sent.",
                "Hindi maipadala ang security email.",
                "The security email could not be sent."
            )
        ];
    }

    $_SESSION["pendingSecurityEmail"] = $payload;

    return [
        "ok" => true,
        "sent" => false,
        "queued" => true,
        "message" => msg(
            "Email delivery is not configured yet.",
            "Hindi pa naka-configure ang email delivery.",
            "Email delivery is not configured yet."
        )
    ];
}

function login_clear_authenticated_session($userId) {
    $userId = trim((string)$userId);
    $sessionToken = trim((string)($_SESSION["active_session_token"] ?? ""));

    if ($userId !== "" && function_exists("security_clear_active_session")) {
        security_clear_active_session($userId, $sessionToken);
    }

    if (function_exists("auth_clear_session")) {
        auth_clear_session();
        return;
    }

    unset(
        $_SESSION["user"],
        $_SESSION["active_session_token"],
        $_SESSION["last_activity"],
        $_SESSION["login_time"]
    );
}

function login_pending_privileged_user() {
    $pending = $_SESSION["pendingPrivilegedLogin"] ?? null;

    if (!is_array($pending)) {
        return null;
    }

    $userId = trim((string)($pending["userId"] ?? ""));
    $createdAt = (int)($pending["createdAt"] ?? 0);

    if ($userId === "" || $createdAt <= 0 || (time() - $createdAt) > 1800) {
        if ($userId !== "" && function_exists("clear_login_otp")) {
            clear_login_otp($userId);
        }

        unset($_SESSION["pendingPrivilegedLogin"]);
        return null;
    }

    $user = find_user_by_id($userId);

    if (
        !$user ||
        ($user["status"] ?? "Active") !== "Active" ||
        !privileged_role_requires_otp($user["role"] ?? "")
    ) {
        if ($userId !== "" && function_exists("clear_login_otp")) {
            clear_login_otp($userId);
        }

        unset($_SESSION["pendingPrivilegedLogin"]);
        return null;
    }

    return $user;
}

function login_pending_privileged_recovery_user() {
    $pending = $_SESSION["pendingPrivilegedRecoveryEnrollment"] ?? null;

    if (!is_array($pending)) {
        return null;
    }

    $userId = trim((string)($pending["userId"] ?? ""));
    $createdAt = (int)($pending["createdAt"] ?? 0);

    if ($userId === "" || $createdAt <= 0 || (time() - $createdAt) > 1800) {
        unset($_SESSION["pendingPrivilegedRecoveryEnrollment"]);
        return null;
    }

    $user = find_user_by_id($userId);

    if (
        !$user ||
        ($user["status"] ?? "Active") !== "Active" ||
        !privileged_role_requires_otp($user["role"] ?? "") ||
        verified_recovery_email($user) !== ""
    ) {
        unset($_SESSION["pendingPrivilegedRecoveryEnrollment"]);
        return null;
    }

    return $user;
}


function login_complete_privileged_session($userId) {
    $userId = trim((string)$userId);
    $user = find_user_by_id($userId);

    if (
        !$user ||
        ($user["status"] ?? "Active") !== "Active" ||
        !privileged_role_requires_otp($user["role"] ?? "")
    ) {
        return false;
    }

    if (
        function_exists("maintenance_is_active") &&
        maintenance_is_active() &&
        !in_array($user["role"] ?? "", ["super_admin", "it_admin"], true)
    ) {
        return false;
    }

    try {
        $sessionToken = function_exists("auth_create_session_token")
            ? auth_create_session_token()
            : bin2hex(random_bytes(32));
    } catch (Throwable $e) {
        return false;
    }

    if (function_exists("security_register_active_session")) {
        if (!security_register_active_session($userId, $sessionToken)) {
            return false;
        }
    } else {
        $user["activeSessionHash"] = hash("sha256", $sessionToken);
        $user["lastLoginAt"] = date("c");
        $user["updatedAt"] = date("c");

        if (!update_record_by_id("users", $userId, $user)) {
            return false;
        }

        $user = find_user_by_id($userId);

        if (!$user) {
            return false;
        }
    }

    session_regenerate_id(true);

    $_SESSION["active_session_token"] = $sessionToken;
    $_SESSION["last_activity"] = time();
    $_SESSION["login_time"] = time();
    $_SESSION["user"] = [
        "id" => $user["id"],
        "code" => $user["code"] ?? "",
        "name" => $user["name"] ?? "",
        "email" => $user["email"] ?? "",
        "role" => $user["role"] ?? "",
        "strand" => $user["strand"] ?? "",
        "section" => $user["section"] ?? "",
        "gradeLevel" => $user["gradeLevel"] ?? "",
        "teacherId" => $user["teacherId"] ?? "",
        "managedSections" => $user["managedSections"] ?? "",
        "mustChangePassword" => !empty($user["mustChangePassword"])
    ];

    if (function_exists("audit_log")) {
        audit_log(
            $userId,
            "LOGIN_OTP_COMPLETED",
            "Privileged sign-in completed after one-time code verification.",
            ["category" => "security"]
        );
    }

    return true;
}

function login_begin_privileged_otp($user) {
    $userId = trim((string)($user["id"] ?? ""));

    if ($userId === "") {
        return [
            "ok" => false,
            "message" => msg(
                "Unable to continue sign-in.",
                "Hindi maipagpatuloy ang sign-in.",
                "Unable to continue sign-in."
            )
        ];
    }

    $deliveryEmail = verified_recovery_email($userId);

    if ($deliveryEmail === "") {
        if (function_exists("audit_log")) {
            audit_log(
                $userId,
                "PRIVILEGED_LOGIN_RECOVERY_REQUIRED",
                "Privileged login could not continue because no verified recovery email is configured.",
                ["category" => "security"]
            );
        }

        return [
            "ok" => false,
            "message" => msg(
                "This privileged account needs a verified recovery email before OTP sign-in can continue.",
                "Kailangan ng verified recovery email ng privileged account na ito bago magpatuloy ang OTP sign-in.",
                "This privileged account needs a verified recovery email before OTP sign-in can continue."
            )
        ];
    }

    $otp = create_login_otp($userId, "privileged_login");

    if (empty($otp["ok"])) {
        return [
            "ok" => false,
            "message" => (string)($otp["message"] ?? msg(
                "Unable to create the verification code.",
                "Hindi makagawa ng verification code.",
                "Unable to create the verification code."
            ))
        ];
    }

    $delivery = login_security_email_delivery(
        "privileged_login_otp",
        $deliveryEmail,
        $otp["code"] ?? "",
        $otp["expiresAt"] ?? "",
        $userId
    );

    if (empty($delivery["sent"])) {
        clear_login_otp($userId, true);

        if (function_exists("audit_log")) {
            audit_log(
                $userId,
                "OTP_DELIVERY_FAILED",
                "Privileged login OTP could not be delivered.",
                ["category" => "security"]
            );
        }

        return [
            "ok" => false,
            "message" => !empty($delivery["queued"])
                ? msg(
                    "OTP email delivery is not configured yet. Privileged sign-in cannot continue until Hostinger SMTP is configured.",
                    "Hindi pa naka-configure ang OTP email delivery. Hindi makakapagpatuloy ang privileged sign-in hanggang ma-configure ang Hostinger SMTP.",
                    "OTP email delivery is not configured yet. Privileged sign-in cannot continue until Hostinger SMTP is configured."
                )
                : msg(
                    "The verification code could not be delivered. Please try again.",
                    "Hindi maipadala ang verification code. Subukan muli.",
                    "The verification code could not be delivered. Please try again."
                )
        ];
    }

    return [
        "ok" => true,
        "maskedEmail" => mask_email_address($deliveryEmail),
        "expiresAt" => (string)($otp["expiresAt"] ?? "")
    ];
}

$allowedModes = [
    "login",
    "forgot",
    "reset",
    "otp",
    "recoverySetup",
    "verifyRecovery"
];

$mode = trim((string)($_GET["mode"] ?? $_POST["mode"] ?? "login"));

if (!in_array($mode, $allowedModes, true)) {
    $mode = "login";
}

if ($mode === "reset" && isset($_GET["token"])) {
    $incomingToken = trim((string)$_GET["token"]);

    if ($incomingToken !== "" && validate_password_reset_token($incomingToken)) {
        $_SESSION["passwordResetToken"] = $incomingToken;
    } else {
        unset($_SESSION["passwordResetToken"]);
        $_SESSION["loginFlashError"] = msg(
            "This password reset link is invalid or expired.",
            "Invalid o expired na ang password reset link.",
            "This password reset link is invalid or expired."
        );
    }

    header("Location: login.php?mode=reset");
    exit;
}

if ($mode === "verifyRecovery" && isset($_GET["token"])) {
    $wasPrivilegedRecoveryEnrollment = is_array($_SESSION["pendingPrivilegedRecoveryEnrollment"] ?? null);
    $result = confirm_recovery_email($_GET["token"] ?? "");

    if (!empty($result["ok"])) {
        unset($_SESSION["pendingPrivilegedRecoveryEnrollment"]);

        $_SESSION["loginFlashNotice"] = $wasPrivilegedRecoveryEnrollment
            ? msg(
                "Recovery email verified successfully. Sign in again to continue.",
                "Matagumpay na na-verify ang recovery email. Mag-sign in muli para magpatuloy.",
                "Recovery email verified successfully. Sign in again to continue."
            )
            : (string)$result["message"];
    } else {
        $_SESSION["loginFlashError"] = (string)($result["message"] ?? "");
    }

    header("Location: login.php");
    exit;
}

if ($mode === "verifyRecovery") {
    header("Location: login.php");
    exit;
}

if ($mode !== "otp" && current_user()) {
    header("Location: dashboard.php");
    exit;
}

if ($mode === "otp" && !login_pending_privileged_user()) {
    $_SESSION["loginFlashError"] = msg(
        "The verification session expired. Sign in again.",
        "Expired na ang verification session. Mag-sign in muli.",
        "The verification session expired. Sign in again."
    );

    header("Location: login.php");
    exit;
}

if ($mode === "recoverySetup" && !login_pending_privileged_recovery_user()) {
    $_SESSION["loginFlashError"] = msg(
        "The recovery email setup session expired. Sign in again.",
        "Expired na ang recovery email setup session. Mag-sign in muli.",
        "The recovery email setup session expired. Sign in again."
    );

    header("Location: login.php");
    exit;
}

$settings = function_exists("system_settings_record")
    ? system_settings_record()
    : [];

$loginContent = function_exists("system_content_record")
    ? system_content_record("login_welcome")
    : [];

$footerContent = function_exists("system_content_record")
    ? system_content_record("footer")
    : [];

$systemName = trim((string)($settings["systemName"] ?? "Ka-Akbay"));

if ($systemName === "") {
    $systemName = "Ka-Akbay";
}

$logoUrl = trim((string)($settings["logoUrl"] ?? ""));
$loginContentActive = ($loginContent["isActive"] ?? true) ? true : false;
$loginTitle = trim((string)($loginContent["title"] ?? ""));
$loginMessage = trim((string)($loginContent["content"] ?? ""));

$footerContentActive = ($footerContent["isActive"] ?? true) ? true : false;
$footerText = trim((string)($footerContent["content"] ?? ""));

$error = (string)($_SESSION["loginFlashError"] ?? "");
$notice = (string)($_SESSION["loginFlashNotice"] ?? "");
$submittedEmail = "";

unset(
    $_SESSION["loginFlashError"],
    $_SESSION["loginFlashNotice"]
);

if (isset($_GET["passwordReset"]) && $_GET["passwordReset"] === "1") {
    $notice = msg(
        "Password reset successfully. You can now sign in.",
        "Matagumpay na na-reset ang password. Maaari ka nang mag-sign in.",
        "Password reset successfully. You can now sign in."
    );
}

if (isset($_GET["recoveryEmailVerified"]) && $_GET["recoveryEmailVerified"] === "1") {
    $notice = msg(
        "Recovery email verified successfully.",
        "Matagumpay na na-verify ang recovery email.",
        "Recovery email verified successfully."
    );
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = trim((string)($_POST["action"] ?? ""));

    if (!verify_csrf($_POST["csrf_token"] ?? "")) {
        $error = msg(
            "Invalid security token.",
            "Hindi wasto ang security token.",
            "Invalid ang security token."
        );
    } elseif ($action === "login") {
        $mode = "login";
        $submittedEmail = strtolower(trim((string)($_POST["email"] ?? "")));

        if (($_POST["terms_agree"] ?? "") !== "1") {
            $error = msg(
                "You must read and agree to the Terms of Use and Privacy Notice before logging in.",
                "Kailangan mong basahin at sang-ayunan ang Terms of Use and Privacy Notice bago mag-login.",
                "You must read and agree to the Terms of Use and Privacy Notice before logging in."
            );
        } else {
            $loginReason = "";

            if (login_user($submittedEmail, $_POST["password"] ?? "", $loginReason)) {
                $loggedUser = current_user();

                if (!$loggedUser) {
                    $error = msg(
                        "Unable to complete sign-in.",
                        "Hindi makumpleto ang sign-in.",
                        "Unable to complete sign-in."
                    );
                } elseif (privileged_role_requires_otp($loggedUser["role"] ?? "")) {
                    $userId = (string)($loggedUser["id"] ?? "");
                    $mustChangePassword = !empty($loggedUser["mustChangePassword"]);
                    $recoveryEmail = verified_recovery_email($userId);

                    if ($recoveryEmail === "") {
                        if (function_exists("audit_log")) {
                            audit_log(
                                $userId,
                                "PRIVILEGED_RECOVERY_ENROLLMENT_REQUIRED",
                                "Privileged sign-in requires first-time verified recovery email enrollment.",
                                ["category" => "security"]
                            );
                        }

                        login_clear_authenticated_session($userId);

                        unset($_SESSION["pendingPrivilegedLogin"]);

                        $_SESSION["pendingPrivilegedRecoveryEnrollment"] = [
                            "userId" => $userId,
                            "mustChangePassword" => $mustChangePassword,
                            "createdAt" => time()
                        ];

                        header("Location: login.php?mode=recoverySetup");
                        exit;
                    }

                    $otpResult = login_begin_privileged_otp($loggedUser);

                    if (empty($otpResult["ok"])) {
                        login_clear_authenticated_session($userId);
                        $error = (string)($otpResult["message"] ?? "");
                    } else {
                        login_clear_authenticated_session($userId);

                        unset($_SESSION["pendingPrivilegedRecoveryEnrollment"]);

                        $_SESSION["pendingPrivilegedLogin"] = [
                            "userId" => $userId,
                            "maskedEmail" => (string)($otpResult["maskedEmail"] ?? ""),
                            "expiresAt" => (string)($otpResult["expiresAt"] ?? ""),
                            "mustChangePassword" => $mustChangePassword,
                            "createdAt" => time()
                        ];

                        header("Location: login.php?mode=otp");
                        exit;
                    }
                } elseif (!empty($loggedUser["mustChangePassword"])) {
                    header("Location: profile.php?forcePasswordChange=1");
                    exit;
                } else {
                    header("Location: dashboard.php");
                    exit;
                }
            } elseif ($loginReason === "inactive") {
                $error = msg(
                    "This account has been deactivated. Please contact the administrator.",
                    "Na-deactivate ang account na ito. Makipag-ugnayan sa administrator.",
                    "This account has been deactivated. Please contact the administrator."
                );
            } elseif ($loginReason === "maintenance") {
                $error = msg(
                    "The system is currently under maintenance. Please try again later.",
                    "Kasalukuyang nasa maintenance ang system. Subukan muli mamaya.",
                    "The system is currently under maintenance. Please try again later."
                );
            } elseif ($loginReason === "locked") {
                $lockedUser = find_user_by_email($submittedEmail);
                $lockoutState = $lockedUser
                    ? security_login_lockout_state($lockedUser)
                    : [
                        "secondsRemaining" => 0
                    ];

                $minutesRemaining = max(
                    1,
                    (int)ceil(((int)($lockoutState["secondsRemaining"] ?? 0)) / 60)
                );

                $error = msg(
                    "Too many failed sign-in attempts. Try again in about " . $minutesRemaining . " minute(s).",
                    "Masyadong maraming maling sign-in attempts. Subukan muli pagkalipas ng humigit-kumulang " . $minutesRemaining . " minuto.",
                    "Too many failed sign-in attempts. Try again in about " . $minutesRemaining . " minute(s)."
                );
            } elseif ($loginReason === "error") {
                $error = msg(
                    "Unable to complete sign-in. Please try again.",
                    "Hindi makumpleto ang sign-in. Subukan muli.",
                    "Unable to complete sign-in. Please try again."
                );
            } else {
                $error = msg(
                    "Invalid email or password.",
                    "Mali ang email o password.",
                    "Invalid email or password."
                );
            }
        }
    } elseif ($action === "setupPrivilegedRecovery") {
        $mode = "recoverySetup";
        $pendingUser = login_pending_privileged_recovery_user();

        if (!$pendingUser) {
            $error = msg(
                "The recovery email setup session expired. Sign in again.",
                "Expired na ang recovery email setup session. Mag-sign in muli.",
                "The recovery email setup session expired. Sign in again."
            );
        } else {
            $userId = (string)($pendingUser["id"] ?? "");
            $result = begin_privileged_recovery_enrollment(
                $userId,
                $_POST["recoveryEmail"] ?? ""
            );

            if (empty($result["ok"])) {
                $error = (string)($result["message"] ?? "");
            } else {
                $delivery = login_security_email_delivery(
                    "recovery_email_verification",
                    $result["email"] ?? "",
                    $result["token"] ?? "",
                    $result["expiresAt"] ?? "",
                    $userId
                );

                if (empty($delivery["sent"])) {
                    cancel_pending_recovery_email($userId);

                    $error = !empty($delivery["queued"])
                        ? msg(
                            "Recovery email delivery is not configured yet.",
                            "Hindi pa naka-configure ang recovery email delivery.",
                            "Recovery email delivery is not configured yet."
                        )
                        : msg(
                            "The recovery email verification message could not be delivered. Please try again.",
                            "Hindi maipadala ang recovery email verification message. Subukan muli.",
                            "The recovery email verification message could not be delivered. Please try again."
                        );
                } else {
                    $_SESSION["pendingPrivilegedRecoveryEnrollment"]["createdAt"] = time();

                    $notice = msg(
                        "Verification sent to " . (string)($result["maskedEmail"] ?? "") . ". Open the verification link, then sign in again. If you do not see the email in your inbox, check your Spam or Junk folder.",
                        "Naipadala ang verification sa " . (string)($result["maskedEmail"] ?? "") . ". Buksan ang verification link, pagkatapos ay mag-sign in muli. Kung wala ito sa inbox, tingnan ang Spam o Junk folder.",
                        "Verification sent to " . (string)($result["maskedEmail"] ?? "") . ". Open the verification link, then sign in again. If wala sa inbox, check your Spam or Junk folder."
                    );
                }
            }
        }

    } elseif ($action === "requestPasswordReset") {
        $mode = "forgot";
        $submittedEmail = strtolower(trim((string)($_POST["email"] ?? "")));
        $result = request_password_reset($submittedEmail);

        if (empty($result["ok"])) {
            $error = msg(
                "Unable to process the recovery request. Please try again.",
                "Hindi ma-process ang recovery request. Subukan muli.",
                "Unable to process the recovery request. Please try again."
            );
        } elseif (!empty($result["throttled"])) {
            $retryAfter = max(1, (int)($result["retryAfter"] ?? 1));
            $retryText = function_exists("security_retry_text")
                ? security_retry_text($retryAfter)
                : ($retryAfter >= 60
                    ? (int)ceil($retryAfter / 60) . " minute(s)"
                    : $retryAfter . " second(s)");

            $error = msg(
                "Too many password recovery requests. Please wait " . $retryText . " before trying again.",
                "Masyadong maraming password recovery request. Maghintay ng " . $retryText . " bago subukan muli.",
                "Too many password recovery requests. Please wait " . $retryText . " before trying again."
            );
        } else {
            if (!empty($result["recoveryAvailable"])) {
                $delivery = login_security_email_delivery(
                    "password_reset",
                    $result["deliveryEmail"] ?? $result["email"] ?? "",
                    $result["token"] ?? "",
                    $result["expiresAt"] ?? "",
                    $result["userId"] ?? ""
                );

                if (empty($delivery["sent"]) && function_exists("audit_log")) {
                    audit_log(
                        (string)($result["userId"] ?? ""),
                        "PASSWORD_RESET_DELIVERY_PENDING",
                        !empty($delivery["queued"])
                            ? "Password reset email is waiting for mail service configuration."
                            : "Password reset email delivery failed.",
                        ["category" => "security"]
                    );
                }
            }

            if (function_exists("send_security_email_message")) {
                $notice = msg(
                    "If an eligible active account matches that login email, password recovery instructions have been sent to its verified recovery email. If you do not see the email in your inbox, check your Spam or Junk folder.",
                    "Kung may eligible na aktibong account na tumutugma sa login email, naipadala ang password recovery instructions sa verified recovery email nito. Kung wala ito sa inbox, tingnan ang Spam o Junk folder.",
                    "If an eligible active account matches that login email, password recovery instructions have been sent to its verified recovery email. If wala sa inbox, check your Spam or Junk folder."
                );
            } else {
                $notice = msg(
                    "The password recovery request was accepted, but email delivery is not configured on this installation yet.",
                    "Tinanggap ang password recovery request, pero hindi pa naka-configure ang email delivery sa installation na ito.",
                    "The password recovery request was accepted, but email delivery is not configured on this installation yet."
                );
            }
        }
    } elseif ($action === "resetPassword") {
        $mode = "reset";
        $resetToken = trim((string)($_SESSION["passwordResetToken"] ?? ""));

        if ($resetToken === "" || !validate_password_reset_token($resetToken)) {
            unset($_SESSION["passwordResetToken"]);

            $error = msg(
                "This password reset link is invalid or expired.",
                "Invalid o expired na ang password reset link.",
                "This password reset link is invalid or expired."
            );
        } else {
            $result = reset_password_with_token(
                $resetToken,
                $_POST["newPassword"] ?? "",
                $_POST["confirmPassword"] ?? ""
            );

            if (!empty($result["ok"])) {
                unset(
                    $_SESSION["passwordResetToken"],
                    $_SESSION["pendingPrivilegedLogin"],
                    $_SESSION["pendingPrivilegedRecoveryEnrollment"]
                );

                $_SESSION["loginFlashNotice"] = (string)$result["message"];

                header("Location: login.php?passwordReset=1");
                exit;
            }

            $error = (string)($result["message"] ?? "");
        }
    } elseif ($action === "verifyOtp") {
        $mode = "otp";
        $pendingUser = login_pending_privileged_user();

        if (!$pendingUser) {
            $error = msg(
                "The verification session expired. Sign in again.",
                "Expired na ang verification session. Mag-sign in muli.",
                "The verification session expired. Sign in again."
            );
        } else {
            $userId = (string)$pendingUser["id"];
            $code = preg_replace('/\D+/', '', (string)($_POST["otp"] ?? ""));

            if (strlen($code) !== 6) {
                $error = msg(
                    "Enter the complete 6-digit authentication code.",
                    "Ilagay ang kumpletong 6-digit authentication code.",
                    "Enter the complete 6-digit authentication code."
                );
            } elseif (!validate_login_otp($userId, $code, "privileged_login")) {
                $otpState = function_exists("privileged_otp_security_state")
                    ? privileged_otp_security_state($userId)
                    : [];

                if (!empty($otpState["locked"])) {
                    unset($_SESSION["pendingPrivilegedLogin"]);

                    $retryAfter = max(1, (int)($otpState["secondsRemaining"] ?? 0));

                    $_SESSION["loginFlashError"] = msg(
                        "Too many incorrect authentication codes were entered. Privileged sign-in has been temporarily locked. Sign in again after " . security_retry_text($retryAfter) . ".",
                        "Masyadong maraming maling authentication code ang nailagay. Pansamantalang naka-lock ang privileged sign-in. Mag-sign in muli pagkatapos ng " . security_retry_text($retryAfter) . ".",
                        "Too many incorrect authentication codes were entered. Privileged sign-in has been temporarily locked. Sign in again after " . security_retry_text($retryAfter) . "."
                    );

                    header("Location: login.php");
                    exit;
                }

                $remainingAttempts = max(
                    0,
                    (int)($otpState["remainingAttempts"] ?? privileged_otp_max_failures())
                );

                $error = $remainingAttempts > 0
                    ? msg(
                        "The authentication code is incorrect or expired. " . $remainingAttempts . " verification attempt(s) remain.",
                        "Mali o expired ang authentication code. May " . $remainingAttempts . " verification attempt(s) pang natitira.",
                        "The authentication code is incorrect or expired. " . $remainingAttempts . " verification attempt(s) remain."
                    )
                    : msg(
                        "The authentication code is invalid or expired.",
                        "Invalid o expired na ang authentication code.",
                        "The authentication code is invalid or expired."
                    );
            } elseif (!login_complete_privileged_session($userId)) {
                unset($_SESSION["pendingPrivilegedLogin"]);

                $error = msg(
                    "Unable to complete sign-in. Please sign in again.",
                    "Hindi makumpleto ang sign-in. Mag-sign in muli.",
                    "Unable to complete sign-in. Please sign in again."
                );
            } else {
                $mustChangePassword = !empty($_SESSION["pendingPrivilegedLogin"]["mustChangePassword"]);

                unset(
                    $_SESSION["pendingPrivilegedLogin"],
                    $_SESSION["pendingPrivilegedRecoveryEnrollment"]
                );

                if ($mustChangePassword) {
                    header("Location: profile.php?forcePasswordChange=1");
                    exit;
                }

                header("Location: dashboard.php");
                exit;
            }
        }
    } elseif ($action === "resendOtp") {
        $mode = "otp";
        $pendingUser = login_pending_privileged_user();

        if (!$pendingUser) {
            $error = msg(
                "The verification session expired. Sign in again.",
                "Expired na ang verification session. Mag-sign in muli.",
                "The verification session expired. Sign in again."
            );
        } else {
            $userId = (string)$pendingUser["id"];
            $deliveryEmail = verified_recovery_email($userId);

            if ($deliveryEmail === "") {
                unset($_SESSION["pendingPrivilegedLogin"]);

                $error = msg(
                    "A verified recovery email is required for this privileged account.",
                    "Kailangan ng verified recovery email para sa privileged account na ito.",
                    "A verified recovery email is required for this privileged account."
                );
            } else {
                $otp = create_login_otp($userId, "privileged_login");

                if (empty($otp["ok"])) {
                    if (!empty($otp["locked"])) {
                        unset($_SESSION["pendingPrivilegedLogin"]);

                        $_SESSION["loginFlashError"] = (string)($otp["message"] ?? msg(
                            "Privileged sign-in is temporarily locked. Sign in again after the lockout expires.",
                            "Pansamantalang naka-lock ang privileged sign-in. Mag-sign in muli kapag tapos na ang lockout.",
                            "Privileged sign-in is temporarily locked. Sign in again after the lockout expires."
                        ));

                        header("Location: login.php");
                        exit;
                    }

                    $error = (string)($otp["message"] ?? "");
                } else {
                    $delivery = login_security_email_delivery(
                        "privileged_login_otp",
                        $deliveryEmail,
                        $otp["code"] ?? "",
                        $otp["expiresAt"] ?? "",
                        $userId
                    );

                    if (empty($delivery["sent"])) {
                        clear_login_otp($userId, true);

                        $error = !empty($delivery["queued"])
                            ? msg(
                                "OTP email delivery is not configured yet.",
                                "Hindi pa naka-configure ang OTP email delivery.",
                                "OTP email delivery is not configured yet."
                            )
                            : msg(
                                "The verification code could not be delivered. Please try again.",
                                "Hindi maipadala ang verification code. Subukan muli.",
                                "The verification code could not be delivered. Please try again."
                            );
                    } else {
                        $_SESSION["pendingPrivilegedLogin"]["maskedEmail"] = mask_email_address($deliveryEmail);
                        $_SESSION["pendingPrivilegedLogin"]["expiresAt"] = (string)($otp["expiresAt"] ?? "");

                        $notice = msg(
                            "A new verification code was sent. If you do not see it in your inbox, check your Spam or Junk folder.",
                            "Nagpadala ng bagong verification code. Kung wala ito sa inbox, tingnan ang Spam o Junk folder.",
                            "A new verification code was sent. If wala sa inbox, check your Spam or Junk folder."
                        );
                    }
                }
            }
        }
    }
}

$resetTokenAvailable = $mode === "reset"
    && !empty($_SESSION["passwordResetToken"])
    && validate_password_reset_token($_SESSION["passwordResetToken"]);

if ($mode === "reset" && !$resetTokenAvailable && $error === "") {
    $error = msg(
        "This password reset link is invalid or expired.",
        "Invalid o expired na ang password reset link.",
        "This password reset link is invalid or expired."
    );
}

$pendingOtp = $mode === "otp"
    ? ($_SESSION["pendingPrivilegedLogin"] ?? [])
    : [];

$pendingOtpUser = $mode === "otp"
    ? login_pending_privileged_user()
    : null;

$pendingRecoveryUser = $mode === "recoverySetup"
    ? login_pending_privileged_recovery_user()
    : null;

$pendingOtpRoleLabel = is_array($pendingOtpUser)
    ? (function_exists("role_label")
        ? role_label($pendingOtpUser["role"] ?? "")
        : ucwords(str_replace("_", " ", (string)($pendingOtpUser["role"] ?? "Privileged Account"))))
    : msg("Privileged Account", "Privileged Account", "Privileged Account");

$pendingRecoveryRoleLabel = is_array($pendingRecoveryUser)
    ? (function_exists("role_label")
        ? role_label($pendingRecoveryUser["role"] ?? "")
        : ucwords(str_replace("_", " ", (string)($pendingRecoveryUser["role"] ?? "Privileged Account"))))
    : msg("Privileged Account", "Privileged Account", "Privileged Account");

$pendingOtpSecurityState = is_array($pendingOtpUser) && function_exists("privileged_otp_security_state")
    ? privileged_otp_security_state($pendingOtpUser)
    : [];

$otpResendRetryAfter = max(
    0,
    (int)($pendingOtpSecurityState["sendRetryAfter"] ?? 0)
);

$otpRemainingAttempts = max(
    0,
    (int)($pendingOtpSecurityState["remainingAttempts"] ?? 0)
);

page_head(msg("Login", "Login", "Login"), false);
?>

<div class="preload-screen" id="preloadScreen">
    <div class="preload-hero">
        <h1><?= e($systemName) ?></h1>

        <div class="preload-line">
            <span></span>
        </div>
    </div>
</div>

<main class="minimal-login-page">
    <div class="login-blob blob-one"></div>
    <div class="login-blob blob-two"></div>
    <div class="login-blob blob-three"></div>

    <section class="minimal-login-card page-enter">
        <div class="minimal-login-brand">
            <?php if ($logoUrl !== ""): ?>
                <img
                    src="<?= e($logoUrl) ?>"
                    alt="<?= e($systemName) ?>"
                    class="brand-logo"
                >
            <?php endif; ?>

            <h1><?= e($systemName) ?></h1>

            <?php if ($loginContentActive && ($loginTitle !== "" || $loginMessage !== "")): ?>
                <p>
                    <?php if ($loginTitle !== ""): ?>
                        <strong><?= e($loginTitle) ?></strong>
                    <?php endif; ?>

                    <?php if ($loginTitle !== "" && $loginMessage !== ""): ?>
                        <br>
                    <?php endif; ?>

                    <?php if ($loginMessage !== ""): ?>
                        <?= e($loginMessage) ?>
                    <?php endif; ?>
                </p>
            <?php else: ?>
                <p>
                    <?= e(msg(
                        "Grade Evaluation Decision Support",
                        "Decision Support para sa Grade Evaluation",
                        "Grade Evaluation Decision Support"
                    )) ?>
                </p>
            <?php endif; ?>
        </div>

        <?php if ($error !== ""): ?>
            <div class="login-error error show message-dismissible" role="alert" data-dismissible-message>
                <span class="message-copy"><?= e($error) ?></span>
                <button type="button" class="message-dismiss" data-message-dismiss aria-label="<?= e(msg("Dismiss message", "Isara ang mensahe", "Dismiss message")) ?>">×</button>
            </div>
        <?php endif; ?>

        <?php if ($notice !== ""): ?>
            <div class="login-notice message-dismissible" role="status" data-dismissible-message>
                <span class="message-copy"><?= e($notice) ?></span>
                <button type="button" class="message-dismiss" data-message-dismiss aria-label="<?= e(msg("Dismiss message", "Isara ang mensahe", "Dismiss message")) ?>">×</button>
            </div>
        <?php endif; ?>

        <?php if ($mode === "login"): ?>
            <form
                method="POST"
                class="minimal-login-form"
                autocomplete="on"
                id="loginForm"
                data-login-form
            >
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e(csrf_token()) ?>"
                >

                <input
                    type="hidden"
                    name="action"
                    value="login"
                >

                <input
                    type="hidden"
                    name="mode"
                    value="login"
                >

                <div class="minimal-input">
                    <span>@</span>

                    <input
                        type="email"
                        name="email"
                        value="<?= e($submittedEmail) ?>"
                        placeholder="<?= e(msg("EMAIL", "EMAIL", "EMAIL")) ?>"
                        autocomplete="email"
                        maxlength="254"
                        required
                    >
                </div>

                <div class="minimal-input password-input-wrap">
                    <span>□</span>

                    <input
                        type="password"
                        name="password"
                        id="loginPassword"
                        placeholder="<?= e(msg("PASSWORD", "PASSWORD", "PASSWORD")) ?>"
                        autocomplete="current-password"
                        required
                    >

                    <button
                        type="button"
                        class="password-visibility-toggle"
                        data-password-toggle
                        data-password-target="loginPassword"
                        aria-label="<?= e(msg("Show password", "Ipakita ang password", "Show password")) ?>"
                        aria-pressed="false"
                    >
                        <svg
                            class="password-eye-icon"
                            viewBox="0 0 24 24"
                            aria-hidden="true"
                            focusable="false"
                        >
                            <path
                                d="M2.25 12s3.5-6 9.75-6 9.75 6 9.75 6-3.5 6-9.75 6S2.25 12 2.25 12Z"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.8"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                            />
                            <circle
                                cx="12"
                                cy="12"
                                r="2.75"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.8"
                            />
                        </svg>
                    </button>
                </div>

                <p class="assigned-account-text">
                    <a href="login.php?mode=forgot">
                        <?= e(msg(
                            "Forgot password?",
                            "Nakalimutan ang password?",
                            "Forgot password?"
                        )) ?>
                    </a>
                </p>

            <div class="terms-login-section">
                <div class="terms-login-title">
                    Ka-Akbay Terms of Use and Privacy Notice
                </div>

                <div
                    class="terms-login-scroll"
                    id="termsScroll"
                    tabindex="0"
                >
                    <h3>1. Acceptance of Terms</h3>

                    <p>
                        By logging in to, accessing, or using Ka-Akbay (the “System”), the user acknowledges that they have read, understood, and agreed to be bound by these Terms of Use and Privacy Notice. If the user does not agree with these terms or does not consent to the processing of personal information where consent is required, the user must discontinue use of the System.
                    </p>

                    <p>
                        Use of Ka-Akbay is subject to applicable Philippine laws and regulations, including Republic Act No. 10173, otherwise known as the Data Privacy Act of 2012, its Implementing Rules and Regulations, and applicable issuances of the National Privacy Commission.
                    </p>

                    <h3>2. Nature and Purpose of the System</h3>

                    <p>
                        Ka-Akbay is an undergraduate thesis prototype developed for educational, research, testing, and demonstration purposes. The System is designed to assist Senior High School students in monitoring their academic workload and related academic information. It processes authorized and user-provided information to generate workload indicators, academic risk classifications, competency information, attendance summaries, task priorities, and advisory recommendations.
                    </p>

                    <p>
                        Ka-Akbay is a decision-support system and shall not be considered an official school information system, learning management system, grading system, or replacement for the professional judgment of teachers, school administrators, guidance personnel, or other authorized educational personnel. Unless expressly authorized by an educational institution, information stored or generated by Ka-Akbay shall not constitute an official academic record.
                    </p>

                    <h3>3. User Accounts and Access</h3>

                    <p>
                        Ka-Akbay does not provide public or self-service account registration. User accounts are created, assigned, managed, and, when necessary, deactivated by authorized administrators of the System. Access privileges are determined according to the role assigned to each user. System roles may include Student, Teacher, Administrator, Super Administrator, and IT Administrator.
                    </p>

                    <p>
                        Users are responsible for keeping their assigned login credentials confidential, using only the account assigned to them, refraining from sharing credentials with unauthorized individuals, reporting suspected unauthorized access or account misuse to an authorized administrator, and accessing only information and functions permitted by their assigned role.
                    </p>

                    <p>
                        Users shall not impersonate another user, attempt to obtain unauthorized privileges, access another person's account, bypass System restrictions, or interfere with the normal operation of Ka-Akbay.
                    </p>

                    <h3>4. Academic Decision-Support Outputs</h3>

                    <p>
                        Ka-Akbay may process academic and workload information using predefined rules, calculations, classifications, and analytical procedures. System-generated outputs may include academic status indicators, workload measurements, academic risk classifications, competency information, attendance summaries, and recommendations concerning scheduling, prioritization, workload distribution, and rest.
                    </p>

                    <p>
                        These outputs are intended solely to provide supplementary decision support. System-generated classifications and recommendations shall not be treated as final academic decisions and shall not automatically determine grades, academic standing, disciplinary action, promotion, retention, or other official institutional decisions. Authorized teachers and school personnel remain responsible for exercising appropriate academic and professional judgment.
                    </p>

                    <h3>5. Accuracy of Information</h3>

                    <p>
                        The reliability of Ka-Akbay's outputs depends on the accuracy, completeness, and timeliness of the information entered into the System. Users who are authorized to enter or update information are responsible for ensuring, to the best of their knowledge, that such information is accurate.
                    </p>

                    <p>
                        Incorrect, incomplete, outdated, or improperly entered information may affect workload calculations, classifications, forecasts, recommendations, and other generated results.
                    </p>

                    <h3>6. Information Collected and Processed</h3>

                    <p>
                        Depending on the user's assigned role and use of the System, Ka-Akbay may process information such as the user's name, assigned account information, email address, user role, grade level, strand, section, subject information, academic assessments and scores, competency-related information, attendance records, tasks, task completion information, task difficulty, estimated duration, deadlines, schedules, academic workload information, teacher validations and reviews, System-generated workload measurements, academic risk classifications, recommendations, login activity, audit records, security logs, and technical activity records.
                    </p>

                    <p>
                        The System shall collect and process only information reasonably necessary for its educational, research, administrative, and technical purposes.
                    </p>

                    <h3>7. Purpose of Data Processing</h3>

                    <p>
                        Information processed through Ka-Akbay may be used for user authentication, account administration, academic workload monitoring, academic risk classification and forecasting, task and schedule management, attendance monitoring, competency monitoring, generation of academic decision-support information, teacher validation and review, student academic monitoring, administrative management of System users, technical troubleshooting, maintenance, security monitoring, audit logging, backup and recovery, and evaluation of the functionality and effectiveness of the thesis prototype.
                    </p>

                    <p>
                        Information may also be used for research analysis and for the preparation of thesis-related findings, reports, presentations, and demonstrations. Where individual identification is not necessary, information used for research reporting and presentation should be anonymized, aggregated, or de-identified whenever appropriate.
                    </p>

                    <h3>8. Privacy and Data Protection</h3>

                    <p>
                        Ka-Akbay shall process personal information in accordance with applicable Philippine data protection requirements, including the Data Privacy Act of 2012. Personal information shall be processed only for legitimate and declared purposes associated with the operation, evaluation, administration, and research objectives of the System.
                    </p>

                    <p>
                        The System shall not intentionally collect personal information that is unnecessary or excessive in relation to these purposes. Personal information processed through Ka-Akbay shall not be sold or used for unrelated commercial advertising or marketing purposes.
                    </p>

                    <h3>9. Consent and Lawful Processing</h3>

                    <p>
                        Where consent is required as the lawful basis for processing personal information, the user acknowledges and agrees to the collection and processing of information for the purposes described in this Privacy Notice.
                    </p>

                    <p>
                        Where another lawful basis for processing applies under Philippine law, information may be processed to the extent permitted by such basis. Where legally applicable, a user may withdraw consent to processing that relies specifically on consent. Withdrawal of consent may affect the user's ability to continue using functions that necessarily require the affected information.
                    </p>

                    <h3>10. Senior High School Students and Minors</h3>

                    <p>
                        Ka-Akbay is intended for Senior High School students, and some student users may be minors. Where required by applicable law, research ethics requirements, school policy, or institutional procedures, appropriate consent, parental or legal guardian authorization, and/or student assent shall be obtained before collecting or processing information involving minors.
                    </p>

                    <p>
                        The thesis researchers and authorized administrators shall observe applicable requirements concerning the privacy, safety, and protection of minor participants.
                    </p>

                    <h3>11. Access to Personal Information</h3>

                    <p>
                        Access to information stored in Ka-Akbay is controlled according to the user's assigned role. Users shall only be provided access to information that is reasonably necessary for the performance of their authorized functions.
                    </p>

                    <p>
                        Depending on System permissions, access may be provided to authorized Students, Teachers, Administrators, Super Administrators, IT Administrators, and authorized members of the thesis research team. Access by administrative or technical personnel shall be limited to legitimate academic, administrative, security, maintenance, troubleshooting, or research purposes.
                    </p>

                    <h3>12. Disclosure of Information</h3>

                    <p>
                        Personal information shall not be disclosed to unauthorized individuals or unrelated third parties except where the data subject has provided appropriate authorization, disclosure is required or permitted by law, disclosure is required under an approved academic or research procedure, disclosure is reasonably necessary to investigate a security incident, or disclosure is otherwise permitted under applicable data protection requirements.
                    </p>

                    <p>
                        Thesis reports, academic presentations, research documentation, and demonstrations should use anonymized, aggregated, or de-identified information whenever individual identification is unnecessary.
                    </p>

                    <h3>13. Data Security</h3>

                    <p>
                        Ka-Akbay implements reasonable technical and organizational measures intended to protect information against unauthorized access, disclosure, modification, misuse, or loss. Such safeguards may include password hashing, authentication controls, role-based access control, restricted administrative functions, audit logging, security and technical logs, backup and recovery mechanisms, and administrative account controls.
                    </p>

                    <p>
                        However, no information system can guarantee absolute security. Users acknowledge that Ka-Akbay is a thesis prototype and may be subject to technical limitations, software errors, interruptions, security vulnerabilities, or data loss.
                    </p>

                    <h3>14. Data Retention and Disposal</h3>

                    <p>
                        Personal information shall be retained only for as long as reasonably necessary to fulfill the stated research, educational, administrative, and technical purposes of Ka-Akbay and any applicable academic or legal requirements.
                    </p>

                    <p>
                        When information is no longer required, it should be securely deleted, anonymized, or otherwise disposed of using reasonable measures appropriate to the nature of the information. Research data retention shall follow the procedures established for the Ka-Akbay thesis and any applicable institutional requirements.
                    </p>

                    <h3>15. Rights of Data Subjects</h3>

                    <p>
                        Subject to applicable Philippine law and any lawful limitations, individuals whose personal information is processed through Ka-Akbay may exercise rights provided under the Data Privacy Act of 2012. These may include the right to be informed regarding the collection and processing of personal information, the right to access personal information concerning them, the right to request correction of inaccurate or incomplete information, the right to object to certain forms of processing, the right to request erasure or blocking where legally appropriate, the right to data portability where applicable, the right to seek remedies for violations of data privacy rights, and the right to file a complaint with the National Privacy Commission.
                    </p>

                    <p>
                        Requests concerning personal information should be directed to the authorized Ka-Akbay research or administrative contact.
                    </p>

                    <h3>16. Acceptable Use</h3>

                    <p>
                        Users shall use Ka-Akbay only for legitimate educational, academic, research, and authorized administrative purposes. Users shall not access another user's account without authorization, share assigned credentials with unauthorized individuals, bypass access restrictions, attempt to obtain unauthorized administrative privileges, intentionally enter malicious or fraudulent information, alter or delete information without authorization, attempt to compromise System security, introduce malicious software or code, intentionally interfere with System availability or operation, misuse information obtained through the System, or use the System for unlawful, abusive, discriminatory, or harmful purposes.
                    </p>

                    <p>
                        Violation of these conditions may result in restriction or deactivation of the user's account and may be reported to the appropriate academic or institutional authority when necessary.
                    </p>

                    <h3>17. Intellectual Property and Academic Use</h3>

                    <p>
                        Ka-Akbay, including its original source code, interface, system design, documentation, research materials, analytical procedures, and thesis-related materials, was developed as part of an undergraduate thesis project.
                    </p>

                    <p>
                        Access to Ka-Akbay does not grant users ownership of the System or unrestricted permission to reproduce, modify, distribute, sell, commercially exploit, or misuse its protected materials. Third-party software, frameworks, libraries, services, trademarks, and other materials incorporated into or referenced by the System remain subject to the rights and licenses of their respective owners.
                    </p>

                    <h3>18. System Availability and Maintenance</h3>

                    <p>
                        Because Ka-Akbay is a thesis prototype, continuous or uninterrupted availability is not guaranteed. The System may be temporarily unavailable due to scheduled or emergency maintenance, System updates, testing, technical errors, security concerns, database maintenance, backup and restoration procedures, or changes required during thesis development and evaluation.
                    </p>

                    <p>
                        Authorized technical administrators may temporarily restrict access when reasonably necessary to protect the System or perform maintenance.
                    </p>

                    <h3>19. Disclaimer of Warranties</h3>

                    <p>
                        Ka-Akbay is provided on an “as is” and “as available” basis for educational and research purposes. The thesis researchers and developers do not guarantee that the System will operate without interruption, be completely free from errors, produce perfectly accurate predictions or classifications, remain completely secure against all possible threats, or be suitable as the sole basis for academic or institutional decisions.
                    </p>

                    <p>
                        Users are expected to exercise appropriate judgment when interpreting information generated by the System.
                    </p>

                    <h3>20. Limitation of Liability</h3>

                    <p>
                        To the extent permitted by applicable law, the thesis researchers and developers shall not be held responsible for losses or adverse outcomes resulting solely from reliance on System-generated classifications, predictions, calculations, or recommendations.
                    </p>

                    <p>
                        Ka-Akbay shall not replace official institutional policies, academic procedures, professional judgment, or authorized school decisions. Nothing in these Terms shall exclude or limit any obligation, right, or liability that cannot legally be excluded or limited under applicable Philippine law.
                    </p>

                    <p>
                        No educational institution shall be represented as endorsing or assuming responsibility for individual System-generated academic recommendations unless expressly authorized by that institution.
                    </p>

                    <h3>21. Changes to the Terms and Privacy Notice</h3>

                    <p>
                        These Terms of Use and Privacy Notice may be revised when necessary to reflect changes to the System, thesis procedures, security practices, research requirements, or applicable laws and regulations.
                    </p>

                    <p>
                        Where a material change affects the processing of personal information or requires additional consent, users shall be appropriately informed before the revised terms are applied where required.
                    </p>

                    <h3>22. User Acknowledgment</h3>

                    <p>
                        By selecting “I Agree,” “Accept,” “Continue,” or another equivalent confirmation before accessing Ka-Akbay, the user acknowledges that they have read and understood these Terms of Use and Privacy Notice.
                    </p>

                    <p>
                        The user further acknowledges that Ka-Akbay is an academic thesis prototype and decision-support system, that its outputs are intended to assist academic monitoring and do not constitute official academic decisions, and that the user's information may be collected, processed, stored, and used for the educational, administrative, technical, and research purposes stated in this notice. Where consent is required as the lawful basis for processing, the user voluntarily consents to such processing.
                    </p>

                    <p>
                        For student users who are minors, any additional parent or legal guardian consent or authorization required by applicable research, institutional, or legal requirements shall be obtained separately.
                    </p>
                </div>

                <div
                    class="terms-scroll-message"
                    id="termsMessage"
                >
                    Scroll to the bottom to enable agreement.
                </div>

                <label class="terms-agree-row">
                    <input
                        type="checkbox"
                        id="termsAgree"
                        name="terms_agree"
                        value="1"
                        disabled
                        required
                    >

                    <span>
                        I have read and agree to the Terms of Use and Privacy Notice.
                    </span>
                </label>
            </div>


                <p class="assigned-account-text">
                    <?= e(msg(
                        "Use your assigned account credentials",
                        "Gamitin ang assigned account credentials",
                        "Use your assigned account credentials"
                    )) ?>
                </p>

                <button
                    type="submit"
                    class="minimal-login-btn"
                    id="loginSubmit"
                    disabled
                >
                    <?= e(msg("LOGIN", "LOGIN", "LOGIN")) ?>
                </button>
            </form>

        <?php elseif ($mode === "recoverySetup"): ?>
            <div class="login-state-head">
                <span class="login-state-kicker">
                    <?= e(msg(
                        "PRIVILEGED ACCOUNT SECURITY",
                        "PRIVILEGED ACCOUNT SECURITY",
                        "PRIVILEGED ACCOUNT SECURITY"
                    )) ?>
                </span>

                <h2>
                    <?= e(msg(
                        "Secure Your Account",
                        "I-secure ang Iyong Account",
                        "Secure Your Account"
                    )) ?>
                </h2>

                <p class="login-instruction">
                    <?= e(msg(
                        "A verified recovery email is required before sign-in as ",
                        "Kailangan ng verified recovery email bago magpatuloy ang sign-in bilang ",
                        "A verified recovery email is required before sign-in as "
                    )) ?>
                    <strong><?= e($pendingRecoveryRoleLabel) ?></strong>.
                    <?= e(msg(
                        " Use a personal email address that is different from your permanent Ka-Akbay login email.",
                        " Gumamit ng personal email address na iba sa permanent Ka-Akbay login email.",
                        " Use a personal email address that is different from your permanent Ka-Akbay login email."
                    )) ?>
                </p>
            </div>

            <form
                method="POST"
                class="minimal-login-form"
                autocomplete="on"
            >
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e(csrf_token()) ?>"
                >

                <input
                    type="hidden"
                    name="action"
                    value="setupPrivilegedRecovery"
                >

                <input
                    type="hidden"
                    name="mode"
                    value="recoverySetup"
                >

                <div class="minimal-input">
                    <span>@</span>

                    <input
                        type="email"
                        name="recoveryEmail"
                        placeholder="<?= e(msg(
                            "RECOVERY EMAIL",
                            "RECOVERY EMAIL",
                            "RECOVERY EMAIL"
                        )) ?>"
                        autocomplete="email"
                        maxlength="254"
                        required
                    >
                </div>

                <button
                    type="submit"
                    class="minimal-login-btn"
                >
                    <?= e(msg(
                        "SEND VERIFICATION",
                        "SEND VERIFICATION",
                        "SEND VERIFICATION"
                    )) ?>
                </button>
            </form>

            <p class="login-secondary-action">
                <a href="login.php">
                    <?= e(msg(
                        "Cancel and return to login",
                        "Kanselahin at bumalik sa login",
                        "Cancel and return to login"
                    )) ?>
                </a>
            </p>

        <?php elseif ($mode === "forgot"): ?>
            <div class="login-state-head">
                <span class="login-state-kicker">
                    <?= e(msg(
                        "ACCOUNT RECOVERY",
                        "ACCOUNT RECOVERY",
                        "ACCOUNT RECOVERY"
                    )) ?>
                </span>

                <h2>
                    <?= e(msg(
                        "Forgot Password?",
                        "Nakalimutan ang Password?",
                        "Forgot Password?"
                    )) ?>
                </h2>

                <p class="login-instruction">
                    <?= e(msg(
                        "Enter your Ka-Akbay login email to request password recovery instructions. Instructions are sent only to the verified recovery email registered to an eligible account.",
                        "Ilagay ang Ka-Akbay login email para humiling ng password recovery instructions. Ipinapadala lamang ang instructions sa verified recovery email ng eligible na account.",
                        "Enter your Ka-Akbay login email to request password recovery instructions. Instructions are sent only to the verified recovery email registered to an eligible account."
                    )) ?>
                </p>
            </div>

            <form
                method="POST"
                class="minimal-login-form"
                autocomplete="on"
            >
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e(csrf_token()) ?>"
                >

                <input
                    type="hidden"
                    name="action"
                    value="requestPasswordReset"
                >

                <input
                    type="hidden"
                    name="mode"
                    value="forgot"
                >

                <div class="minimal-input">
                    <span>@</span>

                    <input
                        type="email"
                        name="email"
                        value="<?= e($submittedEmail) ?>"
                        placeholder="<?= e(msg("LOGIN EMAIL", "LOGIN EMAIL", "LOGIN EMAIL")) ?>"
                        autocomplete="email"
                        maxlength="254"
                        required
                    >
                </div>

                <button
                    type="submit"
                    class="minimal-login-btn"
                >
                    <?= e(msg(
                        "SEND RECOVERY INSTRUCTIONS",
                        "SEND RECOVERY INSTRUCTIONS",
                        "SEND RECOVERY INSTRUCTIONS"
                    )) ?>
                </button>
            </form>

            <p class="login-secondary-action">
                <a href="login.php">
                    <?= e(msg(
                        "Back to login",
                        "Bumalik sa login",
                        "Back to login"
                    )) ?>
                </a>
            </p>

        <?php elseif ($mode === "reset"): ?>
            <?php if ($resetTokenAvailable): ?>
                <div class="login-state-head">
                    <span class="login-state-kicker">
                        <?= e(msg(
                            "ACCOUNT RECOVERY",
                            "ACCOUNT RECOVERY",
                            "ACCOUNT RECOVERY"
                        )) ?>
                    </span>

                    <h2>
                        <?= e(msg(
                            "Create New Password",
                            "Gumawa ng Bagong Password",
                            "Create New Password"
                        )) ?>
                    </h2>

                    <p class="login-instruction">
                        <?= e(msg(
                            "Create a new password to restore access to your Ka-Akbay account.",
                            "Gumawa ng bagong password para maibalik ang access sa iyong Ka-Akbay account.",
                            "Create a new password to restore access to your Ka-Akbay account."
                        )) ?>
                    </p>
                </div>

                <form
                    method="POST"
                    class="minimal-login-form"
                    autocomplete="off"
                >
                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= e(csrf_token()) ?>"
                    >

                    <input
                        type="hidden"
                        name="action"
                        value="resetPassword"
                    >

                    <input
                        type="hidden"
                        name="mode"
                        value="reset"
                    >

                    <div class="minimal-input">
                        <span>□</span>

                        <input
                            type="password"
                            name="newPassword"
                            placeholder="<?= e(msg(
                                "NEW PASSWORD",
                                "BAGONG PASSWORD",
                                "NEW PASSWORD"
                            )) ?>"
                            autocomplete="new-password"
                            required
                        >
                    </div>

                    <div class="minimal-input">
                        <span>□</span>

                        <input
                            type="password"
                            name="confirmPassword"
                            placeholder="<?= e(msg(
                                "CONFIRM NEW PASSWORD",
                                "KUMPIRMAHIN ANG BAGONG PASSWORD",
                                "CONFIRM NEW PASSWORD"
                            )) ?>"
                            autocomplete="new-password"
                            required
                        >
                    </div>

                    <p class="login-security-note">
                        <?= e(msg(
                            "Use at least 8 characters with uppercase, lowercase, a number, and a special character.",
                            "Gumamit ng hindi bababa sa 8 characters na may uppercase, lowercase, numero, at special character.",
                            "Use at least 8 characters with uppercase, lowercase, a number, and a special character."
                        )) ?>
                    </p>

                    <button
                        type="submit"
                        class="minimal-login-btn"
                    >
                        <?= e(msg(
                            "RESET PASSWORD",
                            "RESET PASSWORD",
                            "RESET PASSWORD"
                        )) ?>
                    </button>
                </form>
            <?php endif; ?>

            <p class="login-secondary-action">
                <a href="login.php">
                    <?= e(msg(
                        "Back to login",
                        "Bumalik sa login",
                        "Back to login"
                    )) ?>
                </a>
            </p>

        <?php elseif ($mode === "otp"): ?>
            <div class="login-state-head">
                <span class="login-state-kicker">
                    <?= e(msg(
                        "PRIVILEGED ACCOUNT SECURITY",
                        "PRIVILEGED ACCOUNT SECURITY",
                        "PRIVILEGED ACCOUNT SECURITY"
                    )) ?>
                </span>

                <h2>
                    <?= e(msg(
                        "Additional Authentication Required",
                        "Kailangan ng Karagdagang Authentication",
                        "Additional Authentication Required"
                    )) ?>
                </h2>

                <p class="login-instruction">
                    <?= e(msg(
                        "Verify sign-in as ",
                        "I-verify ang sign-in bilang ",
                        "Verify sign-in as "
                    )) ?>
                    <strong><?= e($pendingOtpRoleLabel) ?></strong>.
                    <?= e(msg(
                        " Enter the 6-digit authentication code sent to ",
                        " Ilagay ang 6-digit authentication code na ipinadala sa ",
                        " Enter the 6-digit authentication code sent to "
                    )) ?>
                    <strong><?= e((string)($pendingOtp["maskedEmail"] ?? "")) ?></strong>.
                    <?= e(msg(
                        " If you do not see the email in your inbox, check your Spam or Junk folder.",
                        " Kung wala ang email sa inbox, tingnan ang Spam o Junk folder.",
                        " If wala ang email sa inbox, check your Spam or Junk folder."
                    )) ?>
                </p>
            </div>

            <form
                method="POST"
                class="minimal-login-form"
                autocomplete="one-time-code"
            >
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e(csrf_token()) ?>"
                >

                <input
                    type="hidden"
                    name="action"
                    value="verifyOtp"
                >

                <input
                    type="hidden"
                    name="mode"
                    value="otp"
                >

                <div class="minimal-input">
                    <span>#</span>

                    <input
                        type="text"
                        name="otp"
                        placeholder="<?= e(msg(
                            "6-DIGIT CODE",
                            "6-DIGIT CODE",
                            "6-DIGIT CODE"
                        )) ?>"
                        inputmode="numeric"
                        pattern="[0-9]{6}"
                        maxlength="6"
                        autocomplete="one-time-code"
                        required
                    >
                </div>

                <?php if ($otpRemainingAttempts > 0): ?>
                    <p class="login-security-note">
                        <?= e(msg(
                            "For account protection, this privileged sign-in allows up to " . privileged_otp_max_failures() . " incorrect authentication-code attempts before a temporary lockout.",
                            "Para sa proteksyon ng account, hanggang " . privileged_otp_max_failures() . " maling authentication-code attempts lamang ang pinapayagan sa privileged sign-in bago ang pansamantalang lockout.",
                            "For account protection, this privileged sign-in allows up to " . privileged_otp_max_failures() . " incorrect authentication-code attempts before a temporary lockout."
                        )) ?>
                    </p>
                <?php endif; ?>

                <button
                    type="submit"
                    class="minimal-login-btn"
                >
                    <?= e(msg(
                        "VERIFY",
                        "VERIFY",
                        "VERIFY"
                    )) ?>
                </button>
            </form>

            <form
                method="POST"
                class="minimal-login-form"
            >
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e(csrf_token()) ?>"
                >

                <input
                    type="hidden"
                    name="action"
                    value="resendOtp"
                >

                <input
                    type="hidden"
                    name="mode"
                    value="otp"
                >

                <button
                    type="submit"
                    class="minimal-login-btn"
                    data-otp-resend-button
                    data-otp-resend-seconds="<?= e((string)$otpResendRetryAfter) ?>"
                    <?= $otpResendRetryAfter > 0 ? "disabled" : "" ?>
                >
                    <span data-otp-resend-label>
                        <?= e(msg(
                            "RESEND CODE",
                            "RESEND CODE",
                            "RESEND CODE"
                        )) ?>
                    </span>
                    <span
                        data-otp-resend-countdown
                        aria-live="polite"
                    ></span>
                </button>
            </form>

            <p class="login-secondary-action">
                <a href="login.php">
                    <?= e(msg(
                        "Cancel and return to login",
                        "Kanselahin at bumalik sa login",
                        "Cancel and return to login"
                    )) ?>
                </a>
            </p>
        <?php endif; ?>

    </section>

    <?php if ($footerContentActive && $footerText !== ""): ?>
        <footer class="minimal-login-footer">
            <?= e($footerText) ?>
        </footer>
    <?php endif; ?>
</main>

<script nonce="<?= e(page_csp_nonce()) ?>">
(function () {
    const termsScroll = document.getElementById("termsScroll");
    const termsAgree = document.getElementById("termsAgree");
    const termsMessage = document.getElementById("termsMessage");
    const loginSubmit = document.getElementById("loginSubmit");
    const loginForm = document.getElementById("loginForm");

    if (
        !termsScroll ||
        !termsAgree ||
        !termsMessage ||
        !loginSubmit ||
        !loginForm
    ) {
        return;
    }

    let termsUnlocked = false;

    termsAgree.checked = false;
    termsAgree.disabled = true;
    loginSubmit.disabled = true;

    function updateLoginButton() {
        loginSubmit.disabled =
            termsAgree.disabled ||
            !termsAgree.checked;
    }

    function unlockTerms() {
        if (termsUnlocked) {
            return;
        }

        termsUnlocked = true;
        termsAgree.disabled = false;

        termsMessage.textContent =
            "You may now confirm your agreement.";

        updateLoginButton();
    }

    function checkTermsPosition() {
        if (termsUnlocked) {
            return;
        }

        const scrollHeight =
            Math.ceil(termsScroll.scrollHeight);

        const clientHeight =
            Math.ceil(termsScroll.clientHeight);

        const scrollTop =
            Math.ceil(termsScroll.scrollTop);

        const maxScroll =
            Math.max(
                0,
                scrollHeight - clientHeight
            );

        if (maxScroll <= 2) {
            unlockTerms();
            return;
        }

        const remaining =
            maxScroll - scrollTop;

        if (remaining <= 20) {
            unlockTerms();
        }
    }

    termsScroll.addEventListener(
        "scroll",
        checkTermsPosition,
        {
            passive: true
        }
    );

    termsScroll.addEventListener(
        "wheel",
        function () {
            requestAnimationFrame(
                checkTermsPosition
            );
        },
        {
            passive: true
        }
    );

    termsScroll.addEventListener(
        "touchmove",
        function () {
            requestAnimationFrame(
                checkTermsPosition
            );
        },
        {
            passive: true
        }
    );

    termsScroll.addEventListener(
        "touchend",
        checkTermsPosition,
        {
            passive: true
        }
    );

    termsScroll.addEventListener(
        "keyup",
        checkTermsPosition
    );

    termsAgree.addEventListener(
        "change",
        updateLoginButton
    );

    loginForm.addEventListener(
        "submit",
        function (event) {
            if (
                termsAgree.disabled ||
                !termsAgree.checked
            ) {
                event.preventDefault();

                checkTermsPosition();
                updateLoginButton();
            }
        }
    );

    let scrollCheckCount = 0;

    const scrollCheckTimer = setInterval(
        function () {
            checkTermsPosition();

            scrollCheckCount++;

            if (
                termsUnlocked ||
                scrollCheckCount >= 300
            ) {
                clearInterval(
                    scrollCheckTimer
                );
            }
        },
        100
    );

    window.addEventListener(
        "resize",
        checkTermsPosition
    );

    checkTermsPosition();
    updateLoginButton();
})();
</script>

<script nonce="<?= e(page_csp_nonce()) ?>">
(function () {
    const resendButton = document.querySelector("[data-otp-resend-button]");

    if (!resendButton) {
        return;
    }

    const countdown = resendButton.querySelector("[data-otp-resend-countdown]");
    let remaining = Math.max(
        0,
        parseInt(resendButton.dataset.otpResendSeconds || "0", 10) || 0
    );

    function formatRemaining(seconds) {
        const safeSeconds = Math.max(0, seconds);

        if (safeSeconds < 60) {
            return safeSeconds + "s";
        }

        const minutes = Math.floor(safeSeconds / 60);
        const secondsPart = safeSeconds % 60;

        return minutes + "m " + String(secondsPart).padStart(2, "0") + "s";
    }

    function renderResendState() {
        if (remaining > 0) {
            resendButton.disabled = true;

            if (countdown) {
                countdown.textContent = " (" + formatRemaining(remaining) + ")";
            }

            return;
        }

        resendButton.disabled = false;

        if (countdown) {
            countdown.textContent = "";
        }
    }

    renderResendState();

    if (remaining <= 0) {
        return;
    }

    const timer = window.setInterval(function () {
        remaining = Math.max(0, remaining - 1);
        renderResendState();

        if (remaining <= 0) {
            window.clearInterval(timer);
        }
    }, 1000);
})();
</script>

<?php page_foot(false); ?>