<?php
require_once __DIR__ . "/app/security.php";
require_once __DIR__ . "/app/auth.php";
require_once __DIR__ . "/app/page_actions.php";
require_once __DIR__ . "/app/page_data.php";
require_once __DIR__ . "/app/layout.php";

require_role(["student"]);

$user = current_user();
$error = handle_page_action("schedules", $user);
$data = get_page_data("schedules", $user);
$edit = $data["editSchedule"] ?? null;
$routine = $data["routineCapacity"] ?? [];
$attendanceRecords = $data["attendanceRecords"] ?? [];
$attendanceSummary = $data["attendanceSummary"] ?? [];

page_head(msg("Subject Schedule", "Iskedyul ng Asignatura", "Subject Schedule"));
sidebar("schedules", $user);
?>

<main class="main page-enter schedule-page">
    <section class="topbar">
        <div>
            <h1><?= e(msg("Subject Schedule", "Iskedyul ng Asignatura", "Subject Schedule")) ?></h1>
        </div>
        <div class="date"><?= e(date("M d, Y")) ?></div>
    </section>

    <div class="error <?= $error ? "show" : "" ?>"><?= e($error) ?></div>

    <section class="schedule-hero">
        <div>
            <span><?= e(msg("WEEKLY SCHEDULE", "LINGGUHANG ISKEDYUL", "WEEKLY SCHEDULE")) ?></span>
            <h2><?= e(count($data["schedules"] ?? [])) ?> <?= e(count($data["schedules"] ?? []) === 1 ? msg("scheduled subject", "naka-schedule na asignatura", "scheduled subject") : msg("scheduled subjects", "naka-schedule na asignatura", "scheduled subjects")) ?></h2>
        </div>

        <div class="schedule-hero-stats">
            <div>
                <small><?= e(msg("Class Hours", "Oras sa Klase", "Class Hours")) ?></small>
                <strong><?= e($data["weeklyClassHours"] ?? 0) ?></strong>
            </div>
            <div>
                <small><?= e(msg("Available Study Time", "Available Study Time", "Available Study Time")) ?></small>
                <strong><?= e($routine["availableStudyTime"] ?? 98) ?></strong>
            </div>
        </div>
    </section>

    <section class="routine-grid">
        <div class="routine-card">
            <span><?= e(msg("Total Weekly Hours", "Kabuuang Oras sa Isang Linggo", "Total Weekly Hours")) ?></span>
            <strong><?= e($routine["weeklyHours"] ?? 168) ?></strong>
        </div>

        <div class="routine-card">
            <span><?= e(msg("Weekly Class Hours", "Lingguhang Oras sa Klase", "Weekly Class Hours")) ?></span>
            <strong><?= e($routine["weeklyClassHours"] ?? 0) ?></strong>
        </div>

        <div class="routine-card">
            <span><?= e(msg("Sleep Buffer", "Sleep Buffer", "Sleep Buffer")) ?></span>
            <strong><?= e($routine["sleepHours"] ?? 56) ?></strong>
        </div>

        <div class="routine-card">
            <span><?= e(msg("Personal Care Buffer", "Personal Care Buffer", "Personal Care Buffer")) ?></span>
            <strong><?= e($routine["personalCareHours"] ?? 14) ?></strong>
        </div>

        <div class="routine-card">
            <span><?= e(msg("Non-Academic Buffer", "Non-Academic Buffer", "Non-Academic Buffer")) ?></span>
            <strong><?= e($routine["nonAcademicBuffer"] ?? 70) ?></strong>
        </div>

        <div class="routine-card">
            <span><?= e(msg("Available Study Time", "Available Study Time", "Available Study Time")) ?></span>
            <strong><?= e($routine["availableStudyTime"] ?? 98) ?></strong>
        </div>
    </section>

    <section class="schedule-layout">
        <div class="card schedule-form-card">
            <div class="card-head">
                <h2><?= e($edit ? msg("Edit Schedule", "I-edit ang Iskedyul", "Edit Schedule") : msg("Add Schedule", "Magdagdag ng Iskedyul", "Add Schedule")) ?></h2>
            </div>

            <form method="POST" class="forms schedule-form">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="scheduleId" value="<?= e($edit["id"] ?? "") ?>">

                <div class="field">
                    <label><?= e(msg("Subject", "Asignatura", "Subject")) ?></label>
                    <input name="subject" value="<?= e($edit["subject"] ?? "") ?>" maxlength="100" required>
                </div>

                <div class="field">
                    <label><?= e(msg("Day", "Araw", "Day")) ?></label>
                    <select name="day" required>
                        <?php foreach (($data["days"] ?? week_days()) as $day): ?>
                            <option value="<?= e($day) ?>" <?= (($edit["day"] ?? "") === $day) ? "selected" : "" ?>><?= e(function_exists("tv") ? tv($day) : $day) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="field">
                    <label><?= e(msg("Start Time", "Oras ng Simula", "Start Time")) ?></label>
                    <input type="time" name="startTime" value="<?= e($edit["startTime"] ?? "") ?>" required>
                </div>

                <div class="field">
                    <label><?= e(msg("End Time", "Oras ng Pagtatapos", "End Time")) ?></label>
                    <input type="time" name="endTime" value="<?= e($edit["endTime"] ?? "") ?>" required>
                </div>

                <div class="field">
                    <label><?= e(msg("Room", "Silid", "Room")) ?></label>
                    <input name="room" value="<?= e($edit["room"] ?? "") ?>" maxlength="80">
                </div>

                <div class="field">
                    <label><?= e(msg("Teacher", "Guro", "Teacher")) ?></label>
                    <input name="teacherName" value="<?= e($edit["teacherName"] ?? "") ?>" maxlength="120">
                </div>

                <div class="button-row full">
                    <button class="btn btn-primary" type="submit"><?= e(msg("Save Schedule", "I-save ang Iskedyul", "Save Schedule")) ?></button>
                    <a class="btn btn-ghost" href="schedules.php"><?= e(msg("Cancel", "Kanselahin", "Cancel")) ?></a>
                </div>
            </form>
        </div>

        <div class="card schedule-side-card">
            <div class="card-head">
                <h2><?= e(msg("Capacity Effect", "Epekto sa Capacity", "Capacity Effect")) ?></h2>
            </div>

            <div class="schedule-metric">
                <span><?= e(msg("Total Weekly Hours", "Kabuuang Oras sa Isang Linggo", "Total Weekly Hours")) ?></span>
                <strong><?= e($routine["weeklyHours"] ?? 168) ?></strong>
            </div>

            <div class="schedule-metric">
                <span><?= e(msg("Weekly Class Hours", "Lingguhang Oras sa Klase", "Weekly Class Hours")) ?></span>
                <strong><?= e($data["weeklyClassHours"] ?? 0) ?></strong>
            </div>

            <div class="schedule-metric">
                <span><?= e(msg("Sleep + Care Buffer", "Sleep + Care Buffer", "Sleep + Care Buffer")) ?></span>
                <strong><?= e($routine["nonAcademicBuffer"] ?? 70) ?></strong>
            </div>

            <div class="schedule-metric">
                <span><?= e(msg("Available Study Time", "Available Study Time", "Available Study Time")) ?></span>
                <strong><?= e($routine["availableStudyTime"] ?? 98) ?></strong>
            </div>

            <a class="btn btn-outline" href="tasks.php"><?= e(msg("Open Tasks", "Buksan ang Tasks", "Open Tasks")) ?></a>
        </div>
    </section>

    <section class="card clean-panel section-space schedule-combined-panel">
        <div class="clean-panel-head">
            <div>
                <h2><?= e(msg("Attendance and Calendar", "Attendance at Calendar", "Attendance and Calendar")) ?></h2>
            </div>
            <div class="tab-buttons">
                <button class="tab-button active" type="button" data-tab-group="schedule-overview" data-tab-target="attendance-summary-panel"><?= e(msg("Attendance", "Attendance", "Attendance")) ?></button>
                <button class="tab-button" type="button" data-tab-group="schedule-overview" data-tab-target="schedule-week-panel"><?= e(msg("Weekly", "Lingguhan", "Weekly")) ?></button>
                <button class="tab-button" type="button" data-tab-group="schedule-overview" data-tab-target="schedule-month-panel"><?= e(msg("Monthly", "Buwanan", "Monthly")) ?></button>
            </div>
        </div>

        <div class="tab-panel active" data-tab-panel-group="schedule-overview" data-tab-panel="attendance-summary-panel">
            <div class="section-subhead">
                <h3><?= e(msg("Attendance Summary", "Buod ng Attendance", "Attendance Summary")) ?></h3>
            </div>

            <div class="monitoring-grid attendance-summary-grid">
                <?php foreach (($data["schedules"] ?? []) as $schedule): ?>
                    <?php
                        $subject = $schedule["subject"] ?? "";
                        $scheduleId = trim((string)($schedule["id"] ?? ""));
                        $summaryKey = $scheduleId !== "" ? "schedule:" . $scheduleId : $subject;
                        $summary = $attendanceSummary[$summaryKey] ?? [];
                        $marked = $summary["marked"] ?? $summary["totalMarked"] ?? $summary["total"] ?? 0;
                        $present = $summary["present"] ?? 0;
                        $absent = $summary["absent"] ?? 0;
                        $excused = $summary["excused"] ?? 0;
                        $absenceRate = $summary["absenceRate"] ?? 0;
                        $consecutiveAbsences = $summary["consecutiveAbsences"] ?? 0;
                        $attendanceStatus = $summary["attendanceStatus"] ?? (($absenceRate > 20 || $consecutiveAbsences >= 5) ? "Attendance Concern" : ($marked > 0 ? "Regular Attendance" : "No Record"));
                    ?>

                    <div class="monitor-card <?= e(view_state_class($attendanceStatus)) ?>">
                        <div class="monitor-card-top">
                            <div>
                                <span><?= e(function_exists("tv") ? tv($schedule["day"] ?? "") : ($schedule["day"] ?? "")) ?></span>
                                <h3><?= e($subject) ?></h3>
                                <p><?= e(($schedule["startTime"] ?? "") . " - " . ($schedule["endTime"] ?? "")) ?></p>
                            </div>
                            <?= badge($attendanceStatus) ?>
                        </div>

                        <div class="monitor-mini-grid">
                            <div>
                                <span><?= e(msg("Marked", "Na-markahan", "Marked")) ?></span>
                                <strong><?= e($marked) ?></strong>
                            </div>
                            <div>
                                <span><?= e(msg("Present", "Pumasok", "Present")) ?></span>
                                <strong><?= e($present) ?></strong>
                            </div>
                            <div>
                                <span><?= e(msg("Absent", "Lumiban", "Absent")) ?></span>
                                <strong><?= e($absent) ?></strong>
                            </div>
                            <div>
                                <span><?= e(msg("Excused", "Excused", "Excused")) ?></span>
                                <strong><?= e($excused) ?></strong>
                            </div>
                            <div>
                                <span><?= e(msg("Absence Rate", "Bahagdan ng Pagliban", "Absence Rate")) ?></span>
                                <strong><?= e($absenceRate) ?>%</strong>
                            </div>
                            <div>
                                <span><?= e(msg("Absence Streak", "Sunod-sunod na Pagliban", "Absence Streak")) ?></span>
                                <strong><?= e($consecutiveAbsences) ?></strong>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>

                <?php if (!count($data["schedules"] ?? [])): ?>
                    <div class="compact-empty">
                        <strong><?= e(msg("No schedule entries yet", "Wala pang schedule entries", "No schedule entries yet")) ?></strong>
                    </div>
                <?php endif; ?>
            </div>

            <div class="section-subhead section-space">
                <h3><?= e(msg("Attendance History", "Kasaysayan ng Attendance", "Attendance History")) ?></h3>
            </div>

            <?php if (count($attendanceRecords)): ?>
                <div class="table-wrap">
                    <table class="table">
                        <thead>
                            <tr>
                                <th><?= e(msg("DATE", "PETSA", "DATE")) ?></th>
                                <th><?= e(msg("SUBJECT", "ASIGNATURA", "SUBJECT")) ?></th>
                                <th><?= e(msg("STATUS", "KALAGAYAN", "STATUS")) ?></th>
                                <th><?= e(msg("NOTE", "TALA", "NOTE")) ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach (array_reverse($attendanceRecords) as $attendance): ?>
                                <tr>
                                    <td><?= e(!empty($attendance["date"]) ? date("M d, Y", strtotime($attendance["date"])) : "--") ?></td>
                                    <td><?= e(($attendance["subject"] ?? "") ?: "--") ?></td>
                                    <td><?= badge(($attendance["status"] ?? "") ?: "No Record") ?></td>
                                    <td><?= e(($attendance["note"] ?? "") ?: "--") ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="compact-empty">
                    <strong><?= e(msg("No attendance records yet", "Wala pang attendance records", "No attendance records yet")) ?></strong>
                </div>
            <?php endif; ?>
        </div>

        <div class="tab-panel" data-tab-panel-group="schedule-overview" data-tab-panel="schedule-week-panel">
            <div class="section-subhead">
                <h3><?= e(msg("Weekly Calendar", "Lingguhang Calendar", "Weekly Calendar")) ?></h3>
            </div>

            <div class="mini-calendar">
                <?php foreach (($data["calendar"] ?? []) as $day => $items): ?>
                    <div class="calendar-day">
                        <div class="calendar-day-head">
                            <strong><?= e(substr(function_exists("tv") ? tv($day) : $day, 0, 3)) ?></strong>
                            <span><?= e(count($items)) ?> <?= e(count($items) === 1 ? msg("class", "klase", "class") : msg("classes", "klase", "classes")) ?></span>
                        </div>

                        <div class="calendar-items">
                            <?php foreach ($items as $schedule): ?>
                                <div class="calendar-item">
                                    <strong><?= e($schedule["subject"] ?? "") ?></strong>
                                    <span><?= e($schedule["startTime"] ?? "") ?> - <?= e($schedule["endTime"] ?? "") ?></span>
                                    <small><?= e(($schedule["room"] ?? "") ?: msg("No room", "Walang room", "No room")) ?></small>
                                </div>
                            <?php endforeach; ?>

                            <?php if (!count($items)): ?>
                                <div class="calendar-empty"><?= e(msg("No class", "Walang klase", "No class")) ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="tab-panel" data-tab-panel-group="schedule-overview" data-tab-panel="schedule-month-panel">
            <div class="month-calendar-head">
                <strong><?= e($data["monthlyCalendar"]["month"] ?? date("F Y")) ?></strong>
                <span><?= e(msg("Repeated class schedule by day", "Paulit-ulit na class schedule ayon sa araw", "Repeated class schedule by day")) ?></span>
            </div>

            <div class="month-calendar-grid">
                <?php foreach (($data["monthlyCalendar"]["days"] ?? []) as $day): ?>
                    <div class="month-day-card <?= count($day["items"] ?? []) ? "busy" : "" ?>">
                        <span><?= e(date("j", strtotime($day["date"]))) ?></span>
                        <small><?= e($day["day"] ?? "") ?></small>

                        <?php foreach (array_slice($day["items"] ?? [], 0, 2) as $item): ?>
                            <div class="month-task-dot">
                                <strong><?= e($item["subject"] ?? "") ?></strong>
                                <em><?= e($item["time"] ?? (($item["startTime"] ?? "") . " - " . ($item["endTime"] ?? ""))) ?></em>
                            </div>
                        <?php endforeach; ?>

                        <?php if (count($day["items"] ?? []) > 2): ?>
                            <p>+<?= e(count($day["items"]) - 2) ?> <?= e(msg("more", "pa", "more")) ?></p>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="card section-space">
        <div class="card-head">
            <h2><?= e(msg("Schedule List", "Listahan ng Iskedyul", "Schedule List")) ?></h2>
        </div>

        <table class="table">
            <thead>
                <tr>
                    <th><?= e(msg("SUBJECT", "ASIGNATURA", "SUBJECT")) ?></th>
                    <th><?= e(msg("DAY", "ARAW", "DAY")) ?></th>
                    <th><?= e(msg("TIME", "ORAS", "TIME")) ?></th>
                    <th><?= e(msg("ROOM", "SILID", "ROOM")) ?></th>
                    <th><?= e(msg("TEACHER", "GURO", "TEACHER")) ?></th>
                    <th><?= e(msg("HOURS", "ORAS", "HOURS")) ?></th>
                    <th><?= e(msg("ACTIONS", "AKSYON", "ACTIONS")) ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach (($data["schedules"] ?? []) as $schedule): ?>
                    <tr>
                        <td>
                            <div>
                                <div><?= e($schedule["subject"] ?? "") ?></div>
                                <small><?= e($schedule["id"] ?? "") ?></small>
                            </div>
                        </td>
                        <td><?= e(function_exists("tv") ? tv($schedule["day"] ?? "") : ($schedule["day"] ?? "")) ?></td>
                        <td><?= e($schedule["startTime"] ?? "") ?> - <?= e($schedule["endTime"] ?? "") ?></td>
                        <td><?= e(($schedule["room"] ?? "") ?: "--") ?></td>
                        <td><?= e(($schedule["teacherName"] ?? "") ?: "--") ?></td>
                        <td><?= e(schedule_duration_hours($schedule)) ?></td>
                        <td>
                            <form method="POST" class="button-row">
                                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="scheduleId" value="<?= e($schedule["id"] ?? "") ?>">
                                <a class="btn btn-outline" href="schedules.php?edit=<?= e($schedule["id"] ?? "") ?>"><?= e(msg("Edit", "I-edit", "Edit")) ?></a>
                                <button class="btn btn-danger" type="submit" name="action" value="delete"><?= e(msg("Delete", "Tanggalin", "Delete")) ?></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>

                <?php if (!count($data["schedules"] ?? [])): ?>
                    <tr>
                        <td colspan="7"><?= e(msg("No schedule entries yet.", "Wala pang schedule entries.", "No schedule entries yet.")) ?></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </section>
</main>

<?php page_foot(); ?>