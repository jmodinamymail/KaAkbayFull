document.addEventListener("DOMContentLoaded",()=>{
    const preloadScreen=document.getElementById("preloadScreen")
    const loginForm=document.querySelector("[data-login-form]")
    const lang=document.documentElement.dataset.lang || document.body.dataset.lang || "en"

    const uiText={
        en:{
            deleteRecord:"Delete this record?",
            deleteAcademicRecord:"Permanently delete this academic record? This cannot be undone.",
            requestDelete:"Submit this deletion request for teacher approval?",
            deleteReasonRequired:"Enter a reason for the deletion request.",
            deleteAnnouncement:"Delete this announcement?",
            restoreBackup:"Restore this backup? Current application data will be replaced.",
            taskRemovalReason:"Enter a reason before removing or cancelling this task.",
            passwordMismatch:"The password confirmation does not match.",
            otpLength:"Enter the 6-digit verification code.",
            loading:"Loading",
            kaakbay:"Ka-Akbay",
            darkMode:"Dark Mode",
            lightMode:"Light Mode",
            openNavigation:"Open navigation",
            closeNavigation:"Close navigation",
            showPassword:"Show password",
            hidePassword:"Hide password"
        },
        tl:{
            deleteRecord:"Tanggalin ang tala na ito?",
            deleteAcademicRecord:"Permanenteng tanggalin ang academic record na ito? Hindi na ito maibabalik.",
            requestDelete:"I-submit ang deletion request na ito para sa approval ng guro?",
            deleteReasonRequired:"Maglagay ng dahilan para sa deletion request.",
            deleteAnnouncement:"Tanggalin ang announcement na ito?",
            restoreBackup:"I-restore ang backup na ito? Papalitan ang kasalukuyang application data.",
            taskRemovalReason:"Maglagay ng dahilan bago i-remove o i-cancel ang task.",
            passwordMismatch:"Hindi magkapareho ang password at confirmation.",
            otpLength:"Ilagay ang 6-digit verification code.",
            loading:"Naglo-load",
            kaakbay:"Ka-Akbay",
            darkMode:"Dark Mode",
            lightMode:"Light Mode",
            openNavigation:"Buksan ang navigation",
            closeNavigation:"Isara ang navigation",
            showPassword:"Ipakita ang password",
            hidePassword:"Itago ang password"
        },
        tg:{
            deleteRecord:"Delete this record?",
            deleteAcademicRecord:"Permanently delete this academic record? This cannot be undone.",
            requestDelete:"Submit this deletion request for teacher approval?",
            deleteReasonRequired:"Enter a reason for the deletion request.",
            deleteAnnouncement:"Delete this announcement?",
            restoreBackup:"Restore this backup? Current application data will be replaced.",
            taskRemovalReason:"Enter a reason before removing or cancelling this task.",
            passwordMismatch:"The password confirmation does not match.",
            otpLength:"Enter the 6-digit verification code.",
            loading:"Loading",
            kaakbay:"Ka-Akbay",
            darkMode:"Dark Mode",
            lightMode:"Light Mode",
            openNavigation:"Open navigation",
            closeNavigation:"Close navigation",
            showPassword:"Show password",
            hidePassword:"Hide password"
        }
    }

    const tx=key=>{
        return (uiText[lang] && uiText[lang][key]) || uiText.en[key] || key
    }

    const systemName=(
        document.querySelector(".minimal-login-brand h1")?.textContent ||
        document.querySelector(".sidebar .logo span")?.textContent ||
        tx("kaakbay")
    ).trim() || tx("kaakbay")

    const savedTheme=localStorage.getItem("kaakbay-theme") || "light"
    document.documentElement.dataset.theme=savedTheme

    const updateThemeLabels=()=>{
        const current=document.documentElement.dataset.theme || "light"
        const nextLabel=current==="dark" ? tx("lightMode") : tx("darkMode")

        document.querySelectorAll("[data-theme-label]").forEach(label=>{
            label.textContent=nextLabel
        })

        document.querySelectorAll("[data-theme-toggle]").forEach(button=>{
            button.setAttribute("aria-label",nextLabel)
            button.setAttribute("title",nextLabel)
        })

        document.querySelectorAll("[data-theme-switch]").forEach(toggle=>{
            toggle.classList.toggle("active",current==="dark")
        })
    }

    document.querySelectorAll("[data-theme-toggle]").forEach(button=>{
        button.addEventListener("click",()=>{
            const current=document.documentElement.dataset.theme || "light"
            const next=current==="dark" ? "light" : "dark"

            document.documentElement.dataset.theme=next
            localStorage.setItem("kaakbay-theme",next)
            updateThemeLabels()
        })
    })

    updateThemeLabels()

    const prepareDismissibleMessage=message=>{
        if(!message || message.dataset.dismissiblePrepared==="true"){
            return
        }

        message.dataset.dismissiblePrepared="true"
        message.classList.add("message-dismissible")

        let copy=message.querySelector(".message-copy")

        if(!copy){
            copy=document.createElement("span")
            copy.className="message-copy"

            const movable=[...message.childNodes].filter(node=>{
                if(node.nodeType===Node.ELEMENT_NODE){
                    return !node.matches?.("[data-message-dismiss]")
                }

                return node.nodeType===Node.TEXT_NODE && node.textContent.trim()!==""
            })

            movable.forEach(node=>copy.appendChild(node))
            message.insertBefore(copy,message.firstChild)
        }

        if(!message.querySelector("[data-message-dismiss]")){
            const button=document.createElement("button")
            button.type="button"
            button.className="message-dismiss"
            button.dataset.messageDismiss=""
            button.setAttribute("aria-label","Dismiss message")
            button.textContent="×"
            message.appendChild(button)
        }

        message.dataset.dismissibleMessage=""
    }

    document.querySelectorAll("[data-dismissible-message],.error.show").forEach(prepareDismissibleMessage)

    document.addEventListener("click",event=>{
        const button=event.target.closest?.("[data-message-dismiss]")

        if(!button){
            return
        }

        const message=button.closest("[data-dismissible-message],.message-dismissible")

        if(!message){
            return
        }

        message.hidden=true
        message.classList.remove("show")
    })

    document.querySelectorAll("[data-restore-branding-form]").forEach(form=>{
        const trigger=form.querySelector("[data-restore-branding-trigger]")
        const start=form.querySelector("[data-restore-branding-start]")
        const confirmation=form.querySelector("[data-restore-branding-confirmation]")
        const password=form.querySelector("[data-restore-branding-password]")
        const cancel=form.querySelector("[data-restore-branding-cancel]")

        if(!trigger || !confirmation || !password){
            return
        }

        const openConfirmation=()=>{
            if(start){
                start.hidden=true
            }

            confirmation.hidden=false
            password.disabled=false
            password.required=true
            password.focus({preventScroll:true})
        }

        const closeConfirmation=()=>{
            confirmation.hidden=true

            if(start){
                start.hidden=false
            }

            password.value=""
            password.required=false
            password.disabled=true
            trigger.focus({preventScroll:true})
        }

        trigger.addEventListener("click",openConfirmation)

        if(cancel){
            cancel.addEventListener("click",closeConfirmation)
        }
    })

    const passwordEyeMarkup=`
        <svg class="password-eye-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
            <path d="M2.5 12s3.4-6 9.5-6 9.5 6 9.5 6-3.4 6-9.5 6-9.5-6-9.5-6Z"></path>
            <circle cx="12" cy="12" r="2.6"></circle>
        </svg>
    `

    const resetPasswordVisibility=(input,button)=>{
        input.type="password"
        button.setAttribute("aria-pressed","false")
        button.setAttribute("aria-label",tx("showPassword"))
    }

    const bindPasswordToggle=(button,input)=>{
        if(button.dataset.passwordVisibilityReady==="true"){
            return
        }

        button.type="button"
        button.classList.add("password-visibility-toggle")
        button.setAttribute("aria-pressed","false")
        button.setAttribute("aria-label",tx("showPassword"))

        if(input.id){
            button.setAttribute("aria-controls",input.id)
        }

        if(!button.querySelector(".password-eye-icon")){
            button.innerHTML=passwordEyeMarkup
        }

        button.dataset.passwordVisibilityReady="true"

        button.addEventListener("click",()=>{
            const showing=input.type==="text"

            input.type=showing ? "password" : "text"
            button.setAttribute("aria-pressed",showing ? "false" : "true")
            button.setAttribute(
                "aria-label",
                showing ? tx("showPassword") : tx("hidePassword")
            )

            input.focus({preventScroll:true})
        })
    }

    const preparePasswordField=input=>{
        if(input.dataset.passwordFieldReady==="true"){
            return
        }

        input.dataset.passwordFieldReady="true"

        let host=input.parentElement

        if(
            !host ||
            (
                !host.classList.contains("password-input-wrap") &&
                !host.classList.contains("minimal-input")
            )
        ){
            const wrapper=document.createElement("div")
            wrapper.className="password-input-wrap password-input-generated-wrap"
            input.parentNode?.insertBefore(wrapper,input)
            wrapper.appendChild(input)
            host=wrapper
        }else{
            host.classList.add("password-input-wrap")
        }

        if(!host){
            return
        }

        let button=null

        if(input.id){
            const escapedId=window.CSS && typeof window.CSS.escape==="function"
                ? window.CSS.escape(input.id)
                : input.id.replace(/["\\]/g,"\\$&")

            button=document.querySelector(
                `[data-password-toggle][data-password-target="${escapedId}"]`
            )
        }

        if(!button){
            button=host.querySelector("[data-password-toggle]")
        }

        if(!button){
            button=document.createElement("button")
            button.type="button"
            button.dataset.passwordToggle=""
            button.className="password-visibility-toggle"

            if(input.id){
                button.dataset.passwordTarget=input.id
            }

            host.appendChild(button)
        }

        bindPasswordToggle(button,input)
    }

    const preparePasswordFields=root=>{
        const scope=root && root.querySelectorAll ? root : document

        scope.querySelectorAll("input[type='password']").forEach(preparePasswordField)
    }

    document.querySelectorAll("[data-password-toggle]").forEach(button=>{
        const targetId=(button.dataset.passwordTarget || "").trim()
        const input=targetId ? document.getElementById(targetId) : null

        if(input){
            preparePasswordField(input)
        }
    })

    preparePasswordFields(document)

    const sidebar=document.querySelector(".sidebar")

    const closeMobileMenu=()=>{
        document.body.classList.remove("nav-open")
        const toggle=document.querySelector(".mobile-menu-toggle")

        if(toggle){
            toggle.setAttribute("aria-expanded","false")
            toggle.setAttribute("aria-label",tx("openNavigation"))
        }
    }

    const openMobileMenu=()=>{
        document.body.classList.add("nav-open")
        const toggle=document.querySelector(".mobile-menu-toggle")

        if(toggle){
            toggle.setAttribute("aria-expanded","true")
            toggle.setAttribute("aria-label",tx("closeNavigation"))
        }
    }

    if(sidebar && !document.querySelector(".mobile-menu-toggle")){
        const toggle=document.createElement("button")
        toggle.type="button"
        toggle.className="mobile-menu-toggle"
        toggle.setAttribute("aria-label",tx("openNavigation"))
        toggle.setAttribute("aria-expanded","false")
        toggle.innerHTML="<span></span>"

        const backdrop=document.createElement("div")
        backdrop.className="mobile-nav-backdrop"

        document.body.appendChild(toggle)
        document.body.appendChild(backdrop)

        toggle.addEventListener("click",()=>{
            if(document.body.classList.contains("nav-open")){
                closeMobileMenu()
            }else{
                openMobileMenu()
            }
        })

        backdrop.addEventListener("click",closeMobileMenu)

        sidebar.querySelectorAll("a.nav-item,a.logout").forEach(link=>{
            link.addEventListener("click",closeMobileMenu)
        })
    }

    if(preloadScreen){
        document.body.classList.add("preloading")
    }

    const escapeHtml=value=>{
        return String(value ?? "").replace(/[&<>"']/g,character=>({
            "&":"&amp;",
            "<":"&lt;",
            ">":"&gt;",
            "\"":"&quot;",
            "'":"&#39;"
        })[character])
    }

    const loaderMarkup=`
        <div class="preload-hero">
            <h1>${escapeHtml(systemName)}</h1>
            <div class="preload-line">
                <span></span>
            </div>
        </div>
    `

    const hidePreload=()=>{
        const loader=document.getElementById("preloadScreen")

        if(!loader){
            document.body.classList.add("loaded")
            return
        }

        loader.classList.add("loaded")
        document.body.classList.remove("preloading")
        document.body.classList.add("loaded")

        setTimeout(()=>{
            if(loader.parentNode){
                loader.remove()
            }
        },420)
    }

    if(preloadScreen){
        window.addEventListener("load",()=>{
            setTimeout(hidePreload,650)
        })

        setTimeout(hidePreload,2600)
    }else{
        document.body.classList.add("loaded")
    }

    if(loginForm){
        loginForm.addEventListener("submit",event=>{
            if(event.defaultPrevented){
                return
            }

            event.preventDefault()

            let loader=document.getElementById("preloadScreen")

            if(!loader){
                loader=document.createElement("div")
                loader.className="preload-screen"
                loader.id="preloadScreen"
                loader.innerHTML=loaderMarkup
                document.body.appendChild(loader)
            }else if(!loader.querySelector(".preload-hero")){
                loader.innerHTML=loaderMarkup
            }

            document.body.classList.add("preloading")
            loader.classList.remove("loaded")

            requestAnimationFrame(()=>{
                requestAnimationFrame(()=>{
                    HTMLFormElement.prototype.submit.call(loginForm)
                })
            })
        })
    }

    const toggleRoleFields=()=>{
        document.querySelectorAll("[data-role-form]").forEach(form=>{
            const roleField=form.querySelector("[data-role-select]")
            const role=roleField ? roleField.value : ""

            form.querySelectorAll("[data-role-field]").forEach(field=>{
                const allowed=(field.dataset.roleField || "").split(" ").filter(Boolean)
                const show=allowed.includes(role)

                field.classList.toggle("is-hidden",!show)

                field.querySelectorAll("input,select,textarea").forEach(input=>{
                    if(show){
                        input.removeAttribute("disabled")
                    }else{
                        input.setAttribute("disabled","disabled")

                        if(input.tagName==="SELECT"){
                            input.selectedIndex=0
                        }else{
                            input.value=""
                        }
                    }
                })
            })
        })
    }

    document.querySelectorAll("[data-role-select]").forEach(select=>{
        select.addEventListener("change",toggleRoleFields)
    })

    toggleRoleFields()

    const toggleCompetencyFields=()=>{
        document.querySelectorAll("form").forEach(form=>{
            const type=form.querySelector("[data-assessment-type]")
            const fields=form.querySelectorAll("[data-competency-field]")

            if(!type || !fields.length){
                return
            }

            const show=type.value==="Competency Check"

            fields.forEach(field=>{
                field.classList.toggle("is-hidden",!show)

                field.querySelectorAll("input,select,textarea").forEach(input=>{
                    if(show){
                        input.removeAttribute("disabled")
                    }else{
                        input.setAttribute("disabled","disabled")
                        input.value=""
                    }
                })
            })
        })
    }

    document.querySelectorAll("[data-assessment-type]").forEach(select=>{
        select.addEventListener("change",toggleCompetencyFields)
    })

    toggleCompetencyFields()

    const updateTaskWeightFields=()=>{
        document.querySelectorAll("form").forEach(form=>{
            const category=form.querySelector("[data-task-category-select]")
            const display=form.querySelector("[data-task-weight-display]")
            const hidden=form.querySelector("[data-task-weight-hidden]")

            if(!category || !display){
                return
            }

            const selected=category.options[category.selectedIndex]
            const weight=selected ? selected.dataset.weight || "1" : "1"

            display.value=weight

            if(hidden){
                hidden.value=weight
            }
        })
    }

    document.querySelectorAll("[data-task-category-select]").forEach(select=>{
        select.addEventListener("change",updateTaskWeightFields)
    })

    updateTaskWeightFields()

    const cards=[...document.querySelectorAll(".kpi,.card,.task,.course-card,.course-tab,.panel,.clean-panel,.simple-summary-card,.weekly-day-card,.monitor-card,.profile-card,.activity-panel,.activity-task-item,.task-workload-overview,.task-focus-card,.compact-task-card,.task-adjust-choice,.record-history-card,.validation-compact-summary,.validation-search-panel")]

    const observer=new IntersectionObserver(entries=>{
        entries.forEach(entry=>{
            if(entry.isIntersecting){
                entry.target.classList.add("is-visible")
                observer.unobserve(entry.target)
            }
        })
    },{threshold:.08})

    cards.forEach((card,index)=>{
        card.style.animationDelay=`${Math.min(index*28,320)}ms`
        observer.observe(card)
    })

    document.querySelectorAll(".table tbody tr,table tbody tr").forEach(row=>{
        row.addEventListener("mouseenter",()=>row.classList.add("row-active"))
        row.addEventListener("mouseleave",()=>row.classList.remove("row-active"))
    })

    document.querySelectorAll(".field input,.field select,.field textarea").forEach(input=>{
        input.addEventListener("focus",()=>input.closest(".field")?.classList.add("field-active"))
        input.addEventListener("blur",()=>input.closest(".field")?.classList.remove("field-active"))
    })

    const cleanPage=value=>{
        return (value || "").replace(/\.php$/,"").replace(/^index$/,"")
    }

    const normalize=value=>{
        const a=document.createElement("a")
        a.href=value

        const page=cleanPage(a.pathname.split("/").pop())
        const hash=a.hash || ""

        return page+hash
    }

    const setActiveNav=()=>{
        const currentPage=cleanPage(window.location.pathname.split("/").pop())
        const currentHash=window.location.hash || ""
        const current=currentPage+currentHash

        document.querySelectorAll(".nav-list a").forEach(link=>{
            const target=normalize(link.getAttribute("href"))
            const targetPage=target.split("#")[0]
            const targetHash=target.includes("#") ? "#"+target.split("#")[1] : ""

            link.classList.remove("active")

            if(current===target){
                link.classList.add("active")
            }else if(!currentHash && currentPage===targetPage && !targetHash){
                link.classList.add("active")
            }
        })

        if(currentHash){
            const exact=[...document.querySelectorAll(".nav-list a")].find(link=>normalize(link.getAttribute("href"))===current)

            if(exact){
                document.querySelectorAll(".nav-list a").forEach(link=>link.classList.remove("active"))
                exact.classList.add("active")
            }
        }
    }

    setActiveNav()
    window.addEventListener("hashchange",setActiveNav)

    document.querySelectorAll('a[href^="#"],a[href*=".php#"],a[href*="#"]').forEach(link=>{
        link.addEventListener("click",event=>{
            const href=link.getAttribute("href")
            const hash=href.includes("#") ? "#"+href.split("#")[1] : ""
            const page=cleanPage(href.split("#")[0].split("/").pop())
            const currentPage=cleanPage(window.location.pathname.split("/").pop())

            if(hash && (!page || page===currentPage)){
                const target=document.querySelector(hash)

                if(target){
                    event.preventDefault()
                    history.pushState(null,"",hash)
                    setActiveNav()
                    closeMobileMenu()
                    target.scrollIntoView({behavior:"smooth",block:"start"})
                }
            }
        })
    })

    document.querySelectorAll("[data-scroll-target]").forEach(button=>{
        button.addEventListener("click",()=>{
            const target=document.getElementById(button.dataset.scrollTarget)

            if(target){
                document.querySelectorAll("[data-scroll-target]").forEach(item=>item.classList.remove("active"))
                button.classList.add("active")
                closeMobileMenu()
                target.scrollIntoView({behavior:"smooth",block:"start"})
            }
        })
    })

    document.querySelectorAll("button[value='delete'],button[name='action'][value='delete'],button[name='taskAction'][value='delete']").forEach(button=>{
        button.addEventListener("click",event=>{
            const confirmationKey=button.classList.contains("record-delete-btn")
                ? "deleteAcademicRecord"
                : "deleteRecord"

            if(!confirm(tx(confirmationKey))){
                event.preventDefault()
            }
        })
    })

    document.querySelectorAll("button[name='action'][value='requestDelete']").forEach(button=>{
        button.addEventListener("click",event=>{
            const form=button.closest("form")
            const reason=form?.querySelector("textarea[name='reason'],input[name='reason']")

            if(reason && reason.value.trim()===""){
                event.preventDefault()
                reason.setCustomValidity(tx("deleteReasonRequired"))
                reason.reportValidity()
                reason.focus()
                return
            }

            if(reason){
                reason.setCustomValidity("")
            }

            if(!confirm(tx("requestDelete"))){
                event.preventDefault()
            }
        })
    })

    document.querySelectorAll("textarea[name='reason'],input[name='reason']").forEach(reason=>{
        const form=reason.closest("form")
        const requestButton=form?.querySelector("button[name='action'][value='requestDelete']")

        if(!requestButton){
            return
        }

        reason.addEventListener("input",()=>{
            if(reason.value.trim()!==""){
                reason.setCustomValidity("")
            }
        })
    })

    document.querySelectorAll("button[name='action'][value='deleteAnnouncement']").forEach(button=>{
        button.addEventListener("click",event=>{
            if(!confirm(tx("deleteAnnouncement"))){
                event.preventDefault()
            }
        })
    })

    document.querySelectorAll("button[name='action'][value='restoreBackup']").forEach(button=>{
        button.addEventListener("click",event=>{
            if(!confirm(tx("restoreBackup"))){
                event.preventDefault()
            }
        })
    })

    document.querySelectorAll("[data-tab-target]").forEach(button=>{
        button.addEventListener("click",()=>{
            const group=button.dataset.tabGroup
            const target=button.dataset.tabTarget

            document.querySelectorAll(`[data-tab-group="${group}"]`).forEach(item=>item.classList.remove("active"))
            document.querySelectorAll(`[data-tab-panel-group="${group}"]`).forEach(panel=>panel.classList.remove("active"))

            button.classList.add("active")

            const targetPanel=document.querySelector(
                `[data-tab-panel-group="${group}"][data-tab-panel="${target}"]`
            )

            targetPanel?.classList.add("active")

            if(targetPanel){
                requestAnimationFrame(()=>{
                    targetPanel.getBoundingClientRect()

                    targetPanel.querySelectorAll(
                        ".weekly-calendar-grid,.month-calendar-grid,.mini-calendar,.attendance-summary-grid"
                    ).forEach(container=>{
                        if("scrollLeft" in container){
                            container.scrollLeft=0
                        }
                    })
                })
            }
        })
    })

    const closeMenus=()=>{
        document.querySelectorAll(".popup-menu.open").forEach(menu=>{
            const owner=menu.dataset.ownerButton || ""

            menu.classList.remove("open")
            menu.style.position=""
            menu.style.left=""
            menu.style.top=""
            menu.style.right=""
            menu.style.bottom=""
            menu.style.width=""
            menu.style.maxHeight=""
            menu.style.overflowY=""
            menu.style.zIndex=""

            if(owner){
                const button=document.querySelector(`[data-menu-button="${owner}"]`)
                const originalParent=button?.parentElement

                if(originalParent && menu.parentElement===document.body){
                    originalParent.appendChild(menu)
                }

                delete menu.dataset.ownerButton
            }
        })
    }

    const positionMenu=(button,menu)=>{
        if(menu.parentElement!==document.body){
            document.body.appendChild(menu)
        }

        const id=button.dataset.menuButton || ""
        menu.dataset.ownerButton=id
        menu.classList.add("open")

        menu.style.position="fixed"
        menu.style.width="220px"
        menu.style.maxHeight="280px"
        menu.style.overflowY="auto"
        menu.style.zIndex="9999"
        menu.style.right="auto"
        menu.style.bottom="auto"

        const rect=button.getBoundingClientRect()
        const menuRect=menu.getBoundingClientRect()
        const gap=8

        let left=rect.right-menuRect.width
        let top=rect.bottom+gap

        if(left<12){
            left=12
        }

        if(left+menuRect.width>window.innerWidth-12){
            left=window.innerWidth-menuRect.width-12
        }

        if(top+menuRect.height>window.innerHeight-12){
            top=rect.top-menuRect.height-gap
        }

        if(top<12){
            top=12
        }

        menu.style.left=`${left}px`
        menu.style.top=`${top}px`
    }

    document.querySelectorAll("[data-menu-button]").forEach(button=>{
        button.addEventListener("click",event=>{
            event.preventDefault()
            event.stopPropagation()

            const id=button.dataset.menuButton
            const menu=document.querySelector(`[data-menu="${id}"]`)

            if(!menu){
                return
            }

            const wasOpen=menu.classList.contains("open")

            closeMenus()

            if(!wasOpen){
                requestAnimationFrame(()=>{
                    positionMenu(button,menu)
                })
            }
        })
    })

    document.addEventListener("click",closeMenus)

    document.querySelectorAll(".popup-menu").forEach(menu=>{
        menu.addEventListener("click",event=>event.stopPropagation())
    })

    window.addEventListener("resize",()=>{
        closeMenus()

        if(window.innerWidth>860){
            closeMobileMenu()
        }
    })

    window.addEventListener("scroll",closeMenus,true)

    const modalStore=new Map()
    const modalTriggerStore=new WeakMap()

    const moveModalToBody=modal=>{
        if(!modalStore.has(modal)){
            const placeholder=document.createComment("modal-placeholder")
            const parent=modal.parentNode

            if(parent){
                parent.insertBefore(placeholder,modal)
                modalStore.set(modal,{parent,placeholder})
            }
        }

        if(modal.parentElement!==document.body){
            document.body.appendChild(modal)
        }
    }

    const restoreModalPosition=modal=>{
        const stored=modalStore.get(modal)

        if(stored && stored.parent && stored.placeholder && stored.placeholder.parentNode){
            stored.parent.insertBefore(modal,stored.placeholder)
            stored.placeholder.remove()
            modalStore.delete(modal)
        }
    }

    const clearSensitiveModalFields=modal=>{
        modal.querySelectorAll("input[data-password-field-ready='true'],input[type='password']").forEach(input=>{
            input.value=""

            const host=input.closest(".password-input-wrap")
            const button=host?.querySelector("[data-password-toggle]")

            if(button){
                resetPasswordVisibility(input,button)
            }else{
                input.type="password"
            }
        })
    }

    const closeModal=(modal,restoreFocus=true)=>{
        if(!modal){
            return
        }

        const trigger=modalTriggerStore.get(modal)

        modal.classList.remove("open")
        modal.setAttribute("aria-hidden","true")
        clearSensitiveModalFields(modal)
        restoreModalPosition(modal)
        modalTriggerStore.delete(modal)

        if(!document.querySelector(".modal-shell.open")){
            document.body.classList.remove("modal-open")
        }

        if(restoreFocus && trigger && document.contains(trigger)){
            setTimeout(()=>trigger.focus({preventScroll:true}),0)
        }
    }

    const closeModals=()=>{
        document.querySelectorAll(".modal-shell.open").forEach(modal=>{
            closeModal(modal,false)
        })

        document.body.classList.remove("modal-open")
        closeMenus()
    }

    const openModal=(modal,trigger=null)=>{
        closeMenus()
        closeMobileMenu()
        moveModalToBody(modal)

        if(trigger){
            modalTriggerStore.set(modal,trigger)
        }

        modal.classList.add("open")
        modal.setAttribute("aria-hidden","false")
        document.body.classList.add("modal-open")

        const card=modal.querySelector(".modal-card")
        const preferredFocus=modal.querySelector(
            "[autofocus],input:not([type='hidden']):not([disabled]),textarea:not([disabled]),select:not([disabled])"
        )
        const fallbackFocus=modal.querySelector(
            "button:not([disabled]),a[href]"
        )
        const firstFocusable=preferredFocus || fallbackFocus

        if(card){
            card.scrollTop=0
        }

        if(firstFocusable){
            setTimeout(()=>firstFocusable.focus({preventScroll:true}),80)
        }
    }

    document.querySelectorAll("[data-modal-open]").forEach(button=>{
        button.addEventListener("click",event=>{
            event.preventDefault()
            event.stopPropagation()

            const id=button.dataset.modalOpen
            const modal=document.querySelector(`[data-modal="${id}"]`)

            if(modal){
                openModal(modal,button)
            }
        })
    })

    document.querySelectorAll("[data-modal-close]").forEach(button=>{
        button.addEventListener("click",()=>{
            closeModal(button.closest(".modal-shell"))
        })
    })

    document.querySelectorAll(".modal-shell").forEach(modal=>{
        modal.setAttribute("aria-hidden","true")

        modal.addEventListener("click",event=>{
            if(event.target===modal){
                closeModal(modal)
            }
        })
    })

    const announcementPopup=document.querySelector("[data-announcement-popup]")

    if(announcementPopup){
        const announcementContent=announcementPopup.querySelector(".record-guidance-strip")
        const announcementText=(
            announcementContent?.textContent ||
            announcementPopup.textContent ||
            ""
        ).replace(/\s+/g," ").trim()

        let announcementHash=0

        for(let index=0;index<announcementText.length;index++){
            announcementHash=((announcementHash<<5)-announcementHash)+announcementText.charCodeAt(index)
            announcementHash|=0
        }

        const announcementDismissKey=`kaakbay-announcement-dismissed-${Math.abs(announcementHash)}`
        let announcementDismissed=false

        try{
            announcementDismissed=sessionStorage.getItem(announcementDismissKey)==="1"
        }catch(error){
            announcementDismissed=false
        }

        if(announcementDismissed){
            announcementPopup.classList.remove("open")
            announcementPopup.setAttribute("aria-hidden","true")
            restoreModalPosition(announcementPopup)

            if(!document.querySelector(".modal-shell.open")){
                document.body.classList.remove("modal-open")
            }
        }else{
            openModal(announcementPopup)
        }

        announcementPopup.querySelectorAll("[data-modal-close]").forEach(button=>{
            button.addEventListener("click",()=>{
                try{
                    sessionStorage.setItem(announcementDismissKey,"1")
                }catch(error){
                }
            })
        })
    }

    document.addEventListener("keydown",event=>{
        if(event.key==="Escape"){
            closeModals()
            closeMobileMenu()
        }

        if(event.key==="Tab"){
            const modal=document.querySelector(".modal-shell.open")

            if(!modal){
                return
            }

            const focusable=[...modal.querySelectorAll("button,input,select,textarea,a[href]")].filter(item=>{
                return !item.hasAttribute("disabled") && item.offsetParent!==null
            })

            if(!focusable.length){
                return
            }

            const first=focusable[0]
            const last=focusable[focusable.length-1]

            if(event.shiftKey && document.activeElement===first){
                event.preventDefault()
                last.focus()
            }else if(!event.shiftKey && document.activeElement===last){
                event.preventDefault()
                first.focus()
            }
        }
    })

    const taskFilters=document.querySelectorAll("[data-task-filter]")
    const taskCards=document.querySelectorAll("[data-task-card]")

    const applyTaskFilter=filter=>{
        taskCards.forEach(card=>{
            const status=(card.dataset.taskStatus || "").toLowerCase()
            const priority=(card.dataset.taskPriority || "").toLowerCase()
            const focus=(card.dataset.taskFocus || "").toLowerCase()
            const title=(card.dataset.taskTitle || "").toLowerCase()
            const subject=(card.dataset.taskSubject || "").toLowerCase()
            const source=`${status} ${priority} ${focus} ${title} ${subject}`
            const show=filter==="all" || source.split(" ").includes(filter) || source.includes(filter)

            card.classList.toggle("is-hidden",!show)
        })
    }

    taskFilters.forEach(button=>{
        button.addEventListener("click",()=>{
            const filter=(button.dataset.taskFilter || "all").toLowerCase()

            taskFilters.forEach(item=>item.classList.remove("active"))
            button.classList.add("active")
            applyTaskFilter(filter)
        })
    })

    const activeTaskFilter=document.querySelector("[data-task-filter].active")

    if(activeTaskFilter){
        applyTaskFilter((activeTaskFilter.dataset.taskFilter || "all").toLowerCase())
    }else if(taskFilters.length){
        applyTaskFilter("all")
    }

    const recordFilters=document.querySelectorAll("[data-record-filter]")
    const recordCards=document.querySelectorAll("[data-record-card]")

    const applyRecordFilter=filter=>{
        const normalizedFilter=(filter || "all").toLowerCase()

        recordCards.forEach(card=>{
            const mode=(card.dataset.recordMode || "").toLowerCase()
            const show=normalizedFilter==="all" || mode===normalizedFilter

            card.classList.toggle("is-hidden",!show)
        })
    }

    recordFilters.forEach(button=>{
        button.addEventListener("click",()=>{
            const filter=button.dataset.recordFilter || "all"

            recordFilters.forEach(item=>item.classList.remove("active"))
            button.classList.add("active")
            applyRecordFilter(filter)
        })
    })

    const activeRecordFilter=document.querySelector("[data-record-filter].active")

    if(activeRecordFilter){
        applyRecordFilter(activeRecordFilter.dataset.recordFilter || "all")
    }

    document.querySelectorAll("details.routine-collapse").forEach(details=>{
        details.addEventListener("toggle",()=>{
            if(details.open){
                setTimeout(()=>{
                    details.scrollIntoView({behavior:"smooth",block:"start"})
                },80)
            }
        })
    })

    document.querySelectorAll("details.record-delete-request").forEach(details=>{
        details.addEventListener("toggle",()=>{
            if(details.open){
                setTimeout(()=>{
                    details.scrollIntoView({behavior:"smooth",block:"nearest"})
                    const textarea=details.querySelector("textarea")

                    if(textarea){
                        textarea.focus({preventScroll:true})
                    }
                },80)
            }
        })
    })

    document.querySelectorAll("input[name='otp'],input[name='otpCode'],input[autocomplete='one-time-code']").forEach(input=>{
        const normalizeOtp=()=>{
            input.value=input.value.replace(/\D+/g,"").slice(0,6)
            input.setCustomValidity("")
        }

        input.addEventListener("input",normalizeOtp)
        input.addEventListener("paste",()=>setTimeout(normalizeOtp,0))

        const form=input.closest("form")

        if(form){
            form.addEventListener("submit",event=>{
                normalizeOtp()

                if(input.value.length!==6){
                    event.preventDefault()
                    input.setCustomValidity(tx("otpLength"))
                    input.reportValidity()
                    input.focus()
                }
            })
        }
    })

    document.querySelectorAll("[data-otp-resend-button]").forEach(button=>{
        if(button.dataset.otpResendReady==="true"){
            return
        }

        const countdown=button.querySelector("[data-otp-resend-countdown]")
        const initialSeconds=Math.max(
            0,
            Number.parseInt(button.dataset.otpResendSeconds || "0",10) || 0
        )

        button.dataset.otpResendReady="true"

        if(
            initialSeconds>0 &&
            countdown &&
            countdown.textContent.trim()!==""
        ){
            return
        }

        let remaining=initialSeconds
        let timer=null

        const formatRemaining=seconds=>{
            const safeSeconds=Math.max(0,Number.parseInt(seconds,10) || 0)

            if(safeSeconds<60){
                return `${safeSeconds}s`
            }

            const minutes=Math.floor(safeSeconds/60)
            const secondsPart=safeSeconds%60

            return `${minutes}m ${String(secondsPart).padStart(2,"0")}s`
        }

        const renderResendState=()=>{
            const waiting=remaining>0

            button.disabled=waiting
            button.setAttribute("aria-disabled",waiting ? "true" : "false")

            if(countdown){
                countdown.textContent=waiting
                    ? ` (${formatRemaining(remaining)})`
                    : ""
            }
        }

        renderResendState()

        if(remaining<=0){
            return
        }

        timer=window.setInterval(()=>{
            remaining=Math.max(0,remaining-1)
            renderResendState()

            if(remaining<=0 && timer){
                window.clearInterval(timer)
                timer=null
            }
        },1000)

        window.addEventListener("pagehide",()=>{
            if(timer){
                window.clearInterval(timer)
                timer=null
            }
        },{once:true})
    })

    document.querySelectorAll("form").forEach(form=>{
        const newPassword=form.querySelector("input[name='newPassword']")
        const confirmation=form.querySelector(
            "input[name='confirmPassword'],input[name='confirmNewPassword']"
        )

        if(!newPassword || !confirmation){
            return
        }

        const syncPasswordConfirmation=()=>{
            const mismatch=confirmation.value!=="" && newPassword.value!==confirmation.value
            confirmation.setCustomValidity(mismatch ? tx("passwordMismatch") : "")
        }

        newPassword.addEventListener("input",syncPasswordConfirmation)
        confirmation.addEventListener("input",syncPasswordConfirmation)

        form.addEventListener("submit",event=>{
            syncPasswordConfirmation()

            if(!confirmation.checkValidity()){
                event.preventDefault()
                confirmation.reportValidity()
                confirmation.focus()
            }
        })
    })

    document.querySelectorAll("form").forEach(form=>{
        const reason=form.querySelector("textarea[name='reason']")

        if(!reason){
            return
        }

        reason.addEventListener("input",()=>{
            reason.setCustomValidity("")
        })

        form.addEventListener("submit",event=>{
            const submitter=event.submitter || document.activeElement
            const isTaskRemoval=submitter &&
                submitter.name==="taskAction" &&
                (submitter.value==="remove" || submitter.value==="cancel")

            if(!isTaskRemoval){
                return
            }

            reason.value=reason.value.trim()

            if(reason.value===""){
                event.preventDefault()
                reason.setCustomValidity(tx("taskRemovalReason"))
                reason.reportValidity()
                reason.focus()
            }
        })
    })

    document.querySelectorAll("form").forEach(form=>{
        form.addEventListener("submit",event=>{
            if(event.defaultPrevented){
                return
            }

            const submitter=event.submitter || document.activeElement

            if(submitter && submitter.matches("button[type='submit'],button:not([type])")){
                if(submitter.name && submitter.value){
                    let preserved=form.querySelector(`input[type="hidden"][data-submit-preserve="${submitter.name}"]`)

                    if(!preserved){
                        preserved=document.createElement("input")
                        preserved.type="hidden"
                        preserved.name=submitter.name
                        preserved.dataset.submitPreserve=submitter.name
                        form.appendChild(preserved)
                    }

                    preserved.value=submitter.value
                }

                submitter.classList.add("is-loading")
                submitter.dataset.submitLocked="true"
                submitter.disabled=true

                setTimeout(()=>{
                    submitter.classList.remove("is-loading")

                    if(submitter.dataset.submitLocked==="true"){
                        delete submitter.dataset.submitLocked
                        submitter.disabled=false
                    }
                },3000)
            }
        })
    })

    window.addEventListener("pageshow",()=>{
        document.querySelectorAll("[data-submit-locked='true']").forEach(button=>{
            delete button.dataset.submitLocked
            button.disabled=false
            button.classList.remove("is-loading")
        })
    })

    const initializePriorityGuidance=()=>{
        const dataElement=document.getElementById("priorityGuidanceData")
        const panel=document.querySelector("[data-priority-guidance-dynamic]")
        const select=document.querySelector("[data-priority-guidance-select]")

        if(!dataElement || !panel || !select){
            return
        }

        let items=[]

        try{
            items=JSON.parse(dataElement.textContent || "[]")
        }catch(error){
            items=[]
        }

        if(!Array.isArray(items) || !items.length){
            return
        }

        const cleanText=value=>String(value ?? "").replace(/[–—]/g,"-")

        const stateClass=value=>{
            const text=cleanText(value).toLowerCase()

            if(
                text.includes("at-risk") ||
                text.includes("failing") ||
                text.includes("concern") ||
                text.includes("mabigat") ||
                text.includes("overdue") ||
                text.includes("not mastered") ||
                text.includes("remediation") ||
                text.includes("critical") ||
                text.includes("not consistent") ||
                text.includes("incomplete") ||
                text.includes("declining") ||
                text.includes("high risk")
            ){
                return "danger"
            }

            if(
                text.includes("warning") ||
                text.includes("nearing") ||
                text.includes("katamtaman") ||
                text.includes("risk") ||
                text.includes("needs") ||
                text.includes("high") ||
                text.includes("medium")
            ){
                return "warning"
            }

            return "good"
        }

        const makeBadge=value=>{
            const item=document.createElement("span")
            item.className=`status ${stateClass(value)}`
            item.textContent=cleanText(value || "No Record")
            return item
        }

        const makeText=value=>{
            const item=document.createElement("p")
            item.textContent=cleanText(value)
            return item
        }

        const makeAdviceCard=(value,index)=>{
            const labels=[
                panel.dataset.labelStart || "Start Here",
                panel.dataset.labelNext || "Next Step",
                panel.dataset.labelAdjustment || "Adjustment"
            ]

            const card=document.createElement("div")
            card.className="recommendation-card"

            const icon=document.createElement("div")
            icon.className="recommendation-icon"
            icon.textContent=String(index+2)

            const body=document.createElement("div")
            const title=document.createElement("strong")
            title.textContent=labels[index] || labels[2] || "Adjustment"

            const paragraph=document.createElement("p")
            paragraph.textContent=cleanText(value)

            body.appendChild(title)
            body.appendChild(paragraph)
            card.appendChild(icon)
            card.appendChild(body)

            return card
        }

        const syncPriorityGuidance=()=>{
            const index=Number.parseInt(select.value,10)
            const item=items[Number.isNaN(index) ? 0 : index] || items[0] || {}

            const subject=panel.querySelector("[data-priority-subject]")
            const risk=panel.querySelector("[data-priority-risk]")
            const grade=panel.querySelector("[data-priority-grade]")
            const academic=panel.querySelector("[data-priority-academic]")
            const competency=panel.querySelector("[data-priority-competency]")
            const attendance=panel.querySelector("[data-priority-attendance]")
            const warnings=panel.querySelector("[data-priority-warnings]")
            const advice=panel.querySelector("[data-priority-advice]")

            const noWarning=panel.dataset.labelNoWarning || "No warning for this subject."

            if(subject){
                subject.textContent=cleanText(item.subject || "Subject")
            }

            if(risk){
                risk.innerHTML=""
                risk.appendChild(makeBadge(item.riskForecast || "No Record"))
            }

            if(grade){
                grade.textContent=cleanText(item.computedGrade ?? "0")
            }

            if(academic){
                academic.textContent=cleanText(item.academicStatus || "No Record")
            }

            if(competency){
                competency.textContent=cleanText(item.competencyStatus || "No Record")
            }

            if(attendance){
                attendance.textContent=cleanText(item.attendanceStatus || "No Record")
            }

            if(warnings){
                warnings.innerHTML=""

                const warningList=Array.isArray(item.warnings)
                    ? item.warnings
                    : []

                if(warningList.length){
                    warningList.forEach(warning=>{
                        warnings.appendChild(makeText(warning))
                    })
                }else{
                    warnings.appendChild(makeText(noWarning))
                }
            }

            if(advice){
                advice.innerHTML=""

                const adviceList=Array.isArray(item.advice)
                    ? item.advice.slice(0,3)
                    : []

                adviceList.forEach((guide,index)=>{
                    advice.appendChild(makeAdviceCard(guide,index))
                })
            }
        }

        if(!select.dataset.priorityGuidanceReady){
            select.dataset.priorityGuidanceReady="true"
            select.addEventListener("change",syncPriorityGuidance)
            select.addEventListener("input",syncPriorityGuidance)
            select.addEventListener("click",()=>setTimeout(syncPriorityGuidance,0))
            select.addEventListener("keyup",syncPriorityGuidance)
        }

        syncPriorityGuidance()
        setTimeout(syncPriorityGuidance,50)
        setTimeout(syncPriorityGuidance,250)
    }

    initializePriorityGuidance()

    document.addEventListener("change",event=>{
        if(event.target && event.target.matches("[data-priority-guidance-select]")){
            initializePriorityGuidance()
        }
    })

    document.addEventListener("input",event=>{
        if(event.target && event.target.matches("[data-priority-guidance-select]")){
            initializePriorityGuidance()
        }
    })

})