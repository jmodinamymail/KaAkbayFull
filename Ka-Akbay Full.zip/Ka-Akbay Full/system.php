<?php
require_once __DIR__ . "/app/security.php";
require_once __DIR__ . "/app/auth.php";
require_once __DIR__ . "/app/page_actions.php";
require_once __DIR__ . "/app/page_data.php";
require_once __DIR__ . "/app/layout.php";

require_it_admin();

$user = current_user();
$error = handle_page_action("system", $user);
$data = get_page_data("system", $user);

$health = $data["health"] ?? system_health_status();
$logs = $data["logs"] ?? latest_system_logs(100);
$backups = $data["backups"] ?? system_backups(30);
$maintenance = $data["maintenance"] ?? maintenance_settings_record();
$technical = function_exists("technical_settings_record")
    ? technical_settings_record()
    : [];
$sessionUsers = function_exists("read_records")
    ? read_records("users")
    : [];

$sessionUsers = array_values(array_filter($sessionUsers, function($account) use ($user) {
    return (string)($account["id"] ?? "") !== (string)($user["id"] ?? "");
}));

usort($sessionUsers, function($a, $b) {
    return strcasecmp((string)($a["name"] ?? ""), (string)($b["name"] ?? ""));
});

$privilegedOtpMonitoring = function_exists("privileged_otp_monitoring_for_it_admin")
    ? privileged_otp_monitoring_for_it_admin($user["id"])
    : [];

$privilegedOtpEvents = function_exists("privileged_otp_failure_events_for_it_admin")
    ? privileged_otp_failure_events_for_it_admin($user["id"], 50)
    : [];

$privilegedOtpLockedCount = count(array_filter(
    $privilegedOtpMonitoring,
    fn($row) => !empty($row["locked"])
));

$privilegedOtpFailedAttemptCount = array_sum(array_map(
    fn($row) => max(0, (int)($row["failedAttempts"] ?? 0)),
    $privilegedOtpMonitoring
));

$otpMaxSendsPerHour = function_exists("otp_max_sends_per_hour")
    ? otp_max_sends_per_hour()
    : (int)($technical["otpMaxSendsPerHour"] ?? 5);

$successMessage = "";

if (($_GET["backupRestored"] ?? "") === "1") {
    $successMessage = msg("Backup restored successfully.", "Matagumpay na na-restore ang backup.", "Backup restored successfully.");
} elseif (($_GET["backupDeleted"] ?? "") === "1") {
    $successMessage = msg("Backup deleted successfully.", "Matagumpay na na-delete ang backup.", "Backup deleted successfully.");
} elseif (($_GET["maintenanceSaved"] ?? "") === "1") {
    $successMessage = msg("Maintenance settings saved.", "Na-save ang maintenance settings.", "Maintenance settings saved.");
} elseif (($_GET["technicalSaved"] ?? "") === "1") {
    $successMessage = msg("Technical security settings saved.", "Na-save ang technical security settings.", "Technical security settings saved.");
} elseif (($_GET["sessionsRevoked"] ?? "") === "1") {
    $successMessage = msg("The selected user's sessions were revoked.", "Na-revoke ang sessions ng napiling user.", "The selected user's sessions were revoked.");
} elseif (($_GET["allSessionsRevoked"] ?? "") === "1") {
    $successMessage = msg("All other user sessions were revoked.", "Na-revoke ang sessions ng lahat ng ibang users.", "All other user sessions were revoked.");
}

function kaakbay_system_datetime_local($value) {
    $value = trim((string)$value);

    if ($value === "") {
        return "";
    }

    $time = strtotime($value);

    if (!$time) {
        return "";
    }

    return date("Y-m-d\TH:i", $time);
}

function kaakbay_system_date($value) {
    $value = trim((string)$value);

    if ($value === "") {
        return "--";
    }

    $time = strtotime($value);

    if (!$time) {
        return "--";
    }

    return date("M d, Y g:i A", $time);
}

function kaakbay_system_file_size($bytes) {
    $bytes = max(0, (int)$bytes);

    if ($bytes < 1024) {
        return $bytes . " B";
    }

    if ($bytes < 1048576) {
        return number_format($bytes / 1024, 1) . " KB";
    }

    if ($bytes < 1073741824) {
        return number_format($bytes / 1048576, 1) . " MB";
    }

    return number_format($bytes / 1073741824, 1) . " GB";
}

function kaakbay_system_backup_type_label($value) {
    $value = strtolower(trim((string)$value));

    if ($value === "pre_restore") {
        return "Pre-Restore";
    }

    if ($value === "manual") {
        return "Manual";
    }

    return $value !== ""
        ? ucwords(str_replace(["_", "-"], " ", $value))
        : "Backup";
}

page_head(
    msg(
        "System Management",
        "System Management",
        "System Management"
    )
);

sidebar("system", $user);
?>

<main class="main page-enter">
    <section class="topbar">
        <div>
            <h1>
                <?= e(msg(
                    "System Management",
                    "System Management",
                    "System Management"
                )) ?>
            </h1>
        </div>

        <div class="date">
            <?= e(msg(
                "IT Admin",
                "IT Admin",
                "IT Admin"
            )) ?>
        </div>
    </section>

    <div class="error <?= $error ? "show" : "" ?>">
        <?= e($error) ?>
    </div>

    <?php if ($successMessage !== ""): ?>
        <div class="password-change-success">
            <?= e($successMessage) ?>
        </div>
    <?php endif; ?>

    <section class="student-overview-card">
        <div class="student-overview-main">
            <span>
                <?= e(msg(
                    "SYSTEM STATUS",
                    "SYSTEM STATUS",
                    "SYSTEM STATUS"
                )) ?>
            </span>

            <h2>
                <?= e($health["status"] ?? "Operational") ?>
            </h2>

            <p>
                <?= e(msg(
                    "System health, maintenance, backups, and technical logs.",
                    "System health, maintenance, backups, and technical logs.",
                    "System health, maintenance, backups, and technical logs."
                )) ?>
            </p>
        </div>

        <div class="student-overview-status">
            <small>
                <?= e(msg(
                    "Database",
                    "Database",
                    "Database"
                )) ?>
            </small>

            <strong>
                <?= e($health["database"] ?? "Offline") ?>
            </strong>

            <?= badge(
                !empty($health["maintenanceMode"])
                    ? msg(
                        "Maintenance",
                        "Maintenance",
                        "Maintenance"
                    )
                    : msg(
                        "Operational",
                        "Operational",
                        "Operational"
                    )
            ) ?>
        </div>
    </section>

    <section class="simple-summary-grid">
        <div class="simple-summary-card">
            <span>
                <?= e(msg(
                    "Users",
                    "Users",
                    "Users"
                )) ?>
            </span>

            <strong>
                <?= e($health["userCount"] ?? 0) ?>
            </strong>
        </div>

        <div class="simple-summary-card">
            <span>
                <?= e(msg(
                    "System Logs",
                    "System Logs",
                    "System Logs"
                )) ?>
            </span>

            <strong>
                <?= e($health["systemLogCount"] ?? 0) ?>
            </strong>
        </div>

        <div class="simple-summary-card">
            <span>
                <?= e(msg(
                    "Backups",
                    "Backups",
                    "Backups"
                )) ?>
            </span>

            <strong>
                <?= e($health["backupCount"] ?? 0) ?>
            </strong>
        </div>

        <div class="simple-summary-card <?= !empty($health["errorsToday"]) ? "danger" : "good" ?>">
            <span>
                <?= e(msg(
                    "Errors Today",
                    "Errors Today",
                    "Errors Today"
                )) ?>
            </span>

            <strong>
                <?= e($health["errorsToday"] ?? 0) ?>
            </strong>
        </div>
    </section>

    <section class="card clean-panel section-space">
        <div class="clean-panel-head">
            <div>
                <h2>
                    <?= e(msg(
                        "Privileged OTP Security",
                        "Privileged OTP Security",
                        "Privileged OTP Security"
                    )) ?>
                </h2>
            </div>

            <?= badge(
                count($privilegedOtpMonitoring) . " " .
                msg(
                    "Tracked Accounts",
                    "Tracked Accounts",
                    "Tracked Accounts"
                )
            ) ?>
        </div>

        <div class="notice full">
            <?= e(msg(
                "OTP failure tracking applies only to Super Administrator and IT Administrator accounts. The IT Administrator can review failures and temporary OTP lockouts but cannot bypass or clear them from this page.",
                "Ang OTP failure tracking ay para lamang sa Super Administrator at IT Administrator accounts. Maaaring tingnan ng IT Administrator ang failures at temporary OTP lockouts ngunit hindi ito maaaring i-bypass o i-clear mula sa page na ito.",
                "OTP failure tracking applies only to Super Administrator and IT Administrator accounts. The IT Administrator can review failures and temporary OTP lockouts but cannot bypass or clear them from this page."
            )) ?>
        </div>

        <section class="simple-summary-grid section-space">
            <div class="simple-summary-card">
                <span><?= e(msg("Privileged Accounts", "Privileged Accounts", "Privileged Accounts")) ?></span>
                <strong><?= e(count($privilegedOtpMonitoring)) ?></strong>
            </div>

            <div class="simple-summary-card <?= $privilegedOtpLockedCount > 0 ? "danger" : "good" ?>">
                <span><?= e(msg("OTP-Locked", "OTP-Locked", "OTP-Locked")) ?></span>
                <strong><?= e($privilegedOtpLockedCount) ?></strong>
            </div>

            <div class="simple-summary-card <?= $privilegedOtpFailedAttemptCount > 0 ? "warning" : "good" ?>">
                <span><?= e(msg("Current Failed OTP Attempts", "Current Failed OTP Attempts", "Current Failed OTP Attempts")) ?></span>
                <strong><?= e($privilegedOtpFailedAttemptCount) ?></strong>
            </div>

            <div class="simple-summary-card <?= count($privilegedOtpEvents) > 0 ? "warning" : "good" ?>">
                <span><?= e(msg("Recent OTP Security Events", "Recent OTP Security Events", "Recent OTP Security Events")) ?></span>
                <strong><?= e(count($privilegedOtpEvents)) ?></strong>
            </div>
        </section>

        <div style="overflow-x:auto" class="section-space">
            <table class="table">
                <thead>
                    <tr>
                        <th><?= e(msg("ACCOUNT", "ACCOUNT", "ACCOUNT")) ?></th>
                        <th><?= e(msg("ROLE", "ROLE", "ROLE")) ?></th>
                        <th><?= e(msg("FAILED OTP", "FAILED OTP", "FAILED OTP")) ?></th>
                        <th><?= e(msg("REMAINING", "REMAINING", "REMAINING")) ?></th>
                        <th><?= e(msg("OTP SENDS", "OTP SENDS", "OTP SENDS")) ?></th>
                        <th><?= e(msg("STATUS", "STATUS", "STATUS")) ?></th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($privilegedOtpMonitoring as $otpAccount): ?>
                        <?php
                            $otpLocked = !empty($otpAccount["locked"]);
                            $otpFailures = max(0, (int)($otpAccount["failedAttempts"] ?? 0));
                            $otpSendCount = max(0, (int)($otpAccount["sendCount"] ?? 0));
                            $otpRetryAfter = max(0, (int)($otpAccount["sendRetryAfter"] ?? 0));
                        ?>
                        <tr>
                            <td>
                                <strong><?= e($otpAccount["name"] ?? "Privileged Account") ?></strong>
                                <?php if (!empty($otpAccount["code"])): ?>
                                    <br>
                                    <small><?= e($otpAccount["code"]) ?></small>
                                <?php endif; ?>
                            </td>

                            <td>
                                <?= e(
                                    function_exists("role_label")
                                        ? role_label($otpAccount["role"] ?? "")
                                        : ucwords(str_replace("_", " ", (string)($otpAccount["role"] ?? "")))
                                ) ?>
                            </td>

                            <td><?= e($otpFailures) ?></td>

                            <td><?= e(max(0, (int)($otpAccount["remainingAttempts"] ?? 0))) ?></td>

                            <td>
                                <?= e($otpSendCount . " / " . $otpMaxSendsPerHour) ?>
                                <?php if ($otpRetryAfter > 0): ?>
                                    <br>
                                    <small>
                                        <?= e(
                                            msg(
                                                "Retry in " . security_retry_text($otpRetryAfter),
                                                "Retry in " . security_retry_text($otpRetryAfter),
                                                "Retry in " . security_retry_text($otpRetryAfter)
                                            )
                                        ) ?>
                                    </small>
                                <?php endif; ?>
                            </td>

                            <td>
                                <?php if ($otpLocked): ?>
                                    <span class="status danger">
                                        <?= e(msg("OTP Locked", "OTP Locked", "OTP Locked")) ?>
                                    </span>
                                    <br>
                                    <small>
                                        <?= e(
                                            msg(
                                                "Until " . kaakbay_system_date($otpAccount["lockoutUntil"] ?? ""),
                                                "Hanggang " . kaakbay_system_date($otpAccount["lockoutUntil"] ?? ""),
                                                "Until " . kaakbay_system_date($otpAccount["lockoutUntil"] ?? "")
                                            )
                                        ) ?>
                                    </small>
                                <?php elseif ($otpFailures > 0): ?>
                                    <span class="status warning">
                                        <?= e(msg("Needs Attention", "Needs Attention", "Needs Attention")) ?>
                                    </span>
                                <?php else: ?>
                                    <span class="status good">
                                        <?= e(msg("Normal", "Normal", "Normal")) ?>
                                    </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                    <?php if (!count($privilegedOtpMonitoring)): ?>
                        <tr>
                            <td colspan="6">
                                <?= e(msg(
                                    "No privileged OTP monitoring data is available.",
                                    "Walang available na privileged OTP monitoring data.",
                                    "No privileged OTP monitoring data is available."
                                )) ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="clean-panel-head section-space">
            <div>
                <h3>
                    <?= e(msg(
                        "Recent Privileged OTP Events",
                        "Recent Privileged OTP Events",
                        "Recent Privileged OTP Events"
                    )) ?>
                </h3>
            </div>

            <?= badge(
                count($privilegedOtpEvents) . " " .
                msg("Recent", "Recent", "Recent")
            ) ?>
        </div>

        <div style="overflow-x:auto">
            <table class="table">
                <thead>
                    <tr>
                        <th><?= e(msg("EVENT", "EVENT", "EVENT")) ?></th>
                        <th><?= e(msg("ACCOUNT", "ACCOUNT", "ACCOUNT")) ?></th>
                        <th><?= e(msg("MESSAGE", "MESSAGE", "MESSAGE")) ?></th>
                        <th><?= e(msg("DATE", "DATE", "DATE")) ?></th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach (array_slice($privilegedOtpEvents, 0, 20) as $otpEvent): ?>
                        <?php
                            $otpEventUser = !empty($otpEvent["userId"])
                                ? find_user_by_id($otpEvent["userId"])
                                : null;
                            $otpAction = trim((string)($otpEvent["action"] ?? "OTP_EVENT"));
                        ?>
                        <tr>
                            <td>
                                <?= e(ucwords(strtolower(str_replace("_", " ", $otpAction)))) ?>
                            </td>

                            <td>
                                <?= e(
                                    ($otpEventUser["name"] ?? "")
                                        ?: ($otpEvent["userId"] ?? "--")
                                        ?: "--"
                                ) ?>
                            </td>

                            <td><?= e($otpEvent["message"] ?? "") ?></td>

                            <td>
                                <?= e(
                                    kaakbay_system_date(
                                        $otpEvent["createdAt"] ?? ""
                                    )
                                ) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                    <?php if (!count($privilegedOtpEvents)): ?>
                        <tr>
                            <td colspan="4">
                                <?= e(msg(
                                    "No privileged OTP failure events have been recorded.",
                                    "Wala pang naitalang privileged OTP failure events.",
                                    "No privileged OTP failure events have been recorded."
                                )) ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <section class="dashboard-focus-grid">
        <div class="card clean-panel">
            <div class="clean-panel-head">
                <div>
                    <h2>
                        <?= e(msg(
                            "System Health",
                            "System Health",
                            "System Health"
                        )) ?>
                    </h2>
                </div>
            </div>

            <div class="mini-stat-list vertical">
                <div>
                    <span>
                        <?= e(msg(
                            "Overall Status",
                            "Overall Status",
                            "Overall Status"
                        )) ?>
                    </span>

                    <strong>
                        <?= e($health["status"] ?? "--") ?>
                    </strong>
                </div>

                <div>
                    <span>
                        <?= e(msg(
                            "Database",
                            "Database",
                            "Database"
                        )) ?>
                    </span>

                    <strong>
                        <?= e($health["database"] ?? "--") ?>
                    </strong>
                </div>

                <div>
                    <span>
                        <?= e(msg(
                            "Last Backup",
                            "Last Backup",
                            "Last Backup"
                        )) ?>
                    </span>

                    <strong>
                        <?= e(
                            !empty($health["lastBackupAt"])
                                ? kaakbay_system_date($health["lastBackupAt"])
                                : msg(
                                    "No Backup",
                                    "No Backup",
                                    "No Backup"
                                )
                        ) ?>
                    </strong>
                </div>

                <div>
                    <span>
                        <?= e(msg(
                            "Last Backup Status",
                            "Last Backup Status",
                            "Last Backup Status"
                        )) ?>
                    </span>

                    <strong>
                        <?= e($health["lastBackupStatus"] ?? "No Backup") ?>
                    </strong>
                </div>

                <div>
                    <span>
                        <?= e(msg(
                            "Last Checked",
                            "Last Checked",
                            "Last Checked"
                        )) ?>
                    </span>

                    <strong>
                        <?= e(kaakbay_system_date($health["checkedAt"] ?? "")) ?>
                    </strong>
                </div>
            </div>
        </div>

        <div class="card clean-panel">
            <div class="clean-panel-head">
                <div>
                    <h2>
                        <?= e(msg(
                            "Maintenance Mode",
                            "Maintenance Mode",
                            "Maintenance Mode"
                        )) ?>
                    </h2>
                </div>

                <?= badge(
                    !empty($maintenance["enabled"])
                        ? msg(
                            "Enabled",
                            "Enabled",
                            "Enabled"
                        )
                        : msg(
                            "Disabled",
                            "Disabled",
                            "Disabled"
                        )
                ) ?>
            </div>

            <form method="POST" class="forms">
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e(csrf_token()) ?>"
                >

                <input
                    type="hidden"
                    name="action"
                    value="saveMaintenance"
                >

                <input
                    type="hidden"
                    name="enabled"
                    value="0"
                >

                <div class="field full">
                    <label>
                        <input
                            type="checkbox"
                            name="enabled"
                            value="1"
                            <?= !empty($maintenance["enabled"]) ? "checked" : "" ?>
                        >

                        <?= e(msg(
                            "Enable Maintenance Mode",
                            "Enable Maintenance Mode",
                            "Enable Maintenance Mode"
                        )) ?>
                    </label>
                </div>

                <div class="field full">
                    <label>
                        <?= e(msg(
                            "Maintenance Message",
                            "Maintenance Message",
                            "Maintenance Message"
                        )) ?>
                    </label>

                    <textarea
                        name="message"
                        maxlength="1000"
                    ><?= e($maintenance["message"] ?? "") ?></textarea>
                </div>

                <div class="field">
                    <label>
                        <?= e(msg(
                            "Start",
                            "Start",
                            "Start"
                        )) ?>
                    </label>

                    <input
                        type="datetime-local"
                        name="startAt"
                        value="<?= e(
                            kaakbay_system_datetime_local(
                                $maintenance["startAt"] ?? ""
                            )
                        ) ?>"
                    >
                </div>

                <div class="field">
                    <label>
                        <?= e(msg(
                            "End",
                            "End",
                            "End"
                        )) ?>
                    </label>

                    <input
                        type="datetime-local"
                        name="endAt"
                        value="<?= e(
                            kaakbay_system_datetime_local(
                                $maintenance["endAt"] ?? ""
                            )
                        ) ?>"
                    >
                </div>

                <div class="field full">
                    <label>
                        <?= e(msg(
                            "Current Password",
                            "Kasalukuyang Password",
                            "Current Password"
                        )) ?>
                    </label>

                    <input
                        type="password"
                        name="currentPassword"
                        autocomplete="current-password"
                        required
                    >
                </div>

                <div class="notice full">
                    <?= e(msg(
                        "Your current password is required before maintenance settings can be changed.",
                        "Kailangan ang kasalukuyang password bago baguhin ang maintenance settings.",
                        "Your current password is required before maintenance settings can be changed."
                    )) ?>
                </div>

                <div class="button-row full">
                    <button
                        class="btn btn-primary"
                        type="submit"
                    >
                        <?= e(msg(
                            "Save Maintenance",
                            "Save Maintenance",
                            "Save Maintenance"
                        )) ?>
                    </button>
                </div>
            </form>
        </div>
    </section>

    <section class="card clean-panel section-space">
        <div class="clean-panel-head">
            <div>
                <h2>
                    <?= e(msg(
                        "Backup & Restore",
                        "Backup & Restore",
                        "Backup & Restore"
                    )) ?>
                </h2>
            </div>

            <div>
                <?= badge(
                    count($backups) . " " .
                    msg(
                        "Backups",
                        "Backups",
                        "Backups"
                    )
                ) ?>
            </div>
        </div>

        <form method="POST" class="forms">
            <input
                type="hidden"
                name="csrf_token"
                value="<?= e(csrf_token()) ?>"
            >

            <input
                type="hidden"
                name="action"
                value="createBackup"
            >

            <div class="field full">
                <label>
                    <?= e(msg(
                        "Backup Label",
                        "Backup Label",
                        "Backup Label"
                    )) ?>
                </label>

                <input
                    name="label"
                    maxlength="120"
                    placeholder="<?= e(msg(
                        "Optional backup name",
                        "Optional backup name",
                        "Optional backup name"
                    )) ?>"
                >
            </div>

            <div class="button-row full">
                <button
                    class="btn btn-primary"
                    type="submit"
                >
                    <?= e(msg(
                        "Create Backup",
                        "Create Backup",
                        "Create Backup"
                    )) ?>
                </button>
            </div>
        </form>

        <div class="monitoring-grid section-space">
            <?php foreach ($backups as $index => $backup): ?>
                <?php
                    $backupId = $backup["id"] ?? "";
                    $backupLabel = trim(
                        (string)($backup["label"] ?? "")
                    );
                ?>

                <div class="monitor-card good">
                    <div class="monitor-card-top">
                        <div>
                            <span>
                                <?= e(
                                    kaakbay_system_backup_type_label(
                                        $backup["type"] ?? "manual"
                                    )
                                ) ?>
                            </span>

                            <h3>
                                <?= e(
                                    $backupLabel !== ""
                                        ? $backupLabel
                                        : msg(
                                            "System Backup",
                                            "System Backup",
                                            "System Backup"
                                        )
                                ) ?>
                            </h3>

                            <p>
                                <?= e(
                                    kaakbay_system_date(
                                        $backup["createdAt"] ?? ""
                                    )
                                ) ?>
                            </p>
                        </div>

                        <button
                            class="dot-action"
                            type="button"
                            data-menu-button="backup-<?= e($index) ?>"
                        >
                            •••
                        </button>

                        <div
                            class="popup-menu"
                            data-menu="backup-<?= e($index) ?>"
                        >
                            <button
                                type="button"
                                data-modal-open="restore-backup-<?= e($index) ?>"
                            >
                                <?= e(msg(
                                    "Restore Backup",
                                    "Restore Backup",
                                    "Restore Backup"
                                )) ?>
                            </button>

                            <button
                                type="button"
                                data-modal-open="delete-backup-<?= e($index) ?>"
                            >
                                <?= e(msg(
                                    "Delete Backup",
                                    "Delete Backup",
                                    "Delete Backup"
                                )) ?>
                            </button>
                        </div>
                    </div>

                    <div class="monitor-status-row">
                        <?= badge(
                            $backup["status"] ?? "Completed"
                        ) ?>
                    </div>

                    <div class="monitor-mini-grid">
                        <div>
                            <span>
                                <?= e(msg(
                                    "Tables",
                                    "Tables",
                                    "Tables"
                                )) ?>
                            </span>

                            <strong>
                                <?= e($backup["tableCount"] ?? 0) ?>
                            </strong>
                        </div>

                        <div>
                            <span>
                                <?= e(msg(
                                    "Records",
                                    "Records",
                                    "Records"
                                )) ?>
                            </span>

                            <strong>
                                <?= e($backup["recordCount"] ?? 0) ?>
                            </strong>
                        </div>

                        <div>
                            <span>
                                <?= e(msg(
                                    "Size",
                                    "Size",
                                    "Size"
                                )) ?>
                            </span>

                            <strong>
                                <?= e(
                                    kaakbay_system_file_size(
                                        $backup["sizeBytes"] ?? 0
                                    )
                                ) ?>
                            </strong>
                        </div>

                        <div>
                            <span>
                                <?= e(msg(
                                    "Status",
                                    "Status",
                                    "Status"
                                )) ?>
                            </span>

                            <strong>
                                <?= e(
                                    $backup["status"] ?? "--"
                                ) ?>
                            </strong>
                        </div>
                    </div>
                </div>

                <div
                    class="modal-shell"
                    data-modal="restore-backup-<?= e($index) ?>"
                >
                    <div class="modal-card">
                        <div class="modal-head">
                            <h3><?= e(msg("Restore Backup", "Restore Backup", "Restore Backup")) ?></h3>
                            <button type="button" data-modal-close>×</button>
                        </div>

                        <form method="POST" class="modal-body forms" autocomplete="off">
                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                            <input type="hidden" name="action" value="restoreBackup">
                            <input type="hidden" name="backupId" value="<?= e($backupId) ?>">

                            <div class="notice full">
                                <?= e(msg(
                                    "Restoring a backup replaces the backed-up system data. Ka-Akbay will first create an automatic pre-restore checkpoint, then revoke existing authentication sessions after a successful restore. Confirm your current password to continue.",
                                    "Papalitan ng restore ang naka-backup na system data. Gagawa muna ang Ka-Akbay ng automatic pre-restore checkpoint at pagkatapos ay ire-revoke ang existing authentication sessions kapag matagumpay ang restore. Kumpirmahin ang current password para magpatuloy.",
                                    "Restoring a backup replaces the backed-up system data. Ka-Akbay will first create an automatic pre-restore checkpoint, then revoke existing authentication sessions after a successful restore. Confirm your current password to continue."
                                )) ?>
                            </div>

                            <div class="field full">
                                <label><?= e(msg("Current Password", "Kasalukuyang Password", "Current Password")) ?></label>
                                <input type="password" name="currentPassword" autocomplete="current-password" required>
                            </div>

                            <div class="button-row full">
                                <button class="btn btn-primary" type="submit">
                                    <?= e(msg("Restore Backup", "Restore Backup", "Restore Backup")) ?>
                                </button>
                                <button class="btn btn-ghost" type="button" data-modal-close>
                                    <?= e(msg("Cancel", "Kanselahin", "Cancel")) ?>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <div
                    class="modal-shell"
                    data-modal="delete-backup-<?= e($index) ?>"
                >
                    <div class="modal-card">
                        <div class="modal-head">
                            <h3><?= e(msg("Delete Backup", "Delete Backup", "Delete Backup")) ?></h3>
                            <button type="button" data-modal-close>×</button>
                        </div>

                        <form method="POST" class="modal-body forms" autocomplete="off">
                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                            <input type="hidden" name="action" value="deleteBackup">
                            <input type="hidden" name="backupId" value="<?= e($backupId) ?>">

                            <div class="notice full">
                                <?= e(msg(
                                    "This permanently removes this stored backup. Confirm your current password to continue.",
                                    "Permanenteng buburahin nito ang backup. Kumpirmahin ang current password para magpatuloy.",
                                    "This permanently removes this stored backup. Confirm your current password to continue."
                                )) ?>
                            </div>

                            <div class="field full">
                                <label><?= e(msg("Current Password", "Kasalukuyang Password", "Current Password")) ?></label>
                                <input type="password" name="currentPassword" autocomplete="current-password" required>
                            </div>

                            <div class="button-row full">
                                <button class="btn btn-danger" type="submit">
                                    <?= e(msg("Delete Backup", "Delete Backup", "Delete Backup")) ?>
                                </button>
                                <button class="btn btn-ghost" type="button" data-modal-close>
                                    <?= e(msg("Cancel", "Kanselahin", "Cancel")) ?>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>

            <?php if (!count($backups)): ?>
                <div class="compact-empty">
                    <strong>
                        <?= e(msg(
                            "No backups yet",
                            "No backups yet",
                            "No backups yet"
                        )) ?>
                    </strong>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <section class="card clean-panel section-space">
        <div class="clean-panel-head">
            <div>
                <h2><?= e(msg("Technical Security Settings", "Technical Security Settings", "Technical Security Settings")) ?></h2>
            </div>
            <?= badge(msg("IT Admin", "IT Admin", "IT Admin")) ?>
        </div>

        <form method="POST" class="forms" autocomplete="off">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="saveTechnicalSettings">

            <div class="field">
                <label><?= e(msg("Session Timeout", "Session Timeout", "Session Timeout")) ?></label>
                <input value="30 minutes" readonly>
            </div>

            <div class="field">
                <label><?= e(msg("Active Session Policy", "Active Session Policy", "Active Session Policy")) ?></label>
                <input value="One active session per account" readonly>
            </div>

            <div class="field">
                <label><?= e(msg("Maximum Login Attempts", "Maximum Login Attempts", "Maximum Login Attempts")) ?></label>
                <input type="number" name="maxLoginAttempts" min="3" max="10" value="<?= e($technical["maxLoginAttempts"] ?? 5) ?>" required>
            </div>

            <div class="field">
                <label><?= e(msg("Lockout Duration (minutes)", "Lockout Duration (minutes)", "Lockout Duration (minutes)")) ?></label>
                <input type="number" name="lockoutMinutes" min="5" max="1440" value="<?= e($technical["lockoutMinutes"] ?? 15) ?>" required>
            </div>

            <div class="field">
                <label><?= e(msg("Password Reset Expiry (minutes)", "Password Reset Expiry (minutes)", "Password Reset Expiry (minutes)")) ?></label>
                <input type="number" name="passwordResetExpiryMinutes" min="5" max="120" value="<?= e($technical["passwordResetExpiryMinutes"] ?? 15) ?>" required>
            </div>

            <div class="field">
                <label><?= e(msg("OTP Expiry (minutes)", "OTP Expiry (minutes)", "OTP Expiry (minutes)")) ?></label>
                <input type="number" name="otpExpiryMinutes" min="5" max="60" value="<?= e($technical["otpExpiryMinutes"] ?? 15) ?>" required>
            </div>

            <div class="field">
                <label><?= e(msg("OTP Resend Cooldown", "OTP Resend Cooldown", "OTP Resend Cooldown")) ?></label>
                <input value="<?= e(($technical["otpResendCooldownSeconds"] ?? 60) . " seconds") ?>" readonly>
            </div>

            <div class="field">
                <label><?= e(msg("Maximum OTP Sends per Hour", "Maximum OTP Sends per Hour", "Maximum OTP Sends per Hour")) ?></label>
                <input value="<?= e($technical["otpMaxSendsPerHour"] ?? 5) ?>" readonly>
            </div>

            <div class="field">
                <label><?= e(msg("Privileged OTP Failure Limit", "Privileged OTP Failure Limit", "Privileged OTP Failure Limit")) ?></label>
                <input value="<?= e(($technical["privilegedOtpMaxFailures"] ?? 5) . " attempts") ?>" readonly>
            </div>

            <div class="field">
                <label><?= e(msg("Privileged OTP Lockout", "Privileged OTP Lockout", "Privileged OTP Lockout")) ?></label>
                <input value="<?= e(($technical["privilegedOtpLockoutMinutes"] ?? 15) . " minutes") ?>" readonly>
            </div>

            <div class="field">
                <label><?= e(msg("Password Recovery Request Cooldown", "Password Recovery Request Cooldown", "Password Recovery Request Cooldown")) ?></label>
                <input value="<?= e(($technical["passwordResetCooldownSeconds"] ?? 60) . " seconds") ?>" readonly>
            </div>

            <div class="field">
                <label><?= e(msg("Recovery Verification Cooldown", "Recovery Verification Cooldown", "Recovery Verification Cooldown")) ?></label>
                <input value="<?= e(($technical["recoveryVerificationCooldownSeconds"] ?? 60) . " seconds") ?>" readonly>
            </div>

            <div class="field">
                <label><?= e(msg("Minimum Password Length", "Minimum Password Length", "Minimum Password Length")) ?></label>
                <input type="number" name="minPasswordLength" min="8" max="32" value="<?= e($technical["minPasswordLength"] ?? 8) ?>" required>
            </div>

            <div class="field">
                <label><?= e(msg("Log Retention (days)", "Log Retention (days)", "Log Retention (days)")) ?></label>
                <input type="number" name="logRetentionDays" min="7" max="3650" value="<?= e($technical["logRetentionDays"] ?? 90) ?>" required>
            </div>

            <div class="field full">
                <label><?= e(msg("Password Requirements", "Password Requirements", "Password Requirements")) ?></label>

                <input type="hidden" name="passwordRequireUppercase" value="0">
                <label>
                    <input type="checkbox" name="passwordRequireUppercase" value="1" <?= !empty($technical["passwordRequireUppercase"]) ? "checked" : "" ?>>
                    <?= e(msg("Require uppercase letter", "Require uppercase letter", "Require uppercase letter")) ?>
                </label>

                <input type="hidden" name="passwordRequireLowercase" value="0">
                <label>
                    <input type="checkbox" name="passwordRequireLowercase" value="1" <?= !empty($technical["passwordRequireLowercase"]) ? "checked" : "" ?>>
                    <?= e(msg("Require lowercase letter", "Require lowercase letter", "Require lowercase letter")) ?>
                </label>

                <input type="hidden" name="passwordRequireNumber" value="0">
                <label>
                    <input type="checkbox" name="passwordRequireNumber" value="1" <?= !empty($technical["passwordRequireNumber"]) ? "checked" : "" ?>>
                    <?= e(msg("Require number", "Require number", "Require number")) ?>
                </label>

                <input type="hidden" name="passwordRequireSpecial" value="0">
                <label>
                    <input type="checkbox" name="passwordRequireSpecial" value="1" <?= !empty($technical["passwordRequireSpecial"]) ? "checked" : "" ?>>
                    <?= e(msg("Require special character", "Require special character", "Require special character")) ?>
                </label>
            </div>

            <div class="field full">
                <label><?= e(msg("Current Password", "Kasalukuyang Password", "Current Password")) ?></label>
                <input type="password" name="currentPassword" autocomplete="current-password" required>
            </div>

            <div class="button-row full">
                <button class="btn btn-primary" type="submit">
                    <?= e(msg("Save Technical Settings", "Save Technical Settings", "Save Technical Settings")) ?>
                </button>
            </div>
        </form>
    </section>

    <section class="card clean-panel section-space">
        <div class="clean-panel-head">
            <div>
                <h2><?= e(msg("Session Management", "Session Management", "Session Management")) ?></h2>
            </div>
            <?= badge(count($sessionUsers) . " " . msg("Other Users", "Other Users", "Other Users")) ?>
        </div>

        <div class="dashboard-focus-grid">
            <form method="POST" class="forms" autocomplete="off">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="action" value="revokeUserSessions">

                <div class="field full">
                    <label><?= e(msg("User", "User", "User")) ?></label>
                    <select name="userId" required>
                        <option value=""><?= e(msg("Select User", "Pumili ng User", "Select User")) ?></option>
                        <?php foreach ($sessionUsers as $sessionAccount): ?>
                            <option value="<?= e($sessionAccount["id"] ?? "") ?>">
                                <?= e(($sessionAccount["name"] ?? "User") . " · " . ($sessionAccount["email"] ?? "") . " · " . ucfirst(str_replace("_", " ", (string)($sessionAccount["role"] ?? "")))) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="field full">
                    <label><?= e(msg("Current Password", "Kasalukuyang Password", "Current Password")) ?></label>
                    <input type="password" name="currentPassword" autocomplete="current-password" required>
                </div>

                <div class="button-row full">
                    <button class="btn btn-outline" type="submit" <?= !count($sessionUsers) ? "disabled" : "" ?>>
                        <?= e(msg("Revoke Selected User Sessions", "Revoke Selected User Sessions", "Revoke Selected User Sessions")) ?>
                    </button>
                </div>
            </form>

            <form method="POST" class="forms" autocomplete="off">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="action" value="revokeAllUserSessions">

                <div class="notice full">
                    <?= e(msg(
                        "This signs out every other account. Your current IT Administrator session remains active.",
                        "Isi-sign out nito ang lahat ng ibang account. Mananatiling active ang kasalukuyang IT Administrator session.",
                        "This signs out every other account. Your current IT Administrator session remains active."
                    )) ?>
                </div>

                <div class="field full">
                    <label><?= e(msg("Current Password", "Kasalukuyang Password", "Current Password")) ?></label>
                    <input type="password" name="currentPassword" autocomplete="current-password" required>
                </div>

                <div class="button-row full">
                    <button class="btn btn-danger" type="submit">
                        <?= e(msg("Revoke All Other Sessions", "Revoke All Other Sessions", "Revoke All Other Sessions")) ?>
                    </button>
                </div>
            </form>
        </div>
    </section>

    <section class="card clean-panel section-space">
        <div class="clean-panel-head">
            <div>
                <h2>
                    <?= e(msg(
                        "System Logs",
                        "System Logs",
                        "System Logs"
                    )) ?>
                </h2>
            </div>

            <div>
                <?= badge(
                    count($logs) . " " .
                    msg(
                        "Recent",
                        "Recent",
                        "Recent"
                    )
                ) ?>
            </div>
        </div>

        <div style="overflow-x:auto">
            <table class="table">
                <thead>
                    <tr>
                        <th>
                            <?= e(msg(
                                "LEVEL",
                                "LEVEL",
                                "LEVEL"
                            )) ?>
                        </th>

                        <th>
                            <?= e(msg(
                                "CATEGORY",
                                "CATEGORY",
                                "CATEGORY"
                            )) ?>
                        </th>

                        <th>
                            <?= e(msg(
                                "MESSAGE",
                                "MESSAGE",
                                "MESSAGE"
                            )) ?>
                        </th>

                        <th>
                            <?= e(msg(
                                "USER",
                                "USER",
                                "USER"
                            )) ?>
                        </th>

                        <th>
                            <?= e(msg(
                                "DATE",
                                "DATE",
                                "DATE"
                            )) ?>
                        </th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($logs as $log): ?>
                        <?php
                            $level = strtolower(
                                trim(
                                    (string)($log["level"] ?? "info")
                                )
                            );

                            $levelLabel = ucfirst($level);
                            $logUser = !empty($log["userId"])
                                ? find_user_by_id($log["userId"])
                                : null;
                        ?>

                        <tr>
                            <td>
                                <?= badge($levelLabel) ?>
                            </td>

                            <td>
                                <?= e(
                                    ucfirst(
                                        (string)(
                                            $log["category"] ?? "system"
                                        )
                                    )
                                ) ?>
                            </td>

                            <td>
                                <?= e($log["message"] ?? "") ?>
                            </td>

                            <td>
                                <?= e(
                                    ($logUser["name"] ?? "")
                                        ?: ($log["userId"] ?? "--")
                                        ?: "--"
                                ) ?>
                            </td>

                            <td>
                                <?= e(
                                    kaakbay_system_date(
                                        $log["createdAt"] ?? ""
                                    )
                                ) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                    <?php if (!count($logs)): ?>
                        <tr>
                            <td colspan="5">
                                <?= e(msg(
                                    "No system logs yet.",
                                    "No system logs yet.",
                                    "No system logs yet."
                                )) ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<?php page_foot(); ?>