<?php
require_once __DIR__ . "/app/security.php";
require_once __DIR__ . "/app/auth.php";
require_once __DIR__ . "/app/page_actions.php";
require_once __DIR__ . "/app/page_data.php";
require_once __DIR__ . "/app/layout.php";

require_login();

$user = current_user();
$error = handle_page_action("dashboard", $user);
$data = get_page_data("dashboard", $user);
$role = $data["role"] ?? $user["role"];

$dashboardAnnouncements = function_exists("announcements_list")
    ? announcements_list(true)
    : [];

$dashboardAnnouncements = array_values(array_filter(
    $dashboardAnnouncements,
    function($announcement) use ($role) {
        if (!is_array($announcement)) {
            return false;
        }

        $audience = strtolower(trim((string)($announcement["audience"] ?? "all")));
        $currentRole = strtolower(trim((string)$role));

        return $audience === "" || $audience === "all" || $audience === $currentRole;
    }
));

$dashboardBranding = layout_system_settings();
$announcementSystemName = trim((string)($dashboardBranding["systemName"] ?? "Ka-Akbay"));
$announcementLogoUrl = trim((string)($dashboardBranding["logoUrl"] ?? ""));

if ($announcementSystemName === "") {
    $announcementSystemName = "Ka-Akbay";
}

page_head(msg("Ka-Akbay Dashboard", "Ka-Akbay Dashboard", "Ka-Akbay Dashboard"));
sidebar("dashboard", $user);
?>

<main class="main page-enter">
    <section class="topbar">
        <div>
            <h1><?= e(msg("Dashboard", "Dashboard", "Dashboard")) ?></h1>
            <?php if (trim((string)($user["name"] ?? "")) !== ""): ?>
                <p class="dashboard-greeting">
                    <span><?= e(msg("Hi,", "Hi,", "Hi,")) ?></span>
                    <strong><?= e(trim((string)$user["name"])) ?></strong>
                </p>
            <?php endif; ?>
        </div>
        <div class="date"><?= e(date("M d, Y")) ?></div>
    </section>

    <div class="error <?= $error ? "show" : "" ?>"><?= e($error) ?></div>

    <?php if (count($dashboardAnnouncements)): ?>
        <div class="modal-shell open announcement-popup" data-announcement-popup>
            <div class="modal-card announcement-modal">
                <div class="announcement-brand">
                    <div class="announcement-brand-main">
                        <?php if ($announcementLogoUrl !== ""): ?>
                            <img
                                src="<?= e($announcementLogoUrl) ?>"
                                alt="<?= e($announcementSystemName) ?>"
                                class="announcement-brand-logo"
                            >
                        <?php endif; ?>

                        <div class="announcement-brand-copy">
                            <strong><?= e($announcementSystemName) ?></strong>
                            <span>
                                <?= e(
                                    count($dashboardAnnouncements) === 1
                                        ? msg("Announcement", "Anunsyo", "Announcement")
                                        : msg("Announcements", "Mga Anunsyo", "Announcements")
                                ) ?>
                            </span>
                        </div>
                    </div>

                    <button
                        class="announcement-close"
                        type="button"
                        data-modal-close
                        aria-label="<?= e(msg("Close announcement", "Isara ang anunsyo", "Close announcement")) ?>"
                    >×</button>
                </div>

                <div class="announcement-content">
                    <?php foreach ($dashboardAnnouncements as $announcement): ?>
                        <div class="announcement-item">
                            <strong><?= e($announcement["title"] ?? msg("Announcement", "Anunsyo", "Announcement")) ?></strong>
                            <p><?= nl2br(e($announcement["message"] ?? "")) ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($role === "student"): ?>
        <?php
            $latest = $data["latest"] ?? null;
            $workload = $data["workload"] ?? [];
            $taskSummary = $data["taskSummary"] ?? [];
            $routine = $data["routineCapacity"] ?? [];
            $weeklyPlan = $data["weeklyPlan"] ?? ["days" => [], "unscheduled" => []];
            $monthlyPlan = $data["monthlyPlan"] ?? ["month" => date("F Y"), "days" => []];
            $advice = $data["advice"] ?? [];
            $flags = $data["flags"] ?? [];
            $flagDetails = $data["flagDetails"] ?? [];
            $tasks = $data["tasks"] ?? [];
            $schedules = $data["schedules"] ?? [];
            $attendanceSummary = $data["attendanceSummary"] ?? [];
            $studentId = $user["id"] ?? "";
            $cleanDashboardText = function($value) {
                return str_replace([html_entity_decode("&#8212;"), html_entity_decode("&#8211;")], "-", (string)$value);
            };
            $dashboardFocus = function_exists("dashboard_focus_summary_for_student") ? dashboard_focus_summary_for_student($studentId, $workload) : [];
            $dashboardAcademic = $dashboardFocus["summary"] ?? [];
            $subjectGuidance = $dashboardFocus["guidance"] ?? [];
            $focusSubject = $dashboardFocus["focusSubject"] ?? null;
            $focusText = $cleanDashboardText($dashboardFocus["focusText"] ?? "");
            $dashboardSubjects = $dashboardAcademic["subjects"] ?? [];
            $latest = $dashboardAcademic["focusRecord"] ?? $latest;
            $overallAcademicStatus = $dashboardAcademic["academicStatus"] ?? ($latest["academicStatus"] ?? "No Record");
            $overallComputedGrade = $dashboardAcademic["averageGrade"] ?? $dashboardAcademic["computedGrade"] ?? ($latest["computedGrade"] ?? 0);
            $overallCompetencyStatus = $dashboardAcademic["competencyStatus"] ?? ($latest["competencyStatus"] ?? "No Record");
            $overallAttendanceStatus = $dashboardAcademic["attendanceStatus"] ?? "No Record";
            $overallRiskForecast = $dashboardAcademic["riskForecast"] ?? "No Record";
            $subjectCount = $dashboardAcademic["subjectCount"] ?? count($dashboardSubjects);
            $attendanceMarkedTotal = 0;
            $attendanceAbsentTotal = 0;
            $attendanceMaxStreak = 0;

            foreach ($attendanceSummary as $attendanceKey => $attendanceItem) {
                if (!is_array($attendanceItem)) {
                    continue;
                }

                if (strpos((string)$attendanceKey, "schedule:") === 0) {
                    continue;
                }

                $markedValue = (int)($attendanceItem["marked"] ?? $attendanceItem["totalMarked"] ?? $attendanceItem["total"] ?? $attendanceItem["markedMeetings"] ?? 0);
                $absentValue = (int)($attendanceItem["absent"] ?? $attendanceItem["absentCount"] ?? 0);
                $streakValue = (int)($attendanceItem["consecutiveAbsences"] ?? 0);

                $attendanceMarkedTotal += $markedValue;
                $attendanceAbsentTotal += $absentValue;
                $attendanceMaxStreak = max($attendanceMaxStreak, $streakValue);
            }

            $studentAttendanceRate = $attendanceMarkedTotal > 0 ? round(($attendanceAbsentTotal / $attendanceMarkedTotal) * 100, 2) : 0;
            $studentAttendanceStatus = $attendanceMarkedTotal > 0 ? attendance_status($studentAttendanceRate, $attendanceMaxStreak) : "No Record";

            if ($studentAttendanceStatus !== "No Record") {
                $overallAttendanceStatus = $studentAttendanceStatus;
            }

            $priorityGuidanceItems = [];

            foreach ($subjectGuidance as $item) {
                if (!is_array($item)) {
                    continue;
                }

                $warnings = [];

                foreach (($item["warnings"] ?? []) as $warning) {
                    $warnings[] = $cleanDashboardText($warning);
                }

                $guidanceItems = [];

                foreach (($item["advice"] ?? []) as $guide) {
                    $guidanceItems[] = $cleanDashboardText($guide);
                }

                $priorityGuidanceItems[] = [
                    "subject" => $cleanDashboardText($item["subject"] ?? msg("Subject", "Asignatura", "Subject")),
                    "computedGrade" => $item["computedGrade"] ?? 0,
                    "academicStatus" => $cleanDashboardText($item["academicStatus"] ?? "No Record"),
                    "competencyStatus" => $cleanDashboardText($item["competencyStatus"] ?? "No Record"),
                    "attendanceStatus" => $cleanDashboardText($item["attendanceStatus"] ?? "No Record"),
                    "riskForecast" => $cleanDashboardText($item["riskForecast"] ?? $overallRiskForecast),
                    "competencyMastery" => $item["competencyMastery"] ?? 0,
                    "warnings" => $warnings,
                    "advice" => $guidanceItems
                ];
            }

            $priorityGuidanceJson = json_encode($priorityGuidanceItems, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
            $ratio = (float)($workload["workloadRatio"] ?? 0);
            $workloadIndex = $workload["lingguhangBigatIndex"] ?? "Magaan";

            if ($workloadIndex === "Mabigat") {
                $meter = 100;
            } elseif ($workloadIndex === "Katamtaman") {
                $meter = 66.67;
            } else {
                $meter = 33.33;
            }
        ?>

        <section class="student-overview-card">
            <div class="student-overview-main">
                <h2><?= e(msg("Academic Status", "Kalagayang Akademiko", "Academic Status")) ?></h2>
            </div>

            <div class="student-overview-status">
                <small><?= e(msg("Main Status", "Pangunahing Kalagayan", "Main Status")) ?></small>
                <strong><?= e(function_exists("tv") ? tv($overallAcademicStatus) : $overallAcademicStatus) ?></strong>
                <span class="dashboard-risk-forecast">
                    <?= badge($overallRiskForecast) ?>
                </span>
                <?= badge($workload["lingguhangBigatIndex"] ?? "Magaan") ?>
            </div>
        </section>

        <section class="simple-summary-grid">
            <div class="simple-summary-card">
                <span><?= e(msg("Academic Status", "Kalagayang Akademiko", "Academic Status")) ?></span>
                <strong><?= e(function_exists("tv") ? tv($overallAcademicStatus) : $overallAcademicStatus) ?></strong>
                <small><?= e($subjectCount > 0 ? msg("Average Grade ", "Average na Marka ", "Average Grade ") . $overallComputedGrade . " · " . $subjectCount . " " . msg("subjects", "subjects", "subjects") : msg("No Record", "Walang Tala", "No Record")) ?></small>
            </div>

            <div class="simple-summary-card">
                <span><?= e(msg("Competency", "Kakayahan", "Competency")) ?></span>
                <strong><?= e(function_exists("tv") ? tv($overallCompetencyStatus) : $overallCompetencyStatus) ?></strong>
                <small><?= e($focusSubject ? ($focusSubject["subject"] ?? "") . " · " . ($focusSubject["competencyMastery"] ?? 0) . msg("% mastery", "% mastery", "% mastery") : msg("No Record", "Walang Tala", "No Record")) ?></small>
            </div>

            <div class="simple-summary-card">
                <span><?= e(msg("Attendance", "Pagpasok", "Attendance")) ?></span>
                <strong><?= e(function_exists("tv") ? tv($overallAttendanceStatus) : $overallAttendanceStatus) ?></strong>
                <small><?= e($attendanceMarkedTotal > 0 ? $studentAttendanceRate . msg("% absence", "% pagliban", "% absence") : msg("No Record", "Walang Tala", "No Record")) ?></small>
            </div>

            <div class="simple-summary-card">
                <span><?= e("Lingguhang Bigat") ?></span>
                <strong><?= e($workload["lingguhangBigatIndex"] ?? "Magaan") ?></strong>
                <small><?= e(msg("Ratio", "Ratio", "Ratio")) ?> <?= e($workload["workloadRatio"] ?? 0) ?></small>
            </div>
        </section>

        <section class="dashboard-focus-grid">
            <div class="card clean-panel">
                <div class="clean-panel-head">
                    <div>
                        <h2><?= e(msg("Priority Guidance", "Pangunahing Gabay", "Priority Guidance")) ?></h2>
                    </div>
                    <a class="btn btn-outline" href="tasks.php"><?= e(msg("Open Tasks", "Buksan ang Tasks", "Open Tasks")) ?></a>
                </div>

                <div class="recommendation-stack priority-guidance-stack">
                    <?php if ($focusText !== ""): ?>
                        <div class="recommendation-card primary">
                            <div class="recommendation-icon">1</div>
                            <div>
                                <strong><?= e(msg("Current Focus", "Kasalukuyang Pokus", "Current Focus")) ?></strong>
                                <p><?= e($focusText) ?></p>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if (count($priorityGuidanceItems)): ?>
                        <div class="field full priority-guidance-select-wrap">
                            <label for="priorityGuidanceSubject"><?= e(msg("Subject", "Asignatura", "Subject")) ?></label>
                            <select id="priorityGuidanceSubject" data-priority-guidance-select>
                                <?php foreach ($priorityGuidanceItems as $index => $item): ?>
                                    <option value="<?= e($index) ?>">
                                        <?= e(($item["subject"] ?? msg("Subject", "Asignatura", "Subject")) . " - " . msg("Computed Grade", "Nakalkulang Marka", "Computed Grade") . " " . ($item["computedGrade"] ?? 0) . " - " . ($item["academicStatus"] ?? "No Record")) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <?php $firstGuidance = $priorityGuidanceItems[0] ?? []; ?>
                        <div class="priority-guidance-dynamic" data-priority-guidance-dynamic data-label-start="<?= e(msg("Start Here", "Magsimula Dito", "Start Here")) ?>" data-label-next="<?= e(msg("Next Step", "Susunod na Hakbang", "Next Step")) ?>" data-label-adjustment="<?= e(msg("Adjustment", "Pag-aayos", "Adjustment")) ?>" data-label-no-warning="<?= e(msg("No warning for this subject.", "Walang babala para sa subject na ito.", "No warning for this subject.")) ?>">
                            <div class="priority-guidance-subject-head">
                                <div>
                                    <span><?= e(msg("Selected Subject", "Napiling Subject", "Selected Subject")) ?></span>
                                    <strong data-priority-subject><?= e($firstGuidance["subject"] ?? msg("Subject", "Asignatura", "Subject")) ?></strong>
                                    
                                </div>
                                <span class="dashboard-risk-forecast" data-priority-risk><?= badge($firstGuidance["riskForecast"] ?? $overallRiskForecast) ?></span>
                            </div>

                            <div class="monitor-mini-grid">
                                <div>
                                    <span><?= e(msg("Grade", "Marka", "Grade")) ?></span>
                                    <strong data-priority-grade><?= e($firstGuidance["computedGrade"] ?? 0) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Academic Status", "Kalagayang Akademiko", "Academic Status")) ?></span>
                                    <strong data-priority-academic><?= e(function_exists("tv") ? tv($firstGuidance["academicStatus"] ?? "No Record") : ($firstGuidance["academicStatus"] ?? "No Record")) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Competency", "Kakayahan", "Competency")) ?></span>
                                    <strong data-priority-competency><?= e(function_exists("tv") ? tv($firstGuidance["competencyStatus"] ?? "No Record") : ($firstGuidance["competencyStatus"] ?? "No Record")) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Attendance", "Pagpasok", "Attendance")) ?></span>
                                    <strong data-priority-attendance><?= e(function_exists("tv") ? tv($firstGuidance["attendanceStatus"] ?? "No Record") : ($firstGuidance["attendanceStatus"] ?? "No Record")) ?></strong>
                                </div>
                            </div>

                            <div class="recommendation-card primary">
                                <div class="recommendation-icon">!</div>
                                <div>
                                    <strong><?= e(msg("Warnings", "Mga Babala", "Warnings")) ?></strong>
                                    <div data-priority-warnings>
                                        <?php if (count($firstGuidance["warnings"] ?? [])): ?>
                                            <?php foreach ($firstGuidance["warnings"] as $warning): ?>
                                                <p><?= e($warning) ?></p>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <p><?= e(msg("No warning for this subject.", "Walang babala para sa subject na ito.", "No warning for this subject.")) ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div data-priority-advice>
                                <?php foreach (array_slice($firstGuidance["advice"] ?? [], 0, 3) as $adviceIndex => $guide): ?>
                                    <div class="recommendation-card">
                                        <div class="recommendation-icon"><?= e($adviceIndex + 2) ?></div>
                                        <div>
                                            <strong><?= e($adviceIndex === 0 ? msg("Start Here", "Magsimula Dito", "Start Here") : ($adviceIndex === 1 ? msg("Next Step", "Susunod na Hakbang", "Next Step") : msg("Adjustment", "Pag-aayos", "Adjustment"))) ?></strong>
                                            <p><?= e($guide) ?></p>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <script type="application/json" id="priorityGuidanceData"><?= $priorityGuidanceJson ?: "[]" ?></script>
                    <?php elseif (count($advice)): ?>
                        <?php foreach (array_slice($advice, 0, 4) as $index => $item): ?>
                            <div class="recommendation-card <?= $index === 0 ? "primary" : "" ?>">
                                <div class="recommendation-icon"><?= e($index + 1) ?></div>
                                <div>
                                    <strong><?= e($index === 0 ? msg("Start Here", "Magsimula Dito", "Start Here") : ($index === 1 ? msg("Next Step", "Susunod na Hakbang", "Next Step") : msg("Adjustment", "Pag-aayos", "Adjustment"))) ?></strong>
                                    <p><?= e($cleanDashboardText($item)) ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="compact-empty">
                            <strong><?= e(msg("No guidance yet", "Wala pang gabay", "No guidance yet")) ?></strong>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card clean-panel">
                <div class="clean-panel-head">
                    <div>
                        <h2><?= e(msg("Weekly Load", "Lingguhang Bigat", "Weekly Load")) ?></h2>
                    </div>
                </div>

                <div class="load-meter-card">
                    <div class="load-meter-top">
                        <div>
                            <span><?= e(msg("Workload Score", "Workload Score", "Workload Score")) ?></span>
                            <strong><?= e($workload["weeklyWorkloadScore"] ?? 0) ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Study Time", "Oras ng Pag-aaral", "Study Time")) ?></span>
                            <strong><?= e($workload["availableStudyTime"] ?? 0) ?>h</strong>
                        </div>
                    </div>

                    <div class="load-meter">
                        <span style="width:<?= e($meter) ?>%"></span>
                    </div>

                    <div class="load-meter-bottom">
                        <span>Magaan</span>
                        <span>Katamtaman</span>
                        <span>Mabigat</span>
                    </div>

                    <div class="mini-stat-list">
                        <div>
                            <span><?= e(msg("Pending", "Nakabinbin", "Pending")) ?></span>
                            <strong><?= e($taskSummary["incomplete"] ?? 0) ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Overdue", "Lampas Deadline", "Overdue")) ?></span>
                            <strong><?= e($taskSummary["overdue"] ?? 0) ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Alerts", "Babala", "Alerts")) ?></span>
                            <strong><?= e($taskSummary["alertCount"] ?? 0) ?></strong>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="card clean-panel weekly-calendar-panel dashboard-attendance-schedule-panel">
            <div class="clean-panel-head">
                <div>
                    <h2><?= e(msg("Attendance and Schedule", "Attendance at Iskedyul", "Attendance and Schedule")) ?></h2>
                </div>
                <div class="tab-buttons">
                    <button class="tab-button active" type="button" data-tab-group="student-overview-panel" data-tab-target="student-attendance-view"><?= e(msg("Attendance", "Attendance", "Attendance")) ?></button>
                    <button class="tab-button" type="button" data-tab-group="student-overview-panel" data-tab-target="student-schedule-view"><?= e(msg("Schedule", "Iskedyul", "Schedule")) ?></button>
                </div>
            </div>

            <div class="tab-panel active" data-tab-panel-group="student-overview-panel" data-tab-panel="student-attendance-view">
                <div class="dashboard-section-divider">
                    <span><?= e(msg("Attendance Summary", "Buod ng Attendance", "Attendance Summary")) ?></span>
                </div>

                <div class="monitoring-grid attendance-summary-grid">
                    <?php foreach ($schedules as $schedule): ?>
                        <?php
                            $scheduleId = trim((string)($schedule["id"] ?? ""));
                            $subject = $schedule["subject"] ?? "";
                            $summaryKey = $scheduleId !== "" ? "schedule:" . $scheduleId : $subject;
                            $summary = $attendanceSummary[$summaryKey] ?? [];
                            $marked = $summary["marked"] ?? $summary["totalMarked"] ?? $summary["total"] ?? $summary["markedMeetings"] ?? 0;
                            $present = $summary["present"] ?? $summary["presentCount"] ?? 0;
                            $absent = $summary["absent"] ?? $summary["absentCount"] ?? 0;
                            $excused = $summary["excused"] ?? $summary["excusedCount"] ?? 0;
                            $absenceRate = $summary["absenceRate"] ?? 0;
                            $consecutiveAbsences = $summary["consecutiveAbsences"] ?? 0;
                            $attendanceStatus = $summary["attendanceStatus"] ?? (($absenceRate > 20 || $consecutiveAbsences >= 5) ? "Attendance Concern" : ($marked > 0 ? "Regular Attendance" : "No Record"));
                        ?>

                        <div class="monitor-card <?= e(view_state_class($attendanceStatus)) ?>">
                            <div class="monitor-card-top">
                                <div>
                                    <span><?= e(function_exists("tv") ? tv($schedule["day"] ?? "") : ($schedule["day"] ?? "")) ?></span>
                                    <h3><?= e($subject) ?></h3>
                                    <p><?= e(($schedule["startTime"] ?? "") . " - " . ($schedule["endTime"] ?? "")) ?></p>
                                </div>
                                <?= badge($attendanceStatus) ?>
                            </div>

                            <div class="monitor-mini-grid">
                                <div>
                                    <span><?= e(msg("Marked", "Na-markahan", "Marked")) ?></span>
                                    <strong><?= e($marked) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Present", "Pumasok", "Present")) ?></span>
                                    <strong><?= e($present) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Absent", "Lumiban", "Absent")) ?></span>
                                    <strong><?= e($absent) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Excused", "Excused", "Excused")) ?></span>
                                    <strong><?= e($excused) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Absence Rate", "Bahagdan ng Pagliban", "Absence Rate")) ?></span>
                                    <strong><?= e($absenceRate) ?>%</strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Absence Streak", "Sunod-sunod na Pagliban", "Absence Streak")) ?></span>
                                    <strong><?= e($consecutiveAbsences) ?></strong>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>

                    <?php if (!count($schedules)): ?>
                        <div class="compact-empty">
                            <strong><?= e(msg("No schedule entries yet", "Wala pang schedule entries", "No schedule entries yet")) ?></strong>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="tab-panel" data-tab-panel-group="student-overview-panel" data-tab-panel="student-schedule-view">
                <div class="dashboard-section-divider">
                    <span><?= e(msg("Schedule", "Iskedyul", "Schedule")) ?></span>
                </div>

                <div class="schedule-mode-panel">
                    <div class="schedule-mode-head">
                        <div>
                            <h3><?= e(msg("Schedule View", "Schedule View", "Schedule View")) ?></h3>
                        </div>
                        <div class="tab-buttons">
                            <button class="tab-button active" type="button" data-tab-group="student-schedule-mode" data-tab-target="student-weekly-routine"><?= e(msg("Weekly Schedule", "Lingguhang Iskedyul", "Weekly Schedule")) ?></button>
                            <button class="tab-button" type="button" data-tab-group="student-schedule-mode" data-tab-target="student-monthly-routine"><?= e(msg("Monthly Schedule", "Buwanang Iskedyul", "Monthly Schedule")) ?></button>
                        </div>
                    </div>

                    <div class="tab-panel active" data-tab-panel-group="student-schedule-mode" data-tab-panel="student-weekly-routine">
                        <div class="dashboard-section-divider compact">
                            <span><?= e(msg("Weekly Schedule", "Lingguhang Iskedyul", "Weekly Schedule")) ?></span>
                        </div>

                        <div class="weekly-calendar-grid">
                            <?php foreach ($weeklyPlan["days"] as $day): ?>
                                <div class="weekly-day-card">
                                    <div class="weekly-day-head">
                                        <div>
                                            <strong><?= e($day["shortDay"]) ?></strong>
                                            <span><?= e(date("M d", strtotime($day["date"]))) ?></span>
                                        </div>
                                        <small><?= e(round(($day["totalStudyMinutes"] ?? 0) / 60, 1)) ?>h <?= e(msg("planned", "nakaplano", "planned")) ?></small>
                                    </div>

                                    <div class="weekly-day-body">
                                        <?php foreach ($day["classBlocks"] as $block): ?>
                                            <div class="weekly-block class-block">
                                                <span><?= e($block["startLabel"]) ?> - <?= e($block["endLabel"]) ?></span>
                                                <strong><?= e($block["subject"]) ?></strong>
                                                <small><?= e($block["room"] ?: msg("Class schedule", "Iskedyul ng Klase", "Class schedule")) ?></small>
                                            </div>
                                        <?php endforeach; ?>

                                        <?php foreach ($day["studyBlocks"] as $block): ?>
                                            <div class="weekly-block study-block">
                                                <span><?= e($block["startLabel"]) ?> - <?= e($block["endLabel"]) ?></span>
                                                <strong><?= e($block["subject"]) ?></strong>
                                                <p><?= e($block["title"]) ?></p>
                                                <small><?= e($block["reason"]) ?> · <?= e(round($block["durationMinutes"] / 60, 1)) ?>h</small>
                                            </div>
                                        <?php endforeach; ?>

                                        <?php if (!count($day["classBlocks"]) && !count($day["studyBlocks"])): ?>
                                            <div class="weekly-empty"><?= e(msg("Open rest or review day", "Araw para sa pahinga o review", "Open rest or review day")) ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <?php if (count($weeklyPlan["unscheduled"])): ?>
                            <div class="weekly-unscheduled">
                                <strong><?= e(msg("Needs adjustment", "Kailangang ayusin", "Needs adjustment")) ?></strong>

                                <div class="weekly-unscheduled-list">
                                    <?php foreach ($weeklyPlan["unscheduled"] as $item): ?>
                                        <div>
                                            <span><?= e($item["subject"]) ?></span>
                                            <strong><?= e($item["title"]) ?></strong>
                                            <small><?= e(round($item["remainingMinutes"] / 60, 1)) ?>h <?= e(msg("remaining", "natitira", "remaining")) ?> · <?= e(msg("Due", "Deadline", "Due")) ?> <?= e($item["dueDate"] ?: msg("not set", "hindi nakatakda", "not set")) ?></small>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="tab-panel" data-tab-panel-group="student-schedule-mode" data-tab-panel="student-monthly-routine">
                        <div class="dashboard-section-divider compact">
                            <span><?= e(msg("Monthly Schedule", "Buwanang Iskedyul", "Monthly Schedule")) ?></span>
                        </div>

                        <div class="month-calendar-head">
                            <strong><?= e($monthlyPlan["month"] ?? date("F Y")) ?></strong>
                            <span><?= e(msg("Task pressure by due date", "Bigat ng tasks batay sa deadline", "Task pressure by due date")) ?></span>
                        </div>

                        <div class="month-calendar-grid">
                            <?php foreach ($monthlyPlan["days"] as $day): ?>
                                <div class="month-day-card <?= ($day["score"] ?? 0) >= 20 ? "busy" : "" ?>">
                                    <span><?= e(date("j", strtotime($day["date"]))) ?></span>
                                    <small><?= e($day["day"]) ?></small>

                                    <?php foreach (array_slice($day["tasks"] ?? [], 0, 2) as $task): ?>
                                        <div class="month-task-dot">
                                            <strong><?= e($task["subject"]) ?></strong>
                                            <em><?= e($task["title"]) ?></em>
                                        </div>
                                    <?php endforeach; ?>

                                    <?php if (count($day["tasks"] ?? []) > 2): ?>
                                        <p>+<?= e(count($day["tasks"]) - 2) ?> <?= e(msg("more", "pa", "more")) ?></p>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="card clean-panel activity-overview-card">
            <div class="clean-panel-head">
                <div>
                    <h2><?= e(msg("Activity Overview", "Buod ng Aktibidad", "Activity Overview")) ?></h2>
                </div>
                <a class="btn btn-outline" href="tasks.php"><?= e(msg("See all", "Tingnan lahat", "See all")) ?></a>
            </div>

            <div class="activity-combined-panel">
                <div class="activity-combined-section">
                    <div class="activity-panel-head">
                        <h3><?= e(msg("Current Flags", "Kasalukuyang Flags", "Current Flags")) ?></h3>
                        <div class="menu-wrap">
                            <button class="dot-action" type="button" data-menu-button="student-flags">•••</button>
                            <div class="popup-menu" data-menu="student-flags">
                                <?php foreach ($flagDetails as $index => $detail): ?>
                                    <button type="button" data-modal-open="flag-<?= e($index) ?>"><?= e(function_exists("tv") ? tv($detail["label"]) : $detail["label"]) ?></button>
                                <?php endforeach; ?>
                                <?php if (!count($flagDetails)): ?>
                                    <span><?= e(msg("No detailed flags", "Walang detalyadong flags", "No detailed flags")) ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="activity-flag-wrap activity-flag-card-list">
                        <?php foreach ($flags as $flag): ?>
                            <?php
                                $flagClass = view_state_class($flag);
                                $flagCategory = msg("Academic Status", "Kalagayang Akademiko", "Academic Status");
                                $flagDescription = msg("Current academic standing.", "Kasalukuyang kalagayang akademiko.", "Current academic standing.");

                                if (text_has($flag, "Mastered") || text_has($flag, "Mastery") || text_has($flag, "Competency")) {
                                    $flagCategory = msg("Competency Status", "Kalagayan ng Kakayahan", "Competency Status");
                                    $flagDescription = msg("Current competency standing.", "Kasalukuyang kalagayan ng kakayahan.", "Current competency standing.");
                                } elseif (text_has($flag, "Attendance")) {
                                    $flagCategory = msg("Attendance Status", "Kalagayan ng Pagpasok", "Attendance Status");
                                    $flagDescription = msg("Current attendance standing.", "Kasalukuyang kalagayan ng pagpasok.", "Current attendance standing.");
                                } elseif (text_has($flag, "Magaan") || text_has($flag, "Katamtaman") || text_has($flag, "Mabigat") || text_has($flag, "Workload")) {
                                    $flagCategory = msg("Workload Status", "Kalagayan ng Workload", "Workload Status");
                                    $flagDescription = msg("Current weekly workload level.", "Kasalukuyang lingguhang antas ng workload.", "Current weekly workload level.");
                                } elseif (text_has($flag, "Requirement")) {
                                    $flagCategory = msg("Requirements Status", "Kalagayan ng Requirements", "Requirements Status");
                                    $flagDescription = msg("Current requirements standing.", "Kasalukuyang kalagayan ng requirements.", "Current requirements standing.");
                                } elseif (text_has($flag, "Trend")) {
                                    $flagCategory = msg("Performance Trend", "Trend ng Performance", "Performance Trend");
                                    $flagDescription = msg("Current performance pattern.", "Kasalukuyang pattern ng performance.", "Current performance pattern.");
                                }
                            ?>

                            <div class="activity-flag-card <?= e($flagClass) ?>">
                                <span class="activity-flag-card-icon status <?= e($flagClass) ?>" aria-hidden="true"></span>

                                <div class="activity-flag-card-copy">
                                    <small><?= e($flagCategory) ?></small>
                                    <strong><?= e(function_exists("tv") ? tv($flag) : $flag) ?></strong>
                                    <p><?= e($flagDescription) ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>

                        <?php if (!count($flags)): ?>
                            <div class="activity-flag-card good">
                                <span class="activity-flag-card-icon status good state-active" aria-hidden="true"></span>

                                <div class="activity-flag-card-copy">
                                    <small><?= e(msg("Current Status", "Kasalukuyang Kalagayan", "Current Status")) ?></small>
                                    <strong><?= e(msg("No active flag", "Walang active flag", "No active flag")) ?></strong>
                                    <p><?= e(msg("No flagged condition requires attention.", "Walang naka-flag na kondisyon na nangangailangan ng pansin.", "No flagged condition requires attention.")) ?></p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php foreach ($flagDetails as $index => $detail): ?>
                        <div class="modal-shell" data-modal="flag-<?= e($index) ?>">
                            <div class="modal-card">
                                <div class="modal-head">
                                    <h3><?= e(function_exists("tv") ? tv($detail["label"]) : $detail["label"]) ?></h3>
                                    <button type="button" data-modal-close>×</button>
                                </div>
                                <div class="modal-body">
                                    <p><strong><?= e(msg("Basis", "Batayan", "Basis")) ?>:</strong> <?= e($detail["basis"]) ?></p>
                                    <p><strong><?= e(msg("Suggested Action", "Iminungkahing Gawin", "Suggested Action")) ?>:</strong> <?= e($detail["action"]) ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="activity-combined-section">
                    <div class="activity-panel-head">
                        <h3><?= e(msg("Recent Tasks", "Pinakabagong Tasks", "Recent Tasks")) ?></h3>
                    </div>

                    <div class="activity-task-list">
                        <?php foreach (array_slice($tasks, 0, 4) as $task): ?>
                            <?php $priority = task_priority($task, ""); ?>
                            <div class="activity-task-item <?= e(strtolower($priority)) ?>">
                                <div>
                                    <strong><?= e($task["title"] ?? msg("Untitled Task", "Walang Pamagat na Task", "Untitled Task")) ?></strong>
                                    <span><?= e($task["subject"] ?? msg("Unassigned Subject", "Walang Subject", "Unassigned Subject")) ?> · <?= e(msg("Due", "Deadline", "Due")) ?> <?= e($task["dueDate"] ?? "--") ?></span>
                                </div>
                                <?= badge($priority) ?>
                            </div>
                        <?php endforeach; ?>

                        <?php if (!count($tasks)): ?>
                            <div class="compact-empty">
                                <strong><?= e(msg("No tasks yet", "Wala pang tasks", "No tasks yet")) ?></strong>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <?php if ($role === "super_admin"): ?>
        <section class="student-overview-card">
            <div class="student-overview-main">
                <h2><?= e(msg("Super Admin", "Super Admin", "Super Admin")) ?></h2>
            </div>

            <div class="student-overview-status">
                <a class="btn btn-primary" href="content.php"><?= e(msg("Content Management", "Content Management", "Content Management")) ?></a>
            </div>
        </section>
    <?php endif; ?>

    <?php if ($role === "it_admin"): ?>
        <?php
            $health = $data["health"] ?? [];
            $backups = $data["backups"] ?? [];
            $latestBackup = $data["latestBackup"] ?? null;
            $maintenance = $data["maintenance"] ?? [];

            $systemStatus = $health["status"] ?? "Operational";
            $databaseStatus = $health["database"] ?? "Offline";
            $errorsToday = (int)($health["errorsToday"] ?? 0);
            $backupCount = (int)($health["backupCount"] ?? count($backups));
            $maintenanceEnabled = !empty($maintenance["enabled"]) || !empty($health["maintenanceMode"]);
            $maintenanceStatus = $maintenanceEnabled ? "Enabled" : "Disabled";
            $lastBackupAt = $health["lastBackupAt"] ?? ($latestBackup["createdAt"] ?? "");
            $lastBackupLabel = $lastBackupAt !== "" && strtotime($lastBackupAt)
                ? date("M d, Y g:i A", strtotime($lastBackupAt))
                : "No Backup";
        ?>

        <section class="student-overview-card">
            <div class="student-overview-main">
                <h2><?= e(msg("IT Admin", "IT Admin", "IT Admin")) ?></h2>
            </div>

            <div class="student-overview-status">
                <small><?= e(msg("System Status", "System Status", "System Status")) ?></small>
                <strong><?= e($systemStatus) ?></strong>
                <?= badge($maintenanceEnabled ? "Maintenance" : $systemStatus) ?>
                <a class="btn btn-primary" href="system.php"><?= e(msg("System Management", "System Management", "System Management")) ?></a>
            </div>
        </section>

        <section class="simple-summary-grid">
            <div class="simple-summary-card <?= e(view_state_class($systemStatus)) ?>">
                <span><?= e(msg("System Status", "System Status", "System Status")) ?></span>
                <strong><?= e($systemStatus) ?></strong>
            </div>

            <div class="simple-summary-card <?= e(view_state_class($databaseStatus)) ?>">
                <span><?= e(msg("Database", "Database", "Database")) ?></span>
                <strong><?= e($databaseStatus) ?></strong>
            </div>

            <div class="simple-summary-card <?= $errorsToday > 0 ? "danger" : "good" ?>">
                <span><?= e(msg("Errors Today", "Errors Today", "Errors Today")) ?></span>
                <strong><?= e($errorsToday) ?></strong>
            </div>

            <div class="simple-summary-card">
                <span><?= e(msg("Backups", "Backups", "Backups")) ?></span>
                <strong><?= e($backupCount) ?></strong>
            </div>

            <div class="simple-summary-card <?= $maintenanceEnabled ? "warning" : "good" ?>">
                <span><?= e(msg("Maintenance", "Maintenance", "Maintenance")) ?></span>
                <strong><?= e($maintenanceStatus) ?></strong>
            </div>

            <div class="simple-summary-card">
                <span><?= e(msg("Last Backup", "Last Backup", "Last Backup")) ?></span>
                <strong><?= e($lastBackupLabel) ?></strong>
            </div>
        </section>

        <section class="dashboard-focus-grid">
            <div class="card clean-panel">
                <div class="clean-panel-head">
                    <div>
                        <h2><?= e(msg("System Health", "System Health", "System Health")) ?></h2>
                    </div>
                    <a class="btn btn-outline" href="system.php"><?= e(msg("Open System Management", "Open System Management", "Open System Management")) ?></a>
                </div>

                <div class="mini-stat-list vertical">
                    <div>
                        <span><?= e(msg("Overall Status", "Overall Status", "Overall Status")) ?></span>
                        <strong><?= e($systemStatus) ?></strong>
                    </div>

                    <div>
                        <span><?= e(msg("Database", "Database", "Database")) ?></span>
                        <strong><?= e($databaseStatus) ?></strong>
                    </div>

                    <div>
                        <span><?= e(msg("Errors Today", "Errors Today", "Errors Today")) ?></span>
                        <strong><?= e($errorsToday) ?></strong>
                    </div>
                </div>
            </div>

            <div class="card clean-panel">
                <div class="clean-panel-head">
                    <div>
                        <h2><?= e(msg("Backup Status", "Backup Status", "Backup Status")) ?></h2>
                    </div>
                </div>

                <div class="mini-stat-list vertical">
                    <div>
                        <span><?= e(msg("Available Backups", "Available Backups", "Available Backups")) ?></span>
                        <strong><?= e($backupCount) ?></strong>
                    </div>

                    <div>
                        <span><?= e(msg("Last Backup", "Last Backup", "Last Backup")) ?></span>
                        <strong><?= e($lastBackupLabel) ?></strong>
                    </div>

                    <div>
                        <span><?= e(msg("Maintenance Mode", "Maintenance Mode", "Maintenance Mode")) ?></span>
                        <strong><?= e($maintenanceStatus) ?></strong>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <?php if ($role === "teacher" || $role === "admin" || $role === "super_admin"): ?>
        <?php
            $counts = $data["counts"] ?? [];
            $rows = $data["rows"] ?? [];
            $flagged = $data["flagged"] ?? [];
            $grouped = $data["groupedSummary"] ?? [];
        ?>

        <section class="student-overview-card">
            <div class="student-overview-main">
                <h2><?= e($role === "teacher" ? msg("Class Monitoring", "Pagsubaybay sa Klase", "Class Monitoring") : msg("System Monitoring", "Pagsubaybay sa System", "System Monitoring")) ?></h2>
            </div>

            <div class="student-overview-status">
                <small><?= e(msg("Total Students", "Kabuuang Mag-aaral", "Total Students")) ?></small>
                <strong><?= e($counts["total"] ?? 0) ?></strong>
                <?= badge(msg("Monitoring", "Minomonitor", "Monitoring")) ?>
            </div>
        </section>

        <section class="simple-summary-grid">
            <div class="simple-summary-card">
                <span><?= e(msg("Total", "Kabuuan", "Total")) ?></span>
                <strong><?= e($counts["total"] ?? 0) ?></strong>
            </div>

            <div class="simple-summary-card warning">
                <span><?= e(msg("Warning", "Babala", "Warning")) ?></span>
                <strong><?= e($counts["warning"] ?? 0) ?></strong>
            </div>

            <div class="simple-summary-card danger">
                <span><?= e(msg("At-Risk", "Nanganganib", "At-Risk")) ?></span>
                <strong><?= e($counts["atRisk"] ?? $counts["risk"] ?? 0) ?></strong>
            </div>

            <div class="simple-summary-card warning">
                <span><?= e(msg("Attendance Concern", "Concern sa Pagpasok", "Attendance Concern")) ?></span>
                <strong><?= e($counts["attendanceConcern"] ?? 0) ?></strong>
            </div>

            <div class="simple-summary-card warning">
                <span>Mabigat</span>
                <strong><?= e($counts["mabigat"] ?? $counts["workloadHigh"] ?? 0) ?></strong>
            </div>

            <div class="simple-summary-card warning">
                <span><?= e(msg("Needs Validation", "Kailangan ng Validation", "Needs Validation")) ?></span>
                <strong><?= e($counts["needsValidation"] ?? 0) ?></strong>
            </div>
        </section>

        <section class="monitoring-board" id="monitoring">
            <div class="clean-panel-head">
                <div>
                    <h2><?= e(msg("Monitoring Records", "Mga Tala ng Pagsubaybay", "Monitoring Records")) ?></h2>
                </div>
                <a class="btn btn-outline" href="monitor.php"><?= e(msg("Open Monitor", "Buksan ang Monitor", "Open Monitor")) ?></a>
            </div>

            <div class="monitoring-grid">
                <?php foreach ($rows as $index => $row): ?>
                    <?php
                        $student = $row["student"] ?? [];
                        $latest = $row["latest"] ?? [];
                        $workloadRow = $row["workload"] ?? [];
                        $flagsRow = $row["flags"] ?? [];
                        $schedules = schedules_for_student($student["id"] ?? "");
                        $guidance = $latest["guidanceOutput"] ?? null;
                    ?>
                    <div class="monitor-card <?= e(view_state_class(implode(" ", $flagsRow))) ?>">
                        <div class="monitor-card-top">
                            <div>
                                <span><?= e($student["code"] ?? "") ?></span>
                                <h3><?= e($student["name"] ?? msg("Student", "Mag-aaral", "Student")) ?></h3>
                                <p><?= e(($student["strand"] ?? "") . " · " . ($student["section"] ?? "")) ?></p>
                            </div>
                            <button class="dot-action" type="button" data-menu-button="monitor-<?= e($index) ?>">•••</button>
                            <div class="popup-menu" data-menu="monitor-<?= e($index) ?>">
                                <button type="button" data-modal-open="monitor-detail-<?= e($index) ?>"><?= e(msg("View Details", "Tingnan ang Detalye", "View Details")) ?></button>
                                <button type="button" data-modal-open="attendance-<?= e($index) ?>"><?= e(msg("Mark Attendance", "Magmarka ng Attendance", "Mark Attendance")) ?></button>
                                <a href="validation.php"><?= e(msg("Validate Output", "I-validate ang Output", "Validate Output")) ?></a>
                            </div>
                        </div>

                        <div class="monitor-status-row">
                            <?= badge($latest["academicStatus"] ?? "No Record") ?>
                            <?= badge($latest["competencyStatus"] ?? "No Record") ?>
                            <?= badge($latest["attendanceStatus"] ?? "No Record") ?>
                            <?= badge($latest["requirementStatus"] ?? "Complete Requirements") ?>
                            <?= badge($workloadRow["lingguhangBigatIndex"] ?? "Magaan") ?>
                        </div>

                        <div class="monitor-mini-grid">
                            <div>
                                <span><?= e(msg("Subject", "Asignatura", "Subject")) ?></span>
                                <strong><?= e($latest["subject"] ?? msg("No Record", "Walang Tala", "No Record")) ?></strong>
                            </div>
                            <div>
                                <span><?= e(msg("Grade", "Marka", "Grade")) ?></span>
                                <strong><?= e($latest["computedGrade"] ?? "--") ?></strong>
                            </div>
                            <div>
                                <span><?= e(msg("Ratio", "Ratio", "Ratio")) ?></span>
                                <strong><?= e($workloadRow["workloadRatio"] ?? 0) ?></strong>
                            </div>
                        </div>

                        <div class="monitor-foot">
                            <span><?= e(function_exists("tv") ? tv($row["followUpType"] ?? "Regular Monitoring") : ($row["followUpType"] ?? "Regular Monitoring")) ?></span>
                        </div>
                    </div>

                    <div class="modal-shell" data-modal="monitor-detail-<?= e($index) ?>">
                        <div class="modal-card large">
                            <div class="modal-head">
                                <h3><?= e($student["code"] ?? "") ?> <?= e(msg("Monitoring Details", "Detalye ng Pagsubaybay", "Monitoring Details")) ?></h3>
                                <button type="button" data-modal-close>×</button>
                            </div>
                            <div class="modal-body">
                                <div class="modal-grid">
                                    <div>
                                        <span><?= e(msg("Student", "Mag-aaral", "Student")) ?></span>
                                        <strong><?= e($student["name"] ?? "") ?></strong>
                                    </div>
                                    <div>
                                        <span><?= e(msg("Subject", "Asignatura", "Subject")) ?></span>
                                        <strong><?= e($latest["subject"] ?? msg("No Record", "Walang Tala", "No Record")) ?></strong>
                                    </div>
                                    <div>
                                        <span><?= e(msg("Academic Status", "Kalagayang Akademiko", "Academic Status")) ?></span>
                                        <strong><?= e(function_exists("tv") ? tv($latest["academicStatus"] ?? "No Record") : ($latest["academicStatus"] ?? "No Record")) ?></strong>
                                    </div>
                                    <div>
                                        <span><?= e(msg("Competency", "Kakayahan", "Competency")) ?></span>
                                        <strong><?= e(function_exists("tv") ? tv($latest["competencyStatus"] ?? "No Record") : ($latest["competencyStatus"] ?? "No Record")) ?></strong>
                                    </div>
                                    <div>
                                        <span><?= e(msg("Attendance", "Pagpasok", "Attendance")) ?></span>
                                        <strong><?= e(function_exists("tv") ? tv($latest["attendanceStatus"] ?? "No Record") : ($latest["attendanceStatus"] ?? "No Record")) ?></strong>
                                    </div>
                                    <div>
                                        <span><?= e(msg("Absence Rate", "Bahagdan ng Pagliban", "Absence Rate")) ?></span>
                                        <strong><?= e($latest["absenceRate"] ?? "--") ?>%</strong>
                                    </div>
                                    <div>
                                        <span><?= e(msg("Consecutive Absences", "Sunod-sunod na Pagliban", "Consecutive Absences")) ?></span>
                                        <strong><?= e($latest["consecutiveAbsences"] ?? "--") ?></strong>
                                    </div>
                                    <div>
                                        <span><?= e(msg("Workload", "Bigat ng Gawain", "Workload")) ?></span>
                                        <strong><?= e($workloadRow["lingguhangBigatIndex"] ?? "Magaan") ?></strong>
                                    </div>
                                </div>

                                <?php if ($guidance): ?>
                                    <div class="record-guidance-strip">
                                        <div><strong><?= e(msg("Status", "Kalagayan", "Status")) ?></strong><br><?= e($guidance["status"] ?? "") ?></div>
                                        <div><strong><?= e(msg("Advisory", "Paalaala", "Advisory")) ?></strong><br><?= e($guidance["advisory"] ?? "") ?></div>
                                        <div><strong><?= e(msg("Guidance", "Gabay", "Guidance")) ?></strong><br><?= e($guidance["guidance"] ?? "") ?></div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="modal-shell" data-modal="attendance-<?= e($index) ?>">
                        <div class="modal-card large">
                            <div class="modal-head">
                                <h3><?= e(msg("Mark Attendance", "Magmarka ng Attendance", "Mark Attendance")) ?></h3>
                                <button type="button" data-modal-close>×</button>
                            </div>
                            <form method="POST" class="modal-body forms">
                                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="action" value="markAttendance">
                                <input type="hidden" name="studentId" value="<?= e($student["id"] ?? "") ?>">
                                <input type="hidden" name="redirect" value="dashboard.php">
                                <input type="hidden" name="subject" data-attendance-subject>
                                <input type="hidden" name="gradingPeriod" data-attendance-grading-period>

                                <div class="field full">
                                    <label><?= e(msg("Student", "Mag-aaral", "Student")) ?></label>
                                    <input value="<?= e(($student["code"] ?? "") . " · " . ($student["name"] ?? "")) ?>" readonly>
                                </div>

                                <div class="field full">
                                    <label><?= e(msg("Subject Schedule", "Iskedyul ng Asignatura", "Subject Schedule")) ?></label>
                                    <select name="scheduleId" required data-attendance-schedule-select>
                                        <option value="" data-subject="" data-grading-period=""><?= e(msg("Select Schedule", "Pumili ng Iskedyul", "Select Schedule")) ?></option>
                                        <?php foreach ($schedules as $schedule): ?>
                                            <option value="<?= e($schedule["id"] ?? "") ?>" data-subject="<?= e($schedule["subject"] ?? "") ?>" data-grading-period="<?= e($schedule["gradingPeriod"] ?? "") ?>">
                                                <?= e(($schedule["subject"] ?? "") . " · " . ($schedule["day"] ?? "") . " · " . ($schedule["startTime"] ?? "") . " - " . ($schedule["endTime"] ?? "")) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="field">
                                    <label><?= e(msg("Date", "Petsa", "Date")) ?></label>
                                    <input type="date" name="date" value="<?= e(date("Y-m-d")) ?>" required>
                                </div>

                                <div class="field">
                                    <label><?= e(msg("Status", "Kalagayan", "Status")) ?></label>
                                    <select name="status" required>
                                        <?php foreach (["Present", "Absent", "Excused"] as $status): ?>
                                            <option value="<?= e($status) ?>"><?= e(function_exists("tv") ? tv($status) : $status) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="field full">
                                    <label><?= e(msg("Note", "Tala", "Note")) ?></label>
                                    <textarea name="note"></textarea>
                                </div>

                                <div class="button-row full">
                                    <button class="btn btn-primary" type="submit"><?= e(msg("Save Attendance", "I-save ang Attendance", "Save Attendance")) ?></button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>

                <?php if (!count($rows)): ?>
                    <div class="compact-empty">
                        <strong><?= e(msg("No monitoring records", "Walang monitoring records", "No monitoring records")) ?></strong>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <section class="dashboard-focus-grid section-space">
            <div class="card clean-panel" id="flagged">
                <div class="clean-panel-head">
                    <div>
                        <h2><?= e(msg("Flagged Records", "Mga Na-flag na Tala", "Flagged Records")) ?></h2>
                    </div>
                </div>

                <div class="compact-task-list">
                    <?php foreach ($flagged as $row): ?>
                        <div class="compact-task-item">
                            <div>
                                <strong><?= e($row["student"]["code"] ?? "") ?></strong>
                                <span><?= e($row["student"]["name"] ?? "") ?></span>
                            </div>
                            <div class="flag-pill-list">
                                <?php foreach (($row["flags"] ?? []) as $flag): ?>
                                    <span class="flag-pill <?= e(view_state_class($flag)) ?>"><?= e(function_exists("tv") ? tv($flag) : $flag) ?></span>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>

                    <?php if (!count($flagged)): ?>
                        <div class="compact-empty">
                            <strong><?= e(msg("No flagged records", "Walang na-flag na tala", "No flagged records")) ?></strong>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card clean-panel" id="summary">
                <div class="clean-panel-head">
                    <div>
                        <h2><?= e(msg("Grouped Summary", "Pinangkat na Buod", "Grouped Summary")) ?></h2>
                    </div>
                </div>

                <div class="compact-task-list">
                    <?php foreach ($grouped as $group): ?>
                        <div class="compact-task-item">
                            <div>
                                <strong><?= e($group["label"] ?? "") ?></strong>
                                <span><?= e($group["students"] ?? 0) ?> <?= e((($group["students"] ?? 0) == 1) ? msg("student", "mag-aaral", "student") : msg("students", "mag-aaral", "students")) ?></span>
                            </div>

                            <div class="group-summary-metrics">
                                <div>
                                    <span><?= e(msg("Warning", "Babala", "Warning")) ?></span>
                                    <strong><?= e($group["warning"] ?? 0) ?></strong>
                                </div>

                                <div>
                                    <span><?= e(msg("At-Risk", "Nanganganib", "At-Risk")) ?></span>
                                    <strong><?= e($group["atRisk"] ?? $group["risk"] ?? 0) ?></strong>
                                </div>

                                <div>
                                    <span><?= e(msg("High Workload", "Mabigat na Gawain", "High Workload")) ?></span>
                                    <strong><?= e($group["mabigat"] ?? $group["workloadHigh"] ?? 0) ?></strong>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>

                    <?php if (!count($grouped)): ?>
                        <div class="compact-empty">
                            <strong><?= e(msg("No grouped data", "Walang pinangkat na datos", "No grouped data")) ?></strong>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>
</main>



<script>
(function(){
    function bootPriorityGuidance(){
        var select=document.querySelector("[data-priority-guidance-select]");
        var dataElement=document.getElementById("priorityGuidanceData");
        var panel=document.querySelector("[data-priority-guidance-dynamic]");

        if(!select || !dataElement || !panel){
            return;
        }

        var items=[];

        try{
            items=JSON.parse(dataElement.textContent || "[]");
        }catch(error){
            items=[];
        }

        if(!Array.isArray(items) || !items.length){
            return;
        }

        var subjectEl=panel.querySelector("[data-priority-subject]");
        var riskEl=panel.querySelector("[data-priority-risk]");
        var gradeEl=panel.querySelector("[data-priority-grade]");
        var academicEl=panel.querySelector("[data-priority-academic]");
        var competencyEl=panel.querySelector("[data-priority-competency]");
        var attendanceEl=panel.querySelector("[data-priority-attendance]");
        var warningsEl=panel.querySelector("[data-priority-warnings]");
        var adviceEl=panel.querySelector("[data-priority-advice]");
        var startLabel=panel.dataset.labelStart || "Start Here";
        var nextLabel=panel.dataset.labelNext || "Next Step";
        var adjustmentLabel=panel.dataset.labelAdjustment || "Adjustment";
        var noWarning=panel.dataset.labelNoWarning || "No warning for this subject.";
        var labels=[startLabel,nextLabel,adjustmentLabel];

        function cleanText(value){
            return String(value === null || value === undefined ? "" : value).replace(/[–—]/g,"-");
        }

        function hasText(value,needle){
            return cleanText(value).toLowerCase().indexOf(needle.toLowerCase()) !== -1;
        }

        function stateKey(value){
            var text=cleanText(value).trim();
            var exact={
                "Regular":"regular",
                "Low Risk":"low-risk",
                "Warning":"warning",
                "Warning Status":"warning-status",
                "At-Risk":"at-risk",
                "At-Risk / Failing":"at-risk-failing",
                "Regular Attendance":"regular-attendance",
                "Attendance Concern":"attendance-concern",
                "Mastered":"mastered",
                "Nearing Mastery":"nearing-mastery",
                "Not Mastered / Remediation Needed":"not-mastered-remediation",
                "Complete Requirements":"complete-requirements",
                "Incomplete Requirements":"incomplete-requirements",
                "Stable Performance Pattern":"stable-performance-pattern",
                "Improving Performance Pattern":"improving-performance-pattern",
                "Declining Performance Pattern":"declining-performance-pattern",
                "Insufficient Trend Data":"insufficient-trend-data",
                "No Record":"no-record",
                "Magaan":"magaan",
                "Katamtaman":"katamtaman",
                "Mabigat":"mabigat",
                "Present":"present",
                "Absent":"absent",
                "Excused":"excused",
                "Submitted":"submitted",
                "Incomplete":"incomplete",
                "Missing":"missing",
                "Needs Review":"needs-review",
                "Not Consistent":"not-consistent",
                "Consistent":"consistent",
                "Not Started":"not-started",
                "In Progress":"in-progress",
                "Completed":"completed",
                "Rescheduled":"rescheduled",
                "Pending":"pending",
                "Overdue":"overdue",
                "Low":"low",
                "Medium":"medium",
                "High":"high",
                "Critical":"critical",
                "Regular Monitoring":"regular-monitoring",
                "Remediation":"remediation",
                "Requirement Follow-up":"requirement-follow-up",
                "Performance Monitoring":"performance-monitoring",
                "Attendance Follow-up":"attendance-follow-up",
                "Workload Follow-up":"workload-follow-up"
            };

            return exact[text] || "";
        }

        function stateClass(value){
            var text=cleanText(value);
            var tone="good";

            if(hasText(text,"At-Risk") || hasText(text,"Failing") || hasText(text,"Concern") || hasText(text,"Mabigat") || hasText(text,"Overdue") || hasText(text,"Not Mastered") || hasText(text,"Remediation") || hasText(text,"Critical") || hasText(text,"Not Consistent") || hasText(text,"Incomplete") || hasText(text,"Declining") || hasText(text,"High Risk")){
                tone="danger";
            }else if(hasText(text,"Warning") || hasText(text,"Nearing") || hasText(text,"Katamtaman") || hasText(text,"Needs") || hasText(text,"High") || hasText(text,"Medium")){
                tone="warning";
            }else if(hasText(text,"Insufficient Trend Data") || hasText(text,"No Record") || hasText(text,"Not Started") || hasText(text,"Rescheduled") || hasText(text,"Pending") || hasText(text,"Excused")){
                tone="neutral";
            }

            var key=stateKey(value);
            return tone+(key ? " state-"+key : "");
        }

        function makeBadge(value){
            var badge=document.createElement("span");
            badge.className="status "+stateClass(value);
            badge.textContent=cleanText(value || "No Record");
            return badge;
        }

        function makeParagraph(value){
            var paragraph=document.createElement("p");
            paragraph.textContent=cleanText(value);
            return paragraph;
        }

        function makeAdviceCard(value,index){
            var card=document.createElement("div");
            card.className="recommendation-card";
            var icon=document.createElement("div");
            icon.className="recommendation-icon";
            icon.textContent=String(index+2);
            var body=document.createElement("div");
            var title=document.createElement("strong");
            title.textContent=labels[index] || adjustmentLabel;
            var text=document.createElement("p");
            text.textContent=cleanText(value);
            body.appendChild(title);
            body.appendChild(text);
            card.appendChild(icon);
            card.appendChild(body);
            return card;
        }

        function syncPriorityGuidance(){
            var index=parseInt(select.value,10);
            var item=items[isNaN(index) ? 0 : index] || items[0] || {};

            if(subjectEl){
                subjectEl.textContent=cleanText(item.subject || "Subject");
            }

            if(riskEl){
                riskEl.innerHTML="";
                riskEl.appendChild(makeBadge(item.riskForecast || "No Record"));
            }

            if(gradeEl){
                gradeEl.textContent=cleanText(item.computedGrade === undefined ? "0" : item.computedGrade);
            }

            if(academicEl){
                academicEl.textContent=cleanText(item.academicStatus || "No Record");
            }

            if(competencyEl){
                competencyEl.textContent=cleanText(item.competencyStatus || "No Record");
            }

            if(attendanceEl){
                attendanceEl.textContent=cleanText(item.attendanceStatus || "No Record");
            }

            if(warningsEl){
                warningsEl.innerHTML="";
                var warnings=Array.isArray(item.warnings) ? item.warnings : [];

                if(warnings.length){
                    warnings.forEach(function(warning){
                        warningsEl.appendChild(makeParagraph(warning));
                    });
                }else{
                    warningsEl.appendChild(makeParagraph(noWarning));
                }
            }

            if(adviceEl){
                adviceEl.innerHTML="";
                var advice=Array.isArray(item.advice) ? item.advice.slice(0,3) : [];

                advice.forEach(function(guide,adviceIndex){
                    adviceEl.appendChild(makeAdviceCard(guide,adviceIndex));
                });
            }
        }

        select.removeEventListener("change",window.kaakbayPriorityGuidanceSync || function(){});
        window.kaakbayPriorityGuidanceSync=syncPriorityGuidance;
        select.addEventListener("change",syncPriorityGuidance);
        select.addEventListener("input",syncPriorityGuidance);
        select.addEventListener("click",function(){setTimeout(syncPriorityGuidance,0);});
        select.addEventListener("keyup",syncPriorityGuidance);
        syncPriorityGuidance();
    }

    if(document.readyState === "loading"){
        document.addEventListener("DOMContentLoaded",bootPriorityGuidance);
    }else{
        bootPriorityGuidance();
    }
})();
</script>

<?php page_foot(); ?>
