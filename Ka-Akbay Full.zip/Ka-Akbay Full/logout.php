<?php
require_once __DIR__ . "/app/security.php";
require_once __DIR__ . "/app/functions.php";

$user = $_SESSION["user"] ?? null;

if ($user) {
    append_record("audit_logs", [
        "id" => "log-" . time() . "-" . bin2hex(random_bytes(3)),
        "userId" => $user["id"],
        "action" => "LOGOUT",
        "createdAt" => date("c")
    ]);
}

$_SESSION = [];

if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), "", time() - 42000, $params["path"], $params["domain"], $params["secure"], $params["httponly"]);
}

session_destroy();

header("Location: login.php");
exit;