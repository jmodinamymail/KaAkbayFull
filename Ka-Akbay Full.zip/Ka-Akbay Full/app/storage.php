<?php
require_once __DIR__ . "/config.php";

function storage_table_map() {
    return [
        "users" => "users",
        "academic_records" => "academic_records",
        "tasks" => "tasks",
        "schedules" => "schedules",
        "attendance" => "attendance",
        "validations" => "validations",
        "delete_requests" => "delete_requests",
        "audit_logs" => "audit_logs",
        "sections" => "sections",
        "system_settings" => "system_settings",
        "system_content" => "system_content",
        "announcements" => "announcements",
        "system_logs" => "system_logs",
        "backups" => "backups",
        "maintenance_settings" => "maintenance_settings"
    ];
}

function storage_files() {
    return storage_table_map();
}

function storage_table($key) {
    $tables = storage_table_map();
    return $tables[$key] ?? "";
}

function db() {
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $pdo = new PDO(DB_DSN, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::ATTR_PERSISTENT => false
    ]);

    return $pdo;
}

function ensure_storage() {
    static $done = false;

    if ($done) {
        return true;
    }

    foreach (storage_table_map() as $table) {
        db()->exec("create table if not exists public." . $table . " (id text primary key, data jsonb not null default '{}'::jsonb, created_at timestamptz default now(), updated_at timestamptz default now())");
    }

    $done = true;
    return true;
}

function storage_record_id($record) {
    if (!empty($record["id"])) {
        return (string)$record["id"];
    }

    return "rec-" . time() . "-" . bin2hex(random_bytes(4));
}

function storage_decode_row($row) {
    if (!$row) {
        return null;
    }

    $data = json_decode($row["data"] ?? "{}", true);

    if (!is_array($data)) {
        $data = [];
    }

    if (empty($data["id"])) {
        $data["id"] = $row["id"] ?? "";
    }

    return $data;
}

function storage_decode_rows($rows) {
    $records = [];

    foreach ($rows as $row) {
        $data = storage_decode_row($row);

        if (is_array($data)) {
            $records[] = $data;
        }
    }

    return $records;
}

function storage_valid_json_field($field) {
    return preg_match('/^[A-Za-z0-9_]+$/', (string)$field) === 1;
}

function storage_safe_order($order) {
    $allowedOrders = [
        "created_at asc, id asc",
        "created_at desc, id desc",
        "updated_at asc, id asc",
        "updated_at desc, id desc",
        "coalesce(data->>'date', data->>'createdAt', '') asc, created_at asc, id asc",
        "coalesce(data->>'date', data->>'createdAt', '') desc, created_at desc, id desc",
        "coalesce(data->>'assessmentDate', data->>'createdAt', '') asc, created_at asc, id asc",
        "coalesce(data->>'assessmentDate', data->>'createdAt', '') desc, created_at desc, id desc",
        "coalesce(data->>'dueDate', data->>'createdAt', '') asc, created_at asc, id asc",
        "coalesce(data->>'dueDate', data->>'createdAt', '') desc, created_at desc, id desc",
        "coalesce(data->>'name', '') asc, created_at asc, id asc",
        "coalesce(data->>'section', '') asc, created_at asc, id asc"
    ];

    return in_array($order, $allowedOrders, true) ? $order : "created_at asc, id asc";
}

function read_records($key) {
    $table = storage_table($key);

    if ($table === "") {
        return [];
    }

    try {
        $stmt = db()->query("select id, data from public." . $table . " order by created_at asc, id asc");
        return storage_decode_rows($stmt->fetchAll());
    } catch (Throwable $e) {
        return [];
    }
}

function read_records_limit($key, $limit = 100, $offset = 0) {
    $table = storage_table($key);

    if ($table === "") {
        return [];
    }

    try {
        $stmt = db()->prepare("select id, data from public." . $table . " order by created_at asc, id asc limit ? offset ?");
        $stmt->execute([(int)$limit, (int)$offset]);
        return storage_decode_rows($stmt->fetchAll());
    } catch (Throwable $e) {
        return [];
    }
}

function read_records_where($key, $field, $value = null, $order = "created_at asc, id asc") {
    $table = storage_table($key);

    if ($table === "") {
        return [];
    }

    if (is_array($field)) {
        return read_records_where_many($key, $field, is_string($value) ? $value : $order);
    }

    if ($field === "" || !storage_valid_json_field($field)) {
        return [];
    }

    $order = storage_safe_order($order);

    try {
        $stmt = db()->prepare("select id, data from public." . $table . " where data->>? = ? order by " . $order);
        $stmt->execute([(string)$field, (string)$value]);
        return storage_decode_rows($stmt->fetchAll());
    } catch (Throwable $e) {
        return [];
    }
}

function read_records_where_in($key, $field, $values, $order = "created_at asc, id asc") {
    $table = storage_table($key);

    if ($table === "" || $field === "" || !storage_valid_json_field($field) || !is_array($values) || !count($values)) {
        return [];
    }

    $order = storage_safe_order($order);
    $values = array_values(array_unique(array_map("strval", $values)));
    $placeholders = implode(",", array_fill(0, count($values), "?"));

    try {
        $params = array_merge([(string)$field], $values);
        $stmt = db()->prepare("select id, data from public." . $table . " where data->>? in (" . $placeholders . ") order by " . $order);
        $stmt->execute($params);
        return storage_decode_rows($stmt->fetchAll());
    } catch (Throwable $e) {
        return [];
    }
}

function read_records_where_many($key, $filters, $order = "created_at asc, id asc") {
    $table = storage_table($key);

    if ($table === "" || !is_array($filters) || !count($filters)) {
        return [];
    }

    $order = storage_safe_order($order);
    $where = [];
    $params = [];

    foreach ($filters as $field => $value) {
        if ($field === "" || !storage_valid_json_field($field)) {
            continue;
        }

        $where[] = "data->>? = ?";
        $params[] = (string)$field;
        $params[] = (string)$value;
    }

    if (!count($where)) {
        return [];
    }

    try {
        $stmt = db()->prepare("select id, data from public." . $table . " where " . implode(" and ", $where) . " order by " . $order);
        $stmt->execute($params);
        return storage_decode_rows($stmt->fetchAll());
    } catch (Throwable $e) {
        return [];
    }
}

function find_storage_record_by_id($key, $id) {
    $table = storage_table($key);

    if ($table === "" || $id === "") {
        return null;
    }

    try {
        $stmt = db()->prepare("select id, data from public." . $table . " where id = ? limit 1");
        $stmt->execute([(string)$id]);
        return storage_decode_row($stmt->fetch());
    } catch (Throwable $e) {
        return null;
    }
}

function find_storage_record_by_field($key, $field, $value) {
    $table = storage_table($key);

    if ($table === "" || $field === "" || !storage_valid_json_field($field)) {
        return null;
    }

    try {
        $stmt = db()->prepare("select id, data from public." . $table . " where data->>? = ? limit 1");
        $stmt->execute([(string)$field, (string)$value]);
        return storage_decode_row($stmt->fetch());
    } catch (Throwable $e) {
        return null;
    }
}

function write_records($key, $data) {
    $table = storage_table($key);

    if ($table === "" || !is_array($data)) {
        return false;
    }

    try {
        $pdo = db();
        $pdo->beginTransaction();
        $pdo->exec("delete from public." . $table);
        $stmt = $pdo->prepare("insert into public." . $table . " (id, data) values (?, cast(? as jsonb)) on conflict (id) do update set data = excluded.data, updated_at = now()");

        foreach (array_values($data) as $record) {
            if (!is_array($record)) {
                continue;
            }

            $id = storage_record_id($record);
            $record["id"] = $id;
            $stmt->execute([$id, json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)]);
        }

        $pdo->commit();
        return true;
    } catch (Throwable $e) {
        if (isset($pdo) && $pdo->inTransaction()) {
            $pdo->rollBack();
        }

        return false;
    }
}

function append_record($key, $record) {
    $table = storage_table($key);

    if ($table === "" || !is_array($record)) {
        return $record;
    }

    try {
        $id = storage_record_id($record);
        $record["id"] = $id;
        $stmt = db()->prepare("insert into public." . $table . " (id, data) values (?, cast(? as jsonb)) on conflict (id) do update set data = excluded.data, updated_at = now()");
        $stmt->execute([$id, json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)]);
        return $record;
    } catch (Throwable $e) {
        return $record;
    }
}

function update_record_by_id($key, $id, $updatedRecord) {
    $table = storage_table($key);

    if ($table === "" || $id === "" || !is_array($updatedRecord)) {
        return false;
    }

    try {
        $updatedRecord["id"] = $id;
        $stmt = db()->prepare("insert into public." . $table . " (id, data) values (?, cast(? as jsonb)) on conflict (id) do update set data = excluded.data, updated_at = now()");
        $stmt->execute([(string)$id, json_encode($updatedRecord, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)]);
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

function delete_record_by_id($key, $id) {
    $table = storage_table($key);

    if ($table === "" || $id === "") {
        return false;
    }

    try {
        $stmt = db()->prepare("delete from public." . $table . " where id = ?");
        $stmt->execute([(string)$id]);
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

function delete_records_where($key, $field, $value) {
    $table = storage_table($key);

    if ($table === "" || $field === "" || !storage_valid_json_field($field)) {
        return false;
    }

    try {
        $stmt = db()->prepare("delete from public." . $table . " where data->>? = ?");
        $stmt->execute([(string)$field, (string)$value]);
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

function count_records($key) {
    $table = storage_table($key);

    if ($table === "") {
        return 0;
    }

    try {
        $stmt = db()->query("select count(*) as total from public." . $table);
        $row = $stmt->fetch();
        return (int)($row["total"] ?? 0);
    } catch (Throwable $e) {
        return 0;
    }
}

function count_records_where($key, $field, $value) {
    $table = storage_table($key);

    if ($table === "" || $field === "" || !storage_valid_json_field($field)) {
        return 0;
    }

    try {
        $stmt = db()->prepare("select count(*) as total from public." . $table . " where data->>? = ?");
        $stmt->execute([(string)$field, (string)$value]);
        $row = $stmt->fetch();
        return (int)($row["total"] ?? 0);
    } catch (Throwable $e) {
        return 0;
    }
}