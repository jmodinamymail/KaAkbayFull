<?php

date_default_timezone_set("Asia/Manila");

if (!function_exists("kaakbay_load_secrets")) {
    function kaakbay_load_secrets() {
        $paths = [];
        $explicit = getenv("KA_AKBAY_SECRETS_FILE");

        if ($explicit !== false && trim((string)$explicit) !== "") {
            $paths[] = trim((string)$explicit);
        }

        $documentRoot = trim((string)($_SERVER["DOCUMENT_ROOT"] ?? ""));

        if ($documentRoot !== "") {
            $paths[] = dirname(rtrim($documentRoot, "/\\")) . DIRECTORY_SEPARATOR . "kaakbay-secrets.php";
        }

        $paths[] = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . "kaakbay-secrets.php";

        foreach (array_values(array_unique($paths)) as $path) {
            if ($path !== "" && is_file($path) && is_readable($path)) {
                $values = require $path;

                if (is_array($values)) {
                    return $values;
                }
            }
        }

        return [];
    }
}

if (!function_exists("kaakbay_config_value")) {
    function kaakbay_config_value($key, $default = "") {
        global $kaakbaySecrets;

        $key = trim((string)$key);
        $environmentValue = getenv($key);

        if ($environmentValue !== false && (string)$environmentValue !== "") {
            return (string)$environmentValue;
        }

        if (isset($_ENV[$key]) && (string)$_ENV[$key] !== "") {
            return (string)$_ENV[$key];
        }

        if (isset($_SERVER[$key]) && (string)$_SERVER[$key] !== "") {
            return (string)$_SERVER[$key];
        }

        if (is_array($kaakbaySecrets) && array_key_exists($key, $kaakbaySecrets)) {
            return (string)$kaakbaySecrets[$key];
        }

        return (string)$default;
    }
}

if (!function_exists("kaakbay_config_bool")) {
    function kaakbay_config_bool($key, $default = false) {
        $value = strtolower(trim(kaakbay_config_value($key, $default ? "1" : "0")));
        return in_array($value, ["1", "true", "yes", "on"], true);
    }
}

$kaakbaySecrets = kaakbay_load_secrets();

define("APP_NAME", "Ka-Akbay");
define("DATA_DIR", dirname(__DIR__) . "/data");
define("SESSION_NAME", "kaakbay_session");
define("APP_ENV", kaakbay_config_value("APP_ENV", "production"));
define("APP_URL", rtrim(kaakbay_config_value("APP_URL", "https://ka-akbay.site"), "/"));

define("DB_DRIVER", "pgsql");
define("DB_HOST", kaakbay_config_value("DB_HOST"));
define("DB_PORT", kaakbay_config_value("DB_PORT", "5432"));
define("DB_NAME", kaakbay_config_value("DB_NAME", "postgres"));
define("DB_USER", kaakbay_config_value("DB_USER"));
define("DB_PASS", kaakbay_config_value("DB_PASS"));
define("DB_SSLMODE", kaakbay_config_value("DB_SSLMODE", "require"));

define(
    "DB_DSN",
    "pgsql:host=" . DB_HOST .
    ";port=" . DB_PORT .
    ";dbname=" . DB_NAME .
    ";sslmode=" . DB_SSLMODE
);

define("MAIL_ENABLED", kaakbay_config_bool("MAIL_ENABLED", true));
define("MAIL_HOST", kaakbay_config_value("MAIL_HOST", "smtp.hostinger.com"));
define("MAIL_PORT", (int)kaakbay_config_value("MAIL_PORT", "587"));
define("MAIL_USERNAME", kaakbay_config_value("MAIL_USERNAME", "noreply@ka-akbay.site"));
define("MAIL_PASSWORD", kaakbay_config_value("MAIL_PASSWORD"));
define("MAIL_ENCRYPTION", strtolower(kaakbay_config_value("MAIL_ENCRYPTION", "tls")));
define("MAIL_FROM_ADDRESS", kaakbay_config_value("MAIL_FROM_ADDRESS", "noreply@ka-akbay.site"));
define("MAIL_FROM_NAME", kaakbay_config_value("MAIL_FROM_NAME", "Ka-Akbay"));
define("MAIL_TIMEOUT", max(5, min(60, (int)kaakbay_config_value("MAIL_TIMEOUT", "15"))));

$requiredConfiguration = [
    "DB_HOST" => DB_HOST,
    "DB_USER" => DB_USER,
    "DB_PASS" => DB_PASS
];

if (MAIL_ENABLED) {
    $requiredConfiguration["MAIL_USERNAME"] = MAIL_USERNAME;
    $requiredConfiguration["MAIL_PASSWORD"] = MAIL_PASSWORD;
}

$missingConfiguration = [];

foreach ($requiredConfiguration as $key => $value) {
    if (trim((string)$value) === "") {
        $missingConfiguration[] = $key;
    }
}

if ($missingConfiguration) {
    throw new RuntimeException(
        "Ka-Akbay server configuration is incomplete: " .
        implode(", ", $missingConfiguration)
    );
}

$mailBootstrap = __DIR__ . "/mail.php";

if (is_file($mailBootstrap)) {
    require_once $mailBootstrap;
}