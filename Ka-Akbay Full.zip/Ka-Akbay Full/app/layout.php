<?php
require_once __DIR__ . "/security.php";
require_once __DIR__ . "/functions.php";

function page_csp_nonce() {
    static $nonce = null;

    if ($nonce === null) {
        $nonce = base64_encode(random_bytes(18));
    }

    return $nonce;
}

function layout_system_settings() {
    if (function_exists("system_settings_record")) {
        return system_settings_record();
    }

    return [
        "systemName" => "Ka-Akbay",
        "logoUrl" => "",
        "primaryColor" => "#294fc3",
        "secondaryColor" => "#f5f7fb",
        "accentColor" => "#D4A017"
    ];
}

function page_head($title, $shell = true) {
    $cssPath = __DIR__ . "/../assets/css/style.css";
    $cssVersion = file_exists($cssPath) ? filemtime($cssPath) : time();
    $lang = function_exists("current_lang") ? current_lang() : "en";
    $settings = layout_system_settings();
    $cspNonce = page_csp_nonce();

    $systemName = trim((string)($settings["systemName"] ?? "Ka-Akbay"));

    if ($systemName === "") {
        $systemName = "Ka-Akbay";
    }

    $primaryColor = $settings["primaryColor"] ?? "#294fc3";
    $secondaryColor = $settings["secondaryColor"] ?? "#f5f7fb";
    $accentColor = $settings["accentColor"] ?? "#D4A017";
?>
<!DOCTYPE html>
<html lang="<?= e($lang) ?>" data-lang="<?= e($lang) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">

<meta
    http-equiv="Content-Security-Policy"
    content="default-src 'self' https://fonts.googleapis.com https://fonts.gstatic.com; img-src 'self' data:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; script-src 'self' 'nonce-<?= e($cspNonce) ?>'; script-src-attr 'none'; frame-ancestors 'self';"
>

<title><?= e($title) ?> | <?= e($systemName) ?></title>

<link
    rel="stylesheet"
    href="/assets/css/style.css?v=<?= e($cssVersion) ?>"
>

<style>
:root {
    --brand-primary: <?= e($primaryColor) ?>;
    --brand-secondary: <?= e($secondaryColor) ?>;
    --brand-accent: <?= e($accentColor) ?>;

    --primary: <?= e($primaryColor) ?>;
    --primary-dark: color-mix(in srgb, <?= e($primaryColor) ?> 78%, black);
    --primary-soft: color-mix(in srgb, <?= e($primaryColor) ?> 8%, white);
    --primary-line: color-mix(in srgb, <?= e($primaryColor) ?> 18%, white);

    --secondary: <?= e($secondaryColor) ?>;
    --accent: <?= e($accentColor) ?>;
}
</style>
</head>

<body data-lang="<?= e($lang) ?>">

<?php if ($shell): ?>
<div class="app">
<?php endif; ?>

<?php
}

function nav_icon($name) {
    $paths = [
        "dashboard" => '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
        "records" => '<path d="M2 4h6a4 4 0 0 1 4 4v13a3 3 0 0 0-3-3H2z"/><path d="M22 4h-6a4 4 0 0 0-4 4v13a3 3 0 0 1 3-3h7z"/>',
        "schedules" => '<rect x="3" y="4" width="18" height="18" rx="2.5"/><path d="M16 2v4M8 2v4M3 10h18"/>',
        "tasks" => '<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="m9 14 2 2 4-4"/>',
        "monitoring" => '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
        "validation" => '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
        "users" => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
        "content" => '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z"/><path d="M14 2v4a2 2 0 0 0 2 2h4M10 9H8M16 13H8M16 17H8"/>',
        "system" => '<rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><path d="M6 6h.01M6 18h.01"/>',
        "profile" => '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        "language" => '<circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
        "moon" => '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9z"/>',
        "sun" => '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/>',
        "logout" => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5M21 12H9"/>'
    ];

    $body = $paths[$name] ?? "";

    if ($body === "") {
        return "";
    }

    return '<svg class="nav-icon nav-icon-' . e($name) . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $body . '</svg>';
}

function nav_link($active, $key, $href, $label, $symbol) {
    $activeKeys = is_array($key) ? $key : [$key];
    $mainKey = $activeKeys[0] ?? "";
    $class = in_array($active, $activeKeys, true)
        ? "nav-item active"
        : "nav-item";

    return
        '<a class="' . e($class) . '" href="' . e($href) . '" data-nav="' . e($href) . '" data-key="' . e($mainKey) . '"' . (in_array($active, $activeKeys, true) ? ' aria-current="page"' : '') . '>' .
            '<span class="nav-symbol" aria-hidden="true">' . (nav_icon($symbol) ?: e($symbol)) . '</span>' .
            '<span>' . e($label) . '</span>' .
        '</a>';
}

function sidebar($active, $user) {
    $role = $user["role"] ?? "";
    $settings = layout_system_settings();

    $systemName = trim((string)($settings["systemName"] ?? "Ka-Akbay"));

    if ($systemName === "") {
        $systemName = "Ka-Akbay";
    }

    $logoUrl = trim((string)($settings["logoUrl"] ?? ""));
?>

<aside class="sidebar">
    <div>
        <div class="logo">
            <?php if ($logoUrl !== ""): ?>
                <img
                    src="<?= e($logoUrl) ?>"
                    alt="<?= e($systemName) ?>"
                    class="brand-logo"
                >
            <?php endif; ?>

            <span><?= e($systemName) ?></span>
        </div>

        <div class="menu-title">
            <?= e(msg(
                "OVERVIEW",
                "PANGKALAHATAN",
                "OVERVIEW"
            )) ?>
        </div>

        <nav class="nav-list">
            <?= nav_link(
                $active,
                "dashboard",
                "dashboard",
                msg(
                    "Dashboard",
                    "Dashboard",
                    "Dashboard"
                ),
                "dashboard"
            ) ?>

            <?php if ($role === "student"): ?>
                <?= nav_link(
                    $active,
                    "records",
                    "records",
                    msg(
                        "Academic Records",
                        "Talaang Akademiko",
                        "Academic Records"
                    ),
                    "records"
                ) ?>

                <?= nav_link(
                    $active,
                    "schedules",
                    "schedules",
                    msg(
                        "Subject Schedule",
                        "Iskedyul ng Asignatura",
                        "Subject Schedule"
                    ),
                    "schedules"
                ) ?>

                <?= nav_link(
                    $active,
                    "tasks",
                    "tasks",
                    msg(
                        "Smart Task Board",
                        "Smart Task Board",
                        "Smart Task Board"
                    ),
                    "tasks"
                ) ?>
            <?php endif; ?>

            <?php if ($role === "teacher"): ?>
                <?= nav_link(
                    $active,
                    ["monitoring", "flagged"],
                    "dashboard#monitoring",
                    msg(
                        "Student Monitoring",
                        "Pagsubaybay sa Mag-aaral",
                        "Student Monitoring"
                    ),
                    "monitoring"
                ) ?>

                <?= nav_link(
                    $active,
                    "validation",
                    "validation",
                    msg(
                        "Teacher Validation",
                        "Validation ng Guro",
                        "Teacher Validation"
                    ),
                    "validation"
                ) ?>
            <?php endif; ?>

            <?php if (in_array($role, ["admin", "super_admin"], true)): ?>
                <?= nav_link(
                    $active,
                    "users",
                    "users",
                    msg(
                        "User Access",
                        "Access ng User",
                        "User Access"
                    ),
                    "users"
                ) ?>

                <?= nav_link(
                    $active,
                    ["summary", "monitoring", "flagged"],
                    "dashboard#monitoring",
                    msg(
                        "Monitoring Summary",
                        "Buod ng Pagsubaybay",
                        "Monitoring Summary"
                    ),
                    "monitoring"
                ) ?>

                <?= nav_link(
                    $active,
                    "validation",
                    "validation",
                    msg(
                        "Validation Summary",
                        "Buod ng Validation",
                        "Validation Summary"
                    ),
                    "validation"
                ) ?>
            <?php endif; ?>

            <?php if ($role === "super_admin"): ?>
                <?= nav_link(
                    $active,
                    "content",
                    "content",
                    msg(
                        "Content Management",
                        "Content Management",
                        "Content Management"
                    ),
                    "content"
                ) ?>
            <?php endif; ?>

            <?php if ($role === "it_admin"): ?>
                <?= nav_link(
                    $active,
                    "system",
                    "system",
                    msg(
                        "System Management",
                        "System Management",
                        "System Management"
                    ),
                    "system"
                ) ?>
            <?php endif; ?>
        </nav>
    </div>

    <div class="sidebar-bottom">
        <div class="menu-title">
            <?= e(msg(
                "SETTINGS",
                "SETTINGS",
                "SETTINGS"
            )) ?>
        </div>

        <nav class="nav-list">
            <a
                href="profile"
                class="nav-item <?= $active === "profile" ? "active" : "" ?>"
                <?= $active === "profile" ? 'aria-current="page"' : "" ?>
            >
                <span class="nav-symbol" aria-hidden="true"><?= nav_icon("profile") ?></span>
                <span>
                    <?= e(msg(
                        "Profile",
                        "Profile",
                        "Profile"
                    )) ?>
                </span>
            </a>

            <a
                href="language"
                class="nav-item <?= $active === "language" ? "active" : "" ?>"
                <?= $active === "language" ? 'aria-current="page"' : "" ?>
            >
                <span class="nav-symbol" aria-hidden="true"><?= nav_icon("language") ?></span>
                <span>
                    <?= e(msg(
                        "Language",
                        "Wika",
                        "Language"
                    )) ?>
                </span>
            </a>

            <button
                class="nav-item theme-toggle"
                type="button"
                data-theme-toggle
                aria-label="Toggle theme"
            >
                <span
                    class="nav-symbol"
                    data-theme-symbol
                    aria-hidden="true"
                >
                    <?= nav_icon("moon") ?>
                    <?= nav_icon("sun") ?>
                </span>

                <span data-theme-label>
                    <?= e(msg(
                        "Dark Mode",
                        "Dark Mode",
                        "Dark Mode"
                    )) ?>
                </span>
            </button>

            <a
                href="logout"
                class="nav-item logout"
            >
                <span class="nav-symbol" aria-hidden="true"><?= nav_icon("logout") ?></span>

                <span>
                    <?= e(msg(
                        "Logout",
                        "Mag-logout",
                        "Logout"
                    )) ?>
                </span>
            </a>
        </nav>
    </div>
</aside>

<?php
}

function badge($text) {
    $displayText = function_exists("tv") ? tv($text) : $text;

    if (function_exists("view_state_class")) {
        $class = view_state_class($text);
    } else {
        $class = "good";

        if (
            text_has($text, "At-Risk") ||
            text_has($text, "Concern") ||
            text_has($text, "Mabigat") ||
            text_has($text, "Overdue") ||
            text_has($text, "Not Mastered") ||
            text_has($text, "Remediation") ||
            text_has($text, "Inactive") ||
            text_has($text, "Critical") ||
            text_has($text, "Not Consistent") ||
            text_has($text, "Incomplete") ||
            text_has($text, "Declining")
        ) {
            $class = "danger";
        } elseif (
            text_has($text, "Warning") ||
            text_has($text, "Nearing") ||
            text_has($text, "Katamtaman") ||
            text_has($text, "Needs") ||
            text_has($text, "High") ||
            text_has($text, "Medium") ||
            text_has($text, "Needs Review")
        ) {
            $class = "warning";
        }
    }

    return
        '<span class="status ' .
        e($class) .
        '">' .
        e($displayText) .
        '</span>';
}

function page_foot($shell = true) {
    $jsPath = __DIR__ . "/../assets/js/app.js";
    $jsVersion = file_exists($jsPath)
        ? filemtime($jsPath)
        : time();
?>

<?php if ($shell): ?>
</div>
<?php endif; ?>

<script src="/assets/js/app.js?v=<?= e($jsVersion) ?>"></script>

</body>
</html>

<?php
}