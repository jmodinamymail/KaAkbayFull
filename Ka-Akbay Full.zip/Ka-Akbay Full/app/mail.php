<?php

if (!function_exists("kaakbay_mailer_autoload")) {
    function kaakbay_mailer_autoload() {
        if (class_exists("PHPMailer\\PHPMailer\\PHPMailer")) {
            return true;
        }

        $autoloaders = [
            dirname(__DIR__) . "/vendor/autoload.php",
            dirname(__DIR__, 2) . "/vendor/autoload.php"
        ];

        foreach ($autoloaders as $autoload) {
            if (is_file($autoload)) {
                require_once $autoload;

                if (class_exists("PHPMailer\\PHPMailer\\PHPMailer")) {
                    return true;
                }
            }
        }

        return false;
    }
}

if (!function_exists("kaakbay_security_email_content")) {
    function kaakbay_security_email_content($type, $token, $expiresAt) {
        $type = trim((string)$type);
        $token = trim((string)$token);
        $expiresAt = trim((string)$expiresAt);

        $safeToken = htmlspecialchars($token, ENT_QUOTES, "UTF-8");
        $expiryText = "";

        if ($expiresAt !== "" && strtotime($expiresAt)) {
            $expiryText = date("M d, Y \\a\\t g:i A", strtotime($expiresAt));
        }

        $safeExpiry = htmlspecialchars($expiryText, ENT_QUOTES, "UTF-8");
        $baseUrl = defined("APP_URL") ? rtrim((string)APP_URL, "/") : "";
        $deliveryTipHtml = "<p><strong>Email Delivery Tip:</strong> If this message is in your Spam or Junk folder, mark it as not spam so future Ka-Akbay security emails are easier to find.</p>";
        $deliveryTipText = "Email Delivery Tip: If this message is in your Spam or Junk folder, mark it as not spam so future Ka-Akbay security emails are easier to find.\n\n";

        if ($type === "privileged_login_otp") {
            $spacedToken = implode(" ", str_split($token));
            $safeSpacedToken = htmlspecialchars(
                $spacedToken,
                ENT_QUOTES,
                "UTF-8"
            );

            return [
                "subject" => "ACTION REQUIRED: Ka-Akbay Sign-In Authentication",

                "html" =>
                    "<p>A privileged sign-in attempt was made on your Ka-Akbay account.</p>" .

                    "<p><strong>Your Authentication Code:</strong></p>" .

                    "<p style=\"font-size:30px;font-weight:700;letter-spacing:7px;margin:18px 0;\">" .
                        $safeSpacedToken .
                    "</p>" .

                    ($safeExpiry !== ""
                        ? "<p>This authentication code will expire on <strong>" .
                            $safeExpiry .
                            "</strong>.</p>"
                        : "") .

                    $deliveryTipHtml .

                    "<p><strong>Important Security Notice:</strong></p>" .

                    "<p>Do not forward this email or share this 6-digit authentication code with anyone. Ka-Akbay representatives will never ask you to provide this code.</p>" .

                    "<p>If you did not initiate this sign-in attempt, do not use or share the code. Consider changing your password if you believe someone else may know your account credentials.</p>" .

                    "<p>Regards,<br><strong>The Ka-Akbay Team</strong></p>",

                "text" =>
                    "A privileged sign-in attempt was made on your Ka-Akbay account.\n\n" .

                    "Your Authentication Code:\n" .
                    $spacedToken . "\n\n" .

                    ($expiryText !== ""
                        ? "This authentication code will expire on " .
                            $expiryText .
                            ".\n\n"
                        : "") .

                    $deliveryTipText .

                    "Important Security Notice:\n" .
                    "Do not forward this email or share this 6-digit authentication code with anyone. Ka-Akbay representatives will never ask you to provide this code.\n\n" .

                    "If you did not initiate this sign-in attempt, do not use or share the code. Consider changing your password if you believe someone else may know your account credentials.\n\n" .

                    "Regards,\n" .
                    "The Ka-Akbay Team"
            ];
        }

        if ($type === "password_change_otp") {
            $spacedToken = implode(" ", str_split($token));
            $safeSpacedToken = htmlspecialchars(
                $spacedToken,
                ENT_QUOTES,
                "UTF-8"
            );

            return [
                "subject" => "ACTION REQUIRED: Verify Your Ka-Akbay Password Change",

                "html" =>
                    "<p>A password change was requested while signed in to your Ka-Akbay account.</p>" .

                    "<p><strong>Your Verification Code:</strong></p>" .

                    "<p style=\"font-size:30px;font-weight:700;letter-spacing:7px;margin:18px 0;\">" .
                        $safeSpacedToken .
                    "</p>" .

                    ($safeExpiry !== ""
                        ? "<p>This verification code will expire on <strong>" .
                            $safeExpiry .
                            "</strong>.</p>"
                        : "") .

                    $deliveryTipHtml .

                    "<p><strong>Important Security Notice:</strong></p>" .

                    "<p>Do not forward this email or share this 6-digit verification code with anyone. Ka-Akbay representatives will never ask you to provide this code.</p>" .

                    "<p>If you did not request this password change, do not use or share the code. Review your account security because the request requires access to your signed-in account and current password.</p>" .

                    "<p>Regards,<br><strong>The Ka-Akbay Team</strong></p>",

                "text" =>
                    "A password change was requested while signed in to your Ka-Akbay account.\n\n" .

                    "Your Verification Code:\n" .
                    $spacedToken . "\n\n" .

                    ($expiryText !== ""
                        ? "This verification code will expire on " .
                            $expiryText .
                            ".\n\n"
                        : "") .

                    $deliveryTipText .

                    "Important Security Notice:\n" .
                    "Do not forward this email or share this 6-digit verification code with anyone. Ka-Akbay representatives will never ask you to provide this code.\n\n" .

                    "If you did not request this password change, do not use or share the code. Review your account security because the request requires access to your signed-in account and current password.\n\n" .

                    "Regards,\n" .
                    "The Ka-Akbay Team"
            ];
        }

        if ($baseUrl === "") {
            return null;
        }

        $routes = [
            "password_reset" => [
                "subject" => "Reset Your Ka-Akbay Password",
                "path" => "/login.php?mode=reset&token=",
                "intro" => "A password reset was requested for your Ka-Akbay account.",
                "instruction" => "Use the secure link below to create a new password and restore access to your account.",
                "button" => "Reset Password",
                "security" => "Do not forward this email or share the password reset link with anyone. The link is intended only for the account owner.",
                "unrequested" => "If you did not request a password reset, do not open the reset link. Your current password will remain unchanged unless the reset process is successfully completed."
            ],

            "recovery_email_verification" => [
                "subject" => "Verify Your Ka-Akbay Recovery Email",
                "path" => "/login.php?mode=verifyRecovery&token=",
                "intro" => "This email address was submitted as the recovery email for a Ka-Akbay account.",
                "instruction" => "Verify this email address before it can be used for password recovery and security verification.",
                "button" => "Verify Recovery Email",
                "security" => "Do not forward this email or share the verification link with anyone. The link is intended only for the owner of this email address.",
                "unrequested" => "If you did not request this verification, do not open the link. This email address will not become an active recovery email unless verification is successfully completed."
            ]
        ];

        if (!isset($routes[$type])) {
            return null;
        }

        $route = $routes[$type];

        $url = $baseUrl . $route["path"] . rawurlencode($token);

        $safeUrl = htmlspecialchars(
            $url,
            ENT_QUOTES,
            "UTF-8"
        );

        $safeIntro = htmlspecialchars(
            $route["intro"],
            ENT_QUOTES,
            "UTF-8"
        );

        $safeInstruction = htmlspecialchars(
            $route["instruction"],
            ENT_QUOTES,
            "UTF-8"
        );

        $safeButton = htmlspecialchars(
            $route["button"],
            ENT_QUOTES,
            "UTF-8"
        );

        $safeSecurity = htmlspecialchars(
            $route["security"],
            ENT_QUOTES,
            "UTF-8"
        );

        $safeUnrequested = htmlspecialchars(
            $route["unrequested"],
            ENT_QUOTES,
            "UTF-8"
        );

        return [
            "subject" => $route["subject"],

            "html" =>
                "<p>" . $safeIntro . "</p>" .

                "<p>" . $safeInstruction . "</p>" .

                "<p>" .
                    "<a href=\"" .
                        $safeUrl .
                        "\" style=\"display:inline-block;padding:12px 18px;background:#294FC3;color:#ffffff;text-decoration:none;border-radius:6px;font-weight:700;\">" .
                        $safeButton .
                    "</a>" .
                "</p>" .

                "<p>If the button does not work, copy and open the following link in your browser:</p>" .

                "<p style=\"word-break:break-all;\">" .
                    $safeUrl .
                "</p>" .

                ($safeExpiry !== ""
                    ? "<p>This security link will expire on <strong>" .
                        $safeExpiry .
                        "</strong>.</p>"
                    : "") .

                $deliveryTipHtml .

                "<p><strong>Important Security Notice:</strong></p>" .

                "<p>" .
                    $safeSecurity .
                "</p>" .

                "<p>" .
                    $safeUnrequested .
                "</p>" .

                "<p>Regards,<br><strong>The Ka-Akbay Team</strong></p>",

            "text" =>
                $route["intro"] . "\n\n" .

                $route["instruction"] . "\n\n" .

                "Open the following secure link:\n" .
                $url . "\n\n" .

                ($expiryText !== ""
                    ? "This security link will expire on " .
                        $expiryText .
                        ".\n\n"
                    : "") .

                $deliveryTipText .

                "Important Security Notice:\n" .
                $route["security"] . "\n\n" .

                $route["unrequested"] . "\n\n" .

                "Regards,\n" .
                "The Ka-Akbay Team"
        ];
    }
}

if (!function_exists("send_security_email_message")) {
    function send_security_email_message($payload) {
        if (!defined("MAIL_ENABLED") || !MAIL_ENABLED) {
            return [
                "ok" => false,
                "sent" => false,
                "queued" => false,
                "message" => "Email delivery is disabled."
            ];
        }

        if (!is_array($payload)) {
            return [
                "ok" => false,
                "sent" => false,
                "queued" => false,
                "message" => "Invalid email request."
            ];
        }

        $recipient = strtolower(
            trim((string)($payload["recipient"] ?? ""))
        );

        $type = trim(
            (string)($payload["type"] ?? "")
        );

        $token = trim(
            (string)($payload["token"] ?? "")
        );

        $expiresAt = trim(
            (string)($payload["expiresAt"] ?? "")
        );

        if (
            $recipient === "" ||
            !filter_var($recipient, FILTER_VALIDATE_EMAIL) ||
            $type === "" ||
            $token === ""
        ) {
            return [
                "ok" => false,
                "sent" => false,
                "queued" => false,
                "message" => "Unable to prepare the security email."
            ];
        }

        $content = kaakbay_security_email_content(
            $type,
            $token,
            $expiresAt
        );

        if (!is_array($content)) {
            return [
                "ok" => false,
                "sent" => false,
                "queued" => false,
                "message" => "Unsupported security email type."
            ];
        }

        if (!kaakbay_mailer_autoload()) {
            error_log(
                "Ka-Akbay mail delivery failed because PHPMailer is unavailable."
            );

            return [
                "ok" => false,
                "sent" => false,
                "queued" => false,
                "message" => "Email delivery is not available on the server."
            ];
        }

        try {
            $mail = new PHPMailer\PHPMailer\PHPMailer(true);

            $mail->isSMTP();
            $mail->Host = MAIL_HOST;
            $mail->SMTPAuth = true;
            $mail->Username = MAIL_USERNAME;
            $mail->Password = MAIL_PASSWORD;
            $mail->Port = MAIL_PORT;
            $mail->Timeout = MAIL_TIMEOUT;
            $mail->SMTPDebug = 0;
            $mail->CharSet = "UTF-8";

            if (
                MAIL_ENCRYPTION === "ssl" ||
                MAIL_ENCRYPTION === "smtps"
            ) {
                $mail->SMTPSecure =
                    PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
            } else {
                $mail->SMTPSecure =
                    PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            }

            $mail->setFrom(
                MAIL_FROM_ADDRESS,
                MAIL_FROM_NAME
            );

            $mail->addAddress($recipient);

            $mail->Subject = (string)$content["subject"];

            $mail->isHTML(true);
            $mail->Body = (string)$content["html"];
            $mail->AltBody = (string)$content["text"];

            $mail->send();

            return [
                "ok" => true,
                "sent" => true,
                "queued" => false,
                "message" => ""
            ];
        } catch (Throwable $exception) {
            error_log(
                "Ka-Akbay security email delivery failed."
            );

            return [
                "ok" => false,
                "sent" => false,
                "queued" => false,
                "message" => "The security email could not be sent."
            ];
        }
    }
}