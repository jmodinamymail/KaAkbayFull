<?php
require_once __DIR__ . "/security.php";

function storage_table_map() {
    return [
        "users" => "users",
        "academic_records" => "academic_records",
        "tasks" => "tasks",
        "schedules" => "schedules",
        "attendance" => "attendance",
        "validations" => "validations",
        "delete_requests" => "delete_requests",
        "sections" => "sections",
        "audit_logs" => "audit_logs",
        "system_settings" => "system_settings",
        "system_content" => "system_content",
        "announcements" => "announcements",
        "system_logs" => "system_logs",
        "backups" => "backups",
        "maintenance_settings" => "maintenance_settings"
    ];
}

function storage_files() {
    return storage_table_map();
}

function storage_table($key) {
    $tables = storage_table_map();
    return $tables[$key] ?? "";
}

function db() {
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $pdo = new PDO(DB_DSN, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
    ]);

    return $pdo;
}

function ensure_storage() {
    static $done = false;

    if ($done) {
        return true;
    }

    if (defined("DB_AUTO_CREATE_TABLES") && DB_AUTO_CREATE_TABLES) {
        foreach (storage_table_map() as $table) {
            db()->exec("create table if not exists public." . $table . " (id text primary key, data jsonb not null default '{}'::jsonb, created_at timestamptz default now(), updated_at timestamptz default now())");
        }
    }

    $done = true;
    return true;
}


function storage_record_id($record) {
    if (!empty($record["id"])) {
        return (string)$record["id"];
    }

    return "rec-" . time() . "-" . bin2hex(random_bytes(4));
}

function storage_cache_key($key, $criteria = [], $orderSql = "") {
    return $key . "|" . md5(json_encode([$criteria, $orderSql]));
}

function storage_cache_pool($action, $key = null, $value = null) {
    static $cache = [];

    if ($action === "get") {
        return array_key_exists($key, $cache) ? $cache[$key] : null;
    }

    if ($action === "set") {
        $cache[$key] = $value;
        return $value;
    }

    if ($action === "clear") {
        $cache = [];
        return true;
    }

    return null;
}

function storage_cache_get($key) {
    return storage_cache_pool("get", $key);
}

function storage_cache_set($key, $value) {
    return storage_cache_pool("set", $key, $value);
}

function storage_cache_clear() {
    return storage_cache_pool("clear");
}

function storage_decode_row($row) {
    $data = json_decode($row["data"] ?? "{}", true);

    if (!is_array($data)) {
        $data = [];
    }

    if (empty($data["id"])) {
        $data["id"] = $row["id"] ?? "";
    }

    return $data;
}

function storage_decode_rows($rows) {
    $records = [];

    foreach ($rows as $row) {
        $records[] = storage_decode_row($row);
    }

    return $records;
}

function storage_valid_json_field($field) {
    return preg_match('/^[A-Za-z0-9_]+$/', (string)$field) === 1;
}

function read_records_where($key, $criteria = [], $orderSql = "created_at asc, id asc") {
    $table = storage_table($key);

    if ($table === "") {
        return [];
    }

    $criteria = is_array($criteria) ? $criteria : [];
    $cacheKey = storage_cache_key($key, $criteria, $orderSql);
    $cached = storage_cache_get($cacheKey);

    if ($cached !== null) {
        return $cached;
    }

    try {
        $where = [];
        $params = [];

        foreach ($criteria as $field => $value) {
            if (!storage_valid_json_field($field)) {
                return [];
            }

            $where[] = "data->>'" . $field . "' = ?";
            $params[] = (string)$value;
        }

        $sql = "select id, data from public." . $table;

        if (count($where)) {
            $sql .= " where " . implode(" and ", $where);
        }

        if ($orderSql !== "") {
            $sql .= " order by " . $orderSql;
        }

        $stmt = db()->prepare($sql);
        $stmt->execute($params);

        return storage_cache_set($cacheKey, storage_decode_rows($stmt->fetchAll()));
    } catch (Throwable $e) {
        return [];
    }
}

function read_records_matching($key, $field, $value, $orderSql = "created_at asc, id asc") {
    return read_records_where($key, [$field => $value], $orderSql);
}

function find_storage_record_where($key, $criteria = []) {
    $records = read_records_where($key, $criteria, "created_at desc, id desc limit 1");
    return $records[0] ?? null;
}


function read_records($key) {
    return read_records_where($key, [], "created_at asc, id asc");
}


function write_records($key, $data) {
    $table = storage_table($key);

    if ($table === "" || !is_array($data)) {
        return false;
    }

    try {
        $pdo = db();
        $pdo->beginTransaction();
        $pdo->exec("delete from public." . $table);
        $stmt = $pdo->prepare("insert into public." . $table . " (id, data) values (?, cast(? as jsonb)) on conflict (id) do update set data = excluded.data");

        foreach (array_values($data) as $record) {
            if (!is_array($record)) {
                continue;
            }

            $id = storage_record_id($record);
            $record["id"] = $id;
            $stmt->execute([$id, json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)]);
        }

        $pdo->commit();
        storage_cache_clear();
        return true;
    } catch (Throwable $e) {
        if (isset($pdo) && $pdo->inTransaction()) {
            $pdo->rollBack();
        }

        return false;
    }
}


function append_record($key, $record) {
    $table = storage_table($key);

    if ($table === "" || !is_array($record)) {
        return $record;
    }

    try {
        $id = storage_record_id($record);
        $record["id"] = $id;
        $stmt = db()->prepare("insert into public." . $table . " (id, data, created_at, updated_at) values (?, cast(? as jsonb), now(), now()) on conflict (id) do update set data = excluded.data, updated_at = now()");
        $stmt->execute([$id, json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)]);
        storage_cache_clear();
        return $record;
    } catch (Throwable $e) {
        return $record;
    }
}



function update_record_by_id($key, $id, $updatedRecord) {
    $table = storage_table($key);

    if ($table === "" || $id === "" || !is_array($updatedRecord)) {
        return false;
    }

    try {
        $updatedRecord["id"] = $id;
        $stmt = db()->prepare("insert into public." . $table . " (id, data, created_at, updated_at) values (?, cast(? as jsonb), now(), now()) on conflict (id) do update set data = excluded.data, updated_at = now()");
        $stmt->execute([$id, json_encode($updatedRecord, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)]);
        storage_cache_clear();
        return true;
    } catch (Throwable $e) {
        return false;
    }
}



function delete_record_by_id($key, $id) {
    $table = storage_table($key);

    if ($table === "" || $id === "") {
        return false;
    }

    try {
        $stmt = db()->prepare("delete from public." . $table . " where id = ?");
        $stmt->execute([$id]);
        storage_cache_clear();
        return true;
    } catch (Throwable $e) {
        return false;
    }
}


function find_storage_record_by_id($key, $id) {
    $table = storage_table($key);

    if ($table === "" || $id === "") {
        return null;
    }

    $cacheKey = storage_cache_key($key, ["id" => $id], "single-id");
    $cached = storage_cache_get($cacheKey);

    if ($cached !== null) {
        return $cached;
    }

    try {
        $stmt = db()->prepare("select id, data from public." . $table . " where id = ? limit 1");
        $stmt->execute([$id]);
        $row = $stmt->fetch();

        if (!$row) {
            return null;
        }

        return storage_cache_set($cacheKey, storage_decode_row($row));
    } catch (Throwable $e) {
        return null;
    }
}


function find_user_by_id($id) {
    return find_storage_record_by_id("users", $id);
}

function find_record_by_id($id) {
    return find_storage_record_by_id("academic_records", $id);
}

function current_lang() {
    $lang = $_SESSION["lang"] ?? "en";

    if (!in_array($lang, ["en", "tl", "tg"], true)) {
        return "en";
    }

    return $lang;
}

function language_label($lang = "") {
    $lang = $lang ?: current_lang();

    if ($lang === "tl") {
        return "Tagalog";
    }

    if ($lang === "tg") {
        return "Taglish";
    }

    return "English";
}

function msg($en, $tl, $tg = null) {
    $lang = current_lang();

    if ($lang === "tl") {
        return $tl;
    }

    if ($lang === "tg") {
        return $tg ?? $tl;
    }

    return $en;
}

function t($key) {
    $lang = current_lang();

    $texts = [
        "app_name" => ["en" => "Ka-Akbay", "tl" => "Ka-Akbay", "tg" => "Ka-Akbay"],
        "login" => ["en" => "Login", "tl" => "Mag-login", "tg" => "Login"],
        "logout" => ["en" => "Logout", "tl" => "Mag-logout", "tg" => "Logout"],
        "email" => ["en" => "Email", "tl" => "Email", "tg" => "Email"],
        "password" => ["en" => "Password", "tl" => "Password", "tg" => "Password"],
        "dashboard" => ["en" => "Dashboard", "tl" => "Dashboard", "tg" => "Dashboard"],
        "academic_records" => ["en" => "Academic Records", "tl" => "Talaang Akademiko", "tg" => "Academic Records"],
        "records" => ["en" => "Records", "tl" => "Mga Tala", "tg" => "Records"],
        "tasks" => ["en" => "Tasks", "tl" => "Mga Gawain", "tg" => "Tasks"],
        "smart_task_board" => ["en" => "Smart Task Board", "tl" => "Smart Task Board", "tg" => "Smart Task Board"],
        "subject_schedule" => ["en" => "Subject Schedule", "tl" => "Iskedyul ng Asignatura", "tg" => "Subject Schedule"],
        "schedule" => ["en" => "Schedule", "tl" => "Iskedyul", "tg" => "Schedule"],
        "monitoring" => ["en" => "Monitoring", "tl" => "Pagsubaybay", "tg" => "Monitoring"],
        "validation" => ["en" => "Validation", "tl" => "Pagpapatunay", "tg" => "Validation"],
        "teacher_validation" => ["en" => "Teacher Validation", "tl" => "Pagpapatunay ng Guro", "tg" => "Teacher Validation"],
        "users" => ["en" => "Users", "tl" => "Mga User", "tg" => "Users"],
        "profile" => ["en" => "Profile", "tl" => "Profile", "tg" => "Profile"],
        "settings" => ["en" => "Settings", "tl" => "Settings", "tg" => "Settings"],
        "content_management" => ["en" => "Content Management", "tl" => "Content Management", "tg" => "Content Management"],
        "branding" => ["en" => "Branding", "tl" => "Branding", "tg" => "Branding"],
        "theme_colors" => ["en" => "Theme & Colors", "tl" => "Theme & Colors", "tg" => "Theme & Colors"],
        "announcements" => ["en" => "Announcements", "tl" => "Mga Announcement", "tg" => "Announcements"],
        "system_settings" => ["en" => "System Settings", "tl" => "System Settings", "tg" => "System Settings"],
        "system_health" => ["en" => "System Health", "tl" => "System Health", "tg" => "System Health"],
        "system_logs" => ["en" => "System Logs", "tl" => "System Logs", "tg" => "System Logs"],
        "backups" => ["en" => "Backups", "tl" => "Mga Backup", "tg" => "Backups"],
        "backup_restore" => ["en" => "Backup & Restore", "tl" => "Backup & Restore", "tg" => "Backup & Restore"],
        "maintenance_mode" => ["en" => "Maintenance Mode", "tl" => "Maintenance Mode", "tg" => "Maintenance Mode"],
        "technical_settings" => ["en" => "Technical Settings", "tl" => "Technical Settings", "tg" => "Technical Settings"],
        "super_admin" => ["en" => "Super Administrator", "tl" => "Super Administrator", "tg" => "Super Administrator"],
        "it_admin" => ["en" => "IT Administrator", "tl" => "IT Administrator", "tg" => "IT Administrator"],
        "language" => ["en" => "Language", "tl" => "Wika", "tg" => "Language"],
        "english" => ["en" => "English", "tl" => "English", "tg" => "English"],
        "tagalog" => ["en" => "Tagalog", "tl" => "Tagalog", "tg" => "Tagalog"],
        "taglish" => ["en" => "Taglish", "tl" => "Taglish", "tg" => "Taglish"],
        "save" => ["en" => "Save", "tl" => "I-save", "tg" => "Save"],
        "save_changes" => ["en" => "Save Changes", "tl" => "I-save ang Pagbabago", "tg" => "Save Changes"],
        "save_record" => ["en" => "Save Record", "tl" => "I-save ang Tala", "tg" => "Save Record"],
        "save_assessment" => ["en" => "Save Assessment", "tl" => "I-save ang Pagtataya", "tg" => "Save Assessment"],
        "save_schedule" => ["en" => "Save Schedule", "tl" => "I-save ang Iskedyul", "tg" => "Save Schedule"],
        "save_attendance" => ["en" => "Save Attendance", "tl" => "I-save ang Attendance", "tg" => "Save Attendance"],
        "save_validation" => ["en" => "Save Validation", "tl" => "I-save ang Validation", "tg" => "Save Validation"],
        "cancel" => ["en" => "Cancel", "tl" => "Kanselahin", "tg" => "Cancel"],
        "edit" => ["en" => "Edit", "tl" => "I-edit", "tg" => "Edit"],
        "delete" => ["en" => "Delete", "tl" => "Burahin", "tg" => "Delete"],
        "clear" => ["en" => "Clear", "tl" => "I-clear", "tg" => "Clear"],
        "search" => ["en" => "Search", "tl" => "Maghanap", "tg" => "Search"],
        "all" => ["en" => "All", "tl" => "Lahat", "tg" => "All"],
        "open" => ["en" => "Open", "tl" => "Buksan", "tg" => "Open"],
        "view_details" => ["en" => "View Details", "tl" => "Tingnan ang Detalye", "tg" => "View Details"],
        "mark_attendance" => ["en" => "Mark Attendance", "tl" => "Markahan ang Attendance", "tg" => "Mark Attendance"],
        "validate_output" => ["en" => "Validate Output", "tl" => "I-validate ang Output", "tg" => "Validate Output"],
        "assessment_entry" => ["en" => "Assessment Entry", "tl" => "Tala ng Pagtataya", "tg" => "Assessment Entry"],
        "edit_assessment_entry" => ["en" => "Edit Assessment Entry", "tl" => "I-edit ang Tala ng Pagtataya", "tg" => "Edit Assessment Entry"],
        "computed_quarterly_summary" => ["en" => "Computed Quarterly Summary", "tl" => "Nakalkulang Buod ng Markahan", "tg" => "Computed Quarterly Summary"],
        "assessment_history" => ["en" => "Assessment History", "tl" => "Kasaysayan ng Pagtataya", "tg" => "Assessment History"],
        "record_history" => ["en" => "Record History", "tl" => "Kasaysayan ng Tala", "tg" => "Record History"],
        "subject" => ["en" => "Subject", "tl" => "Asignatura", "tg" => "Subject"],
        "select_subject" => ["en" => "Select Subject", "tl" => "Pumili ng Asignatura", "tg" => "Select Subject"],
        "strand" => ["en" => "Strand", "tl" => "Strand", "tg" => "Strand"],
        "grade_level" => ["en" => "Grade Level", "tl" => "Baitang", "tg" => "Grade Level"],
        "grading_period" => ["en" => "Grading Period", "tl" => "Markahan", "tg" => "Grading Period"],
        "assessment_type" => ["en" => "Assessment Type", "tl" => "Uri ng Pagtataya", "tg" => "Assessment Type"],
        "assessment_title" => ["en" => "Assessment Title", "tl" => "Pamagat ng Pagtataya", "tg" => "Assessment Title"],
        "score" => ["en" => "Score", "tl" => "Iskor", "tg" => "Score"],
        "total_score" => ["en" => "Total Score", "tl" => "Kabuuang Iskor", "tg" => "Total Score"],
        "submission_status" => ["en" => "Submission Status", "tl" => "Kalagayan ng Pagpapasa", "tg" => "Submission Status"],
        "assessment_date" => ["en" => "Assessment Date", "tl" => "Petsa ng Pagtataya", "tg" => "Assessment Date"],
        "competency_area" => ["en" => "Competency Area", "tl" => "Bahagi ng Kakayahan", "tg" => "Competency Area"],
        "correct_competency_items" => ["en" => "Correct Competency Items", "tl" => "Tamang Competency Items", "tg" => "Correct Competency Items"],
        "total_competency_items" => ["en" => "Total Competency Items", "tl" => "Kabuuang Competency Items", "tg" => "Total Competency Items"],
        "written_work" => ["en" => "Written Work", "tl" => "Written Work", "tg" => "Written Work"],
        "written_works" => ["en" => "Written Works", "tl" => "Written Works", "tg" => "Written Works"],
        "performance_task" => ["en" => "Performance Task", "tl" => "Performance Task", "tg" => "Performance Task"],
        "performance_tasks" => ["en" => "Performance Tasks", "tl" => "Performance Tasks", "tg" => "Performance Tasks"],
        "quarterly_assessment" => ["en" => "Quarterly Assessment", "tl" => "Quarterly Assessment", "tg" => "Quarterly Assessment"],
        "competency_check" => ["en" => "Competency Check", "tl" => "Competency Check", "tg" => "Competency Check"],
        "submitted" => ["en" => "Submitted", "tl" => "Naipasa", "tg" => "Submitted"],
        "incomplete" => ["en" => "Incomplete", "tl" => "Hindi Kumpleto", "tg" => "Incomplete"],
        "missing" => ["en" => "Missing", "tl" => "Kulang", "tg" => "Missing"],
        "grade" => ["en" => "Grade", "tl" => "Marka", "tg" => "Grade"],
        "mastery" => ["en" => "Mastery", "tl" => "Mastery", "tg" => "Mastery"],
        "attendance" => ["en" => "Attendance", "tl" => "Attendance", "tg" => "Attendance"],
        "absence" => ["en" => "Absence", "tl" => "Pagliban", "tg" => "Absence"],
        "absence_rate" => ["en" => "Absence Rate", "tl" => "Bahagdan ng Pagliban", "tg" => "Absence Rate"],
        "absence_streak" => ["en" => "Absence Streak", "tl" => "Sunod-sunod na Pagliban", "tg" => "Absence Streak"],
        "consecutive_absences" => ["en" => "Consecutive Absences", "tl" => "Sunod-sunod na Pagliban", "tg" => "Consecutive Absences"],
        "records_used" => ["en" => "Records Used", "tl" => "Mga Talang Ginamit", "tg" => "Records Used"],
        "mode" => ["en" => "Mode", "tl" => "Mode", "tg" => "Mode"],
        "computed" => ["en" => "Computed", "tl" => "Nakalkula", "tg" => "Computed"],
        "status" => ["en" => "Status", "tl" => "Kalagayan", "tg" => "Status"],
        "advisory" => ["en" => "Advisory", "tl" => "Payo", "tg" => "Advisory"],
        "guidance" => ["en" => "Guidance", "tl" => "Gabay", "tg" => "Guidance"],
        "type" => ["en" => "Type", "tl" => "Uri", "tg" => "Type"],
        "percent" => ["en" => "Percent", "tl" => "Porsiyento", "tg" => "Percent"],
        "competency" => ["en" => "Competency", "tl" => "Competency", "tg" => "Competency"],
        "no_assessment_entries" => ["en" => "No assessment entries yet", "tl" => "Wala pang tala ng pagtataya", "tg" => "No assessment entries yet"],
        "no_quarterly_summary" => ["en" => "No computed quarterly summary yet", "tl" => "Wala pang nakalkulang buod ng markahan", "tg" => "No computed quarterly summary yet"],
        "no_records" => ["en" => "No records yet", "tl" => "Wala pang tala", "tg" => "No records yet"],
        "no_tasks" => ["en" => "No tasks yet", "tl" => "Wala pang gawain", "tg" => "No tasks yet"],
        "no_schedule_entries" => ["en" => "No schedule entries yet", "tl" => "Wala pang iskedyul", "tg" => "No schedule entries yet"],
        "no_monitoring_records" => ["en" => "No monitoring records", "tl" => "Wala pang monitoring records", "tg" => "No monitoring records"],
        "academic_status" => ["en" => "Academic Status", "tl" => "Kalagayang Akademiko", "tg" => "Academic Status"],
        "main_status" => ["en" => "Main Status", "tl" => "Pangunahing Kalagayan", "tg" => "Main Status"],
        "priority_guidance" => ["en" => "Priority Guidance", "tl" => "Priority Guidance", "tg" => "Priority Guidance"],
        "weekly_load" => ["en" => "Weekly Load", "tl" => "Lingguhang Bigat", "tg" => "Weekly Load"],
        "workload_score" => ["en" => "Workload Score", "tl" => "Workload Score", "tg" => "Workload Score"],
        "study_time" => ["en" => "Study Time", "tl" => "Oras ng Pag-aaral", "tg" => "Study Time"],
        "pending" => ["en" => "Pending", "tl" => "Nakahintay", "tg" => "Pending"],
        "overdue" => ["en" => "Overdue", "tl" => "Lampas na sa Deadline", "tg" => "Overdue"],
        "alerts" => ["en" => "Alerts", "tl" => "Mga Alert", "tg" => "Alerts"],
        "suggested_routine" => ["en" => "Suggested Routine", "tl" => "Iminungkahing Routine", "tg" => "Suggested Routine"],
        "weekly" => ["en" => "Weekly", "tl" => "Lingguhan", "tg" => "Weekly"],
        "monthly" => ["en" => "Monthly", "tl" => "Buwanan", "tg" => "Monthly"],
        "activity_overview" => ["en" => "Activity Overview", "tl" => "Buod ng Aktibidad", "tg" => "Activity Overview"],
        "current_flags" => ["en" => "Current Flags", "tl" => "Kasalukuyang Flags", "tg" => "Current Flags"],
        "recent_tasks" => ["en" => "Recent Tasks", "tl" => "Mga Recent Task", "tg" => "Recent Tasks"],
        "see_all" => ["en" => "See all", "tl" => "Tingnan lahat", "tg" => "See all"],
        "open_tasks" => ["en" => "Open Tasks", "tl" => "Buksan ang Tasks", "tg" => "Open Tasks"],
        "start_here" => ["en" => "Start Here", "tl" => "Magsimula Dito", "tg" => "Start Here"],
        "next_step" => ["en" => "Next Step", "tl" => "Susunod na Hakbang", "tg" => "Next Step"],
        "adjustment" => ["en" => "Adjustment", "tl" => "Pag-aayos", "tg" => "Adjustment"],
        "no_guidance" => ["en" => "No guidance yet", "tl" => "Wala pang gabay", "tg" => "No guidance yet"],
        "class_monitoring" => ["en" => "Class Monitoring", "tl" => "Pagsubaybay sa Klase", "tg" => "Class Monitoring"],
        "system_monitoring" => ["en" => "System Monitoring", "tl" => "Pagsubaybay ng System", "tg" => "System Monitoring"],
        "monitoring_records" => ["en" => "Monitoring Records", "tl" => "Mga Tala ng Pagsubaybay", "tg" => "Monitoring Records"],
        "flagged_records" => ["en" => "Flagged Records", "tl" => "Mga Na-flag na Tala", "tg" => "Flagged Records"],
        "grouped_summary" => ["en" => "Grouped Summary", "tl" => "Pinangkat na Buod", "tg" => "Grouped Summary"],
        "total_students" => ["en" => "Total Students", "tl" => "Kabuuang Mag-aaral", "tg" => "Total Students"],
        "total" => ["en" => "Total", "tl" => "Kabuuan", "tg" => "Total"],
        "regular" => ["en" => "Regular", "tl" => "Regular", "tg" => "Regular"],
        "warning" => ["en" => "Warning", "tl" => "Babala", "tg" => "Warning"],
        "at_risk" => ["en" => "At-Risk", "tl" => "Nanganganib", "tg" => "At-Risk"],
        "attendance_concern" => ["en" => "Attendance Concern", "tl" => "May Concern sa Attendance", "tg" => "Attendance Concern"],
        "mabigat" => ["en" => "Mabigat", "tl" => "Mabigat", "tg" => "Mabigat"],
        "needs_validation" => ["en" => "Needs Validation", "tl" => "Kailangang I-validate", "tg" => "Needs Validation"],
        "high_workload" => ["en" => "High Workload", "tl" => "Mabigat na Gawain", "tg" => "High Workload"],
        "students" => ["en" => "Students", "tl" => "Mga Mag-aaral", "tg" => "Students"],
        "student" => ["en" => "Student", "tl" => "Mag-aaral", "tg" => "Student"],
        "student_profile" => ["en" => "Student Profile", "tl" => "Profile ng Mag-aaral", "tg" => "Student Profile"],
        "search_and_filters" => ["en" => "Search and Filters", "tl" => "Search at Filters", "tg" => "Search and Filters"],
        "more_filters" => ["en" => "More Filters", "tl" => "Karagdagang Filters", "tg" => "More Filters"],
        "active" => ["en" => "Active", "tl" => "Aktibo", "tg" => "Active"],
        "inactive" => ["en" => "Inactive", "tl" => "Hindi Aktibo", "tg" => "Inactive"],
        "grouped_monitoring_summary" => ["en" => "Grouped Monitoring Summary", "tl" => "Pinangkat na Buod ng Monitoring", "tg" => "Grouped Monitoring Summary"],
        "outputs_for_validation" => ["en" => "Outputs for Validation", "tl" => "Mga Output para sa Validation", "tg" => "Outputs for Validation"],
        "validation_history" => ["en" => "Validation History", "tl" => "Kasaysayan ng Validation", "tg" => "Validation History"],
        "review_outputs" => ["en" => "Review Outputs", "tl" => "Suriin ang Outputs", "tg" => "Review Outputs"],
        "validation_status" => ["en" => "Validation Status", "tl" => "Kalagayan ng Validation", "tg" => "Validation Status"],
        "validation_note" => ["en" => "Validation Note", "tl" => "Tala ng Validation", "tg" => "Validation Note"],
        "system_output" => ["en" => "System Output", "tl" => "Output ng System", "tg" => "System Output"],
        "consistent" => ["en" => "Consistent", "tl" => "Tugma", "tg" => "Consistent"],
        "needs_review" => ["en" => "Needs Review", "tl" => "Kailangang Suriin", "tg" => "Needs Review"],
        "not_consistent" => ["en" => "Not Consistent", "tl" => "Hindi Tugma", "tg" => "Not Consistent"],
        "day" => ["en" => "Day", "tl" => "Araw", "tg" => "Day"],
        "start_time" => ["en" => "Start Time", "tl" => "Oras ng Simula", "tg" => "Start Time"],
        "end_time" => ["en" => "End Time", "tl" => "Oras ng Tapos", "tg" => "End Time"],
        "room" => ["en" => "Room", "tl" => "Silid", "tg" => "Room"],
        "teacher" => ["en" => "Teacher", "tl" => "Guro", "tg" => "Teacher"],
        "capacity_effect" => ["en" => "Capacity Effect", "tl" => "Epekto sa Capacity", "tg" => "Capacity Effect"],
        "attendance_summary" => ["en" => "Attendance Summary", "tl" => "Buod ng Attendance", "tg" => "Attendance Summary"],
        "calendar_view" => ["en" => "Calendar View", "tl" => "Calendar View", "tg" => "Calendar View"],
        "schedule_list" => ["en" => "Schedule List", "tl" => "Listahan ng Iskedyul", "tg" => "Schedule List"],
        "weekly_schedule" => ["en" => "Weekly Schedule", "tl" => "Lingguhang Iskedyul", "tg" => "Weekly Schedule"],
        "class_hours" => ["en" => "Class Hours", "tl" => "Oras ng Klase", "tg" => "Class Hours"],
        "available_study_time" => ["en" => "Available Study Time", "tl" => "Available Study Time", "tg" => "Available Study Time"],
        "total_weekly_hours" => ["en" => "Total Weekly Hours", "tl" => "Kabuuang Oras sa Isang Linggo", "tg" => "Total Weekly Hours"],
        "weekly_class_hours" => ["en" => "Weekly Class Hours", "tl" => "Lingguhang Oras ng Klase", "tg" => "Weekly Class Hours"],
        "sleep_buffer" => ["en" => "Sleep Buffer", "tl" => "Sleep Buffer", "tg" => "Sleep Buffer"],
        "personal_care_buffer" => ["en" => "Personal Care Buffer", "tl" => "Personal Care Buffer", "tg" => "Personal Care Buffer"],
        "non_academic_buffer" => ["en" => "Non-Academic Buffer", "tl" => "Non-Academic Buffer", "tg" => "Non-Academic Buffer"],
        "present" => ["en" => "Present", "tl" => "Present", "tg" => "Present"],
        "absent" => ["en" => "Absent", "tl" => "Absent", "tg" => "Absent"],
        "excused" => ["en" => "Excused", "tl" => "Excused", "tg" => "Excused"],
        "marked" => ["en" => "Marked", "tl" => "Na-markahan", "tg" => "Marked"],
        "date" => ["en" => "Date", "tl" => "Petsa", "tg" => "Date"],
        "note" => ["en" => "Note", "tl" => "Tala", "tg" => "Note"],
        "actions" => ["en" => "Actions", "tl" => "Aksyon", "tg" => "Actions"],
        "add_schedule" => ["en" => "Add Schedule", "tl" => "Magdagdag ng Iskedyul", "tg" => "Add Schedule"],
        "edit_schedule" => ["en" => "Edit Schedule", "tl" => "I-edit ang Iskedyul", "tg" => "Edit Schedule"],
        "task_title" => ["en" => "Task Title", "tl" => "Pamagat ng Task", "tg" => "Task Title"],
        "category" => ["en" => "Category", "tl" => "Kategorya", "tg" => "Category"],
        "difficulty" => ["en" => "Difficulty", "tl" => "Hirap", "tg" => "Difficulty"],
        "duration" => ["en" => "Duration", "tl" => "Tagal", "tg" => "Duration"],
        "estimated_duration" => ["en" => "Estimated Duration", "tl" => "Tinatayang Tagal", "tg" => "Estimated Duration"],
        "weight" => ["en" => "Weight", "tl" => "Bigat", "tg" => "Weight"],
        "due_date" => ["en" => "Due Date", "tl" => "Deadline", "tg" => "Due Date"],
        "start_date" => ["en" => "Start Date", "tl" => "Petsa ng Simula", "tg" => "Start Date"],
        "task_status" => ["en" => "Task Status", "tl" => "Kalagayan ng Task", "tg" => "Task Status"],
        "not_started" => ["en" => "Not Started", "tl" => "Hindi Pa Nasimulan", "tg" => "Not Started"],
        "in_progress" => ["en" => "In Progress", "tl" => "Ginagawa", "tg" => "In Progress"],
        "completed" => ["en" => "Completed", "tl" => "Tapos", "tg" => "Completed"],
        "rescheduled" => ["en" => "Rescheduled", "tl" => "Na-reschedule", "tg" => "Rescheduled"],
        "start" => ["en" => "Start", "tl" => "Simulan", "tg" => "Start"],
        "done" => ["en" => "Done", "tl" => "Tapos", "tg" => "Done"],
        "move" => ["en" => "Move", "tl" => "Ilipat", "tg" => "Move"],
        "dismiss" => ["en" => "Dismiss", "tl" => "I-dismiss", "tg" => "Dismiss"],
        "breakdown" => ["en" => "Breakdown", "tl" => "Hatiin", "tg" => "Breakdown"],
        "priority" => ["en" => "Priority", "tl" => "Prayoridad", "tg" => "Priority"],
        "low" => ["en" => "Low", "tl" => "Mababa", "tg" => "Low"],
        "medium" => ["en" => "Medium", "tl" => "Katamtaman", "tg" => "Medium"],
        "high" => ["en" => "High", "tl" => "Mataas", "tg" => "High"],
        "critical" => ["en" => "Critical", "tl" => "Kritikal", "tg" => "Critical"],
        "magaan" => ["en" => "Magaan", "tl" => "Magaan", "tg" => "Magaan"],
        "katamtaman" => ["en" => "Katamtaman", "tl" => "Katamtaman", "tg" => "Katamtaman"],
        "regular_attendance" => ["en" => "Regular Attendance", "tl" => "Regular na Attendance", "tg" => "Regular Attendance"],
        "warning_status" => ["en" => "Warning Status", "tl" => "Babala", "tg" => "Warning Status"],
        "at_risk_failing" => ["en" => "At-Risk / Failing", "tl" => "Nanganganib / Bagsak", "tg" => "At-Risk / Failing"],
        "mastered" => ["en" => "Mastered", "tl" => "Mastered", "tg" => "Mastered"],
        "nearing_mastery" => ["en" => "Nearing Mastery", "tl" => "Papalapit sa Mastery", "tg" => "Nearing Mastery"],
        "not_mastered_remediation" => ["en" => "Not Mastered / Remediation Needed", "tl" => "Hindi Mastered / Kailangan ng Remediation", "tg" => "Not Mastered / Remediation Needed"],
        "complete_requirements" => ["en" => "Complete Requirements", "tl" => "Kumpleto ang Requirements", "tg" => "Complete Requirements"],
        "incomplete_requirements" => ["en" => "Incomplete Requirements", "tl" => "Hindi Kumpleto ang Requirements", "tg" => "Incomplete Requirements"],
        "stable_performance_pattern" => ["en" => "Stable Performance Pattern", "tl" => "Stable ang Performance Pattern", "tg" => "Stable Performance Pattern"],
        "improving_performance_pattern" => ["en" => "Improving Performance Pattern", "tl" => "Pataas ang Performance Pattern", "tg" => "Improving Performance Pattern"],
        "declining_performance_pattern" => ["en" => "Declining Performance Pattern", "tl" => "Pababa ang Performance Pattern", "tg" => "Declining Performance Pattern"],
        "insufficient_trend_data" => ["en" => "Insufficient Trend Data", "tl" => "Kulang ang Trend Data", "tg" => "Insufficient Trend Data"],
        "no_record" => ["en" => "No Record", "tl" => "Walang Tala", "tg" => "No Record"],
        "regular_monitoring" => ["en" => "Regular Monitoring", "tl" => "Regular na Monitoring", "tg" => "Regular Monitoring"],
        "remediation" => ["en" => "Remediation", "tl" => "Remediation", "tg" => "Remediation"],
        "requirement_follow_up" => ["en" => "Requirement Follow-up", "tl" => "Follow-up sa Requirement", "tg" => "Requirement Follow-up"],
        "performance_monitoring" => ["en" => "Performance Monitoring", "tl" => "Performance Monitoring", "tg" => "Performance Monitoring"],
        "attendance_follow_up" => ["en" => "Attendance Follow-up", "tl" => "Follow-up sa Attendance", "tg" => "Attendance Follow-up"],
        "workload_follow_up" => ["en" => "Workload Follow-up", "tl" => "Follow-up sa Workload", "tg" => "Workload Follow-up"]
    ];

    return $texts[$key][$lang] ?? $texts[$key]["en"] ?? $key;
}

function text_key($text) {
    $map = [
        "Academic Records" => "academic_records",
        "Assessment Entry" => "assessment_entry",
        "Computed Quarterly Summary" => "computed_quarterly_summary",
        "Assessment History" => "assessment_history",
        "Subject" => "subject",
        "Strand" => "strand",
        "Grade Level" => "grade_level",
        "Grading Period" => "grading_period",
        "Assessment Type" => "assessment_type",
        "Assessment Title" => "assessment_title",
        "Score" => "score",
        "Total Score" => "total_score",
        "Submission Status" => "submission_status",
        "Assessment Date" => "assessment_date",
        "Competency Area" => "competency_area",
        "Correct Competency Items" => "correct_competency_items",
        "Total Competency Items" => "total_competency_items",
        "Written Work" => "written_work",
        "Written Works" => "written_works",
        "Performance Task" => "performance_task",
        "Performance Tasks" => "performance_tasks",
        "Quarterly Assessment" => "quarterly_assessment",
        "Competency Check" => "competency_check",
        "Submitted" => "submitted",
        "Incomplete" => "incomplete",
        "Missing" => "missing",
        "Grade" => "grade",
        "Mastery" => "mastery",
        "Attendance" => "attendance",
        "Absence" => "absence",
        "Status" => "status",
        "Advisory" => "advisory",
        "Guidance" => "guidance",
        "Dashboard" => "dashboard",
        "Tasks" => "tasks",
        "Schedule" => "schedule",
        "Monitoring" => "monitoring",
        "Validation" => "validation",
        "Users" => "users",
        "Profile" => "profile",
        "Content Management" => "content_management",
        "Branding" => "branding",
        "Theme & Colors" => "theme_colors",
        "Announcements" => "announcements",
        "System Settings" => "system_settings",
        "System Health" => "system_health",
        "System Logs" => "system_logs",
        "Backups" => "backups",
        "Backup & Restore" => "backup_restore",
        "Maintenance Mode" => "maintenance_mode",
        "Technical Settings" => "technical_settings",
        "Super Administrator" => "super_admin",
        "IT Administrator" => "it_admin",
        "Regular" => "regular",
        "Warning" => "warning",
        "Warning Status" => "warning_status",
        "At-Risk" => "at_risk",
        "At-Risk / Failing" => "at_risk_failing",
        "Attendance Concern" => "attendance_concern",
        "Regular Attendance" => "regular_attendance",
        "Mastered" => "mastered",
        "Nearing Mastery" => "nearing_mastery",
        "Not Mastered / Remediation Needed" => "not_mastered_remediation",
        "Complete Requirements" => "complete_requirements",
        "Incomplete Requirements" => "incomplete_requirements",
        "Stable Performance Pattern" => "stable_performance_pattern",
        "Improving Performance Pattern" => "improving_performance_pattern",
        "Declining Performance Pattern" => "declining_performance_pattern",
        "Insufficient Trend Data" => "insufficient_trend_data",
        "No Record" => "no_record",
        "Magaan" => "magaan",
        "Katamtaman" => "katamtaman",
        "Mabigat" => "mabigat",
        "Overdue" => "overdue",
        "Needs Review" => "needs_review",
        "Not Consistent" => "not_consistent",
        "Consistent" => "consistent",
        "Present" => "present",
        "Absent" => "absent",
        "Excused" => "excused",
        "Low" => "low",
        "Medium" => "medium",
        "High" => "high",
        "Critical" => "critical",
        "Not Started" => "not_started",
        "In Progress" => "in_progress",
        "Completed" => "completed",
        "Rescheduled" => "rescheduled",
        "Regular Monitoring" => "regular_monitoring",
        "Remediation" => "remediation",
        "Requirement Follow-up" => "requirement_follow_up",
        "Performance Monitoring" => "performance_monitoring",
        "Attendance Follow-up" => "attendance_follow_up",
        "Workload Follow-up" => "workload_follow_up"
    ];

    return $map[$text] ?? "";
}

function tv($text) {
    $key = text_key($text);

    if ($key !== "") {
        return t($key);
    }

    return $text;
}

function view_state_key($text) {
    $text = trim((string)$text);

    if ($text === "") {
        return "";
    }

    $allowedKeys = [
        "regular",
        "warning",
        "warning_status",
        "at_risk",
        "at_risk_failing",
        "attendance_concern",
        "regular_attendance",
        "mastered",
        "nearing_mastery",
        "not_mastered_remediation",
        "complete_requirements",
        "incomplete_requirements",
        "stable_performance_pattern",
        "improving_performance_pattern",
        "declining_performance_pattern",
        "insufficient_trend_data",
        "no_record",
        "magaan",
        "katamtaman",
        "mabigat",
        "overdue",
        "needs_review",
        "not_consistent",
        "consistent",
        "present",
        "absent",
        "excused",
        "low",
        "medium",
        "high",
        "critical",
        "not_started",
        "in_progress",
        "completed",
        "rescheduled",
        "regular_monitoring",
        "remediation",
        "requirement_follow_up",
        "performance_monitoring",
        "attendance_follow_up",
        "workload_follow_up",
        "submitted",
        "incomplete",
        "missing",
        "pending",
        "active",
        "inactive"
    ];

    $key = text_key($text);

    if ($key !== "" && in_array($key, $allowedKeys, true)) {
        return str_replace("_", "-", $key);
    }

    foreach ($allowedKeys as $allowedKey) {
        if ($text === t($allowedKey)) {
            return str_replace("_", "-", $allowedKey);
        }
    }

    $exact = [
        "Low Risk" => "low-risk",
        "Operational" => "operational",
        "Unavailable" => "unavailable",
        "Online" => "online",
        "Offline" => "offline",
        "No Backup" => "no-backup"
    ];

    return $exact[$text] ?? "";
}

function view_state_tone($text) {
    $state = view_state_key($text);

    if (in_array($state, [
        "at-risk",
        "at-risk-failing",
        "attendance-concern",
        "not-mastered-remediation",
        "incomplete-requirements",
        "declining-performance-pattern",
        "mabigat",
        "overdue",
        "not-consistent",
        "critical",
        "missing",
        "inactive",
        "unavailable",
        "offline"
    ], true)) {
        return "danger";
    }

    if (in_array($state, [
        "warning",
        "warning-status",
        "nearing-mastery",
        "katamtaman",
        "needs-review",
        "medium",
        "high",
        "absent",
        "remediation",
        "requirement-follow-up",
        "performance-monitoring",
        "attendance-follow-up",
        "workload-follow-up",
        "no-backup"
    ], true)) {
        return "warning";
    }

    if (in_array($state, [
        "insufficient-trend-data",
        "no-record",
        "not-started",
        "rescheduled",
        "pending",
        "excused"
    ], true)) {
        return "neutral";
    }

    if ($state !== "") {
        return "good";
    }

    if (text_has($text, "At-Risk") || text_has($text, "Failing") || text_has($text, "Concern") || text_has($text, "Mabigat") || text_has($text, "Overdue") || text_has($text, "Not Mastered") || text_has($text, "Remediation") || text_has($text, "Inactive") || text_has($text, "Critical") || text_has($text, "Not Consistent") || text_has($text, "Incomplete") || text_has($text, "Declining")) {
        return "danger";
    }

    if (text_has($text, "Warning") || text_has($text, "Nearing") || text_has($text, "Katamtaman") || text_has($text, "Needs") || text_has($text, "High") || text_has($text, "Medium") || text_has($text, "Needs Review")) {
        return "warning";
    }

    return "good";
}

function view_state_class($text) {
    $tone = view_state_tone($text);
    $state = view_state_key($text);

    return trim($tone . ($state !== "" ? " state-" . $state : ""));
}

function percent_score($score, $total) {
    $score = (float)$score;
    $total = (float)$total;

    if ($total <= 0) {
        return 0;
    }

    return ($score / $total) * 100;
}

function record_mode_value($record) {
    $mode = $record["recordMode"] ?? $record["recordType"] ?? "assessment";

    if ($mode === "quarterly_summary") {
        return "quarterly";
    }

    return in_array($mode, ["assessment", "quarterly"], true) ? $mode : "assessment";
}

function compute_assessment_percentage($record) {
    if (isset($record["score"], $record["totalScore"]) && (float)$record["totalScore"] > 0) {
        return round(percent_score($record["score"], $record["totalScore"]), 2);
    }

    if (isset($record["assessmentPercentage"])) {
        return round((float)$record["assessmentPercentage"], 2);
    }

    return 0;
}

function assessment_entries_for_subject_period($studentId, $subject, $gradingPeriod) {
    $entries = array_values(array_filter(read_records_where("academic_records", ["studentId" => $studentId], "coalesce(data->>'assessmentDate', data->>'createdAt', '') asc, created_at asc, id asc"), function($record) use ($subject, $gradingPeriod) {
        return record_mode_value($record) === "assessment"
            && strtolower(trim((string)($record["subject"] ?? ""))) === strtolower(trim((string)$subject))
            && strtolower(trim((string)($record["gradingPeriod"] ?? ""))) === strtolower(trim((string)$gradingPeriod));
    }));

    usort($entries, function($a, $b) {
        return strtotime($a["assessmentDate"] ?? $a["createdAt"] ?? "now") <=> strtotime($b["assessmentDate"] ?? $b["createdAt"] ?? "now");
    });

    return $entries;
}


function component_summary_from_entries($entries, $assessmentType) {
    $score = 0;
    $total = 0;
    $submitted = 0;
    $incomplete = 0;
    $missing = 0;

    foreach ($entries as $entry) {
        if (($entry["assessmentType"] ?? "") !== $assessmentType) {
            continue;
        }

        $status = requirement_status_value($entry["submissionStatus"] ?? "Submitted");

        if ($status === "Submitted") {
            $submitted++;
        } elseif ($status === "Missing") {
            $missing++;
        } else {
            $incomplete++;
        }

        if (isset($entry["score"], $entry["totalScore"]) && (float)$entry["totalScore"] > 0) {
            $score += (float)$entry["score"];
            $total += (float)$entry["totalScore"];
        }
    }

    return [
        "score" => round($score, 2),
        "total" => round($total, 2),
        "percentage" => $total > 0 ? round(percent_score($score, $total), 2) : 0,
        "submitted" => $submitted,
        "incomplete" => $incomplete,
        "missing" => $missing,
        "status" => ($incomplete > 0 || $missing > 0) ? "Incomplete" : "Submitted"
    ];
}

function computed_quarterly_summary($studentId, $subject, $gradingPeriod) {
    $entries = assessment_entries_for_subject_period($studentId, $subject, $gradingPeriod);
    $written = component_summary_from_entries($entries, "Written Work");
    $performance = component_summary_from_entries($entries, "Performance Task");
    $quarterly = component_summary_from_entries($entries, "Quarterly Assessment");
    $competencyCorrect = 0;
    $competencyTotal = 0;
    $strand = "";
    $gradeLevel = "";
    $latestTime = 0;
    $createdAt = date("c");
    $updatedAt = date("c");

    foreach ($entries as $entry) {
        if ($strand === "" && !empty($entry["strand"])) {
            $strand = $entry["strand"];
        }

        if ($gradeLevel === "" && !empty($entry["gradeLevel"])) {
            $gradeLevel = $entry["gradeLevel"];
        }

        if (($entry["assessmentType"] ?? "") === "Competency Check") {
            $competencyScore = isset($entry["score"]) ? (float)$entry["score"] : (float)($entry["competencyCorrect"] ?? 0);
            $competencyItemTotal = isset($entry["totalScore"]) ? (float)$entry["totalScore"] : (float)($entry["competencyTotal"] ?? 0);

            if ($competencyItemTotal > 0) {
                $competencyCorrect += $competencyScore;
                $competencyTotal += $competencyItemTotal;
            }
        }

        $time = strtotime($entry["updatedAt"] ?? $entry["createdAt"] ?? "now");

        if ($time > $latestTime) {
            $latestTime = $time;
            $updatedAt = $entry["updatedAt"] ?? $entry["createdAt"] ?? date("c");
        }
    }

    $computedGrade = round(($written["percentage"] * 0.25) + ($performance["percentage"] * 0.45) + ($quarterly["percentage"] * 0.30), 2);
    $id = "qtr-" . md5($studentId . "|" . strtolower($subject) . "|" . strtolower($gradingPeriod));

    return [
        "id" => $id,
        "studentId" => $studentId,
        "recordMode" => "quarterly",
        "isComputedSummary" => true,
        "subject" => $subject,
        "strand" => $strand,
        "gradeLevel" => $gradeLevel,
        "gradingPeriod" => $gradingPeriod,
        "writtenWorks" => $written["score"],
        "writtenWorksTotal" => $written["total"],
        "writtenWorksPercentage" => $written["percentage"],
        "writtenStatus" => $written["status"],
        "performanceTasks" => $performance["score"],
        "performanceTasksTotal" => $performance["total"],
        "performanceTasksPercentage" => $performance["percentage"],
        "performanceStatus" => $performance["status"],
        "quarterlyAssessment" => $quarterly["score"],
        "quarterlyAssessmentTotal" => $quarterly["total"],
        "quarterlyAssessmentPercentage" => $quarterly["percentage"],
        "assessmentStatus" => $quarterly["status"],
        "competencyCorrect" => $competencyCorrect,
        "competencyTotal" => $competencyTotal,
        "competencyName" => $competencyTotal > 0 ? "Computed from competency checks" : "",
        "assessmentCount" => count($entries),
        "computedGrade" => $computedGrade,
        "createdAt" => $createdAt,
        "updatedAt" => $updatedAt
    ];
}

function computed_quarterly_summaries_for_student($studentId) {
    $records = records_for_student($studentId);
    $groups = [];

    foreach ($records as $record) {
        if (record_mode_value($record) !== "assessment") {
            continue;
        }

        $subject = trim((string)($record["subject"] ?? ""));
        $gradingPeriod = trim((string)($record["gradingPeriod"] ?? ""));

        if ($subject === "" || $gradingPeriod === "") {
            continue;
        }

        $key = strtolower($subject) . "|" . strtolower($gradingPeriod);
        $groups[$key] = [
            "subject" => $subject,
            "gradingPeriod" => $gradingPeriod
        ];
    }

    $summaries = [];

    foreach ($groups as $group) {
        $summary = computed_quarterly_summary($studentId, $group["subject"], $group["gradingPeriod"]);

        if (($summary["assessmentCount"] ?? 0) > 0) {
            $summaries[] = $summary;
        }
    }

    usort($summaries, function($a, $b) {
        return strtotime($b["updatedAt"] ?? "now") <=> strtotime($a["updatedAt"] ?? "now");
    });

    return $summaries;
}
function component_percentage($record, $scoreKey, $totalKey) {
    if (isset($record[$scoreKey], $record[$totalKey]) && (float)$record[$totalKey] > 0) {
        return round(percent_score($record[$scoreKey], $record[$totalKey]), 2);
    }

    return round((float)($record[$scoreKey] ?? 0), 2);
}

function parse_absence_dates($value) {
    if (is_array($value)) {
        $items = $value;
    } else {
        $items = preg_split("/[,\\n]+/", (string)$value);
    }

    $dates = [];

    foreach ($items as $item) {
        $date = trim((string)$item);

        if ($date === "") {
            continue;
        }

        $time = strtotime($date);

        if ($time) {
            $dates[] = date("Y-m-d", $time);
        }
    }

    $dates = array_values(array_unique($dates));
    sort($dates);

    return $dates;
}

function compute_consecutive_absences_from_dates($dates) {
    $dates = parse_absence_dates($dates);

    if (!count($dates)) {
        return 0;
    }

    $max = 1;
    $current = 1;

    for ($i = 1; $i < count($dates); $i++) {
        $previous = strtotime($dates[$i - 1]);
        $currentDate = strtotime($dates[$i]);
        $diff = (int)(($currentDate - $previous) / 86400);

        if ($diff === 1) {
            $current++;
            $max = max($max, $current);
        } else {
            $current = 1;
        }
    }

    return $max;
}

function compute_competency_mastery($record) {
    if (($record["assessmentType"] ?? "") === "Competency Check") {
        if (isset($record["score"], $record["totalScore"]) && (float)$record["totalScore"] > 0) {
            return round(percent_score($record["score"], $record["totalScore"]), 2);
        }

        if (isset($record["competencyCorrect"], $record["competencyTotal"]) && (float)$record["competencyTotal"] > 0) {
            return round(percent_score($record["competencyCorrect"], $record["competencyTotal"]), 2);
        }
    }

    if (record_mode_value($record) === "quarterly" && isset($record["competencyCorrect"], $record["competencyTotal"]) && (float)$record["competencyTotal"] > 0) {
        return round(percent_score($record["competencyCorrect"], $record["competencyTotal"]), 2);
    }

    return round((float)($record["competencyMastery"] ?? 0), 2);
}

function compute_absence_rate($record) {
    if (isset($record["daysAbsent"], $record["totalClassDays"]) && (float)$record["totalClassDays"] > 0) {
        return round(percent_score($record["daysAbsent"], $record["totalClassDays"]), 2);
    }

    return round((float)($record["absenceRate"] ?? 0), 2);
}

function computed_grade($record) {
    if (record_mode_value($record) === "assessment") {
        return compute_assessment_percentage($record);
    }

    if (!empty($record["isComputedSummary"]) && isset($record["computedGrade"])) {
        return round((float)$record["computedGrade"], 2);
    }

    $written = isset($record["writtenWorksPercentage"]) ? round((float)$record["writtenWorksPercentage"], 2) : component_percentage($record, "writtenWorks", "writtenWorksTotal");
    $performance = isset($record["performanceTasksPercentage"]) ? round((float)$record["performanceTasksPercentage"], 2) : component_percentage($record, "performanceTasks", "performanceTasksTotal");
    $assessment = isset($record["quarterlyAssessmentPercentage"]) ? round((float)$record["quarterlyAssessmentPercentage"], 2) : component_percentage($record, "quarterlyAssessment", "quarterlyAssessmentTotal");

    return round(($written * 0.25) + ($performance * 0.45) + ($assessment * 0.30), 2);
}

function grade_status($grade) {
    $grade = (float)$grade;

    if ($grade < 75) {
        return "At-Risk / Failing";
    }

    if ($grade >= 75 && $grade <= 78) {
        return "Warning Status";
    }

    return "Regular";
}

function competency_status($score) {
    $score = (float)$score;

    if ($score >= 75) {
        return "Mastered";
    }

    if ($score >= 50) {
        return "Nearing Mastery";
    }

    return "Not Mastered / Remediation Needed";
}

function attendance_status($absenceRate, $consecutiveAbsences) {
    if ((float)$absenceRate > 20 || (int)$consecutiveAbsences >= 5) {
        return "Attendance Concern";
    }

    return "Regular Attendance";
}

function attendance_for_student($studentId) {
    $records = read_records_where("attendance", ["studentId" => $studentId], "coalesce(data->>'date', data->>'createdAt', '') asc, created_at asc, id asc");

    usort($records, function($a, $b) {
        return strtotime($a["date"] ?? "now") <=> strtotime($b["date"] ?? "now");
    });

    return $records;
}

function attendance_record_for_student_schedule_date($studentId, $scheduleId, $date) {
    $studentId = trim((string)$studentId);
    $scheduleId = trim((string)$scheduleId);
    $date = trim((string)$date);

    if ($studentId === "" || $scheduleId === "" || $date === "") {
        return null;
    }

    return find_storage_record_where("attendance", [
        "studentId" => $studentId,
        "scheduleId" => $scheduleId,
        "date" => $date
    ]);
}

function attendance_update_lookup_for_student($studentId) {
    $lookup = [];

    foreach (attendance_for_student($studentId) as $record) {
        $scheduleId = trim((string)($record["scheduleId"] ?? ""));
        $date = trim((string)($record["date"] ?? ""));

        if ($scheduleId === "" || $date === "") {
            continue;
        }

        $lookup[$scheduleId . "|" . $date] = [
            "id" => (string)($record["id"] ?? ""),
            "scheduleId" => $scheduleId,
            "date" => $date,
            "subject" => (string)($record["subject"] ?? ""),
            "status" => (string)($record["status"] ?? ""),
            "note" => (string)($record["note"] ?? "")
        ];
    }

    return $lookup;
}


function attendance_records_for_subject_period($studentId, $subject, $gradingPeriod = "", $scheduleId = "") {
    $studentId = trim((string)$studentId);
    $subject = strtolower(trim((string)$subject));
    $gradingPeriod = strtolower(trim((string)$gradingPeriod));
    $scheduleId = trim((string)$scheduleId);

    $records = array_values(array_filter(attendance_for_student($studentId), function($record) use ($subject, $gradingPeriod, $scheduleId) {
        $recordScheduleId = trim((string)($record["scheduleId"] ?? ""));
        $recordSubject = strtolower(trim((string)($record["subject"] ?? "")));
        $recordPeriod = strtolower(trim((string)($record["gradingPeriod"] ?? "")));

        if ($scheduleId !== "") {
            return $recordScheduleId === $scheduleId;
        }

        $sameSubject = $subject === "" || $recordSubject === $subject;
        $samePeriod = $gradingPeriod === "" || $recordPeriod === "" || $recordPeriod === $gradingPeriod;

        return $sameSubject && $samePeriod;
    }));

    usort($records, function($a, $b) {
        return strtotime($a["date"] ?? "now") <=> strtotime($b["date"] ?? "now");
    });

    return $records;
}

function compute_consecutive_absences_from_attendance($records) {
    $records = array_values(array_filter(is_array($records) ? $records : [], function($record) {
        if (!is_array($record) || empty($record["date"])) {
            return false;
        }

        return in_array($record["status"] ?? "", ["Present", "Absent", "Excused"], true);
    }));

    usort($records, function($a, $b) {
        $dateCompare = strtotime($a["date"] ?? "now") <=> strtotime($b["date"] ?? "now");

        if ($dateCompare !== 0) {
            return $dateCompare;
        }

        return strcmp((string)($a["id"] ?? ""), (string)($b["id"] ?? ""));
    });

    $max = 0;
    $current = 0;

    foreach ($records as $record) {
        if (($record["status"] ?? "") === "Absent") {
            $current++;
            $max = max($max, $current);
            continue;
        }

        $current = 0;
    }

    return $max;
}

function compute_absence_rate_from_attendance($records) {
    $marked = 0;
    $absent = 0;

    foreach ($records as $record) {
        $status = $record["status"] ?? "";

        if (in_array($status, ["Present", "Absent", "Excused"], true)) {
            $marked++;
        }

        if ($status === "Absent") {
            $absent++;
        }
    }

    return $marked > 0 ? round(percent_score($absent, $marked), 2) : 0;
}

function attendance_summary_for_subject_period($studentId, $subject, $gradingPeriod = "", $scheduleId = "") {
    $records = attendance_records_for_subject_period($studentId, $subject, $gradingPeriod, $scheduleId);
    $present = 0;
    $absent = 0;
    $excused = 0;

    foreach ($records as $record) {
        if (($record["status"] ?? "") === "Present") {
            $present++;
        }

        if (($record["status"] ?? "") === "Absent") {
            $absent++;
        }

        if (($record["status"] ?? "") === "Excused") {
            $excused++;
        }
    }

    $marked = $present + $absent + $excused;
    $absenceRate = compute_absence_rate_from_attendance($records);
    $consecutiveAbsences = compute_consecutive_absences_from_attendance($records);

    return [
        "records" => $records,
        "markedMeetings" => $marked,
        "presentCount" => $present,
        "absentCount" => $absent,
        "excusedCount" => $excused,
        "absenceRate" => $absenceRate,
        "consecutiveAbsences" => $consecutiveAbsences,
        "attendanceStatus" => $marked > 0 ? attendance_status($absenceRate, $consecutiveAbsences) : "No Record"
    ];
}

function save_attendance_mark($markedBy, $post) {
    $studentId = safe_text($post["studentId"] ?? "", 80);
    $scheduleId = safe_text($post["scheduleId"] ?? "", 80);
    $gradingPeriod = safe_text($post["gradingPeriod"] ?? "", 40);
    $date = safe_text($post["date"] ?? date("Y-m-d"), 20);
    $status = safe_text($post["status"] ?? "", 20);
    $note = safe_text($post["note"] ?? "", 300);
    $confirmAttendanceUpdate = ((string)($post["confirmAttendanceUpdate"] ?? "") === "1");
    $confirmedAttendanceId = safe_text($post["confirmedAttendanceId"] ?? "", 100);

    if ($studentId === "" || $scheduleId === "" || $date === "" || !in_array($status, ["Present", "Absent", "Excused"], true)) {
        return [
            "ok" => false,
            "message" => msg(
                "Complete schedule, date, and attendance status.",
                "Kumpletuhin ang schedule, date, at attendance status.",
                "Complete schedule, date, and attendance status."
            )
        ];
    }

    if ($gradingPeriod !== "") {
        $allowedGradingPeriods = function_exists("grading_periods")
            ? grading_periods()
            : ["Quarter 1", "Quarter 2", "Quarter 3", "Quarter 4"];

        if (!in_array($gradingPeriod, $allowedGradingPeriods, true)) {
            return [
                "ok" => false,
                "message" => msg(
                    "Select a valid grading period.",
                    "Pumili ng wastong grading period.",
                    "Select a valid grading period."
                )
            ];
        }
    }

    $student = find_user_by_id($studentId);

    if (!$student || ($student["role"] ?? "") !== "student" || ($student["status"] ?? "Active") !== "Active") {
        return [
            "ok" => false,
            "message" => msg(
                "The selected student account is not available.",
                "Hindi available ang napiling student account.",
                "The selected student account is not available."
            )
        ];
    }

    $marker = find_user_by_id($markedBy);

    if (
        ($marker["role"] ?? "") === "teacher" &&
        function_exists("student_visible_to_user") &&
        !student_visible_to_user($student, $marker)
    ) {
        return [
            "ok" => false,
            "message" => msg(
                "You are not allowed to mark attendance for this student.",
                "Hindi ka pinapayagang mag-mark ng attendance para sa student na ito.",
                "You are not allowed to mark attendance for this student."
            )
        ];
    }

    $selectedSchedule = null;

    foreach (schedules_for_student($studentId) as $schedule) {
        if (($schedule["id"] ?? "") === $scheduleId) {
            $selectedSchedule = $schedule;
            break;
        }
    }

    if (!$selectedSchedule) {
        return [
            "ok" => false,
            "message" => msg(
                "The selected schedule does not belong to this student.",
                "Ang napiling schedule ay hindi para sa student na ito.",
                "The selected schedule does not belong to this student."
            )
        ];
    }

    $subject = safe_text($selectedSchedule["subject"] ?? "", 100);

    if ($subject === "") {
        return [
            "ok" => false,
            "message" => msg(
                "The selected schedule has no valid subject.",
                "Walang valid na subject ang napiling schedule.",
                "The selected schedule has no valid subject."
            )
        ];
    }

    $dateObject = DateTime::createFromFormat("Y-m-d", $date);
    $dateErrors = DateTime::getLastErrors();

    if (
        !$dateObject ||
        ($dateErrors !== false && (($dateErrors["warning_count"] ?? 0) > 0 || ($dateErrors["error_count"] ?? 0) > 0)) ||
        $dateObject->format("Y-m-d") !== $date
    ) {
        return [
            "ok" => false,
            "message" => msg(
                "Enter a valid attendance date.",
                "Maglagay ng wastong attendance date.",
                "Enter a valid attendance date."
            )
        ];
    }

    $existing = attendance_record_for_student_schedule_date($studentId, $scheduleId, $date);

    if ($existing) {
        $attendanceId = trim((string)($existing["id"] ?? ""));

        if ($attendanceId === "") {
            return [
                "ok" => false,
                "message" => msg(
                    "Unable to update the attendance record.",
                    "Hindi ma-update ang attendance record.",
                    "Unable to update the attendance record."
                )
            ];
        }

        if (!$confirmAttendanceUpdate || $confirmedAttendanceId !== $attendanceId) {
            return [
                "ok" => false,
                "requiresConfirmation" => true,
                "existingRecord" => [
                    "id" => $attendanceId,
                    "studentId" => $studentId,
                    "scheduleId" => $scheduleId,
                    "subject" => $existing["subject"] ?? $subject,
                    "date" => $existing["date"] ?? $date,
                    "status" => $existing["status"] ?? "",
                    "note" => $existing["note"] ?? ""
                ],
                "message" => msg(
                    "Attendance already exists for this student, schedule, and date. Review the existing record and confirm Update Attendance before replacing it.",
                    "May attendance record na para sa student, schedule, at petsang ito. Suriin muna ang existing record at kumpirmahin ang Update Attendance bago ito palitan.",
                    "May existing attendance na para sa student, schedule, at date na ito. Review the existing record and confirm Update Attendance bago palitan."
                )
            ];
        }

        $existing["scheduleId"] = $scheduleId;
        $existing["gradingPeriod"] = $gradingPeriod;
        $existing["subject"] = $subject;
        $existing["date"] = $date;
        $existing["status"] = $status;
        $existing["note"] = $note;
        $existing["markedBy"] = $markedBy;
        $existing["updatedAt"] = date("c");

        $saved = update_record_by_id("attendance", $attendanceId, $existing);
        $successMessage = msg(
            "Attendance updated.",
            "Na-update ang attendance.",
            "Updated ang attendance."
        );
    } else {
        try {
            $attendanceId = "att-" . time() . "-" . bin2hex(random_bytes(3));
        } catch (Throwable $e) {
            return [
                "ok" => false,
                "message" => msg(
                    "Unable to create the attendance record.",
                    "Hindi magawa ang attendance record.",
                    "Unable to create the attendance record."
                )
            ];
        }

        $now = date("c");

        $attendanceRecord = [
            "id" => $attendanceId,
            "studentId" => $studentId,
            "scheduleId" => $scheduleId,
            "subject" => $subject,
            "gradingPeriod" => $gradingPeriod,
            "date" => $date,
            "status" => $status,
            "note" => $note,
            "markedBy" => $markedBy,
            "createdAt" => $now,
            "updatedAt" => $now
        ];

        $saved = update_record_by_id("attendance", $attendanceId, $attendanceRecord);
        $successMessage = msg(
            "Attendance saved.",
            "Nai-save ang attendance.",
            "Saved ang attendance."
        );
    }

    if (!$saved) {
        return [
            "ok" => false,
            "message" => msg(
                "Attendance could not be saved. Please try again.",
                "Hindi ma-save ang attendance. Subukan muli.",
                "Attendance could not be saved. Please try again."
            )
        ];
    }

    $storedRecord = find_storage_record_by_id("attendance", $attendanceId);

    if (
        !$storedRecord ||
        ($storedRecord["studentId"] ?? "") !== $studentId ||
        ($storedRecord["scheduleId"] ?? "") !== $scheduleId ||
        ($storedRecord["date"] ?? "") !== $date
    ) {
        return [
            "ok" => false,
            "message" => msg(
                "Attendance could not be verified after saving.",
                "Hindi ma-verify ang attendance pagkatapos i-save.",
                "Attendance could not be verified after saving."
            )
        ];
    }

    return [
        "ok" => true,
        "message" => $successMessage
    ];
}


function non_academic_buffer_hours() {
    return [
        "sleepHours" => 56,
        "personalCareHours" => 14,
        "totalBuffer" => 70
    ];
}

function available_study_time($weeklyClassHours) {
    $buffer = non_academic_buffer_hours();
    return max(1, 168 - (float)$weeklyClassHours - $buffer["totalBuffer"]);
}

function routine_capacity_summary($weeklyClassHours) {
    $buffer = non_academic_buffer_hours();

    return [
        "weeklyHours" => 168,
        "weeklyClassHours" => round((float)$weeklyClassHours, 2),
        "sleepHours" => $buffer["sleepHours"],
        "personalCareHours" => $buffer["personalCareHours"],
        "nonAcademicBuffer" => $buffer["totalBuffer"],
        "availableStudyTime" => available_study_time($weeklyClassHours)
    ];
}

function weakest_academic_component($record) {
    if (record_mode_value($record) === "assessment") {
        return $record["assessmentType"] ?? "Assessment Entry";
    }

    $components = [
        "Written Works" => isset($record["writtenWorksPercentage"]) ? (float)$record["writtenWorksPercentage"] : component_percentage($record, "writtenWorks", "writtenWorksTotal"),
        "Performance Tasks" => isset($record["performanceTasksPercentage"]) ? (float)$record["performanceTasksPercentage"] : component_percentage($record, "performanceTasks", "performanceTasksTotal"),
        "Quarterly Assessment" => isset($record["quarterlyAssessmentPercentage"]) ? (float)$record["quarterlyAssessmentPercentage"] : component_percentage($record, "quarterlyAssessment", "quarterlyAssessmentTotal")
    ];

    asort($components);
    return array_key_first($components);
}

function grade_guidance_output($record) {
    $grade = (float)($record["computedGrade"] ?? computed_grade($record));
    $academicStatus = $record["academicStatus"] ?? grade_status($grade);
    $weakest = weakest_academic_component($record);
    $subject = $record["subject"] ?? "this subject";

    if ($academicStatus === "At-Risk / Failing") {
        return msg(
            "Prioritize " . $subject . ". Start with " . $weakest . ", create one remediation task, and avoid adding non-urgent workload until the failing area is addressed.",
            "Unahin ang " . $subject . ". Simulan sa " . $weakest . ", gumawa ng remediation task, at iwasang magdagdag ng hindi urgent na gawain hanggang ma-address ang failing area.",
            "Unahin ang " . $subject . ". Start sa " . $weakest . ", gumawa ng remediation task, at huwag muna mag-add ng non-urgent tasks hanggang maayos ang failing area."
        );
    }

    if ($academicStatus === "Warning Status") {
        return msg(
            "Schedule a short review block for " . $subject . ". Focus on " . $weakest . " before high-difficulty deadlines.",
            "Mag-schedule ng maikling review block para sa " . $subject . ". Ituon ito sa " . $weakest . " bago ang mabibigat na deadline.",
            "Mag-schedule ng short review block for " . $subject . ". Focus sa " . $weakest . " before heavy deadlines."
        );
    }

    return msg(
        "Keep " . $subject . " under regular monitoring. Use extra study time for review, unfinished tasks, or early preparation.",
        "Panatilihin ang regular monitoring sa " . $subject . ". Gamitin ang sobrang study time para sa review, hindi pa tapos na gawain, o maagang paghahanda.",
        "Keep " . $subject . " under regular monitoring. Use extra study time for review, unfinished tasks, or early prep."
    );
}

function competency_guidance_output($record) {
    $competency = (float)($record["competencyMastery"] ?? compute_competency_mastery($record));
    $status = $record["competencyStatus"] ?? competency_status($competency);
    $subject = $record["subject"] ?? "this subject";

    if ($competency <= 0) {
        return msg(
            "No competency check has been encoded yet. Add a competency check only when item analysis data is available.",
            "Wala pang competency check na nailagay. Magdagdag lamang ng competency check kapag may item analysis data na available.",
            "No competency check encoded yet. Add competency check lang kapag may item analysis data na available."
        );
    }

    if ($status === "Not Mastered / Remediation Needed") {
        return msg(
            "Set a remediation block for " . $subject . ". Review the missed competency first before moving to new tasks.",
            "Maglaan ng remediation block para sa " . $subject . ". Balikan muna ang hindi na-master na competency bago lumipat sa bagong gawain.",
            "Mag-set ng remediation block for " . $subject . ". Review muna ang missed competency bago lumipat sa new tasks."
        );
    }

    if ($status === "Nearing Mastery") {
        return msg(
            "Add a short review session for " . $subject . ". Focus on practice items until mastery reaches at least 75%.",
            "Magdagdag ng maikling review session para sa " . $subject . ". Mag-focus sa practice items hanggang umabot sa 75% ang mastery.",
            "Add a short review session for " . $subject . ". Focus sa practice items until umabot sa at least 75% ang mastery."
        );
    }

    return msg(
        "Maintain competency practice for " . $subject . " through light review or early preparation.",
        "Panatilihin ang competency practice para sa " . $subject . " gamit ang magaan na review o maagang paghahanda.",
        "Maintain competency practice for " . $subject . " through light review or early prep."
    );
}

function attendance_guidance_output($record) {
    $absenceRate = (float)($record["absenceRate"] ?? compute_absence_rate($record));
    $consecutiveAbsences = (int)($record["consecutiveAbsences"] ?? 0);
    $status = $record["attendanceStatus"] ?? attendance_status($absenceRate, $consecutiveAbsences);
    $subject = $record["subject"] ?? "this subject";

    if ($status === "Attendance Concern") {
        return msg(
            "Protect attendance for " . $subject . ". Avoid scheduling heavy tasks during recovery days and coordinate missed lessons before the next assessment.",
            "Bantayan ang attendance sa " . $subject . ". Iwasang maglagay ng mabibigat na gawain sa recovery days at ayusin ang missed lessons bago ang susunod na assessment.",
            "Protect attendance for " . $subject . ". Iwasan muna ang heavy tasks during recovery days and coordinate missed lessons before next assessment."
        );
    }

    return msg(
        "Keep attendance steady for " . $subject . ". Use the current schedule to protect class time and review time.",
        "Panatilihing maayos ang attendance sa " . $subject . ". Gamitin ang kasalukuyang schedule para maprotektahan ang oras ng klase at review.",
        "Keep attendance steady for " . $subject . ". Use the current schedule to protect class time and review time."
    );
}

function requirement_status_value($status) {
    $status = trim((string)$status);

    if ($status === "Missing") {
        return "Missing";
    }

    if ($status === "Incomplete") {
        return "Incomplete";
    }

    return "Submitted";
}

function requirement_status_for_record($record) {
    if (record_mode_value($record) === "assessment") {
        $status = requirement_status_value($record["submissionStatus"] ?? "Submitted");
        return in_array($status, ["Incomplete", "Missing"], true) ? "Incomplete Requirements" : "Complete Requirements";
    }

    $statuses = [
        requirement_status_value($record["writtenStatus"] ?? "Submitted"),
        requirement_status_value($record["performanceStatus"] ?? "Submitted"),
        requirement_status_value($record["assessmentStatus"] ?? "Submitted")
    ];

    return count(array_intersect($statuses, ["Incomplete", "Missing"])) > 0 ? "Incomplete Requirements" : "Complete Requirements";
}

function missing_requirements_for_record($record) {
    $missing = [];

    if (record_mode_value($record) === "assessment") {
        $status = requirement_status_value($record["submissionStatus"] ?? "Submitted");

        if (in_array($status, ["Incomplete", "Missing"], true)) {
            $missing[] = ($record["assessmentType"] ?? "Assessment") . " - " . $status;
        }

        return $missing;
    }

    $map = [
        "Written Works" => requirement_status_value($record["writtenStatus"] ?? "Submitted"),
        "Performance Tasks" => requirement_status_value($record["performanceStatus"] ?? "Submitted"),
        "Quarterly Assessment" => requirement_status_value($record["assessmentStatus"] ?? "Submitted")
    ];

    foreach ($map as $label => $status) {
        if (in_array($status, ["Incomplete", "Missing"], true)) {
            $missing[] = $label . " - " . $status;
        }
    }

    return $missing;
}

function requirement_guidance_output($record) {
    $missing = missing_requirements_for_record($record);

    if (!count($missing)) {
        return msg(
            "Keep requirements complete and use extra time for review.",
            "Panatilihing kumpleto ang requirements at gamitin ang sobrang oras para sa review.",
            "Keep requirements complete and use extra time for review."
        );
    }

    return msg(
        "Complete or clarify these requirements first: " . implode(", ", $missing) . ". Do this before adding new workload.",
        "Kumpletuhin o linawin muna ang requirements na ito: " . implode(", ", $missing) . ". Gawin ito bago magdagdag ng bagong gawain.",
        "Complete or clarify these requirements first: " . implode(", ", $missing) . ". Do this before adding new workload."
    );
}

function trend_status_for_student_subject($studentId, $subject, $gradingPeriod = "") {
    $records = array_values(array_filter(computed_quarterly_summaries_for_student($studentId), function($record) use ($subject) {
        return strtolower(trim((string)($record["subject"] ?? ""))) === strtolower(trim((string)$subject));
    }));

    if (count($records) < 2) {
        return "Insufficient Trend Data";
    }

    usort($records, function($a, $b) {
        return strtotime($a["updatedAt"] ?? "now") <=> strtotime($b["updatedAt"] ?? "now");
    });

    $latest = computed_grade($records[count($records) - 1]);
    $previous = computed_grade($records[count($records) - 2]);
    $difference = $latest - $previous;

    if ($difference <= -3) {
        return "Declining Performance Pattern";
    }

    if ($difference >= 3) {
        return "Improving Performance Pattern";
    }

    return "Stable Performance Pattern";
}

function trend_guidance_output($record) {
    $trend = $record["trendStatus"] ?? "Insufficient Trend Data";
    $subject = $record["subject"] ?? "this subject";

    if ($trend === "Declining Performance Pattern") {
        return msg(
            "Reduce task piling for " . $subject . " and add review blocks earlier in the week.",
            "Bawasan ang pagsisiksik ng gawain sa " . $subject . " at maglagay ng review blocks nang mas maaga sa linggo.",
            "Reduce task piling for " . $subject . " and add review blocks earlier in the week."
        );
    }

    if ($trend === "Improving Performance Pattern") {
        return msg(
            "Continue the current study pattern for " . $subject . " and avoid delaying requirements.",
            "Ipagpatuloy ang kasalukuyang study pattern para sa " . $subject . " at iwasang ipagpaliban ang requirements.",
            "Continue the current study pattern for " . $subject . " and avoid delaying requirements."
        );
    }

    return msg(
        "Add more assessment records before using trend-based judgment.",
        "Magdagdag pa ng assessment records bago gamitin ang trend-based judgment.",
        "Add more assessment records before using trend-based judgment."
    );
}

function integrated_academic_risk($record, $workload = null, $taskSummary = null) {
    $statuses = [
        $record["academicStatus"] ?? "No Record",
        $record["competencyStatus"] ?? "No Record",
        $record["attendanceStatus"] ?? "No Record",
        $record["requirementStatus"] ?? "Complete Requirements",
        $record["trendStatus"] ?? "Insufficient Trend Data",
        $workload["lingguhangBigatIndex"] ?? "Magaan"
    ];

    if (in_array("At-Risk / Failing", $statuses, true) || in_array("Not Mastered / Remediation Needed", $statuses, true) || in_array("Attendance Concern", $statuses, true) || in_array("Mabigat", $statuses, true)) {
        return "At-Risk";
    }

    if (in_array("Warning Status", $statuses, true) || in_array("Nearing Mastery", $statuses, true) || in_array("Incomplete Requirements", $statuses, true) || in_array("Declining Performance Pattern", $statuses, true) || in_array("Katamtaman", $statuses, true)) {
        return "Warning";
    }

    return "Regular";
}

function follow_up_type_for_record($record, $workload = null) {
    if (($record["academicStatus"] ?? "") === "At-Risk / Failing" || ($record["competencyStatus"] ?? "") === "Not Mastered / Remediation Needed") {
        return "Remediation";
    }

    if (($record["requirementStatus"] ?? "") === "Incomplete Requirements") {
        return "Requirement Follow-up";
    }

    if (($record["attendanceStatus"] ?? "") === "Attendance Concern") {
        return "Attendance Follow-up";
    }

    if (($workload["lingguhangBigatIndex"] ?? "") === "Mabigat") {
        return "Workload Follow-up";
    }

    if (($record["academicStatus"] ?? "") === "Warning Status" || ($record["trendStatus"] ?? "") === "Declining Performance Pattern") {
        return "Performance Monitoring";
    }

    return "Regular Monitoring";
}

function guidance_output_for_record($record, $workload = null, $taskSummary = null) {
    $academicStatus = $record["academicStatus"] ?? "No Record";
    $competencyStatus = $record["competencyStatus"] ?? "No Record";
    $attendanceStatus = $record["attendanceStatus"] ?? "No Record";
    $requirementStatus = $record["requirementStatus"] ?? "Complete Requirements";
    $trendStatus = $record["trendStatus"] ?? "Insufficient Trend Data";
    $workloadStatus = $workload["lingguhangBigatIndex"] ?? "Magaan";
    $subject = $record["subject"] ?? "this subject";
    $risk = integrated_academic_risk($record, $workload, $taskSummary);

    if ($risk === "At-Risk") {
        $status = msg(
            "This record needs immediate monitoring because one or more risk rules were triggered.",
            "Kailangan agad bantayan ang talang ito dahil may risk rule na na-trigger.",
            "This record needs immediate monitoring dahil may risk rule na na-trigger."
        );
    } elseif ($risk === "Warning") {
        $status = msg(
            "This record needs closer monitoring because one or more warning indicators were detected.",
            "Kailangan ng mas malapit na monitoring dahil may warning indicator na nakita.",
            "This record needs closer monitoring dahil may warning indicator na nakita."
        );
    } else {
        $status = msg(
            "This record is under regular monitoring.",
            "Ang talang ito ay nasa regular na monitoring.",
            "This record is under regular monitoring."
        );
    }

    $advisory = "";

    if ($academicStatus === "At-Risk / Failing" || $academicStatus === "Warning Status") {
        $advisory = grade_guidance_output($record);
    } elseif ($competencyStatus === "Not Mastered / Remediation Needed" || $competencyStatus === "Nearing Mastery") {
        $advisory = competency_guidance_output($record);
    } elseif ($attendanceStatus === "Attendance Concern") {
        $advisory = attendance_guidance_output($record);
    } elseif ($requirementStatus === "Incomplete Requirements") {
        $advisory = requirement_guidance_output($record);
    } elseif ($trendStatus === "Declining Performance Pattern") {
        $advisory = trend_guidance_output($record);
    } elseif ($workloadStatus === "Mabigat" || $workloadStatus === "Katamtaman") {
        $advisory = msg(
            "Adjust the weekly workload for " . $subject . ". Move non-urgent tasks, split large tasks, and protect review time.",
            "Ayusin ang lingguhang workload para sa " . $subject . ". Ilipat ang hindi urgent na tasks, hatiin ang malalaking gawain, at protektahan ang review time.",
            "Adjust the weekly workload for " . $subject . ". Move non-urgent tasks, split big tasks, and protect review time."
        );
    } else {
        $advisory = msg(
            "Continue the current routine for " . $subject . " and keep tasks updated.",
            "Ipagpatuloy ang kasalukuyang routine para sa " . $subject . " at panatilihing updated ang tasks.",
            "Continue the current routine for " . $subject . " and keep tasks updated."
        );
    }

    $guidance = msg(
        "Set the next action based on the highest triggered rule, then review the task board before the next deadline.",
        "Itakda ang susunod na aksyon batay sa pinakamataas na rule na na-trigger, pagkatapos ay tingnan ang task board bago ang susunod na deadline.",
        "Set the next action based on the highest triggered rule, then check the task board before the next deadline."
    );

    return [
        "status" => $status,
        "advisory" => $advisory,
        "guidance" => $guidance
    ];
}

function evaluate_record($record, $tasks = null, $workload = null, $taskSummary = null) {
    $record["recordMode"] = record_mode_value($record);
    $record["computedGrade"] = computed_grade($record);
    $record["academicStatus"] = grade_status($record["computedGrade"]);
    $record["assessmentPercentage"] = $record["recordMode"] === "assessment" ? compute_assessment_percentage($record) : ($record["assessmentPercentage"] ?? 0);
    $record["competencyMastery"] = compute_competency_mastery($record);

    if ($record["recordMode"] === "assessment" && ($record["assessmentType"] ?? "") !== "Competency Check" && empty($record["competencyMastery"])) {
        $record["competencyStatus"] = "No Record";
    } else {
        $record["competencyStatus"] = $record["competencyMastery"] > 0 ? competency_status($record["competencyMastery"]) : "No Record";
    }

    $attendanceSummary = attendance_summary_for_subject_period($record["studentId"] ?? "", $record["subject"] ?? "", $record["gradingPeriod"] ?? "");
    $record["attendanceSummary"] = $attendanceSummary;

    if (($attendanceSummary["markedMeetings"] ?? 0) > 0) {
        $record["absenceRate"] = $attendanceSummary["absenceRate"];
        $record["consecutiveAbsences"] = $attendanceSummary["consecutiveAbsences"];
        $record["attendanceStatus"] = $attendanceSummary["attendanceStatus"];
    } else {
        $record["absenceRate"] = compute_absence_rate($record);
        $record["consecutiveAbsences"] = isset($record["consecutiveAbsences"]) ? (int)$record["consecutiveAbsences"] : compute_consecutive_absences_from_dates($record["absenceDates"] ?? []);
        $record["attendanceStatus"] = (($record["absenceRate"] ?? 0) > 0 || ($record["consecutiveAbsences"] ?? 0) > 0) ? attendance_status($record["absenceRate"], $record["consecutiveAbsences"]) : "No Record";
    }

    $record["requirementStatus"] = requirement_status_for_record($record);
    $record["missingRequirements"] = missing_requirements_for_record($record);
    $record["trendStatus"] = trend_status_for_student_subject($record["studentId"] ?? "", $record["subject"] ?? "", $record["gradingPeriod"] ?? "");
    $record["integratedRisk"] = integrated_academic_risk($record, $workload, $taskSummary);
    $record["followUpType"] = follow_up_type_for_record($record, $workload);
    $record["guidanceOutput"] = guidance_output_for_record($record, $workload, $taskSummary);
    $record["advisory"] = array_values(array_filter([
        grade_guidance_output($record),
        $record["competencyStatus"] !== "No Record" ? competency_guidance_output($record) : "",
        $record["attendanceStatus"] !== "No Record" ? attendance_guidance_output($record) : "",
        requirement_guidance_output($record),
        trend_guidance_output($record)
    ]));

    return $record;
}

function records_for_student($studentId) {
    $records = read_records_where("academic_records", ["studentId" => $studentId], "coalesce(data->>'updatedAt', data->>'createdAt', '') desc, updated_at desc, id desc");

    usort($records, function($a, $b) {
        return strtotime($b["updatedAt"] ?? $b["createdAt"] ?? "now") <=> strtotime($a["updatedAt"] ?? $a["createdAt"] ?? "now");
    });

    return $records;
}


function academic_record_history_for_student($studentId) {
    $records = records_for_student($studentId);
    $summaries = computed_quarterly_summaries_for_student($studentId);
    return array_merge($summaries, $records);
}

function latest_record_by_subject($studentId) {
    $latest = [];

    foreach (computed_quarterly_summaries_for_student($studentId) as $record) {
        $subject = $record["subject"] ?? "Unassigned Subject";

        if (!isset($latest[$subject])) {
            $latest[$subject] = evaluate_record($record);
        }
    }

    foreach (records_for_student($studentId) as $record) {
        $subject = $record["subject"] ?? "Unassigned Subject";

        if (!isset($latest[$subject])) {
            $latest[$subject] = evaluate_record($record);
        }
    }

    return $latest;
}

function latest_evaluated_record_for_student($studentId) {
    $summaries = computed_quarterly_summaries_for_student($studentId);

    if (count($summaries)) {
        return evaluate_record($summaries[0]);
    }

    $records = records_for_student($studentId);

    if (count($records)) {
        return evaluate_record($records[0]);
    }

    return null;
}

function kaakbay_valid_date_value($value) {
    $value = trim((string)$value);

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
        return false;
    }

    $date = DateTime::createFromFormat('!Y-m-d', $value);
    $errors = DateTime::getLastErrors();

    if (!$date) {
        return false;
    }

    if (is_array($errors) && (($errors["warning_count"] ?? 0) > 0 || ($errors["error_count"] ?? 0) > 0)) {
        return false;
    }

    return $date->format('Y-m-d') === $value;
}

function kaakbay_valid_time_value($value) {
    $value = trim((string)$value);

    if (!preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $value)) {
        return false;
    }

    return true;
}

function kaakbay_parse_decimal_value($value, $min, $max, $maxDecimals = 2) {
    if (is_int($value) || is_float($value)) {
        $value = (string)$value;
    }

    $value = trim((string)$value);

    if ($value === "" || preg_match('/[eE]/', $value)) {
        return null;
    }

    $maxDecimals = max(0, min(6, (int)$maxDecimals));
    $pattern = $maxDecimals > 0
        ? '/^\d+(?:\.\d{1,' . $maxDecimals . '})?$/'
        : '/^\d+$/';

    if (!preg_match($pattern, $value)) {
        return null;
    }

    $number = (float)$value;

    if (!is_finite($number) || $number < (float)$min || $number > (float)$max) {
        return null;
    }

    return $number;
}

function kaakbay_is_quarter_hour_value($value) {
    $scaled = (float)$value * 4;
    return abs($scaled - round($scaled)) < 0.00001;
}

function kaakbay_task_max_date() {
    return date("Y-m-d", strtotime("+1 year", strtotime(date("Y-m-d"))));
}

function kaakbay_assessment_min_date() {
    return date("Y-m-d", strtotime("-1 year", strtotime(date("Y-m-d"))));
}

function kaakbay_valid_ph_mobile_number($value) {
    $value = trim((string)$value);

    if ($value === "") {
        return true;
    }

    return preg_match('/^(?:09\d{9}|\+639\d{9})$/', $value) === 1;
}

function save_academic_record($studentId, $post) {
    $student = find_user_by_id($studentId);
    $recordId = safe_text($post["recordId"] ?? "", 80);
    $recordMode = "assessment";
    $subject = safe_text($post["subject"] ?? "", 100);
    $strand = safe_text($student["strand"] ?? "", 60);
    $gradeLevel = safe_text($student["gradeLevel"] ?? "", 40);
    $gradingPeriod = safe_text($post["gradingPeriod"] ?? "", 40);
    $assessmentType = safe_text($post["assessmentType"] ?? "", 60);
    $assessmentTitle = safe_text($post["assessmentTitle"] ?? "", 120);
    $scoreRaw = $post["score"] ?? "";
    $totalScoreRaw = $post["totalScore"] ?? "";
    $submissionStatus = safe_text($post["submissionStatus"] ?? "Submitted", 40);
    $assessmentDate = safe_text($post["assessmentDate"] ?? date("Y-m-d"), 20);

    if ($strand === "") {
        $strand = safe_text($post["strand"] ?? "", 60);
    }

    if ($gradeLevel === "") {
        $gradeLevel = safe_text($post["gradeLevel"] ?? "", 40);
    }

    if ($subject === "" || $strand === "" || $gradeLevel === "" || $gradingPeriod === "" || $assessmentType === "" || $assessmentTitle === "") {
        return ["ok" => false, "message" => msg("Complete all required assessment fields.", "Kumpletuhin ang lahat ng required assessment fields.", "Complete all required assessment fields.")];
    }

    if (!in_array($gradingPeriod, grading_periods(), true)) {
        return ["ok" => false, "message" => msg("Select a valid grading period.", "Pumili ng wastong grading period.", "Select a valid grading period.")];
    }

    if (!in_array($assessmentType, ["Written Work", "Performance Task", "Quarterly Assessment", "Competency Check"], true)) {
        return ["ok" => false, "message" => msg("Select a valid assessment type.", "Pumili ng wastong uri ng assessment.", "Select a valid assessment type.")];
    }

    if (!in_array($submissionStatus, ["Submitted", "Missing"], true)) {
        return ["ok" => false, "message" => msg("Select a valid submission status.", "Pumili ng wastong submission status.", "Select a valid submission status.")];
    }

    if (!kaakbay_valid_date_value($assessmentDate)) {
        return ["ok" => false, "message" => msg("Enter a valid assessment date.", "Maglagay ng wastong assessment date.", "Enter a valid assessment date.")];
    }

    if ($assessmentDate > date("Y-m-d")) {
        return ["ok" => false, "message" => msg("Assessment date cannot be in the future.", "Hindi maaaring nasa hinaharap ang assessment date.", "Assessment date cannot be in the future.")];
    }

    $assessmentMinDate = kaakbay_assessment_min_date();

    if ($assessmentDate < $assessmentMinDate) {
        return ["ok" => false, "message" => msg(
            "Assessment date cannot be more than 1 year old.",
            "Hindi maaaring higit sa 1 taon ang lumang assessment date.",
            "Assessment date cannot be more than 1 year old."
        )];
    }

    $totalScore = kaakbay_parse_decimal_value($totalScoreRaw, 1, 200, 2);

    if ($totalScore === null) {
        return ["ok" => false, "message" => msg("Total score must be a number from 1 to 200 with up to 2 decimal places.", "Ang total score ay dapat numerong 1 hanggang 200 na may hanggang 2 decimal places.", "Total score must be a number from 1 to 200 with up to 2 decimal places.")];
    }

    if ($submissionStatus === "Missing") {
        $score = 0.0;
    } else {
        $score = kaakbay_parse_decimal_value($scoreRaw, 0, 200, 2);

        if ($score === null) {
            return ["ok" => false, "message" => msg("Score must be a number from 0 to 200 with up to 2 decimal places.", "Ang score ay dapat numerong 0 hanggang 200 na may hanggang 2 decimal places.", "Score must be a number from 0 to 200 with up to 2 decimal places.")];
        }
    }

    if ($score > $totalScore) {
        return ["ok" => false, "message" => msg("Score cannot be higher than total score.", "Hindi maaaring mas mataas ang score kaysa total score.", "Score cannot be higher than total score.")];
    }

    $existing = null;

    if ($recordId !== "") {
        $found = find_storage_record_by_id("academic_records", $recordId);

        if (is_array($found) && ($found["studentId"] ?? "") === $studentId) {
            $existing = $found;
        }
    }

    if ($existing !== null) {
        if (function_exists("record_has_teacher_validation") && record_has_teacher_validation($recordId)) {
            return ["ok" => false, "message" => msg(
                "This record has already been checked by a teacher and can no longer be edited.",
                "Na-check na ng guro ang record na ito at hindi na ito maaaring i-edit.",
                "This record has already been checked by a teacher and can no longer be edited."
            )];
        }

        if (function_exists("record_has_pending_delete_request") && record_has_pending_delete_request($recordId, $studentId)) {
            return ["ok" => false, "message" => msg(
                "This record has a pending deletion request and cannot be edited until the request is reviewed.",
                "May pending deletion request ang record na ito at hindi muna ito maaaring i-edit hanggang ma-review ang request.",
                "This record has a pending deletion request and cannot be edited until the request is reviewed."
            )];
        }
    }

    $now = date("c");
    $id = $recordId !== "" ? $recordId : "rec-" . time() . "-" . bin2hex(random_bytes(3));

    $record = [
        "id" => $id,
        "studentId" => $studentId,
        "recordMode" => $recordMode,
        "subject" => $subject,
        "strand" => $strand,
        "gradeLevel" => $gradeLevel,
        "gradingPeriod" => $gradingPeriod,
        "assessmentType" => $assessmentType,
        "assessmentTitle" => $assessmentTitle,
        "score" => round($score, 2),
        "totalScore" => round($totalScore, 2),
        "assessmentPercentage" => round(percent_score($score, $totalScore), 2),
        "submissionStatus" => $submissionStatus,
        "assessmentDate" => $assessmentDate,
        "validationStatus" => $existing["validationStatus"] ?? "Pending Teacher Validation",
        "createdAt" => $existing["createdAt"] ?? $now,
        "updatedAt" => $now
    ];

    if ($assessmentType === "Competency Check") {
        $competencyName = safe_text($post["competencyName"] ?? $post["competencyArea"] ?? "", 120);

        if ($competencyName === "") {
            return ["ok" => false, "message" => msg("Enter the competency area for competency check entries.", "Ilagay ang competency area para sa competency check entries.", "Enter the competency area for competency check entries.")];
        }

        $record["competencyName"] = $competencyName;
        $record["competencyCorrect"] = round($score, 2);
        $record["competencyTotal"] = round($totalScore, 2);
        $record["competencyMastery"] = round(percent_score($score, $totalScore), 2);
    }

    if ($existing !== null) {
        if (!update_record_by_id("academic_records", $record["id"], $record)) {
            return ["ok" => false, "message" => msg("Unable to save the record.", "Hindi ma-save ang tala.", "Unable to save the record.")];
        }
    } else {
        append_record("academic_records", $record);
    }

    return ["ok" => true, "message" => msg("Record saved.", "Nai-save ang tala.", "Record saved.")];
}


function task_categories() {
    return [
        "Written Work",
        "Performance Task",
        "Quarterly Assessment",
        "Other Requirement"
    ];
}

function normalize_task_category($category) {
    $category = trim((string)$category);
    $map = [
        "written work" => "Written Work",
        "written works" => "Written Work",
        "performance task" => "Performance Task",
        "performance tasks" => "Performance Task",
        "quarterly assessment" => "Quarterly Assessment",
        "quarterly assessments" => "Quarterly Assessment",
        "competency check" => "Other Requirement",
        "other" => "Other Requirement",
        "other requirement" => "Other Requirement",
        "other requirements" => "Other Requirement"
    ];

    $key = strtolower($category);

    return $map[$key] ?? "Other Requirement";
}

function task_category_weight($category) {
    $category = normalize_task_category($category);
    $weights = [
        "Written Work" => 1.0,
        "Performance Task" => 1.2,
        "Quarterly Assessment" => 1.4,
        "Other Requirement" => 1.0
    ];

    return $weights[$category] ?? 1.0;
}

function task_score($task) {
    return round((float)($task["difficulty"] ?? 1) * (float)($task["estimatedDuration"] ?? 1), 2);
}

function adjusted_task_score($task) {
    $base = task_score($task);
    $weight = task_category_weight($task["category"] ?? "Other Requirement");

    return round($base * $weight, 2);
}

function task_due_timestamp($task) {
    $date = $task["dueDate"] ?? "";

    if ($date === "") {
        return PHP_INT_MAX;
    }

    $time = strtotime($date);

    return $time ?: PHP_INT_MAX;
}

function days_until_due($task) {
    $due = task_due_timestamp($task);

    if ($due === PHP_INT_MAX) {
        return 999;
    }

    $today = strtotime(date("Y-m-d"));
    return (int)floor(($due - $today) / 86400);
}

function computed_task_status($task) {
    $status = $task["status"] ?? "Not Started";

    if ($status === "Completed") {
        return "Completed";
    }

    if (days_until_due($task) < 0) {
        return "Overdue";
    }

    if ($status === "In Progress") {
        return "In Progress";
    }

    if ($status === "Rescheduled") {
        return "Rescheduled";
    }

    return "Not Started";
}

function task_priority($task, $academicStatus = "") {
    $status = computed_task_status($task);
    $days = days_until_due($task);
    $score = adjusted_task_score($task);

    if ($status === "Overdue") {
        return "Critical";
    }

    if ($academicStatus === "At-Risk / Failing" && $days <= 3) {
        return "Critical";
    }

    if ($days <= 1 && $score >= 8) {
        return "Critical";
    }

    if ($days <= 2 || $score >= 10 || $academicStatus === "Warning Status") {
        return "High";
    }

    if ($days <= 5 || $score >= 5) {
        return "Medium";
    }

    return "Low";
}

function task_trigger_messages($task, $academicStatus = "") {
    $messages = [];
    $status = computed_task_status($task);
    $days = days_until_due($task);
    $duration = (float)($task["estimatedDuration"] ?? 0);
    $score = adjusted_task_score($task);

    if ($status === "Overdue") {
        $messages[] = msg(
            "This task is overdue. Move it to today or ask for clarification if the deadline has changed.",
            "Lampas na sa deadline ang task na ito. Ilipat ito sa araw na ito o magtanong kung nagbago ang deadline.",
            "Overdue na ang task na ito. Move it today or ask for clarification if nagbago ang deadline."
        );
    }

    if ($days >= 0 && $days <= 1 && $duration >= 2) {
        $messages[] = msg(
            "The remaining time is tight for the estimated duration. Split the task into smaller blocks.",
            "Kulang ang natitirang oras para sa tinatayang tagal. Hatiin ang task sa mas maliliit na blocks.",
            "Tight ang remaining time for the estimated duration. Split the task into smaller blocks."
        );
    }

    if ($score >= 10) {
        $messages[] = msg(
            "This task has high workload demand. Schedule it before lower-priority tasks.",
            "Mataas ang workload demand ng task na ito. I-schedule ito bago ang mas mababang priority na tasks.",
            "High workload demand ang task na ito. Schedule it before lower-priority tasks."
        );
    }

    if ($academicStatus === "At-Risk / Failing") {
        $messages[] = msg(
            "This subject has an academic risk flag. Prioritize related requirements and review work.",
            "May academic risk flag ang subject na ito. Unahin ang related requirements at review work.",
            "May academic risk flag ang subject na ito. Prioritize related requirements and review work."
        );
    }

    return array_values(array_unique($messages));
}

function task_guidance_output($task, $academicStatus = "", $workloadStatus = "Magaan") {
    $messages = task_trigger_messages($task, $academicStatus);
    $priority = task_priority($task, $academicStatus);
    $days = days_until_due($task);
    $title = $task["title"] ?? "this task";

    if ($priority === "Critical") {
        $messages[] = msg(
            "Do " . $title . " first. Use one focused block now, then update the status after completion.",
            "Unahin ang " . $title . ". Gumamit ng isang focused block ngayon, pagkatapos ay i-update ang status kapag natapos.",
            "Do " . $title . " first. Use one focused block now, then update the status after completion."
        );
    } elseif ($priority === "High") {
        $messages[] = msg(
            "Schedule " . $title . " today or tomorrow before easier tasks.",
            "I-schedule ang " . $title . " ngayong araw o bukas bago ang mas madaling tasks.",
            "Schedule " . $title . " today or tomorrow before easier tasks."
        );
    } elseif ($priority === "Medium") {
        $messages[] = msg(
            "Keep " . $title . " in the weekly plan and avoid leaving it near the deadline.",
            "Isama ang " . $title . " sa weekly plan at iwasang iwan ito malapit sa deadline.",
            "Keep " . $title . " in the weekly plan and avoid leaving it near the deadline."
        );
    }

    if ($workloadStatus === "Mabigat") {
        $messages[] = msg(
            "Your weekly workload is high. Move non-urgent tasks and split long tasks.",
            "Mabigat ang weekly workload. Ilipat ang hindi urgent na tasks at hatiin ang mahahabang tasks.",
            "Mabigat ang weekly workload. Move non-urgent tasks and split long tasks."
        );
    }

    if ($days > 7 && $priority === "Low") {
        $messages[] = msg(
            "This can stay as a light preparation task unless other deadlines become clustered.",
            "Maaari itong manatiling light preparation task maliban kung magsiksikan ang ibang deadlines.",
            "This can stay as a light prep task unless other deadlines become clustered."
        );
    }

    return array_values(array_unique($messages));
}

function task_is_removed($task) {
    if (!is_array($task)) {
        return false;
    }

    $status = strtolower(trim((string)($task["status"] ?? "")));

    return !empty($task["isRemoved"])
        || !empty($task["removedAt"])
        || in_array($status, ["removed", "cancelled", "canceled"], true);
}

function task_history_entry($action, $details = [], $actorUserId = "") {
    return [
        "id" => "hist-" . time() . "-" . bin2hex(random_bytes(3)),
        "action" => safe_text($action, 80),
        "actorUserId" => safe_text($actorUserId, 100),
        "details" => is_array($details) ? $details : ["message" => safe_text($details, 500)],
        "createdAt" => date("c")
    ];
}

function task_append_history($task, $action, $details = [], $actorUserId = "") {
    if (!is_array($task)) {
        $task = [];
    }

    $history = is_array($task["history"] ?? null) ? $task["history"] : [];
    $history[] = task_history_entry($action, $details, $actorUserId);

    if (count($history) > 100) {
        $history = array_slice($history, -100);
    }

    $task["history"] = $history;
    return $task;
}

function task_delete_window_seconds() {
    return 10 * 60;
}

function task_delete_deadline($task) {
    $createdAt = strtotime((string)($task["createdAt"] ?? ""));

    if (!$createdAt) {
        return "";
    }

    return date("c", $createdAt + task_delete_window_seconds());
}

function task_can_be_deleted($task) {
    if (!is_array($task) || task_is_removed($task)) {
        return false;
    }

    $createdAt = strtotime((string)($task["createdAt"] ?? ""));

    if (!$createdAt) {
        return false;
    }

    $age = time() - $createdAt;
    return $age >= 0 && $age <= task_delete_window_seconds();
}

function removed_tasks_for_student($studentId) {
    $records = read_records_where("tasks", ["studentId" => $studentId], "coalesce(data->>'removedAt', data->>'updatedAt', data->>'createdAt', '') desc, updated_at desc, id desc");

    $records = array_values(array_filter($records, function($task) {
        return task_is_removed($task);
    }));

    usort($records, function($a, $b) {
        return strtotime($b["removedAt"] ?? $b["updatedAt"] ?? "now") <=> strtotime($a["removedAt"] ?? $a["updatedAt"] ?? "now");
    });

    return $records;
}

function task_history_for_student($studentId) {
    $tasks = read_records_where("tasks", ["studentId" => $studentId], "coalesce(data->>'updatedAt', data->>'createdAt', '') desc, updated_at desc, id desc");
    $history = [];

    foreach ($tasks as $task) {
        foreach ((array)($task["history"] ?? []) as $entry) {
            if (!is_array($entry)) {
                continue;
            }

            $entry["taskId"] = $task["id"] ?? "";
            $entry["taskTitle"] = $task["title"] ?? "";
            $entry["taskStatus"] = $task["status"] ?? "";
            $history[] = $entry;
        }

        if (task_is_removed($task) && !count((array)($task["history"] ?? []))) {
            $history[] = [
                "id" => "legacy-" . ($task["id"] ?? ""),
                "action" => "removed",
                "actorUserId" => $task["removedBy"] ?? $studentId,
                "details" => [
                    "reason" => $task["removalReason"] ?? "",
                    "mode" => $task["removalMode"] ?? "remove"
                ],
                "createdAt" => $task["removedAt"] ?? $task["updatedAt"] ?? $task["createdAt"] ?? date("c"),
                "taskId" => $task["id"] ?? "",
                "taskTitle" => $task["title"] ?? "",
                "taskStatus" => $task["status"] ?? ""
            ];
        }
    }

    usort($history, function($a, $b) {
        return strtotime($b["createdAt"] ?? "now") <=> strtotime($a["createdAt"] ?? "now");
    });

    return $history;
}

function task_remove_or_delete($taskId, $studentId, $mode, $reason = "") {
    $taskId = trim((string)$taskId);
    $studentId = trim((string)$studentId);
    $mode = strtolower(trim((string)$mode));
    $reason = safe_text($reason, 500);
    $task = find_storage_record_by_id("tasks", $taskId);

    if (!is_array($task) || (string)($task["studentId"] ?? "") !== $studentId) {
        return ["ok" => false, "message" => msg("Task was not found.", "Hindi nakita ang task.", "Task was not found.")];
    }

    if (task_is_removed($task)) {
        audit_log($studentId, "TASK_REMOVAL_REJECTED", "Repeated task removal or deletion attempt was rejected.", [
            "category" => "task",
            "taskId" => $taskId,
            "existingStatus" => $task["status"] ?? ""
        ]);
        return ["ok" => false, "message" => msg("This task is already removed or cancelled.", "Removed o cancelled na ang task na ito.", "This task is already removed or cancelled.")];
    }

    if ($mode === "delete") {
        if (!task_can_be_deleted($task)) {
            audit_log($studentId, "TASK_DELETE_WINDOW_EXPIRED", "Permanent deletion was rejected because the 10-minute period ended.", [
                "category" => "task",
                "taskId" => $taskId
            ]);
            return [
                "ok" => false,
                "requiresRemoval" => true,
                "message" => msg(
                    "The 10-minute delete period has ended. Remove or cancel the task instead and provide a reason.",
                    "Tapos na ang 10-minute delete period. I-remove o i-cancel na lang ang task at maglagay ng reason.",
                    "The 10-minute delete period has ended. Remove or cancel the task instead and provide a reason."
                )
            ];
        }

        $title = (string)($task["title"] ?? "");

        if (!delete_record_by_id("tasks", $taskId)) {
            return ["ok" => false, "message" => msg("Unable to delete the task.", "Hindi ma-delete ang task.", "Unable to delete the task.")];
        }

        audit_log($studentId, "TASK_DELETED", "Task permanently deleted within the allowed 10-minute period.", [
            "category" => "task",
            "taskId" => $taskId,
            "taskTitle" => $title
        ]);

        return ["ok" => true, "deleted" => true, "message" => msg("Task deleted.", "Na-delete ang task.", "Task deleted.")];
    }

    if (!in_array($mode, ["remove", "cancel", "cancelled", "canceled"], true)) {
        return ["ok" => false, "message" => msg("Select a valid task removal action.", "Pumili ng wastong task removal action.", "Select a valid task removal action.")];
    }

    if ($reason === "") {
        return ["ok" => false, "message" => msg("Enter a reason for removing or cancelling the task.", "Maglagay ng reason para sa pag-remove o pag-cancel ng task.", "Enter a reason for removing or cancelling the task.")];
    }

    $status = in_array($mode, ["cancel", "cancelled", "canceled"], true) ? "Cancelled" : "Removed";
    $previousStatus = (string)($task["status"] ?? "Not Started");
    $now = date("c");

    $task["statusBeforeRemoval"] = $previousStatus;
    $task["status"] = $status;
    $task["isRemoved"] = true;
    $task["removedAt"] = $now;
    $task["removedBy"] = $studentId;
    $task["removalMode"] = strtolower($status);
    $task["removalReason"] = $reason;
    $task["dismissed"] = true;
    $task["updatedAt"] = $now;
    $task = task_append_history($task, strtolower($status), [
        "reason" => $reason,
        "previousStatus" => $previousStatus
    ], $studentId);

    if (!update_record_by_id("tasks", $taskId, $task)) {
        return ["ok" => false, "message" => msg("Unable to remove the task.", "Hindi ma-remove ang task.", "Unable to remove the task.")];
    }

    audit_log($studentId, $status === "Cancelled" ? "TASK_CANCELLED" : "TASK_REMOVED", "Task retained in history and excluded from active workload.", [
        "category" => "task",
        "taskId" => $taskId,
        "reason" => $reason
    ]);

    return [
        "ok" => true,
        "removed" => true,
        "status" => $status,
        "message" => $status === "Cancelled"
            ? msg("Task cancelled and kept in history.", "Na-cancel ang task at nanatili sa history.", "Task cancelled and kept in history.")
            : msg("Task removed and kept in history.", "Na-remove ang task at nanatili sa history.", "Task removed and kept in history.")
    ];
}

function tasks_for_student($studentId, $includeRemoved = false) {
    $tasks = read_records_where("tasks", ["studentId" => $studentId], "coalesce(data->>'dueDate', data->>'createdAt', '') asc, created_at asc, id asc");

    if (!$includeRemoved) {
        $tasks = array_values(array_filter($tasks, function($task) {
            return !task_is_removed($task);
        }));
    }

    usort($tasks, function($a, $b) {
        $aCompleted = ($a["status"] ?? "") === "Completed" ? 1 : 0;
        $bCompleted = ($b["status"] ?? "") === "Completed" ? 1 : 0;

        if ($aCompleted !== $bCompleted) {
            return $aCompleted <=> $bCompleted;
        }

        return task_due_timestamp($a) <=> task_due_timestamp($b);
    });

    return $tasks;
}


function save_task($studentId, $post) {
    $taskId = safe_text($post["taskId"] ?? "", 80);
    $title = safe_text($post["title"] ?? "", 120);
    $subject = safe_text($post["subject"] ?? "", 100);
    $category = normalize_task_category($post["category"] ?? "Other Requirement");
    $difficultyRaw = trim((string)($post["difficulty"] ?? ""));
    $durationRaw = $post["estimatedDuration"] ?? $post["duration"] ?? "";
    $startDate = safe_text($post["startDate"] ?? date("Y-m-d"), 20);
    $dueDate = safe_text($post["dueDate"] ?? date("Y-m-d"), 20);
    $status = safe_text($post["status"] ?? "Not Started", 40);
    $notes = safe_text($post["notes"] ?? "", 500);

    if ($title === "" || $subject === "" || $dueDate === "") {
        return ["ok" => false, "message" => msg("Complete task title, subject, and due date.", "Kumpletuhin ang task title, subject, at due date.", "Complete task title, subject, and due date.")];
    }

    if (!preg_match('/^[1-5]$/', $difficultyRaw)) {
        return ["ok" => false, "message" => msg("Difficulty must be an integer from 1 to 5.", "Ang difficulty ay dapat whole number mula 1 hanggang 5.", "Difficulty must be an integer from 1 to 5.")];
    }

    $difficulty = (int)$difficultyRaw;
    $estimatedDuration = kaakbay_parse_decimal_value($durationRaw, 0.25, 12, 2);

    if ($estimatedDuration === null || !kaakbay_is_quarter_hour_value($estimatedDuration)) {
        return ["ok" => false, "message" => msg("Estimated duration must be from 0.25 to 12 hours in 0.25-hour increments.", "Ang estimated duration ay dapat 0.25 hanggang 12 oras sa 0.25-hour increments.", "Estimated duration must be from 0.25 to 12 hours in 0.25-hour increments.")];
    }

    if (!in_array($status, ["Not Started", "In Progress", "Rescheduled", "Completed"], true)) {
        return ["ok" => false, "message" => msg("Select a valid task status.", "Pumili ng wastong task status.", "Select a valid task status.")];
    }

    if (!kaakbay_valid_date_value($startDate) || !kaakbay_valid_date_value($dueDate)) {
        return ["ok" => false, "message" => msg("Enter valid task start and due dates.", "Maglagay ng wastong start at due dates.", "Enter valid task start and due dates.")];
    }

    $existing = null;

    if ($taskId !== "") {
        $found = find_storage_record_by_id("tasks", $taskId);

        if (is_array($found) && ($found["studentId"] ?? "") === $studentId) {
            $existing = $found;
        }
    }

    if ($existing !== null && task_is_removed($existing)) {
        return ["ok" => false, "message" => msg("Removed or cancelled tasks cannot be edited.", "Hindi maaaring i-edit ang removed o cancelled tasks.", "Removed or cancelled tasks cannot be edited.")];
    }

    $today = date("Y-m-d");
    $maxDate = kaakbay_task_max_date();
    $existingStartDate = $existing !== null ? trim((string)($existing["startDate"] ?? "")) : "";
    $startDateChanged = $existing === null || $startDate !== $existingStartDate;

    if ($startDateChanged && $startDate < $today) {
        return ["ok" => false, "message" => msg("Task start date cannot be earlier than today.", "Hindi maaaring mas maaga sa kasalukuyang araw ang task start date.", "Task start date cannot be earlier than today.")];
    }

    if ($startDate > $maxDate || $dueDate > $maxDate) {
        return ["ok" => false, "message" => msg("Task dates cannot be more than 1 year from today.", "Hindi maaaring lumampas ng 1 taon mula ngayon ang task dates.", "Task dates cannot be more than 1 year from today.")];
    }

    if ($dueDate < $startDate) {
        return ["ok" => false, "message" => msg("Due date cannot be earlier than the start date.", "Hindi maaaring mas maaga ang due date kaysa start date.", "Due date cannot be earlier than the start date.")];
    }

    $weightFactor = task_category_weight($category);
    $now = date("c");
    $id = $taskId !== "" ? $taskId : "task-" . time() . "-" . bin2hex(random_bytes(3));
    $taskScore = round($difficulty * $estimatedDuration, 2);
    $adjustedTaskScore = round($taskScore * $weightFactor, 2);

    $task = [
        "id" => $id,
        "studentId" => $studentId,
        "title" => $title,
        "subject" => $subject,
        "category" => $category,
        "difficulty" => $difficulty,
        "estimatedDuration" => round($estimatedDuration, 2),
        "duration" => round($estimatedDuration, 2),
        "weightFactor" => round($weightFactor, 2),
        "taskScore" => $taskScore,
        "adjustedTaskScore" => $adjustedTaskScore,
        "startDate" => $startDate,
        "dueDate" => $dueDate,
        "status" => $status,
        "notes" => $notes,
        "dismissed" => $existing["dismissed"] ?? false,
        "subtasks" => $existing["subtasks"] ?? [],
        "history" => $existing["history"] ?? [],
        "isRemoved" => false,
        "removedAt" => "",
        "removedBy" => "",
        "removalMode" => "",
        "removalReason" => "",
        "createdAt" => $existing["createdAt"] ?? $now,
        "updatedAt" => $now
    ];

    if ($status === "Completed") {
        $task["completedAt"] = $existing["completedAt"] ?? $now;
    } elseif (isset($existing["completedAt"])) {
        $task["completedAt"] = $existing["completedAt"];
    }

    $task = task_append_history(
        $task,
        $existing !== null ? "updated" : "created",
        [
            "status" => $status,
            "subject" => $subject,
            "dueDate" => $dueDate
        ],
        $studentId
    );

    $saved = $existing !== null
        ? update_record_by_id("tasks", $task["id"], $task)
        : (bool)append_record("tasks", $task);

    if (!$saved) {
        return ["ok" => false, "message" => msg("Unable to save the task.", "Hindi ma-save ang task.", "Unable to save the task.")];
    }

    audit_log($studentId, $existing !== null ? "TASK_UPDATED" : "TASK_CREATED", $existing !== null ? "Task updated." : "Task created.", [
        "category" => "task",
        "taskId" => $id
    ]);

    return [
        "ok" => true,
        "message" => msg("Task saved.", "Nai-save ang task.", "Task saved."),
        "taskId" => $id,
        "deleteUntil" => task_delete_deadline($task)
    ];
}


function update_task_action($taskId, $studentId, $action, $post = []) {
    $task = find_storage_record_by_id("tasks", $taskId);

    if (!is_array($task) || ($task["studentId"] ?? "") !== $studentId || task_is_removed($task)) {
        return false;
    }

    $action = strtolower(trim((string)$action));

    if ($action === "delete") {
        $result = task_remove_or_delete($taskId, $studentId, "delete", "");
        return !empty($result["ok"]);
    }

    if (in_array($action, ["remove", "cancel", "cancelled", "canceled"], true)) {
        $result = task_remove_or_delete($taskId, $studentId, $action, $post["reason"] ?? $post["removalReason"] ?? "");
        return !empty($result["ok"]);
    }

    if (!in_array($action, ["start", "done", "dismiss", "move", "subtask"], true)) {
        return false;
    }

    $historyDetails = [];
    $historyAction = $action;

    if ($action === "start") {
        $task["status"] = "In Progress";
        $task["dismissed"] = false;
        $historyDetails["status"] = "In Progress";
    }

    if ($action === "done") {
        $task["status"] = "Completed";
        $task["completedAt"] = date("c");
        $task["dismissed"] = true;
        $historyDetails["status"] = "Completed";
    }

    if ($action === "dismiss") {
        $task["dismissed"] = true;
    }

    if ($action === "move") {
        $newDueDate = safe_text($post["newDueDate"] ?? "", 20);
        $today = date("Y-m-d");
        $maxDate = kaakbay_task_max_date();

        if (!kaakbay_valid_date_value($newDueDate)) {
            return false;
        }

        if ($newDueDate < $today || $newDueDate > $maxDate) {
            return false;
        }

        $historyDetails["previousDueDate"] = $task["dueDate"] ?? "";
        $historyDetails["newDueDate"] = $newDueDate;
        $task["dueDate"] = $newDueDate;
        $task["status"] = "Rescheduled";
        $task["dismissed"] = false;
    }

    if ($action === "subtask") {
        $title = safe_text($post["subtaskTitle"] ?? "", 120);
        $durationRaw = $post["subtaskDuration"] ?? "";
        $duration = kaakbay_parse_decimal_value($durationRaw, 0.25, 8, 2);

        if ($title === "" || $duration === null || !kaakbay_is_quarter_hour_value($duration)) {
            return false;
        }

        $task["subtasks"] = $task["subtasks"] ?? [];
        $task["subtasks"][] = [
            "id" => "sub-" . time() . "-" . bin2hex(random_bytes(2)),
            "title" => $title,
            "duration" => round($duration, 2),
            "status" => "Pending",
            "createdAt" => date("c")
        ];
        $task["dismissed"] = false;
        $historyDetails["subtaskTitle"] = $title;
    }

    $difficulty = (float)($task["difficulty"] ?? 0);
    $duration = (float)($task["estimatedDuration"] ?? $task["duration"] ?? 0);
    $weightFactor = (float)($task["weightFactor"] ?? 1);

    if ($difficulty > 0 && $duration > 0) {
        $task["taskScore"] = round($difficulty * $duration, 2);
        $task["adjustedTaskScore"] = round($task["taskScore"] * $weightFactor, 2);
    }

    $task["updatedAt"] = date("c");
    $task = task_append_history($task, $historyAction, $historyDetails, $studentId);

    if (!update_record_by_id("tasks", $taskId, $task)) {
        return false;
    }

    audit_log($studentId, "TASK_ACTION", "Task action completed.", [
        "category" => "task",
        "taskId" => (string)$taskId,
        "taskAction" => $action
    ]);

    return true;
}


function weekly_class_hours_from_schedule($studentId) {
    $total = 0;

    foreach (schedules_for_student($studentId) as $schedule) {
        $total += schedule_duration_hours($schedule);
    }

    return round($total, 2);
}

function task_summary_for_student($studentId) {
    $tasks = tasks_for_student($studentId);
    $summary = [
        "total" => count($tasks),
        "completed" => 0,
        "incomplete" => 0,
        "overdue" => 0,
        "alertCount" => 0
    ];

    $latestBySubject = latest_record_by_subject($studentId);

    foreach ($tasks as $task) {
        if (($task["status"] ?? "") === "Completed") {
            $summary["completed"]++;
        } else {
            $summary["incomplete"]++;
        }

        if (computed_task_status($task) === "Overdue") {
            $summary["overdue"]++;
        }

        $subject = $task["subject"] ?? "";
        $academicStatus = $latestBySubject[$subject]["academicStatus"] ?? "";

        if (count(task_trigger_messages($task, $academicStatus))) {
            $summary["alertCount"]++;
        }
    }

    return $summary;
}

function deadline_cluster_adjustment($tasks) {
    $dates = [];

    foreach ($tasks as $task) {
        if (($task["status"] ?? "") === "Completed") {
            continue;
        }

        $dueDate = $task["dueDate"] ?? "";

        if ($dueDate === "") {
            continue;
        }

        $dates[$dueDate] = ($dates[$dueDate] ?? 0) + 1;
    }

    $clusters = 0;
    $adjustment = 0;

    foreach ($dates as $count) {
        if ($count >= 2) {
            $clusters++;
            $adjustment += ($count - 1) * 1.5;
        }
    }

    return [
        "deadlineClusters" => $clusters,
        "deadlineClusterAdjustment" => round($adjustment, 2)
    ];
}

function workload_summary($records, $tasks, $studentId = null) {
    $weeklyScore = 0;
    $today = strtotime(date("Y-m-d"));
    $weekEnd = strtotime("+7 days", $today);

    foreach ($tasks as $task) {
        if (($task["status"] ?? "") === "Completed") {
            continue;
        }

        $due = task_due_timestamp($task);

        if ($due >= $today && $due <= $weekEnd) {
            $weeklyScore += adjusted_task_score($task);
        }
    }

    $cluster = deadline_cluster_adjustment($tasks);
    $weeklyScore += $cluster["deadlineClusterAdjustment"];

    $weeklyClassHours = $studentId ? weekly_class_hours_from_schedule($studentId) : 0;
    $availableStudyTime = available_study_time($weeklyClassHours);
    $ratio = $availableStudyTime > 0 ? round($weeklyScore / $availableStudyTime, 2) : 0;

    if ($ratio > 0.60) {
        $index = "Mabigat";
    } elseif ($ratio >= 0.30) {
        $index = "Katamtaman";
    } else {
        $index = "Magaan";
    }

    return [
        "weeklyWorkloadScore" => round($weeklyScore, 2),
        "weeklyClassHours" => round($weeklyClassHours, 2),
        "availableStudyTime" => round($availableStudyTime, 2),
        "workloadRatio" => $ratio,
        "lingguhangBigatIndex" => $index,
        "deadlineClusters" => $cluster["deadlineClusters"],
        "deadlineClusterAdjustment" => $cluster["deadlineClusterAdjustment"]
    ];
}

function workload_guidance_output($workload) {
    $index = $workload["lingguhangBigatIndex"] ?? "Magaan";

    if ($index === "Mabigat") {
        return msg(
            "Move non-urgent tasks, split long tasks, and protect rest blocks this week.",
            "Ilipat ang hindi urgent na tasks, hatiin ang mahahabang gawain, at protektahan ang rest blocks ngayong linggo.",
            "Move non-urgent tasks, split long tasks, and protect rest blocks this week."
        );
    }

    if ($index === "Katamtaman") {
        return msg(
            "Keep the weekly plan balanced and finish near-deadline tasks before adding new work.",
            "Panatilihing balanse ang weekly plan at tapusin ang malapit na deadline bago magdagdag ng bagong gawain.",
            "Keep the weekly plan balanced and finish near-deadline tasks before adding new work."
        );
    }

    return msg(
        "Use the light workload window for early review and small pending tasks.",
        "Gamitin ang magaan na workload window para sa maagang review at maliliit na pending tasks.",
        "Use the light workload window for early review and small pending tasks."
    );
}

function student_guidance_output($latest, $workload, $tasks) {
    $guidance = [];
    $latest = $latest ? evaluate_record($latest, $tasks, $workload, null) : null;
    $workloadStatus = $workload["lingguhangBigatIndex"] ?? "Magaan";
    $activeTasks = array_values(array_filter($tasks, fn($task) => ($task["status"] ?? "") !== "Completed"));

    if ($latest) {
        $subject = $latest["subject"] ?? msg("the selected subject", "ang napiling asignatura", "the selected subject");
        $grade = $latest["computedGrade"] ?? "";
        $academicStatus = $latest["academicStatus"] ?? "No Record";
        $competencyStatus = $latest["competencyStatus"] ?? "No Record";
        $attendanceStatus = $latest["attendanceStatus"] ?? "No Record";
        $requirementStatus = $latest["requirementStatus"] ?? "Complete Requirements";

        if ($academicStatus === "At-Risk / Failing") {
            $guidance[] = msg("Focus on " . $subject . " first because the computed grade is below 75. Review the lowest assessment type, finish missing requirements, then ask the teacher which topic needs remediation.", "Unahin ang " . $subject . " dahil mas mababa sa 75 ang computed grade. Balikan ang pinakamababang assessment type, tapusin ang kulang na requirements, at itanong sa guro kung anong topic ang kailangan ng remediation.", "Focus muna sa " . $subject . " because below 75 ang computed grade. Review the lowest assessment type, finish missing requirements, then ask the teacher which topic needs remediation.");
        } elseif ($academicStatus === "Warning Status") {
            $guidance[] = msg("Keep " . $subject . " under close review because the grade is within the warning range. Add one short review task before the next deadline.", "Panatilihing minomonitor ang " . $subject . " dahil nasa warning range ang marka. Magdagdag ng isang maikling review task bago ang susunod na deadline.", "Keep " . $subject . " under review because nasa warning range ang grade. Add one short review task before the next deadline.");
        }

        if ($competencyStatus === "Not Mastered / Remediation Needed") {
            $guidance[] = msg("Review the competency area with the lowest mastery. Create one remediation task for that skill before adding new non-urgent tasks.", "Balikan ang competency area na may pinakamababang mastery. Gumawa ng isang remediation task para sa skill na iyon bago magdagdag ng bagong hindi urgent na gawain.", "Review the competency area with the lowest mastery. Create one remediation task for that skill before adding new non-urgent tasks.");
        } elseif ($competencyStatus === "Nearing Mastery") {
            $guidance[] = msg("Practice a few more items for the competency area because the result is close to mastery but still needs reinforcement.", "Mag-practice pa ng ilang items para sa competency area dahil malapit na sa mastery pero kailangan pa ng reinforcement.", "Practice a few more items for the competency area because close to mastery na pero needs reinforcement pa.");
        }

        if ($attendanceStatus === "Attendance Concern") {
            $guidance[] = msg("Attendance is already flagged. Check the missed subject schedule and ask the teacher what activity or lesson must be recovered.", "Na-flag na ang attendance. Tingnan ang na-miss na subject schedule at itanong sa guro kung anong activity o lesson ang kailangang habulin.", "Attendance is already flagged. Check the missed subject schedule and ask the teacher what activity or lesson needs to be recovered.");
        }

        if ($requirementStatus === "Incomplete Requirements") {
            $guidance[] = msg("Submit the missing requirement first because incomplete work can pull down the computed subject result.", "Ipasa muna ang kulang na requirement dahil maaaring bumaba ang computed subject result kapag may kulang na gawain.", "Submit the missing requirement first because incomplete work can pull down the computed subject result.");
        }
    }

    if ($workloadStatus === "Mabigat") {
        $guidance[] = msg("The weekly workload is high. Split large tasks into smaller blocks and avoid adding non-urgent work until overdue or high-priority tasks are handled.", "Mabigat ang lingguhang gawain. Hatiin ang malalaking task sa mas maliliit na bahagi at iwasan muna ang hindi urgent na gawain hanggang matapos ang overdue o high-priority tasks.", "The weekly workload is high. Split large tasks into smaller blocks and avoid adding non-urgent work until overdue or high-priority tasks are handled.");
    } elseif ($workloadStatus === "Katamtaman") {
        $guidance[] = msg("The workload is manageable but needs spacing. Schedule one task block per day instead of doing several tasks near the deadline.", "Kaya pa ang workload pero kailangang ayusin ang pagitan. Mag-schedule ng isang task block bawat araw sa halip na pagsabay-sabayin malapit sa deadline.", "The workload is manageable but needs spacing. Schedule one task block per day instead of doing several tasks near the deadline.");
    } else {
        $guidance[] = msg("Use the light workload window for early review, small pending tasks, or remediation practice.", "Gamitin ang magaan na workload window para sa maagang review, maliliit na pending task, o remediation practice.", "Use the light workload window for early review, small pending tasks, or remediation practice.");
    }

    usort($activeTasks, function($a, $b) use ($latest) {
        $rank = ["Critical" => 1, "High" => 2, "Medium" => 3, "Low" => 4];
        $status = $latest["academicStatus"] ?? "";

        return ($rank[task_priority($a, $status)] ?? 9) <=> ($rank[task_priority($b, $status)] ?? 9);
    });

    foreach (array_slice($activeTasks, 0, 2) as $task) {
        $title = $task["title"] ?? msg("Untitled Task", "Walang Pamagat na Task", "Untitled Task");
        $subject = $task["subject"] ?? msg("Unassigned Subject", "Walang Asignatura", "Unassigned Subject");
        $dueDate = $task["dueDate"] ?? "";
        $computedStatus = computed_task_status($task);
        $priority = task_priority($task, $latest["academicStatus"] ?? "");

        if ($computedStatus === "Overdue") {
            $guidance[] = msg("Handle " . $title . " in " . $subject . " today because it is overdue. Mark it done only after the requirement is completed.", "Asikasuhin ngayong araw ang " . $title . " sa " . $subject . " dahil overdue na ito. I-mark lamang na done kapag tapos na ang requirement.", "Handle " . $title . " in " . $subject . " today because overdue na. Mark it done only after the requirement is completed.");
        } elseif (in_array($priority, ["Critical", "High"], true)) {
            $guidance[] = msg("Prioritize " . $title . " in " . $subject . ($dueDate !== "" ? " before " . $dueDate : "") . ". Work on the first small step, then update its task status.", "Unahin ang " . $title . " sa " . $subject . ($dueDate !== "" ? " bago ang " . $dueDate : "") . ". Gawin muna ang unang maliit na hakbang, tapos i-update ang task status.", "Prioritize " . $title . " in " . $subject . ($dueDate !== "" ? " before " . $dueDate : "") . ". Work on the first small step, then update its task status.");
        }
    }

    if (!count($guidance)) {
        $guidance[] = msg("No urgent action is required. Continue regular monitoring and keep the task board updated.", "Walang urgent na aksyon sa ngayon. Ipagpatuloy ang regular monitoring at panatilihing updated ang task board.", "No urgent action is required. Continue regular monitoring and keep the task board updated.");
    }

    return array_values(array_unique(array_filter($guidance)));
}

function student_flag_details($latest, $workload, $taskSummary) {
    $details = [];

    if ($latest) {
        if (($latest["academicStatus"] ?? "") !== "Regular" && ($latest["academicStatus"] ?? "") !== "No Record") {
            $details[] = [
                "label" => $latest["academicStatus"],
                "basis" => "Grade = " . ($latest["computedGrade"] ?? "--"),
                "action" => grade_guidance_output($latest)
            ];
        }

        if (($latest["competencyStatus"] ?? "") !== "Mastered" && ($latest["competencyStatus"] ?? "") !== "No Record") {
            $details[] = [
                "label" => $latest["competencyStatus"],
                "basis" => "Competency Mastery = " . ($latest["competencyMastery"] ?? "--") . "%",
                "action" => competency_guidance_output($latest)
            ];
        }

        if (($latest["attendanceStatus"] ?? "") !== "Regular Attendance" && ($latest["attendanceStatus"] ?? "") !== "No Record") {
            $details[] = [
                "label" => $latest["attendanceStatus"],
                "basis" => "Absence Rate = " . ($latest["absenceRate"] ?? "--") . "%; Consecutive Absences = " . ($latest["consecutiveAbsences"] ?? "--"),
                "action" => attendance_guidance_output($latest)
            ];
        }

        if (($latest["requirementStatus"] ?? "") === "Incomplete Requirements") {
            $details[] = [
                "label" => $latest["requirementStatus"],
                "basis" => implode(", ", $latest["missingRequirements"] ?? []),
                "action" => requirement_guidance_output($latest)
            ];
        }

        if (($latest["trendStatus"] ?? "") === "Declining Performance Pattern") {
            $details[] = [
                "label" => $latest["trendStatus"],
                "basis" => "Recent computed records show a decline.",
                "action" => trend_guidance_output($latest)
            ];
        }
    }

    if (($workload["lingguhangBigatIndex"] ?? "Magaan") !== "Magaan") {
        $details[] = [
            "label" => $workload["lingguhangBigatIndex"] ?? "Magaan",
            "basis" => "Workload Ratio = " . ($workload["workloadRatio"] ?? 0),
            "action" => workload_guidance_output($workload)
        ];
    }

    if (($taskSummary["overdue"] ?? 0) > 0) {
        $details[] = [
            "label" => "Overdue Tasks",
            "basis" => ($taskSummary["overdue"] ?? 0) . " overdue task/s",
            "action" => msg("Complete overdue tasks before adding new workload.", "Tapusin muna ang overdue tasks bago magdagdag ng bagong gawain.", "Complete overdue tasks before adding new workload.")
        ];
    }

    return $details;
}
function schedule_duration_hours($schedule) {
    $start = strtotime($schedule["startTime"] ?? "");
    $end = strtotime($schedule["endTime"] ?? "");

    if (!$start || !$end || $end <= $start) {
        return 0;
    }

    return round(($end - $start) / 3600, 2);
}

function week_days() {
    return ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
}

function schedules_for_student($studentId) {
    $schedules = read_records_where("schedules", ["studentId" => $studentId], "created_at asc, id asc");

    usort($schedules, function($a, $b) {
        $days = array_flip(week_days());
        $aDay = $days[$a["day"] ?? "Monday"] ?? 9;
        $bDay = $days[$b["day"] ?? "Monday"] ?? 9;

        if ($aDay !== $bDay) {
            return $aDay <=> $bDay;
        }

        return strcmp($a["startTime"] ?? "", $b["startTime"] ?? "");
    });

    return $schedules;
}


function schedule_subjects_for_student($studentId) {
    $subjects = [];

    foreach (schedules_for_student($studentId) as $schedule) {
        $subject = trim((string)($schedule["subject"] ?? ""));

        if ($subject !== "") {
            $subjects[] = $subject;
        }
    }

    $subjects = array_values(array_unique($subjects));
    sort($subjects);

    return $subjects;
}

function save_schedule($studentId, $post) {
    $scheduleId = safe_text($post["scheduleId"] ?? "", 80);
    $subject = safe_text($post["subject"] ?? "", 100);
    $day = safe_text($post["day"] ?? "", 20);
    $startTime = safe_text($post["startTime"] ?? "", 20);
    $endTime = safe_text($post["endTime"] ?? "", 20);
    $room = safe_text($post["room"] ?? "", 80);
    $teacherName = safe_text($post["teacherName"] ?? "", 120);

    if ($subject === "" || $day === "" || $startTime === "" || $endTime === "") {
        return ["ok" => false, "message" => msg("Complete subject, day, start time, and end time.", "Kumpletuhin ang subject, araw, oras ng simula, at oras ng tapos.", "Complete subject, day, start time, and end time.")];
    }

    if (!in_array($day, week_days(), true)) {
        return ["ok" => false, "message" => msg("Select a valid day.", "Pumili ng wastong araw.", "Select a valid day.")];
    }

    if (!kaakbay_valid_time_value($startTime) || !kaakbay_valid_time_value($endTime)) {
        return ["ok" => false, "message" => msg("Enter valid start and end times.", "Maglagay ng wastong start at end times.", "Enter valid start and end times.")];
    }

    if (time_to_minutes($endTime) <= time_to_minutes($startTime)) {
        return ["ok" => false, "message" => msg("End time must be later than start time.", "Dapat mas huli ang end time kaysa start time.", "End time must be later than start time.")];
    }

    $existing = null;

    if ($scheduleId !== "") {
        $found = find_storage_record_by_id("schedules", $scheduleId);

        if (is_array($found) && ($found["studentId"] ?? "") === $studentId) {
            $existing = $found;
        }
    }

    $newStart = time_to_minutes($startTime);
    $newEnd = time_to_minutes($endTime);

    foreach (schedules_for_student($studentId) as $otherSchedule) {
        $otherId = (string)($otherSchedule["id"] ?? "");

        if ($scheduleId !== "" && $otherId === $scheduleId) {
            continue;
        }

        if (($otherSchedule["day"] ?? "") !== $day) {
            continue;
        }

        $otherStartTime = trim((string)($otherSchedule["startTime"] ?? ""));
        $otherEndTime = trim((string)($otherSchedule["endTime"] ?? ""));

        if (!kaakbay_valid_time_value($otherStartTime) || !kaakbay_valid_time_value($otherEndTime)) {
            continue;
        }

        $otherStart = time_to_minutes($otherStartTime);
        $otherEnd = time_to_minutes($otherEndTime);

        if ($newStart < $otherEnd && $newEnd > $otherStart) {
            return ["ok" => false, "message" => msg("This schedule overlaps an existing class on the same day.", "Nag-o-overlap ang schedule na ito sa kasalukuyang klase sa parehong araw.", "This schedule overlaps an existing class on the same day.")];
        }
    }

    $now = date("c");
    $id = $scheduleId !== "" ? $scheduleId : "sch-" . time() . "-" . bin2hex(random_bytes(3));

    $schedule = [
        "id" => $id,
        "studentId" => $studentId,
        "subject" => $subject,
        "day" => $day,
        "startTime" => $startTime,
        "endTime" => $endTime,
        "room" => $room,
        "teacherName" => $teacherName,
        "createdAt" => $existing["createdAt"] ?? $now,
        "updatedAt" => $now
    ];

    $saved = $existing !== null
        ? update_record_by_id("schedules", $schedule["id"], $schedule)
        : (bool)append_record("schedules", $schedule);

    if (!$saved) {
        return ["ok" => false, "message" => msg("Unable to save the schedule.", "Hindi ma-save ang iskedyul.", "Unable to save the schedule.")];
    }

    return ["ok" => true, "message" => msg("Schedule saved.", "Nai-save ang iskedyul.", "Schedule saved.")];
}


function delete_schedule($studentId, $scheduleId) {
    $schedule = find_storage_record_by_id("schedules", $scheduleId);

    if (!is_array($schedule) || ($schedule["studentId"] ?? "") !== $studentId) {
        return false;
    }

    return delete_record_by_id("schedules", $scheduleId);
}


function schedule_calendar_grid($studentId) {
    $grid = [];

    foreach (week_days() as $day) {
        $grid[$day] = [];
    }

    foreach (schedules_for_student($studentId) as $schedule) {
        $day = $schedule["day"] ?? "Monday";

        if (!isset($grid[$day])) {
            $grid[$day] = [];
        }

        $grid[$day][] = $schedule;
    }

    foreach ($grid as &$items) {
        usort($items, fn($a, $b) => strcmp($a["startTime"] ?? "", $b["startTime"] ?? ""));
    }

    unset($items);

    return $grid;
}

function monthly_subject_calendar($studentId) {
    $schedules = schedules_for_student($studentId);
    $start = strtotime(date("Y-m-01"));
    $end = strtotime(date("Y-m-t"));
    $days = [];

    for ($time = $start; $time <= $end; $time = strtotime("+1 day", $time)) {
        $dayName = date("l", $time);
        $date = date("Y-m-d", $time);
        $items = [];

        foreach ($schedules as $schedule) {
            if (($schedule["day"] ?? "") === $dayName) {
                $items[] = [
                    "subject" => $schedule["subject"] ?? "",
                    "startTime" => $schedule["startTime"] ?? "",
                    "endTime" => $schedule["endTime"] ?? "",
                    "time" => ($schedule["startTime"] ?? "") . " - " . ($schedule["endTime"] ?? ""),
                    "room" => $schedule["room"] ?? ""
                ];
            }
        }

        $days[] = [
            "date" => $date,
            "day" => substr($dayName, 0, 3),
            "items" => $items
        ];
    }

    return [
        "month" => date("F Y"),
        "days" => $days
    ];
}

function time_to_minutes($time) {
    $parts = explode(":", (string)$time);

    if (count($parts) < 2) {
        return 0;
    }

    return ((int)$parts[0] * 60) + (int)$parts[1];
}

function minutes_to_time_label($minutes) {
    $minutes = max(0, (int)$minutes);
    $hours = floor($minutes / 60);
    $mins = $minutes % 60;
    $ampm = $hours >= 12 ? "PM" : "AM";
    $displayHour = $hours % 12;

    if ($displayHour === 0) {
        $displayHour = 12;
    }

    return $displayHour . ":" . str_pad((string)$mins, 2, "0", STR_PAD_LEFT) . " " . $ampm;
}

function weekly_dates() {
    $monday = strtotime("monday this week");
    $days = [];

    foreach (week_days() as $index => $day) {
        $time = strtotime("+$index day", $monday);
        $days[] = [
            "day" => $day,
            "shortDay" => substr($day, 0, 3),
            "date" => date("Y-m-d", $time)
        ];
    }

    return $days;
}

function dynamic_weekly_study_calendar($studentId, $tasks, $latestBySubject = []) {
    $schedules = schedules_for_student($studentId);
    $days = [];
    $unscheduled = [];
    $weeklyDates = weekly_dates();
    $activeTasks = array_values(array_filter($tasks, function($task) {
        return ($task["status"] ?? "") !== "Completed";
    }));

    usort($activeTasks, function($a, $b) use ($latestBySubject) {
        $rank = ["Critical" => 1, "High" => 2, "Medium" => 3, "Low" => 4];
        $aStatus = $latestBySubject[$a["subject"] ?? ""]["academicStatus"] ?? "";
        $bStatus = $latestBySubject[$b["subject"] ?? ""]["academicStatus"] ?? "";
        $aPriority = task_priority($a, $aStatus);
        $bPriority = task_priority($b, $bStatus);

        if (($rank[$aPriority] ?? 9) !== ($rank[$bPriority] ?? 9)) {
            return ($rank[$aPriority] ?? 9) <=> ($rank[$bPriority] ?? 9);
        }

        return task_due_timestamp($a) <=> task_due_timestamp($b);
    });

    $taskMinutes = [];

    foreach ($activeTasks as $task) {
        $taskMinutes[$task["id"]] = max(30, (int)round(((float)($task["estimatedDuration"] ?? 1)) * 60));
    }

    foreach ($weeklyDates as $dayInfo) {
        $dayName = $dayInfo["day"];
        $classBlocks = [];
        $studyBlocks = [];

        foreach ($schedules as $schedule) {
            if (($schedule["day"] ?? "") !== $dayName) {
                continue;
            }

            $classBlocks[] = [
                "subject" => $schedule["subject"] ?? "",
                "room" => $schedule["room"] ?? "",
                "start" => time_to_minutes($schedule["startTime"] ?? "00:00"),
                "end" => time_to_minutes($schedule["endTime"] ?? "00:00"),
                "startLabel" => date("g:i A", strtotime($schedule["startTime"] ?? "00:00")),
                "endLabel" => date("g:i A", strtotime($schedule["endTime"] ?? "00:00"))
            ];
        }

        usort($classBlocks, fn($a, $b) => $a["start"] <=> $b["start"]);

        $studyStart = 18 * 60;
        $studyEnd = 21 * 60;
        $cursor = $studyStart;
        $dailyLimit = 180;
        $used = 0;

        foreach ($activeTasks as $task) {
            $taskId = $task["id"] ?? "";

            if (($taskMinutes[$taskId] ?? 0) <= 0) {
                continue;
            }

            $dueDate = $task["dueDate"] ?? "";
            $date = $dayInfo["date"];

            if ($dueDate !== "" && strtotime($date) > strtotime($dueDate)) {
                continue;
            }

            if ($used >= $dailyLimit || $cursor >= $studyEnd) {
                break;
            }

            $blockMinutes = min($taskMinutes[$taskId], 60, $dailyLimit - $used, $studyEnd - $cursor);

            if ($blockMinutes < 30) {
                continue;
            }

            $linkedStatus = $latestBySubject[$task["subject"] ?? ""]["academicStatus"] ?? "";
            $priority = task_priority($task, $linkedStatus);

            $studyBlocks[] = [
                "taskId" => $taskId,
                "title" => $task["title"] ?? "Untitled Task",
                "subject" => $task["subject"] ?? "Unassigned Subject",
                "priority" => $priority,
                "start" => $cursor,
                "end" => $cursor + $blockMinutes,
                "startLabel" => minutes_to_time_label($cursor),
                "endLabel" => minutes_to_time_label($cursor + $blockMinutes),
                "durationMinutes" => $blockMinutes,
                "reason" => $priority . " priority"
            ];

            $taskMinutes[$taskId] -= $blockMinutes;
            $cursor += $blockMinutes + 15;
            $used += $blockMinutes;
        }

        $days[] = [
            "day" => $dayName,
            "shortDay" => $dayInfo["shortDay"],
            "date" => $dayInfo["date"],
            "classBlocks" => $classBlocks,
            "studyBlocks" => $studyBlocks,
            "totalStudyMinutes" => array_sum(array_map(fn($block) => $block["durationMinutes"], $studyBlocks))
        ];
    }

    foreach ($activeTasks as $task) {
        $taskId = $task["id"] ?? "";

        if (($taskMinutes[$taskId] ?? 0) > 0) {
            $unscheduled[] = [
                "taskId" => $taskId,
                "title" => $task["title"] ?? "Untitled Task",
                "subject" => $task["subject"] ?? "Unassigned Subject",
                "dueDate" => $task["dueDate"] ?? "",
                "remainingMinutes" => $taskMinutes[$taskId]
            ];
        }
    }

    return [
        "days" => $days,
        "unscheduled" => $unscheduled
    ];
}

function dynamic_monthly_study_calendar($studentId, $tasks, $latestBySubject = []) {
    $start = strtotime(date("Y-m-01"));
    $end = strtotime(date("Y-m-t"));
    $days = [];

    for ($time = $start; $time <= $end; $time = strtotime("+1 day", $time)) {
        $date = date("Y-m-d", $time);
        $items = [];
        $score = 0;

        foreach ($tasks as $task) {
            if (($task["status"] ?? "") === "Completed") {
                continue;
            }

            if (($task["dueDate"] ?? "") === $date) {
                $linkedStatus = $latestBySubject[$task["subject"] ?? ""]["academicStatus"] ?? "";
                $priority = task_priority($task, $linkedStatus);
                $taskScore = adjusted_task_score($task);
                $score += $taskScore;

                $items[] = [
                    "title" => $task["title"] ?? "Untitled Task",
                    "subject" => $task["subject"] ?? "Unassigned Subject",
                    "priority" => $priority,
                    "score" => $taskScore
                ];
            }
        }

        $days[] = [
            "date" => $date,
            "day" => substr(date("D", $time), 0, 3),
            "tasks" => $items,
            "score" => round($score, 2)
        ];
    }

    return [
        "month" => date("F Y"),
        "days" => $days
    ];
}

function all_students() {
    return read_records_where("users", ["role" => "student"], "created_at asc, id asc");
}


function student_visible_to_user($student, $viewer) {
    if (($viewer["role"] ?? "") === "admin") {
        return true;
    }

    if (($viewer["role"] ?? "") === "teacher") {
        $teacherId = $viewer["id"] ?? "";
        $managed = array_filter(array_map("trim", explode(",", $viewer["managedSections"] ?? "")));

        if (($student["teacherId"] ?? "") === $teacherId) {
            return true;
        }

        if (count($managed) && in_array($student["section"] ?? "", $managed, true)) {
            return true;
        }
    }

    return false;
}

function evaluated_student_rows($filters = []) {
    $students = all_students();
    $rows = [];

    foreach ($students as $student) {
        $records = academic_record_history_for_student($student["id"] ?? "");
        $tasks = tasks_for_student($student["id"] ?? "");
        $workload = workload_summary($records, $tasks, $student["id"] ?? "");
        $taskSummary = task_summary_for_student($student["id"] ?? "");
        $latest = null;

        foreach ($records as $record) {
            if (record_mode_value($record) === "quarterly") {
                $latest = evaluate_record($record, $tasks, $workload, $taskSummary);
                break;
            }
        }

        if (!$latest && count($records)) {
            $latest = evaluate_record($records[0], $tasks, $workload, $taskSummary);
        }

        $flags = [];

        if ($latest) {
            foreach ([
                $latest["academicStatus"] ?? "",
                $latest["competencyStatus"] ?? "",
                $latest["attendanceStatus"] ?? "",
                $latest["requirementStatus"] ?? "",
                $latest["trendStatus"] ?? ""
            ] as $status) {
                if (!in_array($status, ["", "No Record", "Regular", "Mastered", "Regular Attendance", "Complete Requirements", "Stable Performance Pattern", "Improving Performance Pattern", "Insufficient Trend Data"], true)) {
                    $flags[] = $status;
                }
            }
        }

        if (($workload["lingguhangBigatIndex"] ?? "Magaan") !== "Magaan") {
            $flags[] = $workload["lingguhangBigatIndex"];
        }

        $row = [
            "student" => $student,
            "latest" => $latest,
            "records" => $records,
            "tasks" => $tasks,
            "workload" => $workload,
            "taskSummary" => $taskSummary,
            "flags" => array_values(array_unique($flags)),
            "followUpType" => $latest ? follow_up_type_for_record($latest, $workload) : "No Record"
        ];

        if (($filters["gradeStatus"] ?? "") !== "" && (($latest["academicStatus"] ?? "") !== $filters["gradeStatus"])) {
            continue;
        }

        if (($filters["competencyStatus"] ?? "") !== "" && (($latest["competencyStatus"] ?? "") !== $filters["competencyStatus"])) {
            continue;
        }

        if (($filters["attendanceStatus"] ?? "") !== "" && (($latest["attendanceStatus"] ?? "") !== $filters["attendanceStatus"])) {
            continue;
        }

        if (($filters["workloadStatus"] ?? "") !== "" && (($workload["lingguhangBigatIndex"] ?? "") !== $filters["workloadStatus"])) {
            continue;
        }

        if (($filters["strand"] ?? "") !== "" && stripos($student["strand"] ?? "", $filters["strand"]) === false) {
            continue;
        }

        if (($filters["section"] ?? "") !== "" && stripos($student["section"] ?? "", $filters["section"]) === false) {
            continue;
        }

        if (($filters["subject"] ?? "") !== "" && stripos($latest["subject"] ?? "", $filters["subject"]) === false) {
            continue;
        }

        $rows[] = $row;
    }

    usort($rows, function($a, $b) {
        $rank = ["At-Risk" => 1, "Warning" => 2, "Regular" => 3];
        $aRisk = $a["latest"]["integratedRisk"] ?? "Regular";
        $bRisk = $b["latest"]["integratedRisk"] ?? "Regular";

        if (($rank[$aRisk] ?? 9) !== ($rank[$bRisk] ?? 9)) {
            return ($rank[$aRisk] ?? 9) <=> ($rank[$bRisk] ?? 9);
        }

        return strcmp($a["student"]["name"] ?? "", $b["student"]["name"] ?? "");
    });

    return $rows;
}

function monitoring_counts($rows) {
    $counts = [
        "total" => count($rows),
        "regular" => 0,
        "warning" => 0,
        "atRisk" => 0,
        "risk" => 0,
        "remediation" => 0,
        "attendanceConcern" => 0,
        "mabigat" => 0,
        "workloadHigh" => 0,
        "needsValidation" => 0,
        "incompleteRequirements" => 0,
        "decliningPattern" => 0
    ];

    foreach ($rows as $row) {
        $latest = $row["latest"] ?? [];
        $workload = $row["workload"] ?? [];
        $risk = $latest["integratedRisk"] ?? "Regular";

        if ($risk === "Regular") {
            $counts["regular"]++;
        }

        if ($risk === "Warning") {
            $counts["warning"]++;
        }

        if ($risk === "At-Risk") {
            $counts["atRisk"]++;
            $counts["risk"]++;
        }

        if (($latest["competencyStatus"] ?? "") === "Not Mastered / Remediation Needed" || ($latest["academicStatus"] ?? "") === "At-Risk / Failing") {
            $counts["remediation"]++;
        }

        if (($latest["attendanceStatus"] ?? "") === "Attendance Concern") {
            $counts["attendanceConcern"]++;
        }

        if (($workload["lingguhangBigatIndex"] ?? "") === "Mabigat") {
            $counts["mabigat"]++;
            $counts["workloadHigh"]++;
        }

        if (($latest["requirementStatus"] ?? "") === "Incomplete Requirements") {
            $counts["incompleteRequirements"]++;
            $counts["needsValidation"]++;
        }

        if (($latest["trendStatus"] ?? "") === "Declining Performance Pattern") {
            $counts["decliningPattern"]++;
        }

        if (count($row["flags"] ?? [])) {
            $counts["needsValidation"]++;
        }
    }

    return $counts;
}

function grouped_monitoring_summary($rows) {
    $groups = [];

    foreach ($rows as $row) {
        $student = $row["student"] ?? [];
        $label = trim(($student["strand"] ?? "Unassigned") . " · " . ($student["section"] ?? "Unassigned"));

        if (!isset($groups[$label])) {
            $groups[$label] = [
                "label" => $label,
                "students" => 0,
                "regular" => 0,
                "warning" => 0,
                "atRisk" => 0,
                "risk" => 0,
                "remediation" => 0,
                "attendanceConcern" => 0,
                "mabigat" => 0,
                "workloadHigh" => 0
            ];
        }

        $groups[$label]["students"]++;

        $latest = $row["latest"] ?? [];
        $workload = $row["workload"] ?? [];
        $risk = $latest["integratedRisk"] ?? "Regular";

        if ($risk === "Regular") {
            $groups[$label]["regular"]++;
        }

        if ($risk === "Warning") {
            $groups[$label]["warning"]++;
        }

        if ($risk === "At-Risk") {
            $groups[$label]["atRisk"]++;
            $groups[$label]["risk"]++;
        }

        if (($latest["academicStatus"] ?? "") === "At-Risk / Failing" || ($latest["competencyStatus"] ?? "") === "Not Mastered / Remediation Needed") {
            $groups[$label]["remediation"]++;
        }

        if (($latest["attendanceStatus"] ?? "") === "Attendance Concern") {
            $groups[$label]["attendanceConcern"]++;
        }

        if (($workload["lingguhangBigatIndex"] ?? "") === "Mabigat") {
            $groups[$label]["mabigat"]++;
            $groups[$label]["workloadHigh"]++;
        }
    }

    ksort($groups);

    return array_values($groups);
}
function validation_status_from_score_record($record) {
    $score = $record["score"] ?? "";
    $totalScore = $record["totalScore"] ?? "";
    $submissionStatus = requirement_status_value($record["submissionStatus"] ?? "Submitted");

    if ($submissionStatus === "Missing" || $submissionStatus === "Incomplete") {
        return "Needs Review";
    }

    if ($score === "" || $totalScore === "" || !is_numeric($score) || !is_numeric($totalScore)) {
        return "Needs Review";
    }

    $scoreValue = (float)$score;
    $totalValue = (float)$totalScore;

    if ($totalValue <= 0 || $scoreValue < 0 || $scoreValue > $totalValue) {
        return "Not Consistent";
    }

    $percentage = percent_score($scoreValue, $totalValue);

    return $percentage < 75 ? "Needs Review" : "Consistent";
}
function validation_status_from_system_output($systemOutput, $latest = null, $workload = null, $taskSummary = null) {
    $systemOutput = trim((string)$systemOutput);
    $latest = is_array($latest) ? $latest : [];
    $workload = is_array($workload) ? $workload : [];
    $taskSummary = is_array($taskSummary) ? $taskSummary : [];

    $academicStatus = $latest["academicStatus"] ?? "";
    $competencyStatus = $latest["competencyStatus"] ?? "";
    $attendanceStatus = $latest["attendanceStatus"] ?? "";
    $requirementStatus = $latest["requirementStatus"] ?? "";
    $trendStatus = $latest["trendStatus"] ?? "";
    $workloadStatus = $workload["lingguhangBigatIndex"] ?? "";
    $alertCount = (int)($taskSummary["alertCount"] ?? 0);

    $combined = strtolower(trim($systemOutput . " " . $academicStatus . " " . $competencyStatus . " " . $attendanceStatus . " " . $requirementStatus . " " . $trendStatus . " " . $workloadStatus));

    if ($systemOutput === "" || text_has($combined, "no record")) {
        return "Needs Review";
    }

    if (
        text_has($combined, "at-risk") ||
        text_has($combined, "failing") ||
        text_has($combined, "warning") ||
        text_has($combined, "not mastered") ||
        text_has($combined, "remediation") ||
        text_has($combined, "attendance concern") ||
        text_has($combined, "incomplete") ||
        text_has($combined, "missing") ||
        text_has($combined, "declining") ||
        text_has($combined, "mabigat") ||
        text_has($combined, "needs review") ||
        $alertCount > 0
    ) {
        return "Needs Review";
    }

    return "Consistent";
}

function validation_rule_basis($status) {
    if ($status === "Not Consistent") {
        return msg("The encoded values contain an invalid or conflicting score condition.", "May hindi tugma o mali sa na-encode na score condition.", "The encoded values contain an invalid or conflicting score condition.");
    }

    if ($status === "Needs Review") {
        return msg("The rule-based system detected a low score, low competency result, academic concern, attendance concern, requirement issue, trend concern, workload concern, missing entry, or incomplete condition that needs teacher review.", "May nakita ang rule-based system na mababang score, mababang competency result, academic concern, attendance concern, requirement issue, trend concern, workload concern, missing entry, o incomplete condition na kailangan ng teacher review.", "The rule-based system detected a low score, low competency result, academic concern, attendance concern, requirement issue, trend concern, workload concern, missing entry, or incomplete condition that needs teacher review.");
    }

    return msg("The encoded data and computed output are consistent with the rule-based checks.", "Tugma ang encoded data at computed output sa rule-based checks.", "The encoded data and computed output are consistent with the rule-based checks.");
}

function find_academic_record_for_validation($studentId, $recordId) {
    if ($studentId === "" || $recordId === "") {
        return null;
    }

    foreach (academic_record_history_for_student($studentId) as $record) {
        if (($record["id"] ?? "") === $recordId) {
            return evaluate_record($record);
        }
    }

    foreach (computed_quarterly_summaries_for_student($studentId) as $record) {
        if (($record["id"] ?? "") === $recordId) {
            return evaluate_record($record);
        }
    }

    return null;
}

function auto_validation_status_for_post($studentId, $recordId, $systemOutput) {
    $record = find_academic_record_for_validation($studentId, $recordId);

    if ($record) {
        if (record_mode_value($record) === "assessment") {
            return validation_status_from_score_record($record);
        }

        $tasks = tasks_for_student($studentId);
        $records = array_map(fn($item) => evaluate_record($item), records_for_student($studentId));
        $workload = workload_summary($records, $tasks, $studentId);
        $taskSummary = task_summary_for_student($studentId);
        return validation_status_from_system_output($systemOutput, $record, $workload, $taskSummary);
    }

    return validation_status_from_system_output($systemOutput);
}

function validation_summary_counts($validations) {
    $counts = [
        "total" => count($validations),
        "consistent" => 0,
        "needsReview" => 0,
        "notConsistent" => 0
    ];

    foreach ($validations as $validation) {
        $status = $validation["validationStatus"] ?? "";

        if ($status === "Consistent") {
            $counts["consistent"]++;
        }

        if ($status === "Needs Review") {
            $counts["needsReview"]++;
        }

        if ($status === "Not Consistent") {
            $counts["notConsistent"]++;
        }
    }

    return $counts;
}

function save_validation($teacherId, $post) {
    $studentId = safe_text($post["studentId"] ?? "", 80);
    $recordId = safe_text($post["recordId"] ?? "", 80);
    $subject = safe_text($post["subject"] ?? "", 100);
    $systemOutput = safe_text($post["systemOutput"] ?? "", 500);
    $note = safe_text($post["note"] ?? "", 700);
    $itemAnalysisNotes = safe_text($post["itemAnalysisNotes"] ?? "", 700);
    $competencyArea = safe_text($post["competencyArea"] ?? "", 150);
    $followUpPlan = safe_text($post["followUpPlan"] ?? "", 700);

    if ($studentId === "" || $subject === "" || $systemOutput === "") {
        return ["ok" => false, "message" => msg("Complete the validation fields.", "Kumpletuhin ang validation fields.", "Complete the validation fields.")];
    }

    $validationStatus = auto_validation_status_for_post($studentId, $recordId, $systemOutput);
    $ruleBasis = validation_rule_basis($validationStatus);

    append_record("validations", [
        "id" => "val-" . time() . "-" . bin2hex(random_bytes(3)),
        "teacherId" => $teacherId,
        "studentId" => $studentId,
        "recordId" => $recordId,
        "subject" => $subject,
        "systemOutput" => $systemOutput,
        "validationStatus" => $validationStatus,
        "ruleBasis" => $ruleBasis,
        "note" => $note,
        "itemAnalysisNotes" => $itemAnalysisNotes,
        "competencyArea" => $competencyArea,
        "followUpPlan" => $followUpPlan,
        "createdAt" => date("c")
    ]);

    return ["ok" => true, "message" => msg("Review saved with system-determined validation status.", "Nai-save ang review gamit ang system-determined validation status.", "Review saved with system-determined validation status.")];
}

function app_roles() {
    return ["student", "teacher", "admin", "super_admin", "it_admin"];
}

function administrative_roles() {
    return ["admin", "super_admin", "it_admin"];
}

function role_is_super_admin($role) {
    return strtolower((string)$role) === "super_admin";
}

function role_is_it_admin($role) {
    return strtolower((string)$role) === "it_admin";
}

function role_can_manage_content($role) {
    return role_is_super_admin($role);
}

function role_can_manage_technical_system($role) {
    return role_is_it_admin($role);
}

function user_has_any_role($userId, $roles) {
    $user = find_user_by_id((string)$userId);
    $roles = is_array($roles) ? $roles : [$roles];

    return $user
        && ($user["status"] ?? "Active") === "Active"
        && in_array($user["role"] ?? "", $roles, true);
}

function user_code_prefix($role) {
    $role = strtolower((string)$role);

    if ($role === "super_admin") {
        return "SAD";
    }

    if ($role === "it_admin") {
        return "ITA";
    }

    if ($role === "admin") {
        return "ADM";
    }

    if ($role === "teacher") {
        return "TEA";
    }

    return "STU";
}

function next_user_code($role) {
    $prefix = user_code_prefix($role);
    $max = 0;

    foreach (read_records("users") as $user) {
        $code = $user["code"] ?? "";

        if (strpos($code, $prefix . "-") === 0) {
            $number = (int)substr($code, strlen($prefix) + 1);
            $max = max($max, $number);
        }
    }

    return $prefix . "-" . str_pad((string)($max + 1), 3, "0", STR_PAD_LEFT);
}

function email_exists($email, $ignoreId = "") {
    foreach (read_records("users") as $user) {
        if (($user["id"] ?? "") !== $ignoreId && strtolower($user["email"] ?? "") === strtolower($email)) {
            return true;
        }
    }

    return false;
}

function find_user_by_email($email) {
    $email = strtolower(trim((string)$email));

    if ($email === "" || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return null;
    }

    foreach (read_records("users") as $user) {
        if (strtolower(trim((string)($user["email"] ?? ""))) === $email) {
            return $user;
        }
    }

    return null;
}

function mask_email_address($email) {
    $email = strtolower(trim((string)$email));

    if ($email === "" || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return "";
    }

    [$local, $domain] = explode("@", $email, 2);
    $localLength = function_exists("mb_strlen") ? mb_strlen($local, "UTF-8") : strlen($local);

    if ($localLength <= 1) {
        $maskedLocal = "*";
    } elseif ($localLength === 2) {
        $maskedLocal = substr($local, 0, 1) . "*";
    } else {
        $maskedLocal = substr($local, 0, 1) . str_repeat("*", max(3, $localLength - 2)) . substr($local, -1);
    }

    return $maskedLocal . "@" . $domain;
}

function recovery_email_verification_expiry_minutes() {
    $settings = function_exists("technical_settings_record")
        ? technical_settings_record()
        : [];

    return max(5, min(120, (int)($settings["emailVerificationExpiryMinutes"] ?? 15)));
}

function recovery_email_status($userOrId) {
    $user = is_array($userOrId) ? $userOrId : find_user_by_id((string)$userOrId);

    if (!$user) {
        return [
            "configured" => false,
            "verified" => false,
            "email" => "",
            "maskedEmail" => "",
            "pendingEmail" => "",
            "maskedPendingEmail" => "",
            "verifiedAt" => ""
        ];
    }

    $recoveryEmail = strtolower(trim((string)($user["recoveryEmail"] ?? "")));
    $verified = $recoveryEmail !== ""
        && filter_var($recoveryEmail, FILTER_VALIDATE_EMAIL)
        && !empty($user["recoveryEmailVerified"]);

    $pendingEmail = strtolower(trim((string)($user["pendingRecoveryEmail"] ?? "")));

    return [
        "configured" => $recoveryEmail !== "",
        "verified" => $verified,
        "email" => $verified ? $recoveryEmail : "",
        "maskedEmail" => $verified ? mask_email_address($recoveryEmail) : "",
        "pendingEmail" => $pendingEmail,
        "maskedPendingEmail" => $pendingEmail !== "" ? mask_email_address($pendingEmail) : "",
        "verifiedAt" => $verified ? (string)($user["recoveryEmailVerifiedAt"] ?? "") : ""
    ];
}

function verified_recovery_email($userOrId) {
    $status = recovery_email_status($userOrId);
    return $status["verified"] ? $status["email"] : "";
}

function security_password_policy() {
    $settings = function_exists("technical_settings_record")
        ? technical_settings_record()
        : [];

    return [
        "minLength" => max(8, min(64, (int)($settings["minPasswordLength"] ?? 8))),
        "maxLength" => 128,
        "requireUppercase" => array_key_exists("passwordRequireUppercase", $settings) ? system_bool_value($settings["passwordRequireUppercase"]) : true,
        "requireLowercase" => array_key_exists("passwordRequireLowercase", $settings) ? system_bool_value($settings["passwordRequireLowercase"]) : true,
        "requireNumber" => array_key_exists("passwordRequireNumber", $settings) ? system_bool_value($settings["passwordRequireNumber"]) : true,
        "requireSpecial" => array_key_exists("passwordRequireSpecial", $settings) ? system_bool_value($settings["passwordRequireSpecial"]) : true
    ];
}

function password_policy_errors($password, $user = null) {
    $password = (string)$password;
    $policy = security_password_policy();
    $errors = [];
    $length = function_exists("mb_strlen") ? mb_strlen($password, "UTF-8") : strlen($password);

    if ($length < $policy["minLength"]) {
        $errors[] = "Password must be at least " . $policy["minLength"] . " characters.";
    }

    if ($length > $policy["maxLength"]) {
        $errors[] = "Password must not exceed " . $policy["maxLength"] . " characters.";
    }

    if ($policy["requireUppercase"] && !preg_match('/[A-Z]/', $password)) {
        $errors[] = "Password must include an uppercase letter.";
    }

    if ($policy["requireLowercase"] && !preg_match('/[a-z]/', $password)) {
        $errors[] = "Password must include a lowercase letter.";
    }

    if ($policy["requireNumber"] && !preg_match('/[0-9]/', $password)) {
        $errors[] = "Password must include a number.";
    }

    if ($policy["requireSpecial"] && !preg_match('/[^A-Za-z0-9]/', $password)) {
        $errors[] = "Password must include a special character.";
    }

    if (preg_match('/\s/', $password)) {
        $errors[] = "Password must not contain spaces.";
    }

    $lower = strtolower($password);
    $common = [
        "password",
        "password123",
        "password1234",
        "qwerty123",
        "admin123",
        "kaakbay123"
    ];

    if (in_array($lower, $common, true)) {
        $errors[] = "Choose a less predictable password.";
    }

    if (is_array($user)) {
        $fragments = [
            strtolower(trim((string)($user["name"] ?? ""))),
            strtolower(trim((string)($user["email"] ?? ""))),
            strtolower(trim((string)($user["code"] ?? "")))
        ];

        foreach ($fragments as $fragment) {
            if ($fragment === "") {
                continue;
            }

            $fragment = preg_replace('/[^a-z0-9]/', '', $fragment);

            if (strlen($fragment) >= 4 && strpos(preg_replace('/[^a-z0-9]/', '', $lower), $fragment) !== false) {
                $errors[] = "Password must not contain easily guessed account information.";
                break;
            }
        }
    }

    return array_values(array_unique($errors));
}

function password_meets_policy($password, $user = null) {
    return count(password_policy_errors($password, $user)) === 0;
}

function password_policy_message($password, $user = null) {
    $errors = password_policy_errors($password, $user);

    if (!count($errors)) {
        return "";
    }

    return implode(" ", $errors);
}

function generate_temporary_password($length = 16) {
    $length = max(12, min(64, (int)$length));
    $upper = "ABCDEFGHJKLMNPQRSTUVWXYZ";
    $lower = "abcdefghijkmnopqrstuvwxyz";
    $numbers = "23456789";
    $special = "!@#$%&*_-+=";
    $all = $upper . $lower . $numbers . $special;

    $chars = [
        $upper[random_int(0, strlen($upper) - 1)],
        $lower[random_int(0, strlen($lower) - 1)],
        $numbers[random_int(0, strlen($numbers) - 1)],
        $special[random_int(0, strlen($special) - 1)]
    ];

    while (count($chars) < $length) {
        $chars[] = $all[random_int(0, strlen($all) - 1)];
    }

    for ($i = count($chars) - 1; $i > 0; $i--) {
        $j = random_int(0, $i);
        $tmp = $chars[$i];
        $chars[$i] = $chars[$j];
        $chars[$j] = $tmp;
    }

    return implode("", $chars);
}

function security_hash_secret($value) {
    return hash("sha256", (string)$value);
}

function security_random_token($bytes = 32) {
    $bytes = max(16, min(64, (int)$bytes));
    return bin2hex(random_bytes($bytes));
}

function security_expiry_iso($minutes = 15) {
    return date("c", time() + (max(1, (int)$minutes) * 60));
}

function security_expiry_valid($value) {
    $timestamp = strtotime((string)$value);
    return $timestamp !== false && $timestamp >= time();
}

function security_rate_limit_value($key, $default, $minimum, $maximum) {
    $settings = function_exists("technical_settings_record")
        ? technical_settings_record()
        : [];

    $value = isset($settings[$key]) ? (int)$settings[$key] : (int)$default;
    return max((int)$minimum, min((int)$maximum, $value));
}

function otp_resend_cooldown_seconds() {
    return security_rate_limit_value("otpResendCooldownSeconds", 60, 30, 300);
}

function otp_max_sends_per_hour() {
    return security_rate_limit_value("otpMaxSendsPerHour", 5, 3, 10);
}

function privileged_otp_max_failures() {
    return security_rate_limit_value("privilegedOtpMaxFailures", 5, 3, 10);
}

function privileged_otp_lockout_minutes() {
    return security_rate_limit_value("privilegedOtpLockoutMinutes", 15, 5, 60);
}

function password_reset_request_cooldown_seconds() {
    return security_rate_limit_value("passwordResetCooldownSeconds", 60, 30, 300);
}

function password_reset_max_requests_per_hour() {
    return security_rate_limit_value("passwordResetMaxRequestsPerHour", 5, 3, 10);
}

function recovery_verification_request_cooldown_seconds() {
    return security_rate_limit_value("recoveryVerificationCooldownSeconds", 60, 30, 300);
}

function recovery_verification_max_requests_per_hour() {
    return security_rate_limit_value("recoveryVerificationMaxRequestsPerHour", 5, 3, 10);
}

function password_change_otp_max_failures() {
    return security_rate_limit_value("passwordChangeOtpMaxFailures", 5, 3, 10);
}

function password_change_otp_lockout_minutes() {
    return security_rate_limit_value("passwordChangeOtpLockoutMinutes", 15, 5, 60);
}

function password_change_otp_expiry_minutes() {
    $settings = function_exists("technical_settings_record")
        ? technical_settings_record()
        : [];

    return max(5, min(60, (int)($settings["otpExpiryMinutes"] ?? 15)));
}

function password_change_challenge_ttl_seconds() {
    return 1800;
}

function password_change_verification_ttl_seconds() {
    return 600;
}

function security_rate_limit_state($record, $lastField, $windowField, $countField, $cooldownSeconds, $maxRequests, $windowSeconds = 3600) {
    $record = is_array($record) ? $record : [];
    $now = time();
    $cooldownSeconds = max(1, (int)$cooldownSeconds);
    $maxRequests = max(1, (int)$maxRequests);
    $windowSeconds = max($cooldownSeconds, (int)$windowSeconds);
    $windowStart = strtotime((string)($record[$windowField] ?? ""));
    $lastAt = strtotime((string)($record[$lastField] ?? ""));
    $count = max(0, (int)($record[$countField] ?? 0));

    if (!$windowStart || ($now - $windowStart) >= $windowSeconds) {
        $windowStart = $now;
        $count = 0;
    }

    $cooldownRemaining = $lastAt && $lastAt <= $now
        ? max(0, $cooldownSeconds - ($now - $lastAt))
        : 0;
    $windowRemaining = max(0, ($windowStart + $windowSeconds) - $now);
    $limitRemaining = $count >= $maxRequests ? $windowRemaining : 0;
    $retryAfter = max($cooldownRemaining, $limitRemaining);

    return [
        "allowed" => $retryAfter <= 0,
        "retryAfter" => max(0, (int)$retryAfter),
        "count" => $count,
        "remaining" => max(0, $maxRequests - $count),
        "windowStartedAt" => date("c", $windowStart),
        "windowEndsAt" => date("c", $windowStart + $windowSeconds),
        "lastRequestedAt" => $lastAt ? date("c", $lastAt) : ""
    ];
}

function security_rate_limit_consume(&$record, $lastField, $windowField, $countField, $cooldownSeconds, $maxRequests, $windowSeconds = 3600) {
    $record = is_array($record) ? $record : [];
    $state = security_rate_limit_state(
        $record,
        $lastField,
        $windowField,
        $countField,
        $cooldownSeconds,
        $maxRequests,
        $windowSeconds
    );

    if (empty($state["allowed"])) {
        return $state;
    }

    $now = time();
    $windowStartedAt = strtotime((string)$state["windowStartedAt"]);
    $windowStartedAt = $windowStartedAt ?: $now;
    $count = max(0, (int)$state["count"]) + 1;

    $record[$lastField] = date("c", $now);
    $record[$windowField] = date("c", $windowStartedAt);
    $record[$countField] = $count;

    return [
        "allowed" => true,
        "retryAfter" => 0,
        "count" => $count,
        "remaining" => max(0, (int)$maxRequests - $count),
        "windowStartedAt" => $record[$windowField],
        "windowEndsAt" => date("c", $windowStartedAt + max((int)$windowSeconds, (int)$cooldownSeconds)),
        "lastRequestedAt" => $record[$lastField]
    ];
}

function security_session_rate_limit_consume($bucket, $subject, $cooldownSeconds, $maxRequests, $windowSeconds = 3600) {
    $bucket = preg_replace('/[^A-Za-z0-9_.-]/', '', (string)$bucket);
    $subjectHash = hash("sha256", strtolower(trim((string)$subject)));

    if ($bucket === "") {
        $bucket = "general";
    }

    if (!isset($_SESSION["security_request_limits"]) || !is_array($_SESSION["security_request_limits"])) {
        $_SESSION["security_request_limits"] = [];
    }

    if (!isset($_SESSION["security_request_limits"][$bucket]) || !is_array($_SESSION["security_request_limits"][$bucket])) {
        $_SESSION["security_request_limits"][$bucket] = [];
    }

    $record = $_SESSION["security_request_limits"][$bucket][$subjectHash] ?? [];
    $state = security_rate_limit_consume(
        $record,
        "lastRequestedAt",
        "windowStartedAt",
        "requestCount",
        $cooldownSeconds,
        $maxRequests,
        $windowSeconds
    );

    $_SESSION["security_request_limits"][$bucket][$subjectHash] = $record;
    return $state;
}

function security_retry_text($seconds) {
    $seconds = max(1, (int)$seconds);

    if ($seconds >= 60) {
        $minutes = (int)ceil($seconds / 60);
        return $minutes . " minute" . ($minutes === 1 ? "" : "s");
    }

    return $seconds . " second" . ($seconds === 1 ? "" : "s");
}

function privileged_otp_security_state($userOrId) {
    $user = is_array($userOrId) ? $userOrId : find_user_by_id((string)$userOrId);

    if (!$user || !privileged_role_requires_otp($user["role"] ?? "")) {
        return [
            "tracked" => false,
            "locked" => false,
            "failedAttempts" => 0,
            "remainingAttempts" => 0,
            "lockoutUntil" => "",
            "secondsRemaining" => 0,
            "sendCount" => 0,
            "sendRemaining" => 0,
            "sendRetryAfter" => 0
        ];
    }

    $now = time();
    $maxFailures = privileged_otp_max_failures();
    $failed = max(0, (int)($user["privilegedOtpFailedAttempts"] ?? 0));
    $lockoutUntil = trim((string)($user["privilegedOtpLockoutUntil"] ?? ""));
    $lockoutTime = $lockoutUntil !== "" ? strtotime($lockoutUntil) : false;
    $secondsRemaining = $lockoutTime && $lockoutTime > $now ? $lockoutTime - $now : 0;
    $sendState = security_rate_limit_state(
        $user,
        "otpSendLastAt",
        "otpSendWindowStartedAt",
        "otpSendCount",
        otp_resend_cooldown_seconds(),
        otp_max_sends_per_hour(),
        3600
    );

    return [
        "tracked" => true,
        "locked" => $secondsRemaining > 0,
        "failedAttempts" => $failed,
        "remainingAttempts" => max(0, $maxFailures - $failed),
        "lockoutUntil" => $secondsRemaining > 0 ? $lockoutUntil : "",
        "secondsRemaining" => max(0, (int)$secondsRemaining),
        "sendCount" => max(0, (int)$sendState["count"]),
        "sendRemaining" => max(0, (int)$sendState["remaining"]),
        "sendRetryAfter" => max(0, (int)$sendState["retryAfter"])
    ];
}


function password_change_clear_account_state(&$user, $clearRateLimits = false, $clearFailureState = false) {
    if (!is_array($user)) {
        return;
    }

    $user["passwordChangeChallengeHash"] = "";
    $user["passwordChangeChallengeExpiresAt"] = "";
    $user["passwordChangeOtpHash"] = "";
    $user["passwordChangeOtpExpiresAt"] = "";
    $user["passwordChangeOtpAttempts"] = 0;
    $user["passwordChangeOtpCreatedAt"] = "";
    $user["passwordChangeOtpUsedAt"] = "";

    if ($clearRateLimits) {
        $user["passwordChangeOtpSendLastAt"] = "";
        $user["passwordChangeOtpSendWindowStartedAt"] = "";
        $user["passwordChangeOtpSendCount"] = 0;
    }

    if ($clearFailureState) {
        $user["passwordChangeOtpFailedAttempts"] = 0;
        $user["passwordChangeOtpFailureWindowStartedAt"] = "";
        $user["passwordChangeOtpLockoutUntil"] = "";
    }
}

function password_change_clear_session_state($userId = "") {
    $userId = trim((string)$userId);

    foreach (["pendingPasswordChange", "verifiedPasswordChange"] as $key) {
        if (!isset($_SESSION[$key]) || !is_array($_SESSION[$key])) {
            continue;
        }

        if ($userId === "" || (string)($_SESSION[$key]["userId"] ?? "") === $userId) {
            unset($_SESSION[$key]);
        }
    }
}

function password_change_session_binding() {
    $token = trim((string)($_SESSION["active_session_token"] ?? ""));

    if ($token === "") {
        return "";
    }

    return security_hash_secret($token);
}

function password_change_full_user($userOrId) {
    if (is_array($userOrId)) {
        $id = trim((string)($userOrId["id"] ?? ""));

        if ($id !== "") {
            $stored = find_user_by_id($id);

            if ($stored) {
                return $stored;
            }
        }

        return $userOrId;
    }

    return find_user_by_id((string)$userOrId);
}

function password_change_bootstrap_bypass_for_user($userOrId) {
    $user = password_change_full_user($userOrId);

    if (!$user || ($user["status"] ?? "Active") !== "Active") {
        return false;
    }

    $role = strtolower(trim((string)($user["role"] ?? "")));

    if (!in_array($role, app_roles(), true)) {
        return false;
    }

    return !empty($user["mustChangePassword"]) || !empty($user["passwordTemporary"]);
}

function password_change_otp_required_for_user($userOrId) {
    $user = password_change_full_user($userOrId);

    if (!$user || ($user["status"] ?? "Active") !== "Active") {
        return false;
    }

    $role = strtolower(trim((string)($user["role"] ?? "")));

    if (!in_array($role, app_roles(), true)) {
        return false;
    }

    if (password_change_bootstrap_bypass_for_user($user)) {
        return false;
    }

    return true;
}

function password_change_pending_context($userId, $user = null) {
    $userId = trim((string)$userId);
    $user = $user ?: find_user_by_id($userId);
    $pending = $_SESSION["pendingPasswordChange"] ?? null;

    if (
        $userId === "" ||
        !$user ||
        !is_array($pending) ||
        (string)($pending["userId"] ?? "") !== $userId
    ) {
        return null;
    }

    $expiresAt = (int)($pending["expiresAt"] ?? 0);
    $sessionBinding = password_change_session_binding();
    $storedBinding = trim((string)($pending["sessionBinding"] ?? ""));
    $challenge = trim((string)($pending["challenge"] ?? ""));
    $storedChallengeHash = trim((string)($user["passwordChangeChallengeHash"] ?? ""));
    $passwordFingerprint = trim((string)($pending["passwordHashFingerprint"] ?? ""));
    $currentPasswordFingerprint = security_hash_secret((string)($user["passwordHash"] ?? ""));

    if (
        $expiresAt < time() ||
        $sessionBinding === "" ||
        $storedBinding === "" ||
        !hash_equals($storedBinding, $sessionBinding) ||
        $challenge === "" ||
        $storedChallengeHash === "" ||
        !hash_equals($storedChallengeHash, security_hash_secret($challenge)) ||
        !security_expiry_valid($user["passwordChangeChallengeExpiresAt"] ?? "") ||
        $passwordFingerprint === "" ||
        !hash_equals($passwordFingerprint, $currentPasswordFingerprint)
    ) {
        return null;
    }

    return $pending;
}

function password_change_verified_context($userId, $user = null) {
    $userId = trim((string)$userId);
    $user = $user ?: find_user_by_id($userId);
    $verified = $_SESSION["verifiedPasswordChange"] ?? null;

    if (
        $userId === "" ||
        !$user ||
        !is_array($verified) ||
        (string)($verified["userId"] ?? "") !== $userId
    ) {
        return null;
    }

    $expiresAt = (int)($verified["expiresAt"] ?? 0);
    $sessionBinding = password_change_session_binding();
    $storedBinding = trim((string)($verified["sessionBinding"] ?? ""));
    $challenge = trim((string)($verified["challenge"] ?? ""));
    $storedChallengeHash = trim((string)($user["passwordChangeChallengeHash"] ?? ""));
    $passwordFingerprint = trim((string)($verified["passwordHashFingerprint"] ?? ""));
    $currentPasswordFingerprint = security_hash_secret((string)($user["passwordHash"] ?? ""));

    if (
        $expiresAt < time() ||
        $sessionBinding === "" ||
        $storedBinding === "" ||
        !hash_equals($storedBinding, $sessionBinding) ||
        $challenge === "" ||
        $storedChallengeHash === "" ||
        !hash_equals($storedChallengeHash, security_hash_secret($challenge)) ||
        !security_expiry_valid($user["passwordChangeChallengeExpiresAt"] ?? "") ||
        empty($user["passwordChangeOtpUsedAt"]) ||
        $passwordFingerprint === "" ||
        !hash_equals($passwordFingerprint, $currentPasswordFingerprint)
    ) {
        return null;
    }

    return $verified;
}

function password_change_verification_valid($userId) {
    return password_change_verified_context($userId) !== null;
}

function password_change_otp_state($userOrId) {
    $user = password_change_full_user($userOrId);

    if (!$user) {
        return [
            "required" => false,
            "bootstrapBypass" => false,
            "recoveryAvailable" => false,
            "maskedRecoveryEmail" => "",
            "pending" => false,
            "verified" => false,
            "locked" => false,
            "failedAttempts" => 0,
            "remainingAttempts" => 0,
            "lockoutUntil" => "",
            "secondsRemaining" => 0,
            "sendCount" => 0,
            "sendRemaining" => 0,
            "sendRetryAfter" => 0,
            "otpExpiresAt" => "",
            "otpSecondsRemaining" => 0,
            "verificationSecondsRemaining" => 0
        ];
    }

    $userId = (string)($user["id"] ?? "");
    $required = password_change_otp_required_for_user($user);
    $bootstrapBypass = password_change_bootstrap_bypass_for_user($user);
    $recoveryEmail = verified_recovery_email($user);
    $now = time();
    $failureWindowStart = strtotime((string)($user["passwordChangeOtpFailureWindowStartedAt"] ?? ""));
    $failedAttempts = max(0, (int)($user["passwordChangeOtpFailedAttempts"] ?? 0));

    if (!$failureWindowStart || ($now - $failureWindowStart) > 1800) {
        $failedAttempts = 0;
    }

    $lockoutUntil = trim((string)($user["passwordChangeOtpLockoutUntil"] ?? ""));
    $lockoutTime = $lockoutUntil !== "" ? strtotime($lockoutUntil) : false;
    $secondsRemaining = $lockoutTime && $lockoutTime > $now ? $lockoutTime - $now : 0;
    $sendState = security_rate_limit_state(
        $user,
        "passwordChangeOtpSendLastAt",
        "passwordChangeOtpSendWindowStartedAt",
        "passwordChangeOtpSendCount",
        otp_resend_cooldown_seconds(),
        otp_max_sends_per_hour(),
        3600
    );
    $otpExpiresAt = trim((string)($user["passwordChangeOtpExpiresAt"] ?? ""));
    $otpExpiryTime = $otpExpiresAt !== "" ? strtotime($otpExpiresAt) : false;
    $otpSecondsRemaining = $otpExpiryTime && $otpExpiryTime > $now ? $otpExpiryTime - $now : 0;
    $verifiedContext = password_change_verified_context($userId, $user);
    $pendingContext = $verifiedContext ? null : password_change_pending_context($userId, $user);
    $verificationSecondsRemaining = $verifiedContext
        ? max(0, (int)($verifiedContext["expiresAt"] ?? 0) - $now)
        : 0;

    return [
        "required" => $required,
        "bootstrapBypass" => $bootstrapBypass,
        "recoveryAvailable" => $recoveryEmail !== "",
        "maskedRecoveryEmail" => $recoveryEmail !== "" ? mask_email_address($recoveryEmail) : "",
        "pending" => $pendingContext !== null,
        "verified" => $verifiedContext !== null,
        "locked" => $secondsRemaining > 0,
        "failedAttempts" => $failedAttempts,
        "remainingAttempts" => max(0, password_change_otp_max_failures() - $failedAttempts),
        "lockoutUntil" => $secondsRemaining > 0 ? $lockoutUntil : "",
        "secondsRemaining" => max(0, (int)$secondsRemaining),
        "sendCount" => max(0, (int)($sendState["count"] ?? 0)),
        "sendRemaining" => max(0, (int)($sendState["remaining"] ?? 0)),
        "sendRetryAfter" => max(0, (int)($sendState["retryAfter"] ?? 0)),
        "otpExpiresAt" => $otpSecondsRemaining > 0 ? $otpExpiresAt : "",
        "otpSecondsRemaining" => max(0, (int)$otpSecondsRemaining),
        "verificationSecondsRemaining" => $verificationSecondsRemaining
    ];
}

function begin_password_change_otp($userId, $currentPassword) {
    $userId = trim((string)$userId);
    $user = find_user_by_id($userId);

    if (!$user || ($user["status"] ?? "Active") !== "Active") {
        return ["ok" => false, "message" => msg("User account was not found.", "Hindi nakita ang user account.", "User account was not found.")];
    }

    if (!password_change_otp_required_for_user($user)) {
        return [
            "ok" => false,
            "otpRequired" => false,
            "bootstrapBypass" => password_change_bootstrap_bypass_for_user($user),
            "message" => msg(
                "OTP verification is not required for this password change.",
                "Hindi kailangan ang OTP verification para sa password change na ito.",
                "OTP verification is not required for this password change."
            )
        ];
    }

    if (!verify_current_password($userId, $currentPassword)) {
        audit_log($userId, "PASSWORD_CHANGE_VERIFICATION_FAILED", "Current password verification failed before password-change OTP issuance.", ["category" => "security"]);
        return ["ok" => false, "message" => msg("Current password is incorrect.", "Mali ang kasalukuyang password.", "Current password is incorrect.")];
    }

    $recoveryEmail = verified_recovery_email($user);

    if ($recoveryEmail === "") {
        audit_log($userId, "PASSWORD_CHANGE_OTP_UNAVAILABLE", "Password-change OTP could not be issued because no verified recovery email is configured.", ["category" => "security"]);
        return [
            "ok" => false,
            "recoveryRequired" => true,
            "message" => msg(
                "Verify a recovery email before changing your password.",
                "Mag-verify muna ng recovery email bago magpalit ng password.",
                "Verify a recovery email before changing your password."
            )
        ];
    }

    $sessionBinding = password_change_session_binding();

    if ($sessionBinding === "") {
        return ["ok" => false, "message" => msg("Your session could not be verified. Sign in again.", "Hindi ma-verify ang session. Mag-sign in muli.", "Your session could not be verified. Sign in again.")];
    }

    $lockoutUntil = strtotime((string)($user["passwordChangeOtpLockoutUntil"] ?? ""));

    if ($lockoutUntil && $lockoutUntil > time()) {
        $retryAfter = $lockoutUntil - time();
        password_change_clear_session_state($userId);
        audit_log($userId, "PASSWORD_CHANGE_OTP_BLOCKED", "Password-change OTP issuance was blocked during a temporary OTP lockout.", [
            "category" => "security",
            "retryAfter" => $retryAfter
        ]);

        return [
            "ok" => false,
            "locked" => true,
            "retryAfter" => $retryAfter,
            "message" => msg(
                "Too many incorrect verification codes were entered. Try again after " . security_retry_text($retryAfter) . ".",
                "Masyadong maraming maling verification code ang nailagay. Subukan muli pagkatapos ng " . security_retry_text($retryAfter) . ".",
                "Too many incorrect verification codes were entered. Try again after " . security_retry_text($retryAfter) . "."
            )
        ];
    }

    if ($lockoutUntil && $lockoutUntil <= time()) {
        $user["passwordChangeOtpFailedAttempts"] = 0;
        $user["passwordChangeOtpFailureWindowStartedAt"] = "";
        $user["passwordChangeOtpLockoutUntil"] = "";
    }

    $sendLimit = security_rate_limit_consume(
        $user,
        "passwordChangeOtpSendLastAt",
        "passwordChangeOtpSendWindowStartedAt",
        "passwordChangeOtpSendCount",
        otp_resend_cooldown_seconds(),
        otp_max_sends_per_hour(),
        3600
    );

    if (empty($sendLimit["allowed"])) {
        $retryAfter = (int)($sendLimit["retryAfter"] ?? 0);
        $user["updatedAt"] = date("c");
        update_record_by_id("users", $userId, $user);
        audit_log($userId, "PASSWORD_CHANGE_OTP_THROTTLED", "Password-change OTP issuance was throttled.", [
            "category" => "security",
            "retryAfter" => $retryAfter,
            "sendCount" => (int)($sendLimit["count"] ?? 0)
        ]);

        return [
            "ok" => false,
            "throttled" => true,
            "retryAfter" => $retryAfter,
            "message" => msg(
                "Please wait " . security_retry_text($retryAfter) . " before requesting another verification code.",
                "Maghintay ng " . security_retry_text($retryAfter) . " bago humiling ng panibagong verification code.",
                "Please wait " . security_retry_text($retryAfter) . " before requesting another verification code."
            )
        ];
    }

    $failureWindowStart = strtotime((string)($user["passwordChangeOtpFailureWindowStartedAt"] ?? ""));

    if (!$failureWindowStart || (time() - $failureWindowStart) > 1800) {
        $user["passwordChangeOtpFailedAttempts"] = 0;
        $user["passwordChangeOtpFailureWindowStartedAt"] = "";
    }

    $challenge = security_random_token(32);
    $otp = str_pad((string)random_int(0, 999999), 6, "0", STR_PAD_LEFT);
    $challengeExpiresAt = date("c", time() + password_change_challenge_ttl_seconds());
    $otpExpiresAt = security_expiry_iso(password_change_otp_expiry_minutes());

    $user["passwordChangeChallengeHash"] = security_hash_secret($challenge);
    $user["passwordChangeChallengeExpiresAt"] = $challengeExpiresAt;
    $user["passwordChangeOtpHash"] = security_hash_secret($otp);
    $user["passwordChangeOtpExpiresAt"] = $otpExpiresAt;
    $user["passwordChangeOtpAttempts"] = 0;
    $user["passwordChangeOtpCreatedAt"] = date("c");
    $user["passwordChangeOtpUsedAt"] = "";
    $user["updatedAt"] = date("c");

    if (!update_record_by_id("users", $userId, $user)) {
        return ["ok" => false, "message" => msg("Unable to create the verification code.", "Hindi makagawa ng verification code.", "Unable to create the verification code.")];
    }

    $_SESSION["pendingPasswordChange"] = [
        "userId" => $userId,
        "challenge" => $challenge,
        "sessionBinding" => $sessionBinding,
        "passwordHashFingerprint" => security_hash_secret((string)($user["passwordHash"] ?? "")),
        "startedAt" => time(),
        "expiresAt" => strtotime($challengeExpiresAt)
    ];
    unset($_SESSION["verifiedPasswordChange"]);

    audit_log($userId, "PASSWORD_CHANGE_OTP_REQUESTED", "Password-change OTP created for the verified recovery email.", [
        "category" => "security",
        "recoveryEmailHash" => hash("sha256", $recoveryEmail),
        "sendCount" => (int)($user["passwordChangeOtpSendCount"] ?? 0)
    ]);

    return [
        "ok" => true,
        "otpRequired" => true,
        "userId" => $userId,
        "email" => $recoveryEmail,
        "maskedEmail" => mask_email_address($recoveryEmail),
        "code" => $otp,
        "expiresAt" => $otpExpiresAt,
        "resendAfter" => otp_resend_cooldown_seconds(),
        "resendAvailableAt" => date("c", time() + otp_resend_cooldown_seconds())
    ];
}

function resend_password_change_otp($userId) {
    $userId = trim((string)$userId);
    $user = find_user_by_id($userId);

    if (!$user || ($user["status"] ?? "Active") !== "Active" || !password_change_otp_required_for_user($user)) {
        return ["ok" => false, "message" => msg("Password-change verification is unavailable.", "Hindi available ang password-change verification.", "Password-change verification is unavailable.")];
    }

    $pending = password_change_pending_context($userId, $user);

    if (!$pending) {
        password_change_clear_session_state($userId);
        return [
            "ok" => false,
            "restartRequired" => true,
            "message" => msg(
                "Password-change verification expired. Confirm your current password again.",
                "Expired na ang password-change verification. I-confirm muli ang current password.",
                "Password-change verification expired. Confirm your current password again."
            )
        ];
    }

    $recoveryEmail = verified_recovery_email($user);

    if ($recoveryEmail === "") {
        password_change_clear_session_state($userId);
        password_change_clear_account_state($user);
        $user["updatedAt"] = date("c");
        update_record_by_id("users", $userId, $user);

        return [
            "ok" => false,
            "recoveryRequired" => true,
            "message" => msg(
                "A verified recovery email is required to continue.",
                "Kailangan ng verified recovery email para magpatuloy.",
                "A verified recovery email is required to continue."
            )
        ];
    }

    $lockoutUntil = strtotime((string)($user["passwordChangeOtpLockoutUntil"] ?? ""));

    if ($lockoutUntil && $lockoutUntil > time()) {
        $retryAfter = $lockoutUntil - time();
        password_change_clear_session_state($userId);

        return [
            "ok" => false,
            "locked" => true,
            "retryAfter" => $retryAfter,
            "message" => msg(
                "Too many incorrect verification codes were entered. Try again after " . security_retry_text($retryAfter) . ".",
                "Masyadong maraming maling verification code ang nailagay. Subukan muli pagkatapos ng " . security_retry_text($retryAfter) . ".",
                "Too many incorrect verification codes were entered. Try again after " . security_retry_text($retryAfter) . "."
            )
        ];
    }

    if ($lockoutUntil && $lockoutUntil <= time()) {
        $user["passwordChangeOtpFailedAttempts"] = 0;
        $user["passwordChangeOtpFailureWindowStartedAt"] = "";
        $user["passwordChangeOtpLockoutUntil"] = "";
    }

    $sendLimit = security_rate_limit_consume(
        $user,
        "passwordChangeOtpSendLastAt",
        "passwordChangeOtpSendWindowStartedAt",
        "passwordChangeOtpSendCount",
        otp_resend_cooldown_seconds(),
        otp_max_sends_per_hour(),
        3600
    );

    if (empty($sendLimit["allowed"])) {
        $retryAfter = (int)($sendLimit["retryAfter"] ?? 0);
        $user["updatedAt"] = date("c");
        update_record_by_id("users", $userId, $user);
        audit_log($userId, "PASSWORD_CHANGE_OTP_THROTTLED", "Password-change OTP resend was throttled.", [
            "category" => "security",
            "retryAfter" => $retryAfter,
            "sendCount" => (int)($sendLimit["count"] ?? 0)
        ]);

        return [
            "ok" => false,
            "throttled" => true,
            "retryAfter" => $retryAfter,
            "message" => msg(
                "Please wait " . security_retry_text($retryAfter) . " before requesting another verification code.",
                "Maghintay ng " . security_retry_text($retryAfter) . " bago humiling ng panibagong verification code.",
                "Please wait " . security_retry_text($retryAfter) . " before requesting another verification code."
            )
        ];
    }

    $otp = str_pad((string)random_int(0, 999999), 6, "0", STR_PAD_LEFT);
    $otpExpiresAt = security_expiry_iso(password_change_otp_expiry_minutes());

    $user["passwordChangeOtpHash"] = security_hash_secret($otp);
    $user["passwordChangeOtpExpiresAt"] = $otpExpiresAt;
    $user["passwordChangeOtpAttempts"] = 0;
    $user["passwordChangeOtpCreatedAt"] = date("c");
    $user["passwordChangeOtpUsedAt"] = "";
    $user["updatedAt"] = date("c");

    if (!update_record_by_id("users", $userId, $user)) {
        return ["ok" => false, "message" => msg("Unable to resend the verification code.", "Hindi maipadala muli ang verification code.", "Unable to resend the verification code.")];
    }

    audit_log($userId, "PASSWORD_CHANGE_OTP_RESENT", "Password-change OTP was reissued to the verified recovery email.", [
        "category" => "security",
        "recoveryEmailHash" => hash("sha256", $recoveryEmail),
        "sendCount" => (int)($user["passwordChangeOtpSendCount"] ?? 0)
    ]);

    return [
        "ok" => true,
        "userId" => $userId,
        "email" => $recoveryEmail,
        "maskedEmail" => mask_email_address($recoveryEmail),
        "code" => $otp,
        "expiresAt" => $otpExpiresAt,
        "resendAfter" => otp_resend_cooldown_seconds(),
        "resendAvailableAt" => date("c", time() + otp_resend_cooldown_seconds())
    ];
}

function validate_password_change_otp($userId, $code) {
    $userId = trim((string)$userId);
    $code = preg_replace('/\D+/', '', (string)$code);
    $user = find_user_by_id($userId);

    if (!$user || ($user["status"] ?? "Active") !== "Active" || !password_change_otp_required_for_user($user)) {
        return ["ok" => false, "message" => msg("Password-change verification is unavailable.", "Hindi available ang password-change verification.", "Password-change verification is unavailable.")];
    }

    $pending = password_change_pending_context($userId, $user);

    if (!$pending) {
        password_change_clear_session_state($userId);
        return [
            "ok" => false,
            "restartRequired" => true,
            "message" => msg(
                "Password-change verification expired. Confirm your current password again.",
                "Expired na ang password-change verification. I-confirm muli ang current password.",
                "Password-change verification expired. Confirm your current password again."
            )
        ];
    }

    $lockoutUntil = strtotime((string)($user["passwordChangeOtpLockoutUntil"] ?? ""));

    if ($lockoutUntil && $lockoutUntil > time()) {
        $retryAfter = $lockoutUntil - time();
        password_change_clear_session_state($userId);

        return [
            "ok" => false,
            "locked" => true,
            "retryAfter" => $retryAfter,
            "message" => msg(
                "Too many incorrect verification codes were entered. Try again after " . security_retry_text($retryAfter) . ".",
                "Masyadong maraming maling verification code ang nailagay. Subukan muli pagkatapos ng " . security_retry_text($retryAfter) . ".",
                "Too many incorrect verification codes were entered. Try again after " . security_retry_text($retryAfter) . "."
            )
        ];
    }

    if ($lockoutUntil && $lockoutUntil <= time()) {
        $user["passwordChangeOtpFailedAttempts"] = 0;
        $user["passwordChangeOtpFailureWindowStartedAt"] = "";
        $user["passwordChangeOtpLockoutUntil"] = "";
    }

    $storedHash = trim((string)($user["passwordChangeOtpHash"] ?? ""));
    $attempts = max(0, (int)($user["passwordChangeOtpAttempts"] ?? 0));

    if (
        strlen($code) !== 6 ||
        $storedHash === "" ||
        !empty($user["passwordChangeOtpUsedAt"]) ||
        !security_expiry_valid($user["passwordChangeOtpExpiresAt"] ?? "")
    ) {
        audit_log($userId, "PASSWORD_CHANGE_OTP_REJECTED", "Expired or unavailable password-change verification code.", ["category" => "security"]);

        return [
            "ok" => false,
            "expired" => true,
            "message" => msg(
                "The verification code is invalid or expired. Request a new code.",
                "Invalid o expired na ang verification code. Humiling ng bagong code.",
                "The verification code is invalid or expired. Request a new code."
            )
        ];
    }

    if (!hash_equals($storedHash, security_hash_secret($code))) {
        $now = time();
        $failureWindowStart = strtotime((string)($user["passwordChangeOtpFailureWindowStartedAt"] ?? ""));

        if (!$failureWindowStart || ($now - $failureWindowStart) > 1800) {
            $user["passwordChangeOtpFailureWindowStartedAt"] = date("c", $now);
            $user["passwordChangeOtpFailedAttempts"] = 0;
        }

        $user["passwordChangeOtpAttempts"] = $attempts + 1;
        $user["passwordChangeOtpFailedAttempts"] = max(0, (int)($user["passwordChangeOtpFailedAttempts"] ?? 0)) + 1;
        $maxFailures = password_change_otp_max_failures();
        $remainingAttempts = max(0, $maxFailures - (int)$user["passwordChangeOtpFailedAttempts"]);

        if (
            $user["passwordChangeOtpAttempts"] >= $maxFailures ||
            $user["passwordChangeOtpFailedAttempts"] >= $maxFailures
        ) {
            $user["passwordChangeOtpLockoutUntil"] = date("c", time() + (password_change_otp_lockout_minutes() * 60));
            password_change_clear_account_state($user, false, false);
            $user["updatedAt"] = date("c");
            update_record_by_id("users", $userId, $user);
            password_change_clear_session_state($userId);

            audit_log($userId, "PASSWORD_CHANGE_OTP_LOCKED", "Maximum password-change OTP failures reached. The password-change challenge was cancelled.", [
                "category" => "security",
                "failedAttempts" => (int)($user["passwordChangeOtpFailedAttempts"] ?? $maxFailures),
                "lockoutMinutes" => password_change_otp_lockout_minutes()
            ]);

            return [
                "ok" => false,
                "locked" => true,
                "retryAfter" => password_change_otp_lockout_minutes() * 60,
                "remainingAttempts" => 0,
                "message" => msg(
                    "Too many incorrect verification codes were entered. Try again after " . password_change_otp_lockout_minutes() . " minutes.",
                    "Masyadong maraming maling verification code ang nailagay. Subukan muli pagkatapos ng " . password_change_otp_lockout_minutes() . " minuto.",
                    "Too many incorrect verification codes were entered. Try again after " . password_change_otp_lockout_minutes() . " minutes."
                )
            ];
        }

        $user["updatedAt"] = date("c");
        update_record_by_id("users", $userId, $user);

        audit_log($userId, "PASSWORD_CHANGE_OTP_FAILED", "Invalid password-change verification code.", [
            "category" => "security",
            "codeAttempt" => $user["passwordChangeOtpAttempts"],
            "cumulativeAttempt" => $user["passwordChangeOtpFailedAttempts"]
        ]);

        return [
            "ok" => false,
            "remainingAttempts" => $remainingAttempts,
            "message" => msg(
                "Incorrect verification code. " . $remainingAttempts . " attempt" . ($remainingAttempts === 1 ? "" : "s") . " remaining.",
                "Mali ang verification code. " . $remainingAttempts . " attempt" . ($remainingAttempts === 1 ? "" : "s") . " na lang.",
                "Incorrect verification code. " . $remainingAttempts . " attempt" . ($remainingAttempts === 1 ? "" : "s") . " remaining."
            )
        ];
    }

    $user["passwordChangeOtpHash"] = "";
    $user["passwordChangeOtpExpiresAt"] = "";
    $user["passwordChangeOtpAttempts"] = 0;
    $user["passwordChangeOtpUsedAt"] = date("c");
    $user["passwordChangeOtpFailedAttempts"] = 0;
    $user["passwordChangeOtpFailureWindowStartedAt"] = "";
    $user["passwordChangeOtpLockoutUntil"] = "";
    $user["updatedAt"] = date("c");

    if (!update_record_by_id("users", $userId, $user)) {
        return ["ok" => false, "message" => msg("Unable to verify the code.", "Hindi ma-verify ang code.", "Unable to verify the code.")];
    }

    $_SESSION["verifiedPasswordChange"] = [
        "userId" => $userId,
        "challenge" => (string)$pending["challenge"],
        "sessionBinding" => (string)$pending["sessionBinding"],
        "passwordHashFingerprint" => (string)$pending["passwordHashFingerprint"],
        "verifiedAt" => time(),
        "expiresAt" => time() + password_change_verification_ttl_seconds()
    ];
    unset($_SESSION["pendingPasswordChange"]);

    audit_log($userId, "PASSWORD_CHANGE_OTP_VERIFIED", "Password-change OTP accepted.", ["category" => "security"]);

    return [
        "ok" => true,
        "verified" => true,
        "expiresIn" => password_change_verification_ttl_seconds(),
        "message" => msg(
            "Verification successful. You can now set your new password.",
            "Matagumpay ang verification. Maaari mo nang ilagay ang bagong password.",
            "Verification successful. You can now set your new password."
        )
    ];
}

function cancel_password_change_otp($userId) {
    $userId = trim((string)$userId);
    $sessionUserId = trim((string)($_SESSION["user"]["id"] ?? ""));

    if ($userId === "" || $sessionUserId === "" || $sessionUserId !== $userId) {
        return false;
    }

    $user = find_user_by_id($userId);

    if (!$user) {
        password_change_clear_session_state($userId);
        return false;
    }

    password_change_clear_account_state($user, false, false);
    $user["updatedAt"] = date("c");
    $saved = update_record_by_id("users", $userId, $user);
    password_change_clear_session_state($userId);

    if ($saved) {
        audit_log($userId, "PASSWORD_CHANGE_OTP_CANCELLED", "Pending password-change verification was cancelled.", ["category" => "security"]);
    }

    return $saved;
}

function password_reset_expiry_minutes() {
    $settings = function_exists("technical_settings_record")
        ? technical_settings_record()
        : [];

    return max(5, min(120, (int)($settings["passwordResetExpiryMinutes"] ?? 15)));
}

function request_password_reset($email) {
    $email = strtolower(trim((string)$email));
    $genericMessage = msg(
        "If an active account matches that login email and has a verified recovery email, password recovery instructions can be sent.",
        "Kung may aktibong account na tumutugma sa login email at may verified recovery email, maaaring ipadala ang password recovery instructions.",
        "If may active account na matching that login email at may verified recovery email, password recovery instructions can be sent."
    );

    $sessionLimit = security_session_rate_limit_consume(
        "password_reset",
        $email !== "" ? $email : "invalid",
        password_reset_request_cooldown_seconds(),
        password_reset_max_requests_per_hour(),
        3600
    );

    if (empty($sessionLimit["allowed"])) {
        return [
            "ok" => true,
            "message" => $genericMessage,
            "found" => false,
            "recoveryAvailable" => false,
            "throttled" => true,
            "retryAfter" => (int)($sessionLimit["retryAfter"] ?? 0)
        ];
    }

    if ($email === "" || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return [
            "ok" => true,
            "message" => $genericMessage,
            "found" => false,
            "recoveryAvailable" => false
        ];
    }

    $user = find_user_by_email($email);

    if (!$user || ($user["status"] ?? "Active") !== "Active") {
        audit_log("", "PASSWORD_RESET_REQUEST", "Password reset was requested for an unavailable account.", ["category" => "security"]);
        return [
            "ok" => true,
            "message" => $genericMessage,
            "found" => false,
            "recoveryAvailable" => false
        ];
    }

    $userLimit = security_rate_limit_consume(
        $user,
        "passwordResetRateLastAt",
        "passwordResetRateWindowStartedAt",
        "passwordResetRateCount",
        password_reset_request_cooldown_seconds(),
        password_reset_max_requests_per_hour(),
        3600
    );

    if (empty($userLimit["allowed"])) {
        update_record_by_id("users", (string)$user["id"], $user);
        audit_log((string)$user["id"], "PASSWORD_RESET_THROTTLED", "Password reset request was throttled.", [
            "category" => "security",
            "retryAfter" => (int)($userLimit["retryAfter"] ?? 0)
        ]);

        return [
            "ok" => true,
            "message" => $genericMessage,
            "found" => true,
            "recoveryAvailable" => false,
            "throttled" => true,
            "retryAfter" => (int)($userLimit["retryAfter"] ?? 0)
        ];
    }

    $recoveryEmail = verified_recovery_email($user);

    if ($recoveryEmail === "") {
        $user["updatedAt"] = date("c");
        update_record_by_id("users", (string)$user["id"], $user);
        audit_log((string)$user["id"], "PASSWORD_RESET_UNAVAILABLE", "Password reset was requested but no verified recovery email is configured.", ["category" => "security"]);

        return [
            "ok" => true,
            "message" => $genericMessage,
            "found" => true,
            "recoveryAvailable" => false,
            "userId" => (string)$user["id"],
            "maskedRecoveryEmail" => ""
        ];
    }

    $token = security_random_token(32);
    $user["passwordResetTokenHash"] = security_hash_secret($token);
    $user["passwordResetExpiresAt"] = security_expiry_iso(password_reset_expiry_minutes());
    $user["passwordResetRequestedAt"] = date("c");
    $user["passwordResetUsedAt"] = "";
    $user["updatedAt"] = date("c");

    if (!update_record_by_id("users", (string)$user["id"], $user)) {
        return ["ok" => false, "message" => msg("Unable to prepare password recovery.", "Hindi maihanda ang password recovery.", "Unable to prepare password recovery.")];
    }

    audit_log((string)$user["id"], "PASSWORD_RESET_REQUESTED", "Password reset token created for the verified recovery email.", ["category" => "security"]);

    return [
        "ok" => true,
        "message" => $genericMessage,
        "found" => true,
        "recoveryAvailable" => true,
        "userId" => (string)$user["id"],
        "loginEmail" => (string)($user["email"] ?? ""),
        "email" => $recoveryEmail,
        "deliveryEmail" => $recoveryEmail,
        "maskedRecoveryEmail" => mask_email_address($recoveryEmail),
        "token" => $token,
        "expiresAt" => $user["passwordResetExpiresAt"]
    ];
}

function password_reset_user_for_token($token) {
    $token = trim((string)$token);

    if ($token === "") {
        return null;
    }

    $tokenHash = security_hash_secret($token);

    foreach (read_records("users") as $user) {
        $storedHash = trim((string)($user["passwordResetTokenHash"] ?? ""));

        if (
            $storedHash !== "" &&
            hash_equals($storedHash, $tokenHash) &&
            empty($user["passwordResetUsedAt"]) &&
            security_expiry_valid($user["passwordResetExpiresAt"] ?? "")
        ) {
            return $user;
        }
    }

    return null;
}

function validate_password_reset_token($token) {
    return password_reset_user_for_token($token) !== null;
}

function clear_password_reset_token($userId) {
    $user = find_user_by_id((string)$userId);

    if (!$user) {
        return false;
    }

    $user["passwordResetTokenHash"] = "";
    $user["passwordResetExpiresAt"] = "";
    $user["passwordResetUsedAt"] = date("c");
    $user["updatedAt"] = date("c");

    return update_record_by_id("users", (string)$userId, $user);
}

function reset_password_with_token($token, $newPassword, $confirmPassword) {
    $user = password_reset_user_for_token($token);

    if (!$user) {
        return ["ok" => false, "message" => msg("This password reset link is invalid or expired.", "Invalid o expired na ang password reset link.", "This password reset link is invalid or expired.")];
    }

    if ((string)$newPassword !== (string)$confirmPassword) {
        return ["ok" => false, "message" => msg("New passwords do not match.", "Hindi magkapareho ang bagong passwords.", "New passwords do not match.")];
    }

    if (password_verify((string)$newPassword, $user["passwordHash"] ?? "")) {
        return ["ok" => false, "message" => msg("New password must be different from the current password.", "Dapat iba ang bagong password sa kasalukuyang password.", "New password must be different from the current password.")];
    }

    $policyMessage = password_policy_message($newPassword, $user);

    if ($policyMessage !== "") {
        return ["ok" => false, "message" => $policyMessage];
    }

    $user["passwordHash"] = password_hash((string)$newPassword, PASSWORD_DEFAULT);
    $user["mustChangePassword"] = false;
    $user["passwordTemporary"] = false;
    $user["passwordChangedAt"] = date("c");
    $user["passwordResetTokenHash"] = "";
    $user["passwordResetExpiresAt"] = "";
    $user["passwordResetUsedAt"] = date("c");
    $user["failedLoginAttempts"] = 0;
    $user["lockoutUntil"] = "";
    password_change_clear_account_state($user, true, true);
    $user["activeSessionHash"] = security_hash_secret(security_random_token(32));
    $user["sessionInvalidationReason"] = "password_reset";
    $user["sessionVersion"] = max(1, (int)($user["sessionVersion"] ?? 1)) + 1;
    $user["updatedAt"] = date("c");

    if (!update_record_by_id("users", (string)$user["id"], $user)) {
        return ["ok" => false, "message" => msg("Unable to reset the password.", "Hindi ma-reset ang password.", "Unable to reset the password.")];
    }

    password_change_clear_session_state((string)$user["id"]);
    audit_log((string)$user["id"], "PASSWORD_RESET_COMPLETED", "Password reset completed and existing sessions were revoked.", ["category" => "security"]);

    return ["ok" => true, "message" => msg("Password reset successfully. You can now sign in.", "Matagumpay na na-reset ang password. Maaari ka nang mag-sign in.", "Password reset successfully. You can now sign in.")];
}

function privileged_role_requires_otp($role) {
    return in_array(strtolower((string)$role), ["admin", "super_admin", "it_admin"], true);
}

function login_otp_expiry_minutes() {
    $settings = function_exists("technical_settings_record")
        ? technical_settings_record()
        : [];

    return max(5, min(60, (int)($settings["otpExpiryMinutes"] ?? 15)));
}

function create_login_otp($userId, $purpose = "privileged_login") {
    $user = find_user_by_id((string)$userId);

    if (!$user || ($user["status"] ?? "Active") !== "Active") {
        return ["ok" => false, "message" => msg("Account is unavailable.", "Hindi available ang account.", "Account is unavailable.")];
    }

    $isPrivilegedLogin = $purpose === "privileged_login" && privileged_role_requires_otp($user["role"] ?? "");

    if ($purpose === "privileged_login" && !$isPrivilegedLogin) {
        return ["ok" => false, "message" => msg("OTP is not required for this account.", "Hindi kailangan ng OTP para sa account na ito.", "OTP is not required for this account.")];
    }

    if ($isPrivilegedLogin) {
        $lockoutUntil = strtotime((string)($user["privilegedOtpLockoutUntil"] ?? ""));

        if ($lockoutUntil && $lockoutUntil > time()) {
            unset($_SESSION["pendingPrivilegedLogin"]);
            $retryAfter = $lockoutUntil - time();
            audit_log((string)$user["id"], "PRIVILEGED_OTP_BLOCKED", "OTP issuance was blocked during a privileged OTP lockout.", [
                "category" => "security",
                "retryAfter" => $retryAfter
            ]);

            return [
                "ok" => false,
                "message" => msg(
                    "Too many incorrect authentication codes were entered. Sign in again after " . security_retry_text($retryAfter) . ".",
                    "Masyadong maraming maling authentication code ang nailagay. Mag-sign in muli pagkatapos ng " . security_retry_text($retryAfter) . ".",
                    "Too many incorrect authentication codes were entered. Sign in again after " . security_retry_text($retryAfter) . "."
                ),
                "locked" => true,
                "retryAfter" => $retryAfter
            ];
        }

        if ($lockoutUntil && $lockoutUntil <= time()) {
            $user["privilegedOtpFailedAttempts"] = 0;
            $user["privilegedOtpFailureWindowStartedAt"] = "";
            $user["privilegedOtpLockoutUntil"] = "";
        }

        $sendLimit = security_rate_limit_consume(
            $user,
            "otpSendLastAt",
            "otpSendWindowStartedAt",
            "otpSendCount",
            otp_resend_cooldown_seconds(),
            otp_max_sends_per_hour(),
            3600
        );

        if (empty($sendLimit["allowed"])) {
            $retryAfter = (int)($sendLimit["retryAfter"] ?? 0);
            audit_log((string)$user["id"], "OTP_RESEND_THROTTLED", "Privileged OTP issuance was throttled.", [
                "category" => "security",
                "purpose" => $purpose,
                "retryAfter" => $retryAfter,
                "sendCount" => (int)($sendLimit["count"] ?? 0)
            ]);

            return [
                "ok" => false,
                "message" => msg(
                    "Please wait " . security_retry_text($retryAfter) . " before requesting another authentication code.",
                    "Maghintay ng " . security_retry_text($retryAfter) . " bago humiling ng panibagong authentication code.",
                    "Please wait " . security_retry_text($retryAfter) . " before requesting another authentication code."
                ),
                "throttled" => true,
                "retryAfter" => $retryAfter
            ];
        }
    }

    $otp = str_pad((string)random_int(0, 999999), 6, "0", STR_PAD_LEFT);
    $user["otpHash"] = security_hash_secret($otp);
    $user["otpPurpose"] = safe_text($purpose, 80);
    $user["otpExpiresAt"] = security_expiry_iso(login_otp_expiry_minutes());
    $user["otpAttempts"] = 0;
    $user["otpCreatedAt"] = date("c");
    $user["otpUsedAt"] = "";
    $user["updatedAt"] = date("c");

    if (!update_record_by_id("users", (string)$user["id"], $user)) {
        return ["ok" => false, "message" => msg("Unable to create the verification code.", "Hindi makagawa ng verification code.", "Unable to create the verification code.")];
    }

    audit_log((string)$user["id"], "OTP_CREATED", "A one-time verification code was created.", [
        "category" => "security",
        "purpose" => $purpose,
        "sendCount" => $isPrivilegedLogin ? (int)($user["otpSendCount"] ?? 0) : 0
    ]);

    return [
        "ok" => true,
        "userId" => (string)$user["id"],
        "email" => (string)($user["email"] ?? ""),
        "code" => $otp,
        "expiresAt" => $user["otpExpiresAt"],
        "resendAfter" => $isPrivilegedLogin ? otp_resend_cooldown_seconds() : 0,
        "resendAvailableAt" => $isPrivilegedLogin ? date("c", time() + otp_resend_cooldown_seconds()) : ""
    ];
}

function validate_login_otp($userId, $code, $purpose = "privileged_login") {
    $user = find_user_by_id((string)$userId);

    if (!$user || ($user["status"] ?? "Active") !== "Active") {
        return false;
    }

    $isPrivilegedLogin = $purpose === "privileged_login" && privileged_role_requires_otp($user["role"] ?? "");

    if ($isPrivilegedLogin) {
        $lockoutUntil = strtotime((string)($user["privilegedOtpLockoutUntil"] ?? ""));

        if ($lockoutUntil && $lockoutUntil > time()) {
            unset($_SESSION["pendingPrivilegedLogin"]);
            audit_log((string)$userId, "PRIVILEGED_OTP_BLOCKED", "OTP verification was blocked during a privileged OTP lockout.", [
                "category" => "security",
                "retryAfter" => $lockoutUntil - time()
            ]);
            return false;
        }

        if ($lockoutUntil && $lockoutUntil <= time()) {
            $user["privilegedOtpFailedAttempts"] = 0;
            $user["privilegedOtpFailureWindowStartedAt"] = "";
            $user["privilegedOtpLockoutUntil"] = "";
        }
    }

    $storedHash = trim((string)($user["otpHash"] ?? ""));
    $storedPurpose = trim((string)($user["otpPurpose"] ?? ""));
    $attempts = max(0, (int)($user["otpAttempts"] ?? 0));

    if (
        $storedHash === "" ||
        $storedPurpose !== (string)$purpose ||
        !empty($user["otpUsedAt"]) ||
        !security_expiry_valid($user["otpExpiresAt"] ?? "")
    ) {
        audit_log((string)$userId, "OTP_REJECTED", "Expired or unavailable one-time verification code.", ["category" => "security", "purpose" => $purpose]);
        return false;
    }

    if (!$isPrivilegedLogin && $attempts >= 5) {
        audit_log((string)$userId, "OTP_BLOCKED", "Maximum OTP verification attempts reached.", ["category" => "security", "purpose" => $purpose]);
        return false;
    }

    if (!hash_equals($storedHash, security_hash_secret(trim((string)$code)))) {
        $user["otpAttempts"] = $attempts + 1;
        $metadata = [
            "category" => "security",
            "purpose" => $purpose,
            "codeAttempt" => $user["otpAttempts"]
        ];

        if ($isPrivilegedLogin) {
            $windowStart = strtotime((string)($user["privilegedOtpFailureWindowStartedAt"] ?? ""));

            if (!$windowStart || (time() - $windowStart) > 1800) {
                $windowStart = time();
                $user["privilegedOtpFailureWindowStartedAt"] = date("c", $windowStart);
                $user["privilegedOtpFailedAttempts"] = 0;
            }

            $user["privilegedOtpFailedAttempts"] = max(0, (int)($user["privilegedOtpFailedAttempts"] ?? 0)) + 1;
            $metadata["cumulativeAttempt"] = $user["privilegedOtpFailedAttempts"];
            $maxFailures = privileged_otp_max_failures();

            if ($user["privilegedOtpFailedAttempts"] >= $maxFailures) {
                $user["privilegedOtpLockoutUntil"] = date("c", time() + (privileged_otp_lockout_minutes() * 60));
                $user["otpHash"] = "";
                $user["otpPurpose"] = "";
                $user["otpExpiresAt"] = "";
                $user["otpAttempts"] = 0;
                $user["updatedAt"] = date("c");
                update_record_by_id("users", (string)$userId, $user);
                unset($_SESSION["pendingPrivilegedLogin"]);

                audit_log((string)$userId, "PRIVILEGED_OTP_LOCKED", "Maximum cumulative privileged OTP failures reached. Pending privileged sign-in was cancelled.", [
                    "category" => "security",
                    "purpose" => $purpose,
                    "failedAttempts" => $user["privilegedOtpFailedAttempts"],
                    "lockoutMinutes" => privileged_otp_lockout_minutes()
                ]);
                return false;
            }
        } elseif ($user["otpAttempts"] >= 5) {
            $user["otpHash"] = "";
            $user["otpExpiresAt"] = "";
        }

        $user["updatedAt"] = date("c");
        update_record_by_id("users", (string)$userId, $user);
        audit_log((string)$userId, "OTP_FAILED", "Invalid one-time verification code.", $metadata);
        return false;
    }

    $user["otpUsedAt"] = date("c");
    $user["otpHash"] = "";
    $user["otpPurpose"] = "";
    $user["otpExpiresAt"] = "";
    $user["otpAttempts"] = 0;

    if ($isPrivilegedLogin) {
        $user["privilegedOtpFailedAttempts"] = 0;
        $user["privilegedOtpFailureWindowStartedAt"] = "";
        $user["privilegedOtpLockoutUntil"] = "";
    }

    $user["updatedAt"] = date("c");
    update_record_by_id("users", (string)$userId, $user);

    audit_log((string)$userId, "OTP_VERIFIED", "One-time verification code accepted.", ["category" => "security", "purpose" => $purpose]);
    return true;
}

function clear_login_otp($userId, $releaseSendThrottle = false) {
    $user = find_user_by_id((string)$userId);

    if (!$user) {
        return false;
    }

    $user["otpHash"] = "";
    $user["otpPurpose"] = "";
    $user["otpExpiresAt"] = "";
    $user["otpAttempts"] = 0;
    $user["otpUsedAt"] = "";

    if ($releaseSendThrottle && privileged_role_requires_otp($user["role"] ?? "")) {
        $user["otpSendCount"] = max(0, (int)($user["otpSendCount"] ?? 0) - 1);
        $user["otpSendLastAt"] = "";
    }

    $user["updatedAt"] = date("c");

    return update_record_by_id("users", (string)$userId, $user);
}

function verify_current_password($userId, $password) {
    $user = find_user_by_id((string)$userId);

    return $user
        && ($user["status"] ?? "Active") === "Active"
        && password_verify((string)$password, $user["passwordHash"] ?? "");
}

function begin_email_change_verification($userId, $newEmail, $currentPassword) {
    $userId = trim((string)$userId);
    $user = find_user_by_id($userId);

    if ($user) {
        audit_log(
            $userId,
            "LOGIN_EMAIL_CHANGE_BLOCKED",
            "Login email change was blocked because login emails are permanent after account creation.",
            ["category" => "security"]
        );
    }

    return [
        "ok" => false,
        "message" => msg(
            "Login email cannot be changed after account creation.",
            "Hindi maaaring palitan ang login email pagkatapos gawin ang account.",
            "Login email cannot be changed after account creation."
        )
    ];
}

function email_change_user_for_token($token) {
    return null;
}

function confirm_email_change($token) {
    return [
        "ok" => false,
        "message" => msg(
            "Login email changes are disabled. The login email is a permanent account identifier.",
            "Disabled ang pagpapalit ng login email. Permanent account identifier ang login email.",
            "Login email changes are disabled. The login email is a permanent account identifier."
        )
    ];
}

function begin_recovery_email_verification($userId, $newRecoveryEmail, $currentPassword) {
    $userId = trim((string)$userId);
    $newRecoveryEmail = strtolower(trim((string)$newRecoveryEmail));
    $user = find_user_by_id($userId);

    if (!$user || ($user["status"] ?? "Active") !== "Active") {
        return ["ok" => false, "message" => msg("User account was not found.", "Hindi nakita ang user account.", "User account was not found.")];
    }

    if (!verify_current_password($userId, $currentPassword)) {
        audit_log($userId, "RECOVERY_EMAIL_CHANGE_REJECTED", "Current password verification failed.", ["category" => "security"]);
        return ["ok" => false, "message" => msg("Current password is incorrect.", "Mali ang kasalukuyang password.", "Current password is incorrect.")];
    }

    if ($newRecoveryEmail === "" || !filter_var($newRecoveryEmail, FILTER_VALIDATE_EMAIL)) {
        return ["ok" => false, "message" => msg("Enter a valid recovery email address.", "Maglagay ng wastong recovery email address.", "Enter a valid recovery email address.")];
    }

    $loginEmail = strtolower(trim((string)($user["email"] ?? "")));
    $currentRecoveryEmail = strtolower(trim((string)($user["recoveryEmail"] ?? "")));

    if ($newRecoveryEmail === $loginEmail) {
        return ["ok" => false, "message" => msg("Use a recovery email different from your login email.", "Gumamit ng recovery email na iba sa login email.", "Use a recovery email different from your login email.")];
    }

    if (
        $currentRecoveryEmail !== "" &&
        !empty($user["recoveryEmailVerified"]) &&
        $newRecoveryEmail === $currentRecoveryEmail
    ) {
        return ["ok" => false, "message" => msg("That recovery email is already verified for this account.", "Verified na ang recovery email na iyon para sa account na ito.", "That recovery email is already verified for this account.")];
    }

    $limit = security_rate_limit_consume(
        $user,
        "recoveryEmailVerificationRateLastAt",
        "recoveryEmailVerificationRateWindowStartedAt",
        "recoveryEmailVerificationRateCount",
        recovery_verification_request_cooldown_seconds(),
        recovery_verification_max_requests_per_hour(),
        3600
    );

    if (empty($limit["allowed"])) {
        $retryAfter = (int)($limit["retryAfter"] ?? 0);
        audit_log($userId, "RECOVERY_EMAIL_VERIFICATION_THROTTLED", "Recovery email verification request was throttled.", [
            "category" => "security",
            "retryAfter" => $retryAfter
        ]);

        return [
            "ok" => false,
            "message" => msg(
                "Please wait " . security_retry_text($retryAfter) . " before requesting another recovery email verification.",
                "Maghintay ng " . security_retry_text($retryAfter) . " bago humiling ng panibagong recovery email verification.",
                "Please wait " . security_retry_text($retryAfter) . " before requesting another recovery email verification."
            ),
            "throttled" => true,
            "retryAfter" => $retryAfter
        ];
    }

    $token = security_random_token(32);
    $user["pendingRecoveryEmail"] = $newRecoveryEmail;
    $user["recoveryEmailVerificationTokenHash"] = security_hash_secret($token);
    $user["recoveryEmailVerificationExpiresAt"] = security_expiry_iso(recovery_email_verification_expiry_minutes());
    $user["recoveryEmailVerificationRequestedAt"] = date("c");
    $user["recoveryEmailVerificationUsedAt"] = "";
    $user["updatedAt"] = date("c");

    if (!update_record_by_id("users", $userId, $user)) {
        return ["ok" => false, "message" => msg("Unable to prepare recovery email verification.", "Hindi maihanda ang recovery email verification.", "Unable to prepare recovery email verification.")];
    }

    audit_log($userId, "RECOVERY_EMAIL_VERIFICATION_REQUESTED", "Recovery email verification requested.", [
        "category" => "security"
    ]);

    return [
        "ok" => true,
        "message" => msg("A verification message can now be sent to the new recovery email.", "Maaari nang ipadala ang verification message sa bagong recovery email.", "A verification message can now be sent to the new recovery email."),
        "email" => $newRecoveryEmail,
        "maskedEmail" => mask_email_address($newRecoveryEmail),
        "token" => $token,
        "expiresAt" => $user["recoveryEmailVerificationExpiresAt"]
    ];
}

function begin_privileged_recovery_enrollment($userId, $newRecoveryEmail) {
    $userId = trim((string)$userId);
    $newRecoveryEmail = strtolower(trim((string)$newRecoveryEmail));
    $pending = $_SESSION["pendingPrivilegedRecoveryEnrollment"] ?? null;
    $pendingUserId = is_array($pending) ? trim((string)($pending["userId"] ?? "")) : "";
    $pendingCreatedAt = is_array($pending) ? (int)($pending["createdAt"] ?? 0) : 0;

    if (
        $userId === "" ||
        !is_array($pending) ||
        $pendingUserId === "" ||
        !hash_equals($pendingUserId, $userId) ||
        $pendingCreatedAt <= 0 ||
        (time() - $pendingCreatedAt) > 1800
    ) {
        return [
            "ok" => false,
            "message" => msg(
                "The recovery email setup session is invalid or expired. Sign in again.",
                "Invalid o expired ang recovery email setup session. Mag-sign in muli.",
                "The recovery email setup session is invalid or expired. Sign in again."
            )
        ];
    }

    $user = find_user_by_id($userId);

    if (
        !$user ||
        ($user["status"] ?? "Active") !== "Active" ||
        !privileged_role_requires_otp($user["role"] ?? "")
    ) {
        return [
            "ok" => false,
            "message" => msg(
                "This recovery email setup session is unavailable.",
                "Hindi available ang recovery email setup session na ito.",
                "This recovery email setup session is unavailable."
            )
        ];
    }

    if (verified_recovery_email($user) !== "") {
        return [
            "ok" => false,
            "message" => msg(
                "This privileged account already has a verified recovery email.",
                "May verified recovery email na ang privileged account na ito.",
                "This privileged account already has a verified recovery email."
            )
        ];
    }

    if ($newRecoveryEmail === "" || !filter_var($newRecoveryEmail, FILTER_VALIDATE_EMAIL)) {
        return [
            "ok" => false,
            "message" => msg(
                "Enter a valid recovery email address.",
                "Maglagay ng wastong recovery email address.",
                "Enter a valid recovery email address."
            )
        ];
    }

    $loginEmail = strtolower(trim((string)($user["email"] ?? "")));

    if ($newRecoveryEmail === $loginEmail) {
        return [
            "ok" => false,
            "message" => msg(
                "Use a recovery email different from your login email.",
                "Gumamit ng recovery email na iba sa login email.",
                "Use a recovery email different from your login email."
            )
        ];
    }

    $limit = security_rate_limit_consume(
        $user,
        "recoveryEmailVerificationRateLastAt",
        "recoveryEmailVerificationRateWindowStartedAt",
        "recoveryEmailVerificationRateCount",
        recovery_verification_request_cooldown_seconds(),
        recovery_verification_max_requests_per_hour(),
        3600
    );

    if (empty($limit["allowed"])) {
        $retryAfter = (int)($limit["retryAfter"] ?? 0);
        audit_log($userId, "PRIVILEGED_RECOVERY_ENROLLMENT_THROTTLED", "Privileged recovery email enrollment request was throttled.", [
            "category" => "security",
            "retryAfter" => $retryAfter
        ]);

        return [
            "ok" => false,
            "message" => msg(
                "Please wait " . security_retry_text($retryAfter) . " before requesting another recovery email verification.",
                "Maghintay ng " . security_retry_text($retryAfter) . " bago humiling ng panibagong recovery email verification.",
                "Please wait " . security_retry_text($retryAfter) . " before requesting another recovery email verification."
            ),
            "throttled" => true,
            "retryAfter" => $retryAfter
        ];
    }

    $token = security_random_token(32);
    $user["pendingRecoveryEmail"] = $newRecoveryEmail;
    $user["recoveryEmailVerificationTokenHash"] = security_hash_secret($token);
    $user["recoveryEmailVerificationExpiresAt"] = security_expiry_iso(recovery_email_verification_expiry_minutes());
    $user["recoveryEmailVerificationRequestedAt"] = date("c");
    $user["recoveryEmailVerificationUsedAt"] = "";
    $user["updatedAt"] = date("c");

    if (!update_record_by_id("users", $userId, $user)) {
        return [
            "ok" => false,
            "message" => msg(
                "Unable to prepare recovery email verification.",
                "Hindi maihanda ang recovery email verification.",
                "Unable to prepare recovery email verification."
            )
        ];
    }

    audit_log(
        $userId,
        "PRIVILEGED_RECOVERY_ENROLLMENT_REQUESTED",
        "First-time recovery email verification requested for a privileged account.",
        ["category" => "security"]
    );

    return [
        "ok" => true,
        "message" => msg(
            "A verification message can now be sent to the recovery email.",
            "Maaari nang ipadala ang verification message sa recovery email.",
            "A verification message can now be sent to the recovery email."
        ),
        "email" => $newRecoveryEmail,
        "maskedEmail" => mask_email_address($newRecoveryEmail),
        "token" => $token,
        "expiresAt" => $user["recoveryEmailVerificationExpiresAt"]
    ];
}

function recovery_email_user_for_token($token) {
    $token = trim((string)$token);

    if ($token === "") {
        return null;
    }

    $hash = security_hash_secret($token);

    foreach (read_records("users") as $user) {
        $storedHash = trim((string)($user["recoveryEmailVerificationTokenHash"] ?? ""));
        $pendingEmail = strtolower(trim((string)($user["pendingRecoveryEmail"] ?? "")));

        if (
            $storedHash !== "" &&
            hash_equals($storedHash, $hash) &&
            $pendingEmail !== "" &&
            filter_var($pendingEmail, FILTER_VALIDATE_EMAIL) &&
            empty($user["recoveryEmailVerificationUsedAt"]) &&
            security_expiry_valid($user["recoveryEmailVerificationExpiresAt"] ?? "")
        ) {
            return $user;
        }
    }

    return null;
}

function validate_recovery_email_verification_token($token) {
    return recovery_email_user_for_token($token) !== null;
}

function confirm_recovery_email($token) {
    $user = recovery_email_user_for_token($token);

    if (!$user) {
        return ["ok" => false, "message" => msg("This recovery email verification link is invalid or expired.", "Invalid o expired na ang recovery email verification link.", "This recovery email verification link is invalid or expired.")];
    }

    $newRecoveryEmail = strtolower(trim((string)($user["pendingRecoveryEmail"] ?? "")));
    $loginEmail = strtolower(trim((string)($user["email"] ?? "")));

    if (
        $newRecoveryEmail === "" ||
        !filter_var($newRecoveryEmail, FILTER_VALIDATE_EMAIL) ||
        $newRecoveryEmail === $loginEmail
    ) {
        return ["ok" => false, "message" => msg("The recovery email address cannot be used.", "Hindi maaaring gamitin ang recovery email address.", "The recovery email address cannot be used.")];
    }

    $previousRecoveryEmail = strtolower(trim((string)($user["recoveryEmail"] ?? "")));
    $user["recoveryEmail"] = $newRecoveryEmail;
    $user["recoveryEmailVerified"] = true;
    $user["recoveryEmailVerifiedAt"] = date("c");
    $user["pendingRecoveryEmail"] = "";
    $user["recoveryEmailVerificationTokenHash"] = "";
    $user["recoveryEmailVerificationExpiresAt"] = "";
    $user["recoveryEmailVerificationRequestedAt"] = "";
    $user["recoveryEmailVerificationUsedAt"] = date("c");
    password_change_clear_account_state($user, false, false);
    $user["updatedAt"] = date("c");

    if (!update_record_by_id("users", (string)$user["id"], $user)) {
        return ["ok" => false, "message" => msg("Unable to verify the recovery email.", "Hindi ma-verify ang recovery email.", "Unable to verify the recovery email.")];
    }

    password_change_clear_session_state((string)$user["id"]);
    audit_log((string)$user["id"], "RECOVERY_EMAIL_VERIFIED", "Recovery email verified and activated.", [
        "category" => "security",
        "previousRecoveryEmailHash" => $previousRecoveryEmail !== "" ? hash("sha256", $previousRecoveryEmail) : ""
    ]);

    return [
        "ok" => true,
        "message" => msg("Recovery email verified successfully.", "Matagumpay na na-verify ang recovery email.", "Recovery email verified successfully."),
        "email" => $newRecoveryEmail,
        "maskedEmail" => mask_email_address($newRecoveryEmail)
    ];
}

function cancel_pending_recovery_email($userId) {
    $userId = trim((string)$userId);
    $user = find_user_by_id($userId);

    if (!$user) {
        return false;
    }

    $user["pendingRecoveryEmail"] = "";
    $user["recoveryEmailVerificationTokenHash"] = "";
    $user["recoveryEmailVerificationExpiresAt"] = "";
    $user["recoveryEmailVerificationRequestedAt"] = "";
    $user["recoveryEmailVerificationUsedAt"] = "";
    $user["updatedAt"] = date("c");

    $saved = update_record_by_id("users", $userId, $user);

    if ($saved) {
        audit_log($userId, "RECOVERY_EMAIL_VERIFICATION_CANCELLED", "Pending recovery email verification was cancelled.", ["category" => "security"]);
    }

    return $saved;
}

function remove_recovery_email($userId, $currentPassword) {
    $userId = trim((string)$userId);
    $user = find_user_by_id($userId);

    if (!$user || ($user["status"] ?? "Active") !== "Active") {
        return ["ok" => false, "message" => msg("User account was not found.", "Hindi nakita ang user account.", "User account was not found.")];
    }

    if (!verify_current_password($userId, $currentPassword)) {
        audit_log($userId, "RECOVERY_EMAIL_REMOVAL_REJECTED", "Current password verification failed.", ["category" => "security"]);
        return ["ok" => false, "message" => msg("Current password is incorrect.", "Mali ang kasalukuyang password.", "Current password is incorrect.")];
    }

    $hadRecovery = verified_recovery_email($user) !== "";

    if ($hadRecovery && privileged_role_requires_otp($user["role"] ?? "")) {
        audit_log($userId, "PRIVILEGED_RECOVERY_EMAIL_REMOVAL_BLOCKED", "Privileged accounts must retain a verified recovery email for OTP authentication.", ["category" => "security"]);
        return [
            "ok" => false,
            "message" => msg(
                "Privileged accounts must keep a verified recovery email. Verify a replacement recovery email instead of removing it.",
                "Kailangang may verified recovery email ang privileged account. Mag-verify ng kapalit na recovery email sa halip na alisin ito.",
                "Privileged accounts must keep a verified recovery email. Verify a replacement recovery email instead of removing it."
            )
        ];
    }

    $user["recoveryEmail"] = "";
    $user["recoveryEmailVerified"] = false;
    $user["recoveryEmailVerifiedAt"] = "";
    $user["pendingRecoveryEmail"] = "";
    $user["recoveryEmailVerificationTokenHash"] = "";
    $user["recoveryEmailVerificationExpiresAt"] = "";
    $user["recoveryEmailVerificationRequestedAt"] = "";
    $user["recoveryEmailVerificationUsedAt"] = "";
    $user["passwordResetTokenHash"] = "";
    $user["passwordResetExpiresAt"] = "";
    $user["passwordResetRequestedAt"] = "";
    $user["passwordResetUsedAt"] = "";
    password_change_clear_account_state($user, false, false);
    $user["updatedAt"] = date("c");

    if (!update_record_by_id("users", $userId, $user)) {
        return ["ok" => false, "message" => msg("Unable to remove the recovery email.", "Hindi maalis ang recovery email.", "Unable to remove the recovery email.")];
    }

    password_change_clear_session_state($userId);
    audit_log($userId, "RECOVERY_EMAIL_REMOVED", $hadRecovery ? "Verified recovery email removed." : "Recovery email settings cleared.", ["category" => "security"]);

    return [
        "ok" => true,
        "message" => msg("Recovery email removed. Password recovery by email is unavailable until another recovery email is verified.", "Inalis ang recovery email. Hindi available ang password recovery by email hanggang may ma-verify na bagong recovery email.", "Recovery email removed. Password recovery by email is unavailable until another recovery email is verified.")
    ];
}

function security_login_lockout_state($userOrId) {
    $user = is_array($userOrId) ? $userOrId : find_user_by_id((string)$userOrId);

    if (!$user) {
        return [
            "locked" => false,
            "failedAttempts" => 0,
            "remainingAttempts" => 0,
            "lockoutUntil" => "",
            "secondsRemaining" => 0
        ];
    }

    $settings = function_exists("technical_settings_record") ? technical_settings_record() : [];
    $maxAttempts = max(1, (int)($settings["maxLoginAttempts"] ?? 5));
    $failed = max(0, (int)($user["failedLoginAttempts"] ?? 0));
    $lockoutUntil = trim((string)($user["lockoutUntil"] ?? ""));
    $until = $lockoutUntil !== "" ? strtotime($lockoutUntil) : false;
    $seconds = $until && $until > time() ? $until - time() : 0;

    return [
        "locked" => $seconds > 0,
        "failedAttempts" => $failed,
        "remainingAttempts" => max(0, $maxAttempts - $failed),
        "lockoutUntil" => $seconds > 0 ? $lockoutUntil : "",
        "secondsRemaining" => max(0, (int)$seconds)
    ];
}

function security_register_login_failure($userId) {
    $user = find_user_by_id((string)$userId);

    if (!$user) {
        return security_login_lockout_state([]);
    }

    $settings = function_exists("technical_settings_record") ? technical_settings_record() : [];
    $maxAttempts = max(1, (int)($settings["maxLoginAttempts"] ?? 5));
    $lockoutMinutes = max(1, (int)($settings["lockoutMinutes"] ?? 15));
    $user["failedLoginAttempts"] = max(0, (int)($user["failedLoginAttempts"] ?? 0)) + 1;

    if ($user["failedLoginAttempts"] >= $maxAttempts) {
        $user["lockoutUntil"] = date("c", time() + ($lockoutMinutes * 60));
        audit_log((string)$userId, "ACCOUNT_TEMPORARILY_LOCKED", "Maximum failed login attempts reached.", ["category" => "security"]);
    } else {
        audit_log((string)$userId, "LOGIN_FAILED", "Invalid password.", ["category" => "security", "attempt" => $user["failedLoginAttempts"]]);
    }

    $user["updatedAt"] = date("c");
    update_record_by_id("users", (string)$userId, $user);

    return security_login_lockout_state($user);
}

function security_clear_login_failures($userId) {
    $user = find_user_by_id((string)$userId);

    if (!$user) {
        return false;
    }

    $user["failedLoginAttempts"] = 0;
    $user["lockoutUntil"] = "";
    $user["updatedAt"] = date("c");

    return update_record_by_id("users", (string)$userId, $user);
}

function privileged_otp_monitoring_for_it_admin($viewerUserId) {
    $viewer = find_user_by_id((string)$viewerUserId);

    if (!$viewer || ($viewer["status"] ?? "Active") !== "Active" || ($viewer["role"] ?? "") !== "it_admin") {
        return [];
    }

    $rows = [];

    foreach (read_records("users") as $user) {
        if (!privileged_role_requires_otp($user["role"] ?? "")) {
            continue;
        }

        $state = privileged_otp_security_state($user);
        $rows[] = [
            "id" => (string)($user["id"] ?? ""),
            "code" => (string)($user["code"] ?? ""),
            "name" => (string)($user["name"] ?? ""),
            "role" => (string)($user["role"] ?? ""),
            "status" => (string)($user["status"] ?? "Active"),
            "failedAttempts" => (int)($state["failedAttempts"] ?? 0),
            "remainingAttempts" => (int)($state["remainingAttempts"] ?? 0),
            "locked" => !empty($state["locked"]),
            "lockoutUntil" => (string)($state["lockoutUntil"] ?? ""),
            "secondsRemaining" => (int)($state["secondsRemaining"] ?? 0),
            "sendCount" => (int)($state["sendCount"] ?? 0),
            "sendRemaining" => (int)($state["sendRemaining"] ?? 0),
            "sendRetryAfter" => (int)($state["sendRetryAfter"] ?? 0)
        ];
    }

    usort($rows, function($a, $b) {
        if (!empty($a["locked"]) !== !empty($b["locked"])) {
            return !empty($a["locked"]) ? -1 : 1;
        }

        return ((int)$b["failedAttempts"]) <=> ((int)$a["failedAttempts"]);
    });

    return $rows;
}

function privileged_otp_failure_events_for_it_admin($viewerUserId, $limit = 100) {
    $viewer = find_user_by_id((string)$viewerUserId);

    if (!$viewer || ($viewer["status"] ?? "Active") !== "Active" || ($viewer["role"] ?? "") !== "it_admin") {
        return [];
    }

    $limit = max(1, min(200, (int)$limit));
    $allowedActions = [
        "OTP_FAILED",
        "OTP_BLOCKED",
        "PRIVILEGED_OTP_BLOCKED",
        "PRIVILEGED_OTP_LOCKED",
        "OTP_RESEND_THROTTLED"
    ];
    $events = [];

    foreach (latest_audit_logs(500) as $log) {
        if (!in_array((string)($log["action"] ?? ""), $allowedActions, true)) {
            continue;
        }

        $target = find_user_by_id((string)($log["userId"] ?? ""));

        if (!$target || !privileged_role_requires_otp($target["role"] ?? "")) {
            continue;
        }

        $events[] = $log;

        if (count($events) >= $limit) {
            break;
        }
    }

    return $events;
}

function account_lockouts_for_super_admin($viewerUserId) {
    $viewer = find_user_by_id((string)$viewerUserId);

    if (!$viewer || ($viewer["status"] ?? "Active") !== "Active" || ($viewer["role"] ?? "") !== "super_admin") {
        return [];
    }

    $rows = [];

    foreach (read_records("users") as $user) {
        $state = security_login_lockout_state($user);

        if (empty($state["locked"]) && (int)($state["failedAttempts"] ?? 0) <= 0) {
            continue;
        }

        $rows[] = [
            "id" => (string)($user["id"] ?? ""),
            "code" => (string)($user["code"] ?? ""),
            "name" => (string)($user["name"] ?? ""),
            "email" => (string)($user["email"] ?? ""),
            "role" => (string)($user["role"] ?? ""),
            "status" => (string)($user["status"] ?? "Active"),
            "locked" => !empty($state["locked"]),
            "failedAttempts" => (int)($state["failedAttempts"] ?? 0),
            "remainingAttempts" => (int)($state["remainingAttempts"] ?? 0),
            "lockoutUntil" => (string)($state["lockoutUntil"] ?? ""),
            "secondsRemaining" => (int)($state["secondsRemaining"] ?? 0)
        ];
    }

    usort($rows, function($a, $b) {
        if (!empty($a["locked"]) !== !empty($b["locked"])) {
            return !empty($a["locked"]) ? -1 : 1;
        }

        return ((int)$b["failedAttempts"]) <=> ((int)$a["failedAttempts"]);
    });

    return $rows;
}

function security_register_active_session($userId, $sessionToken) {
    $user = find_user_by_id((string)$userId);
    $sessionToken = trim((string)$sessionToken);

    if (!$user || $sessionToken === "") {
        return false;
    }

    $user["activeSessionHash"] = security_hash_secret($sessionToken);
    $user["sessionInvalidationReason"] = "new_login";
    $user["lastLoginAt"] = date("c");
    $user["lastSessionStartedAt"] = date("c");
    $user["failedLoginAttempts"] = 0;
    $user["lockoutUntil"] = "";
    $user["updatedAt"] = date("c");

    return update_record_by_id("users", (string)$userId, $user);
}

function security_active_session_matches($userId, $sessionToken) {
    $user = find_user_by_id((string)$userId);
    $stored = trim((string)($user["activeSessionHash"] ?? ""));
    $sessionToken = trim((string)$sessionToken);

    return $user
        && $stored !== ""
        && $sessionToken !== ""
        && hash_equals($stored, security_hash_secret($sessionToken));
}

function security_clear_active_session($userId, $sessionToken = "") {
    $user = find_user_by_id((string)$userId);

    if (!$user) {
        return false;
    }

    $stored = trim((string)($user["activeSessionHash"] ?? ""));
    $sessionToken = trim((string)$sessionToken);

    if ($sessionToken !== "" && $stored !== "" && !hash_equals($stored, security_hash_secret($sessionToken))) {
        return false;
    }

    $user["activeSessionHash"] = "";
    $user["sessionInvalidationReason"] = "logout";
    password_change_clear_account_state($user, false, false);
    $user["lastLogoutAt"] = date("c");
    $user["updatedAt"] = date("c");

    $saved = update_record_by_id("users", (string)$userId, $user);

    if ($saved) {
        password_change_clear_session_state((string)$userId);
    }

    return $saved;
}

function sensitive_action_key($scope) {
    $scope = strtolower(trim((string)$scope));
    $scope = preg_replace('/[^a-z0-9_-]/', '', $scope);
    return $scope !== "" ? $scope : "general";
}

function confirm_sensitive_action($userId, $password, $scope = "general", $ttlSeconds = 300) {
    $userId = trim((string)$userId);
    $scope = sensitive_action_key($scope);

    if (!verify_current_password($userId, $password)) {
        audit_log($userId, "SENSITIVE_ACTION_VERIFICATION_FAILED", "Current password confirmation failed.", ["category" => "security", "scope" => $scope]);
        return false;
    }

    if (!isset($_SESSION["sensitive_action_verified"]) || !is_array($_SESSION["sensitive_action_verified"])) {
        $_SESSION["sensitive_action_verified"] = [];
    }

    $_SESSION["sensitive_action_verified"][$scope] = [
        "userId" => $userId,
        "verifiedAt" => time(),
        "expiresAt" => time() + max(60, min(900, (int)$ttlSeconds)
        )
    ];

    audit_log($userId, "SENSITIVE_ACTION_VERIFIED", "Current password confirmation succeeded.", ["category" => "security", "scope" => $scope]);
    return true;
}

function sensitive_action_is_verified($userId, $scope = "general", $consume = false) {
    $scope = sensitive_action_key($scope);
    $record = $_SESSION["sensitive_action_verified"][$scope] ?? null;

    if (
        !is_array($record) ||
        (string)($record["userId"] ?? "") !== (string)$userId ||
        (int)($record["expiresAt"] ?? 0) < time()
    ) {
        unset($_SESSION["sensitive_action_verified"][$scope]);
        return false;
    }

    if ($consume) {
        unset($_SESSION["sensitive_action_verified"][$scope]);
    }

    return true;
}

function clear_sensitive_action_verification($scope = "") {
    if ($scope === "") {
        unset($_SESSION["sensitive_action_verified"]);
        return true;
    }

    $scope = sensitive_action_key($scope);
    unset($_SESSION["sensitive_action_verified"][$scope]);
    return true;
}

function create_user_account($post) {
    $name = safe_text($post["name"] ?? "", 120);
    $email = strtolower(safe_text($post["email"] ?? "", 150));
    $password = (string)($post["password"] ?? "");
    $role = strtolower(safe_text($post["role"] ?? "", 30));
    $strand = safe_text($post["strand"] ?? "", 80);
    $section = safe_text($post["section"] ?? "", 80);
    $gradeLevel = safe_text($post["gradeLevel"] ?? "", 40);
    $teacherId = safe_text($post["teacherId"] ?? "", 80);
    $managedSections = safe_text($post["managedSections"] ?? "", 250);
    $sectionNames = function_exists("section_names_list") ? section_names_list() : [];
    $generatedTemporaryPassword = false;

    if ($name === "" || $email === "" || $role === "") {
        return ["ok" => false, "message" => msg("Complete name, email, and role.", "Kumpletuhin ang name, email, at role.", "Complete name, email, and role.")];
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return ["ok" => false, "message" => msg("Enter a valid email address.", "Maglagay ng wastong email address.", "Enter a valid email address.")];
    }

    if (!in_array($role, app_roles(), true)) {
        return ["ok" => false, "message" => msg("Select a valid role.", "Pumili ng wastong role.", "Select a valid role.")];
    }

    $actorId = trim((string)($_SESSION["user"]["id"] ?? ""));
    $actorRole = strtolower((string)($_SESSION["user"]["role"] ?? ""));

    if (in_array($role, ["super_admin", "it_admin"], true) && $actorRole !== "super_admin") {
        return ["ok" => false, "message" => msg("Only the Super Administrator can create privileged system accounts.", "Super Administrator lamang ang maaaring gumawa ng privileged system accounts.", "Only the Super Administrator can create privileged system accounts.")];
    }

    if ($password === "") {
        $password = generate_temporary_password(16);
        $generatedTemporaryPassword = true;
    }

    $policyMessage = password_policy_message($password, [
        "name" => $name,
        "email" => $email,
        "code" => ""
    ]);

    if ($policyMessage !== "") {
        return ["ok" => false, "message" => $policyMessage];
    }

    if (email_exists($email)) {
        return ["ok" => false, "message" => msg("Email already exists.", "May kaparehong email na.", "Email already exists.")];
    }

    $users = read_records("users");

    if ($role === "student") {
        $strand = $strand !== "" ? $strand : "ABM";
        $section = $section !== "" ? $section : ($sectionNames[0] ?? "12-A");
        $gradeLevel = $gradeLevel !== "" ? $gradeLevel : "Grade 12";

        if (count($sectionNames) && !in_array($section, $sectionNames, true)) {
            return ["ok" => false, "message" => msg("Select a valid section.", "Pumili ng wastong section.", "Select a valid section.")];
        }

        $managedSections = "";

        if ($teacherId === "") {
            foreach ($users as $existingUser) {
                if (($existingUser["role"] ?? "") === "teacher" && ($existingUser["status"] ?? "Active") === "Active") {
                    $teacherId = $existingUser["id"] ?? "";
                    break;
                }
            }
        }
    }

    if ($role === "teacher") {
        $strand = "All";
        $section = "All";
        $gradeLevel = "All";
        $teacherId = "";
        $managedSections = $managedSections;
    }

    if (in_array($role, administrative_roles(), true)) {
        $strand = "All";
        $section = "All";
        $gradeLevel = "All";
        $teacherId = "";
        $managedSections = "";
    }

    $userId = $role . "-" . time() . "-" . bin2hex(random_bytes(3));
    $record = [
        "id" => $userId,
        "code" => next_user_code($role),
        "name" => $name,
        "email" => $email,
        "emailVerified" => false,
        "emailVerifiedAt" => "",
        "pendingEmail" => "",
        "recoveryEmail" => "",
        "recoveryEmailVerified" => false,
        "recoveryEmailVerifiedAt" => "",
        "pendingRecoveryEmail" => "",
        "recoveryEmailVerificationTokenHash" => "",
        "recoveryEmailVerificationExpiresAt" => "",
        "recoveryEmailVerificationRequestedAt" => "",
        "recoveryEmailVerificationUsedAt" => "",
        "passwordHash" => password_hash($password, PASSWORD_DEFAULT),
        "passwordTemporary" => true,
        "mustChangePassword" => true,
        "temporaryPasswordIssuedAt" => date("c"),
        "passwordChangedAt" => "",
        "passwordChangeChallengeHash" => "",
        "passwordChangeChallengeExpiresAt" => "",
        "passwordChangeOtpHash" => "",
        "passwordChangeOtpExpiresAt" => "",
        "passwordChangeOtpAttempts" => 0,
        "passwordChangeOtpCreatedAt" => "",
        "passwordChangeOtpUsedAt" => "",
        "passwordChangeOtpSendLastAt" => "",
        "passwordChangeOtpSendWindowStartedAt" => "",
        "passwordChangeOtpSendCount" => 0,
        "passwordChangeOtpFailedAttempts" => 0,
        "passwordChangeOtpFailureWindowStartedAt" => "",
        "passwordChangeOtpLockoutUntil" => "",
        "failedLoginAttempts" => 0,
        "lockoutUntil" => "",
        "activeSessionHash" => "",
        "sessionInvalidationReason" => "",
        "lastLoginAt" => "",
        "lastLogoutAt" => "",
        "role" => $role,
        "strand" => $strand,
        "section" => $section,
        "gradeLevel" => $gradeLevel,
        "status" => "Active",
        "teacherId" => $teacherId,
        "managedSections" => $managedSections,
        "birthDate" => "",
        "contactNumber" => "",
        "details" => "",
        "sessionVersion" => 1,
        "createdBy" => $actorId,
        "createdAt" => date("c"),
        "updatedAt" => date("c")
    ];

    if (!update_record_by_id("users", $userId, $record)) {
        return ["ok" => false, "message" => msg("Unable to create the user.", "Hindi nagawa ang user.", "Unable to create the user.")];
    }

    audit_log($actorId, "USER_CREATED", "User account created with a temporary password.", [
        "category" => "security",
        "targetUserId" => $userId,
        "targetRole" => $role
    ]);

    $result = [
        "ok" => true,
        "message" => msg("User created. The password must be changed on first login.", "Nagawa ang user. Kailangang palitan ang password sa unang login.", "User created. The password must be changed on first login."),
        "userId" => $userId,
        "mustChangePassword" => true
    ];

    if ($generatedTemporaryPassword) {
        $result["temporaryPassword"] = $password;
    }

    return $result;
}

function toggle_user_status($userId, $updatedBy = "") {
    $userId = trim((string)$userId);
    $updatedBy = trim((string)$updatedBy);

    if ($userId === "") {
        return false;
    }

    if ($updatedBy !== "" && $userId === $updatedBy) {
        return false;
    }

    $users = read_records("users");
    $targetIndex = null;

    foreach ($users as $index => $user) {
        if (($user["id"] ?? "") === $userId) {
            $targetIndex = $index;
            break;
        }
    }

    if ($targetIndex === null) {
        return false;
    }

    $currentStatus = ($users[$targetIndex]["status"] ?? "Active") === "Active" ? "Active" : "Inactive";
    $newStatus = $currentStatus === "Active" ? "Inactive" : "Active";
    $adminRoles = administrative_roles();
    $targetRole = $users[$targetIndex]["role"] ?? "";
    $actor = $updatedBy !== "" ? find_user_by_id($updatedBy) : null;
    $actorRole = $actor["role"] ?? "";

    if (in_array($targetRole, ["super_admin", "it_admin"], true) && $actorRole !== "super_admin") {
        return false;
    }

    if ($newStatus === "Inactive" && in_array($targetRole, $adminRoles, true)) {
        $activeAdminCount = 0;

        foreach ($users as $existingUser) {
            if (($existingUser["status"] ?? "Active") === "Active" && in_array($existingUser["role"] ?? "", $adminRoles, true)) {
                $activeAdminCount++;
            }
        }

        if ($activeAdminCount <= 1) {
            return false;
        }
    }

    $users[$targetIndex]["status"] = $newStatus;
    $users[$targetIndex]["updatedAt"] = date("c");
    $users[$targetIndex]["updatedBy"] = $updatedBy;

    if ($newStatus === "Inactive") {
        $users[$targetIndex]["activeSessionHash"] = security_hash_secret(security_random_token(32));
        $users[$targetIndex]["sessionInvalidationReason"] = "account_deactivated";
        $users[$targetIndex]["sessionVersion"] = max(1, (int)($users[$targetIndex]["sessionVersion"] ?? 1)) + 1;
        $users[$targetIndex]["otpHash"] = "";
        $users[$targetIndex]["otpPurpose"] = "";
        $users[$targetIndex]["otpExpiresAt"] = "";
        $users[$targetIndex]["otpAttempts"] = 0;
        $users[$targetIndex]["otpUsedAt"] = "";
        $users[$targetIndex]["privilegedOtpFailedAttempts"] = 0;
        $users[$targetIndex]["privilegedOtpFailureWindowStartedAt"] = "";
        $users[$targetIndex]["privilegedOtpLockoutUntil"] = "";
        password_change_clear_account_state($users[$targetIndex], true, true);
    }

    if (!write_records("users", $users)) {
        return false;
    }

    audit_log($updatedBy, $newStatus === "Active" ? "USER_REACTIVATED" : "USER_DEACTIVATED", "User account status changed.", [
        "category" => "security",
        "targetUserId" => $userId,
        "targetRole" => $targetRole,
        "newStatus" => $newStatus
    ]);

    return true;
}

function change_user_role($targetUserId, $newRole, $actorUserId) {
    $targetUserId = trim((string)$targetUserId);
    $actorUserId = trim((string)$actorUserId);
    $newRole = strtolower(trim((string)$newRole));
    $target = find_user_by_id($targetUserId);
    $actor = find_user_by_id($actorUserId);

    if (!$target || !$actor || ($actor["status"] ?? "Active") !== "Active") {
        return ["ok" => false, "message" => msg("Unable to update this account.", "Hindi ma-update ang account na ito.", "Unable to update this account.")];
    }

    if (($actor["role"] ?? "") !== "super_admin") {
        return ["ok" => false, "message" => msg("Only the Super Administrator can change account roles.", "Super Administrator lamang ang maaaring magpalit ng account role.", "Only the Super Administrator can change account roles.")];
    }

    if (!in_array($newRole, app_roles(), true)) {
        return ["ok" => false, "message" => msg("Select a valid role.", "Pumili ng wastong role.", "Select a valid role.")];
    }

    $oldRole = strtolower((string)($target["role"] ?? ""));

    if ($oldRole === $newRole) {
        return ["ok" => true, "message" => msg("No role change was needed.", "Walang kailangang baguhin sa role.", "No role change was needed.")];
    }

    if ($targetUserId === $actorUserId) {
        return ["ok" => false, "message" => msg("You cannot change your own role here.", "Hindi mo maaaring palitan ang sarili mong role dito.", "You cannot change your own role here.")];
    }

    if ($oldRole === "super_admin") {
        $activeSuperAdmins = 0;

        foreach (read_records("users") as $user) {
            if (($user["role"] ?? "") === "super_admin" && ($user["status"] ?? "Active") === "Active") {
                $activeSuperAdmins++;
            }
        }

        if ($activeSuperAdmins <= 1) {
            return ["ok" => false, "message" => msg("At least one active Super Administrator must remain.", "Dapat may manatiling kahit isang active Super Administrator.", "At least one active Super Administrator must remain.")];
        }
    }

    $target["role"] = $newRole;
    $target["code"] = next_user_code($newRole);
    $target["activeSessionHash"] = security_hash_secret(security_random_token(32));
    $target["sessionInvalidationReason"] = "role_change";
    $target["sessionVersion"] = max(1, (int)($target["sessionVersion"] ?? 1)) + 1;
    $target["otpHash"] = "";
    $target["otpPurpose"] = "";
    $target["otpExpiresAt"] = "";
    $target["otpAttempts"] = 0;
    $target["otpUsedAt"] = "";
    $target["privilegedOtpFailedAttempts"] = 0;
    $target["privilegedOtpFailureWindowStartedAt"] = "";
    $target["privilegedOtpLockoutUntil"] = "";
    $target["otpSendLastAt"] = "";
    $target["otpSendWindowStartedAt"] = "";
    $target["otpSendCount"] = 0;
    password_change_clear_account_state($target, true, true);
    $target["mustChangePassword"] = true;
    $target["updatedAt"] = date("c");
    $target["updatedBy"] = $actorUserId;

    if ($newRole === "student") {
        $target["strand"] = ($target["strand"] ?? "") !== "" && strtolower((string)($target["strand"] ?? "")) !== "all" ? $target["strand"] : "ABM";
        $target["section"] = ($target["section"] ?? "") !== "" && strtolower((string)($target["section"] ?? "")) !== "all" ? $target["section"] : (section_names_list()[0] ?? "12-A");
        $target["gradeLevel"] = ($target["gradeLevel"] ?? "") !== "" && strtolower((string)($target["gradeLevel"] ?? "")) !== "all" ? $target["gradeLevel"] : "Grade 12";
        $target["managedSections"] = "";
    } elseif ($newRole === "teacher") {
        $target["strand"] = "All";
        $target["section"] = "All";
        $target["gradeLevel"] = "All";
        $target["teacherId"] = "";
    } else {
        $target["strand"] = "All";
        $target["section"] = "All";
        $target["gradeLevel"] = "All";
        $target["teacherId"] = "";
        $target["managedSections"] = "";
    }

    if (!update_record_by_id("users", $targetUserId, $target)) {
        return ["ok" => false, "message" => msg("Unable to update the account role.", "Hindi ma-update ang account role.", "Unable to update the account role.")];
    }

    audit_log($actorUserId, "USER_ROLE_CHANGED", "User role changed and existing sessions were revoked.", [
        "category" => "security",
        "targetUserId" => $targetUserId,
        "oldRole" => $oldRole,
        "newRole" => $newRole
    ]);

    return ["ok" => true, "message" => msg("Account role updated. The user must sign in again and change their password.", "Na-update ang account role. Kailangang mag-sign in muli at magpalit ng password ang user.", "Account role updated. The user must sign in again and change their password.")];
}

function toggle_user_status_with_confirmation($userId, $updatedBy, $currentPassword = "") {
    $target = find_user_by_id((string)$userId);
    $actor = find_user_by_id((string)$updatedBy);

    if (!$target || !$actor || ($actor["status"] ?? "Active") !== "Active") {
        return ["ok" => false, "message" => msg("Unable to update this account.", "Hindi ma-update ang account na ito.", "Unable to update this account.")];
    }

    $targetIsPrivileged = privileged_role_requires_otp($target["role"] ?? "");

    if ($targetIsPrivileged) {
        if (($actor["role"] ?? "") !== "super_admin") {
            return ["ok" => false, "message" => msg("Only the Super Administrator can change a privileged account status.", "Super Administrator lamang ang maaaring magbago ng status ng privileged account.", "Only the Super Administrator can change a privileged account status.")];
        }

        $scope = "user_status_" . preg_replace('/[^A-Za-z0-9_-]/', '', (string)$userId);

        if (!confirm_sensitive_action($updatedBy, $currentPassword, $scope, 300)) {
            return ["ok" => false, "message" => msg("Current password confirmation is required to change a privileged account status.", "Kailangan ang current password confirmation para baguhin ang status ng privileged account.", "Current password confirmation is required to change a privileged account status.")];
        }

        if (!sensitive_action_is_verified($updatedBy, $scope, true)) {
            return ["ok" => false, "message" => msg("Account status confirmation expired.", "Expired na ang account status confirmation.", "Account status confirmation expired.")];
        }
    }

    $ok = toggle_user_status($userId, $updatedBy);

    return $ok
        ? ["ok" => true, "message" => msg("Account status updated.", "Na-update ang account status.", "Account status updated.")]
        : ["ok" => false, "message" => msg("Unable to update the account status.", "Hindi ma-update ang account status.", "Unable to update the account status.")];
}

function change_user_role_with_confirmation($targetUserId, $newRole, $actorUserId, $currentPassword) {
    $scope = "user_role_" . preg_replace('/[^A-Za-z0-9_-]/', '', (string)$targetUserId);

    if (!confirm_sensitive_action($actorUserId, $currentPassword, $scope, 300)) {
        return ["ok" => false, "message" => msg("Current password confirmation is required to change an account role.", "Kailangan ang current password confirmation para magpalit ng account role.", "Current password confirmation is required to change an account role.")];
    }

    if (!sensitive_action_is_verified($actorUserId, $scope, true)) {
        return ["ok" => false, "message" => msg("Account role confirmation expired.", "Expired na ang account role confirmation.", "Account role confirmation expired.")];
    }

    return change_user_role($targetUserId, $newRole, $actorUserId);
}

function update_user_assignment($userId, $post) {
    $users = read_records("users");
    $sectionNames = function_exists("section_names_list") ? section_names_list() : [];

    foreach ($users as &$user) {
        if (($user["id"] ?? "") === $userId) {
            $role = $user["role"] ?? "";
            $strand = safe_text($post["strand"] ?? ($user["strand"] ?? ""), 80);
            $section = safe_text($post["section"] ?? ($user["section"] ?? ""), 80);
            $gradeLevel = safe_text($post["gradeLevel"] ?? ($user["gradeLevel"] ?? ""), 40);
            $teacherId = safe_text($post["teacherId"] ?? ($user["teacherId"] ?? ""), 80);
            $managedSections = safe_text($post["managedSections"] ?? ($user["managedSections"] ?? ""), 250);

            if ($role === "student") {
                $user["strand"] = $strand !== "" ? $strand : "ABM";
                $user["section"] = $section !== "" ? $section : ($sectionNames[0] ?? "12-A");
                $user["gradeLevel"] = $gradeLevel !== "" ? $gradeLevel : "Grade 12";

                if (count($sectionNames) && !in_array($user["section"], $sectionNames, true)) {
                    return false;
                }
                $user["teacherId"] = $teacherId;
                $user["managedSections"] = "";
            } elseif ($role === "teacher") {
                $user["strand"] = "All";
                $user["section"] = "All";
                $user["gradeLevel"] = "All";
                $user["teacherId"] = "";
                $user["managedSections"] = $managedSections;
            } elseif (in_array($role, administrative_roles(), true)) {
                $user["strand"] = "All";
                $user["section"] = "All";
                $user["gradeLevel"] = "All";
                $user["teacherId"] = "";
                $user["managedSections"] = "";
            }

            $user["updatedAt"] = date("c");
            break;
        }
    }

    unset($user);

    write_records("users", $users);
    return true;
}

function change_user_password($userId, $post) {
    $userId = trim((string)$userId);
    $currentPassword = (string)($post["currentPassword"] ?? "");
    $newPassword = (string)($post["newPassword"] ?? "");
    $confirmNewPassword = (string)($post["confirmNewPassword"] ?? "");

    if ($userId === "") {
        return ["ok" => false, "message" => msg("User account was not found.", "Hindi nakita ang user account.", "User account was not found.")];
    }

    $account = find_user_by_id($userId);

    if (!$account || ($account["status"] ?? "Active") !== "Active") {
        return ["ok" => false, "message" => msg("User account was not found.", "Hindi nakita ang user account.", "User account was not found.")];
    }

    if (!in_array($account["role"] ?? "", app_roles(), true)) {
        return ["ok" => false, "message" => msg("This account cannot change its password here.", "Hindi maaaring magpalit ng password dito ang account na ito.", "This account cannot change its password here.")];
    }

    $requiresOtp = password_change_otp_required_for_user($account);

    if ($newPassword === "" || $confirmNewPassword === "" || (!$requiresOtp && $currentPassword === "")) {
        return ["ok" => false, "message" => msg("Complete all password fields.", "Kumpletuhin ang lahat ng password fields.", "Complete all password fields.")];
    }

    if ($requiresOtp) {
        if (!password_change_verification_valid($userId)) {
            audit_log($userId, "PASSWORD_CHANGE_REJECTED", "Password change was blocked because recovery-email OTP verification was not completed.", [
                "category" => "security",
                "otpRequired" => true
            ]);

            return [
                "ok" => false,
                "otpRequired" => true,
                "verificationRequired" => true,
                "message" => msg(
                    "Verify the code sent to your recovery email before setting a new password.",
                    "I-verify muna ang code na ipinadala sa recovery email bago maglagay ng bagong password.",
                    "Verify the code sent to your recovery email before setting a new password."
                )
            ];
        }
    } elseif (!password_verify($currentPassword, $account["passwordHash"] ?? "")) {
        audit_log($userId, "PASSWORD_CHANGE_FAILED", "Current password verification failed.", ["category" => "security"]);
        return ["ok" => false, "message" => msg("Current password is incorrect.", "Mali ang kasalukuyang password.", "Current password is incorrect.")];
    }

    if ($newPassword !== $confirmNewPassword) {
        return ["ok" => false, "message" => msg("New passwords do not match.", "Hindi magkapareho ang bagong passwords.", "New passwords do not match.")];
    }

    if (password_verify($newPassword, $account["passwordHash"] ?? "")) {
        return ["ok" => false, "message" => msg("New password must be different from the current password.", "Dapat iba ang bagong password sa kasalukuyang password.", "New password must be different from the current password.")];
    }

    $policyMessage = password_policy_message($newPassword, $account);

    if ($policyMessage !== "") {
        return ["ok" => false, "message" => $policyMessage];
    }

    $account["passwordHash"] = password_hash($newPassword, PASSWORD_DEFAULT);
    $account["mustChangePassword"] = false;
    $account["passwordTemporary"] = false;
    $account["passwordChangedAt"] = date("c");
    $account["temporaryPasswordIssuedAt"] = "";
    $account["passwordResetTokenHash"] = "";
    $account["passwordResetExpiresAt"] = "";
    $account["passwordResetUsedAt"] = "";
    $account["otpHash"] = "";
    $account["otpPurpose"] = "";
    $account["otpExpiresAt"] = "";
    $account["otpAttempts"] = 0;
    $account["failedLoginAttempts"] = 0;
    $account["lockoutUntil"] = "";
    password_change_clear_account_state($account, true, true);
    $account["updatedAt"] = date("c");

    if (!update_record_by_id("users", $userId, $account)) {
        return ["ok" => false, "message" => msg("Unable to change password.", "Hindi napalitan ang password.", "Unable to change password.")];
    }

    password_change_clear_session_state($userId);

    if (isset($_SESSION["user"]) && (string)($_SESSION["user"]["id"] ?? "") === $userId) {
        $_SESSION["user"]["mustChangePassword"] = false;
    }

    audit_log(
        $userId,
        "PASSWORD_CHANGED",
        $requiresOtp
            ? "Password changed successfully after recovery-email OTP verification."
            : "Password changed successfully.",
        [
            "category" => "security",
            "otpVerified" => $requiresOtp,
            "role" => (string)($account["role"] ?? "")
        ]
    );

    return [
        "ok" => true,
        "otpVerified" => $requiresOtp,
        "message" => msg("Password changed successfully.", "Matagumpay na napalitan ang password.", "Password changed successfully.")
    ];
}

function update_profile($userId, $post) {
    $userId = trim((string)$userId);
    $name = safe_text($post["name"] ?? "", 120);
    $birthDate = safe_text($post["birthDate"] ?? "", 20);
    $contactNumber = safe_text($post["contactNumber"] ?? "", 40);
    $details = safe_text($post["details"] ?? "", 700);

    if ($name === "") {
        return ["ok" => false, "message" => msg("Complete your name.", "Kumpletuhin ang pangalan.", "Complete your name.")];
    }

    if ($birthDate !== "") {
        if (!kaakbay_valid_date_value($birthDate)) {
            return ["ok" => false, "message" => msg("Enter a valid birth date.", "Maglagay ng wastong birth date.", "Enter a valid birth date.")];
        }

        if ($birthDate > date("Y-m-d")) {
            return ["ok" => false, "message" => msg("Birth date cannot be in the future.", "Hindi maaaring nasa hinaharap ang birth date.", "Birth date cannot be in the future.")];
        }
    }

    if (!kaakbay_valid_ph_mobile_number($contactNumber)) {
        return ["ok" => false, "message" => msg("Enter a valid Philippine mobile number using 09XXXXXXXXX or +639XXXXXXXXX.", "Maglagay ng wastong Philippine mobile number gamit ang 09XXXXXXXXX o +639XXXXXXXXX.", "Enter a valid Philippine mobile number using 09XXXXXXXXX or +639XXXXXXXXX.")];
    }

    $account = find_user_by_id($userId);

    if (!$account) {
        return ["ok" => false, "message" => msg("User account was not found.", "Hindi nakita ang user account.", "User account was not found.")];
    }

    $loginEmail = strtolower(trim((string)($account["email"] ?? "")));

    if ($loginEmail === "" || !filter_var($loginEmail, FILTER_VALIDATE_EMAIL)) {
        return ["ok" => false, "message" => msg("The account login email is invalid.", "Invalid ang login email ng account.", "The account login email is invalid.")];
    }

    $account["pendingEmail"] = "";
    $account["emailVerificationTokenHash"] = "";
    $account["emailVerificationExpiresAt"] = "";
    $account["emailVerificationRequestedAt"] = "";
    $account["name"] = $name;
    $account["birthDate"] = $birthDate;
    $account["contactNumber"] = $contactNumber;
    $account["details"] = $details;
    $account["updatedAt"] = date("c");

    if (!update_record_by_id("users", $userId, $account)) {
        return ["ok" => false, "message" => msg("Unable to save profile.", "Hindi ma-save ang profile.", "Unable to save profile.")];
    }

    if (isset($_SESSION["user"]) && (string)($_SESSION["user"]["id"] ?? "") === $userId) {
        $_SESSION["user"]["name"] = $name;
        $_SESSION["user"]["email"] = $loginEmail;
    }

    audit_log($userId, "PROFILE_UPDATED", "Profile updated.", ["category" => "account"]);

    return [
        "ok" => true,
        "message" => msg("Profile saved.", "Nai-save ang profile.", "Profile saved."),
        "emailChangePending" => false
    ];
}

function available_sections_from_users($users = null) {
    $sections = [];

    if (function_exists("active_sections_list")) {
        foreach (active_sections_list() as $section) {
            $name = trim((string)($section["name"] ?? ""));

            if ($name !== "") {
                $sections[] = $name;
            }
        }
    }

    $users = $users ?? read_records("users");

    foreach ($users as $user) {
        $section = trim((string)($user["section"] ?? ""));

        if ($section !== "" && strtolower($section) !== "all") {
            $sections[] = $section;
        }

        $managed = array_filter(array_map("trim", explode(",", $user["managedSections"] ?? "")));

        foreach ($managed as $item) {
            if ($item !== "") {
                $sections[] = $item;
            }
        }
    }

    $sections = array_values(array_unique($sections));
    sort($sections);

    return $sections;
}

function sections_list($includeInactive = false) {
    $sections = read_records("sections");

    if (!$includeInactive) {
        $sections = array_values(array_filter($sections, function($section) {
            return ($section["status"] ?? "Active") === "Active";
        }));
    }

    usort($sections, function($a, $b) {
        $aValue = strtolower(trim(($a["gradeLevel"] ?? "") . " " . ($a["strand"] ?? "") . " " . ($a["name"] ?? "")));
        $bValue = strtolower(trim(($b["gradeLevel"] ?? "") . " " . ($b["strand"] ?? "") . " " . ($b["name"] ?? "")));
        return $aValue <=> $bValue;
    });

    return $sections;
}

function active_sections_list() {
    return sections_list(false);
}

function section_names_list() {
    $names = [];

    foreach (active_sections_list() as $section) {
        $name = trim((string)($section["name"] ?? ""));

        if ($name !== "") {
            $names[] = $name;
        }
    }

    $names = array_values(array_unique($names));
    sort($names);

    return $names;
}

function find_section_by_name($name) {
    $target = strtolower(trim((string)$name));

    if ($target === "") {
        return null;
    }

    foreach (sections_list(true) as $section) {
        if (strtolower(trim((string)($section["name"] ?? ""))) === $target) {
            return $section;
        }
    }

    return null;
}

function create_section($post) {
    $name = strtoupper(safe_text($post["name"] ?? $post["section"] ?? "", 40));
    $strand = safe_text($post["strand"] ?? "", 80);
    $gradeLevel = safe_text($post["gradeLevel"] ?? "", 40);

    if ($name === "" || $strand === "" || $gradeLevel === "") {
        return ["ok" => false, "message" => msg("Complete section name, strand, and grade level.", "Kumpletuhin ang section name, strand, at grade level.", "Complete section name, strand, and grade level.")];
    }

    $existing = find_section_by_name($name);

    if ($existing && ($existing["status"] ?? "Active") === "Active") {
        return ["ok" => false, "message" => msg("Section already exists.", "May ganitong section na.", "Section already exists.")];
    }

    if ($existing) {
        $existing["name"] = $name;
        $existing["strand"] = $strand;
        $existing["gradeLevel"] = $gradeLevel;
        $existing["status"] = "Active";
        $existing["updatedAt"] = date("c");
        update_record_by_id("sections", $existing["id"] ?? "", $existing);
        return ["ok" => true, "message" => msg("Section saved.", "Nai-save ang section.", "Section saved.")];
    }

    append_record("sections", [
        "id" => "sec-" . strtolower(preg_replace("/[^a-zA-Z0-9]+/", "-", $name)) . "-" . bin2hex(random_bytes(2)),
        "name" => $name,
        "strand" => $strand,
        "gradeLevel" => $gradeLevel,
        "status" => "Active",
        "createdAt" => date("c"),
        "updatedAt" => date("c")
    ]);

    return ["ok" => true, "message" => msg("Section saved.", "Nai-save ang section.", "Section saved.")];
}

function delete_section($sectionId) {
    $sectionId = safe_text($sectionId, 80);

    if ($sectionId === "") {
        return ["ok" => false, "message" => msg("Section not found.", "Hindi nakita ang section.", "Section not found.")];
    }

    $section = find_storage_record_by_id("sections", $sectionId);

    if (!$section) {
        return ["ok" => false, "message" => msg("Section not found.", "Hindi nakita ang section.", "Section not found.")];
    }

    $section["status"] = "Inactive";
    $section["updatedAt"] = date("c");
    update_record_by_id("sections", $sectionId, $section);

    return ["ok" => true, "message" => msg("Section removed.", "Na-remove ang section.", "Section removed.")];
}

function available_sections_from_storage() {
    return section_names_list();
}

function find_teacher_name($teacherId) {
    $teacher = find_user_by_id($teacherId);

    if (!$teacher) {
        return "";
    }

    return $teacher["name"] ?? "";
}

function language_options() {
    return [
        "en" => "English",
        "tl" => "Tagalog",
        "tg" => "Taglish"
    ];
}

function save_language_preference($lang) {
    if (!array_key_exists($lang, language_options())) {
        $lang = "en";
    }

    $_SESSION["lang"] = $lang;

    return true;
}

function day_index($day) {
    $days = array_flip(week_days());
    return $days[$day] ?? 0;
}

function grading_periods() {
    return ["Quarter 1", "Quarter 2", "Quarter 3", "Quarter 4"];
}

function strands() {
    return ["ABM", "HUMSS", "STEM", "GAS", "TVL", "Arts and Design", "Sports"];
}

function grade_levels() {
    return ["Grade 11", "Grade 12"];
}

function assessment_types() {
    return ["Written Work", "Performance Task", "Quarterly Assessment", "Competency Check"];
}

function submission_statuses() {
    return ["Submitted", "Incomplete", "Missing"];
}

function attendance_statuses() {
    return ["Present", "Absent", "Excused"];
}

function validation_statuses() {
    return ["Consistent", "Needs Review", "Not Consistent"];
}

function academic_status_options() {
    return ["Regular", "Warning Status", "At-Risk / Failing"];
}

function competency_status_options() {
    return ["Mastered", "Nearing Mastery", "Not Mastered / Remediation Needed"];
}

function attendance_status_options() {
    return ["Regular Attendance", "Attendance Concern"];
}

function workload_status_options() {
    return ["Magaan", "Katamtaman", "Mabigat"];
}

function requirement_status_options() {
    return ["Complete Requirements", "Incomplete Requirements"];
}

function trend_status_options() {
    return ["Insufficient Trend Data", "Stable Performance Pattern", "Improving Performance Pattern", "Declining Performance Pattern"];
}

function follow_up_type_options() {
    return ["Regular Monitoring", "Monitoring", "Remediation", "Requirement Follow-up", "Performance Monitoring", "Attendance Follow-up", "Workload Follow-up"];
}

function task_status_options() {
    return ["Not Started", "In Progress", "Rescheduled", "Completed"];
}

function monitoring_search_text($row) {
    $student = $row["student"] ?? [];
    $latest = $row["latest"] ?? [];
    $workload = $row["workload"] ?? [];

    return strtolower(trim(
        ($student["code"] ?? "") . " " .
        ($student["name"] ?? "") . " " .
        ($student["email"] ?? "") . " " .
        ($student["strand"] ?? "") . " " .
        ($student["section"] ?? "") . " " .
        ($latest["subject"] ?? "") . " " .
        ($latest["academicStatus"] ?? "") . " " .
        ($latest["competencyStatus"] ?? "") . " " .
        ($latest["attendanceStatus"] ?? "") . " " .
        ($latest["requirementStatus"] ?? "") . " " .
        ($latest["trendStatus"] ?? "") . " " .
        ($workload["lingguhangBigatIndex"] ?? "") . " " .
        ($row["followUpType"] ?? "")
    ));
}

function filter_monitoring_rows($rows, $filters) {
    $filtered = [];

    foreach ($rows as $row) {
        $student = $row["student"] ?? [];
        $latest = $row["latest"] ?? [];
        $workload = $row["workload"] ?? [];

        if (($filters["q"] ?? "") !== "" && strpos(monitoring_search_text($row), strtolower($filters["q"])) === false) {
            continue;
        }

        if (($filters["gradeStatus"] ?? "") !== "" && (($latest["academicStatus"] ?? "") !== $filters["gradeStatus"])) {
            continue;
        }

        if (($filters["competencyStatus"] ?? "") !== "" && (($latest["competencyStatus"] ?? "") !== $filters["competencyStatus"])) {
            continue;
        }

        if (($filters["attendanceStatus"] ?? "") !== "" && (($latest["attendanceStatus"] ?? "") !== $filters["attendanceStatus"])) {
            continue;
        }

        if (($filters["workloadStatus"] ?? "") !== "" && (($workload["lingguhangBigatIndex"] ?? "") !== $filters["workloadStatus"])) {
            continue;
        }

        if (($filters["requirementStatus"] ?? "") !== "" && (($latest["requirementStatus"] ?? "") !== $filters["requirementStatus"])) {
            continue;
        }

        if (($filters["trendStatus"] ?? "") !== "" && (($latest["trendStatus"] ?? "") !== $filters["trendStatus"])) {
            continue;
        }

        if (($filters["followUpType"] ?? "") !== "" && (($row["followUpType"] ?? "") !== $filters["followUpType"])) {
            continue;
        }

        if (($filters["strand"] ?? "") !== "" && stripos($student["strand"] ?? "", $filters["strand"]) === false) {
            continue;
        }

        if (($filters["section"] ?? "") !== "" && stripos($student["section"] ?? "", $filters["section"]) === false) {
            continue;
        }

        if (($filters["subject"] ?? "") !== "" && stripos($latest["subject"] ?? "", $filters["subject"]) === false) {
            continue;
        }

        $filtered[] = $row;
    }

    return $filtered;
}

function validation_search_text($validation) {
    return strtolower(trim(
        ($validation["subject"] ?? "") . " " .
        ($validation["systemOutput"] ?? "") . " " .
        ($validation["validationStatus"] ?? "") . " " .
        ($validation["note"] ?? "") . " " .
        ($validation["itemAnalysisNotes"] ?? "") . " " .
        ($validation["competencyArea"] ?? "") . " " .
        ($validation["followUpPlan"] ?? "")
    ));
}

function filter_validations($validations, $filters) {
    $filtered = [];

    foreach ($validations as $validation) {
        if (($filters["q"] ?? "") !== "" && strpos(validation_search_text($validation), strtolower($filters["q"])) === false) {
            continue;
        }

        if (($filters["validationStatus"] ?? "") !== "" && (($validation["validationStatus"] ?? "") !== $filters["validationStatus"])) {
            continue;
        }

        if (($filters["subject"] ?? "") !== "" && stripos($validation["subject"] ?? "", $filters["subject"]) === false) {
            continue;
        }

        $filtered[] = $validation;
    }

    return $filtered;
}

function active_filter_count($filters) {
    $count = 0;

    foreach ($filters as $value) {
        if (trim((string)$value) !== "") {
            $count++;
        }
    }

    return $count;
}

function dashboard_student_latest($studentId) {
    $records = academic_record_history_for_student($studentId);

    foreach ($records as $record) {
        if (record_mode_value($record) === "quarterly") {
            return evaluate_record($record);
        }
    }

    if (count($records)) {
        return evaluate_record($records[0]);
    }

    return null;
}

function dashboard_flags_for_student($latest, $workload) {
    if (!$latest) {
        return [];
    }

    $flags = [
        $latest["academicStatus"] ?? "",
        $latest["competencyStatus"] ?? "",
        $latest["attendanceStatus"] ?? "",
        $latest["requirementStatus"] ?? "",
        $latest["trendStatus"] ?? "",
        $workload["lingguhangBigatIndex"] ?? ""
    ];

    return array_values(array_filter($flags, function($flag) {
        return !in_array($flag, [
            "",
            "No Record",
            "Regular",
            "Mastered",
            "Regular Attendance",
            "Complete Requirements",
            "Stable Performance Pattern",
            "Improving Performance Pattern",
            "Insufficient Trend Data",
            "Magaan"
        ], true);
    }));
}

function student_attendance_summary($studentId) {
    $records = attendance_for_student($studentId);
    $summary = [];

    foreach ($records as $record) {
        $subject = trim((string)($record["subject"] ?? "Unassigned Subject"));
        $scheduleId = trim((string)($record["scheduleId"] ?? ""));
        $keys = [$subject];

        if ($scheduleId !== "") {
            $keys[] = "schedule:" . $scheduleId;
        }

        foreach (array_values(array_unique($keys)) as $key) {
            if (!isset($summary[$key])) {
                $summary[$key] = [
                    "subject" => $subject,
                    "scheduleId" => $scheduleId,
                    "marked" => 0,
                    "present" => 0,
                    "absent" => 0,
                    "excused" => 0,
                    "absenceRate" => 0,
                    "consecutiveAbsences" => 0,
                    "attendanceStatus" => "No Record",
                    "records" => []
                ];
            }

            $summary[$key]["records"][] = $record;

            if (in_array($record["status"] ?? "", ["Present", "Absent", "Excused"], true)) {
                $summary[$key]["marked"]++;
            }

            if (($record["status"] ?? "") === "Present") {
                $summary[$key]["present"]++;
            }

            if (($record["status"] ?? "") === "Absent") {
                $summary[$key]["absent"]++;
            }

            if (($record["status"] ?? "") === "Excused") {
                $summary[$key]["excused"]++;
            }
        }
    }

    foreach ($summary as &$item) {
        $item["absenceRate"] = compute_absence_rate_from_attendance($item["records"]);
        $item["consecutiveAbsences"] = compute_consecutive_absences_from_attendance($item["records"]);
        $item["attendanceStatus"] = $item["marked"] > 0 ? attendance_status($item["absenceRate"], $item["consecutiveAbsences"]) : "No Record";
    }

    unset($item);

    return $summary;
}

function latest_validation_for_record($recordId) {
    $recordId = trim((string)$recordId);

    if ($recordId === "") {
        return null;
    }

    $validations = read_records_where("validations", ["recordId" => $recordId], "coalesce(data->>'createdAt', '') desc, created_at desc, id desc");

    usort($validations, function($a, $b) {
        return strtotime($b["createdAt"] ?? "now") <=> strtotime($a["createdAt"] ?? "now");
    });

    return $validations[0] ?? null;
}


function record_has_teacher_validation($recordId) {
    return latest_validation_for_record($recordId) !== null;
}

function academic_record_delete_grace_seconds() {
    return 5 * 60;
}

function academic_record_created_timestamp($record) {
    if (!is_array($record)) {
        return 0;
    }

    $createdAt = trim((string)($record["createdAt"] ?? ""));

    if ($createdAt === "") {
        return 0;
    }

    $timestamp = strtotime($createdAt);

    return $timestamp === false ? 0 : $timestamp;
}

function academic_record_direct_delete_remaining_seconds($record) {
    if (!is_array($record)) {
        return 0;
    }

    $recordId = trim((string)($record["id"] ?? ""));

    if ($recordId === "" || record_has_teacher_validation($recordId)) {
        return 0;
    }

    $createdTimestamp = academic_record_created_timestamp($record);

    if ($createdTimestamp <= 0) {
        return 0;
    }

    return max(0, ($createdTimestamp + academic_record_delete_grace_seconds()) - time());
}

function academic_record_can_direct_delete($record, $studentId = "") {
    if (!is_array($record)) {
        return false;
    }

    $studentId = trim((string)$studentId);

    if ($studentId !== "" && ($record["studentId"] ?? "") !== $studentId) {
        return false;
    }

    return academic_record_direct_delete_remaining_seconds($record) > 0;
}

function teacher_validation_map_for_records($records) {
    $map = [];

    foreach ($records as $record) {
        $recordId = $record["id"] ?? "";

        if ($recordId !== "") {
            $map[$recordId] = latest_validation_for_record($recordId);
        }
    }

    return $map;
}

function delete_requests_for_student($studentId) {
    $studentId = trim((string)$studentId);
    $requests = read_records_where("delete_requests", ["studentId" => $studentId], "coalesce(data->>'updatedAt', data->>'createdAt', '') desc, updated_at desc, id desc");

    usort($requests, function($a, $b) {
        return strtotime($b["updatedAt"] ?? $b["createdAt"] ?? "now") <=> strtotime($a["updatedAt"] ?? $a["createdAt"] ?? "now");
    });

    return $requests;
}

function latest_delete_request_for_record($recordId, $studentId = "") {
    $recordId = trim((string)$recordId);
    $studentId = trim((string)$studentId);

    if ($recordId === "") {
        return null;
    }

    $criteria = ["recordId" => $recordId];

    if ($studentId !== "") {
        $criteria["studentId"] = $studentId;
    }

    $requests = read_records_where("delete_requests", $criteria, "coalesce(data->>'updatedAt', data->>'createdAt', '') desc, updated_at desc, id desc");

    if (!count($requests)) {
        return null;
    }

    usort($requests, function($a, $b) {
        return strtotime($b["updatedAt"] ?? $b["createdAt"] ?? "now") <=> strtotime($a["updatedAt"] ?? $a["createdAt"] ?? "now");
    });

    return $requests[0];
}

function delete_request_for_record($recordId, $studentId = "") {
    return latest_delete_request_for_record($recordId, $studentId);
}

function record_has_pending_delete_request($recordId, $studentId = "") {
    $request = latest_delete_request_for_record($recordId, $studentId);
    return $request && (($request["status"] ?? "") === "Pending");
}

function delete_request_map_for_records($records, $studentId = "") {
    $map = [];

    foreach ($records as $record) {
        $recordId = $record["id"] ?? "";

        if ($recordId !== "") {
            $map[$recordId] = latest_delete_request_for_record($recordId, $studentId);
        }
    }

    return $map;
}

function academic_record_delete_request_snapshot($record) {
    if (!is_array($record)) {
        return [];
    }

    $allowedFields = [
        "id",
        "studentId",
        "recordMode",
        "subject",
        "strand",
        "gradeLevel",
        "gradingPeriod",
        "assessmentType",
        "assessmentTitle",
        "score",
        "totalScore",
        "assessmentPercentage",
        "submissionStatus",
        "assessmentDate",
        "competencyName",
        "competencyCorrect",
        "competencyTotal",
        "competencyMastery",
        "validationStatus",
        "createdAt",
        "updatedAt"
    ];

    $snapshot = [];

    foreach ($allowedFields as $field) {
        if (array_key_exists($field, $record)) {
            $snapshot[$field] = $record[$field];
        }
    }

    return $snapshot;
}

function save_record_delete_request($studentId, $recordId, $reason = "") {
    $studentId = safe_text($studentId, 80);
    $recordId = safe_text($recordId, 80);
    $reason = safe_text($reason, 700);

    if ($studentId === "" || $recordId === "") {
        return ["ok" => false, "message" => msg("Select a record to request deletion.", "Pumili ng record para humiling ng deletion.", "Select a record to request deletion.")];
    }

    $target = find_record_by_id($recordId);

    if ($target && ($target["studentId"] ?? "") !== $studentId) {
        $target = null;
    }

    if (!$target) {
        return ["ok" => false, "message" => msg("Record not found.", "Hindi nahanap ang record.", "Record not found.")];
    }

    if (academic_record_can_direct_delete($target, $studentId)) {
        return ["ok" => false, "message" => msg(
            "This record is still within the 5-minute deletion window. You may delete it directly.",
            "Pasok pa sa 5-minute deletion window ang record na ito. Maaari mo pa itong burahin nang direkta.",
            "This record is still within the 5-minute deletion window. You may delete it directly."
        )];
    }

    if ($reason === "") {
        return ["ok" => false, "message" => msg("Enter a reason for the deletion request.", "Maglagay ng dahilan para sa deletion request.", "Enter a reason for the deletion request.")];
    }

    $requests = read_records("delete_requests");
    $snapshot = academic_record_delete_request_snapshot($target);

    foreach ($requests as &$request) {
        if (($request["recordId"] ?? "") === $recordId && ($request["studentId"] ?? "") === $studentId && ($request["status"] ?? "") === "Pending") {
            $request["reason"] = $reason;
            $request["recordSnapshot"] = $request["recordSnapshot"] ?? $snapshot;
            $request["updatedAt"] = date("c");
            write_records("delete_requests", $requests);
            return ["ok" => true, "message" => msg("Deletion request updated.", "Na-update ang deletion request.", "Deletion request updated.")];
        }
    }

    unset($request);

    $requests[] = [
        "id" => "del-" . time() . "-" . bin2hex(random_bytes(3)),
        "studentId" => $studentId,
        "recordId" => $recordId,
        "subject" => $target["subject"] ?? "",
        "assessmentType" => $target["assessmentType"] ?? "",
        "assessmentTitle" => $target["assessmentTitle"] ?? "",
        "reason" => $reason,
        "status" => "Pending",
        "requestedBy" => $studentId,
        "reviewedBy" => "",
        "reviewNote" => "",
        "reviewedAt" => "",
        "recordSnapshot" => $snapshot,
        "createdAt" => date("c"),
        "updatedAt" => date("c")
    ];

    write_records("delete_requests", $requests);

    return ["ok" => true, "message" => msg("Deletion request submitted.", "Naisumite ang deletion request.", "Deletion request submitted.")];
}

function delete_academic_record($studentId, $recordId, $force = false) {
    $studentId = safe_text($studentId, 80);
    $recordId = safe_text($recordId, 80);

    if ($studentId === "" || $recordId === "") {
        return ["ok" => false, "message" => msg("Record not found.", "Hindi nahanap ang record.", "Record not found.")];
    }

    $target = find_record_by_id($recordId);

    if (!$target || ($target["studentId"] ?? "") !== $studentId) {
        return ["ok" => false, "message" => msg("Record not found.", "Hindi nahanap ang record.", "Record not found.")];
    }

    if (!$force && !academic_record_can_direct_delete($target, $studentId)) {
        if (record_has_teacher_validation($recordId)) {
            return ["ok" => false, "message" => msg(
                "This record has already been checked by a teacher. Submit a deletion request instead.",
                "Na-check na ng guro ang record na ito. Mag-submit muna ng deletion request.",
                "This record has already been checked by a teacher. Submit a deletion request instead."
            )];
        }

        return ["ok" => false, "message" => msg(
            "The 5-minute direct deletion window has expired. Submit a deletion request for teacher approval.",
            "Tapos na ang 5-minute direct deletion window. Mag-submit ng deletion request para sa approval ng guro.",
            "The 5-minute direct deletion window has expired. Submit a deletion request for teacher approval."
        )];
    }

    if (!delete_record_by_id("academic_records", $recordId)) {
        return ["ok" => false, "message" => msg("Unable to delete the record.", "Hindi mabura ang record.", "Unable to delete the record.")];
    }

    if ($force) {
        $validations = read_records("validations");
        $remainingValidations = array_values(array_filter(
            $validations,
            fn($validation) => ($validation["recordId"] ?? "") !== $recordId
        ));

        if (count($remainingValidations) !== count($validations)) {
            write_records("validations", $remainingValidations);
        }
    }

    return ["ok" => true, "message" => msg("Record deleted.", "Nabura ang record.", "Record deleted.")];
}

function deletion_requests_for_review($status = "") {
    $status = trim((string)$status);
    $requests = $status !== "" ? read_records_where("delete_requests", ["status" => $status], "coalesce(data->>'updatedAt', data->>'createdAt', '') desc, updated_at desc, id desc") : read_records("delete_requests");

    usort($requests, function($a, $b) {
        return strtotime($b["updatedAt"] ?? $b["createdAt"] ?? "now") <=> strtotime($a["updatedAt"] ?? $a["createdAt"] ?? "now");
    });

    return $requests;
}

function review_record_delete_request($requestId, $reviewedBy, $decision, $reviewNote = "") {
    $requestId = safe_text($requestId, 80);
    $reviewedBy = safe_text($reviewedBy, 80);
    $decision = safe_text($decision, 30);
    $reviewNote = safe_text($reviewNote, 700);

    if ($requestId === "" || !in_array($decision, ["Approved", "Rejected"], true)) {
        return ["ok" => false, "message" => msg("Select a valid deletion request decision.", "Pumili ng wastong decision para sa deletion request.", "Select a valid deletion request decision.")];
    }

    if ($decision === "Rejected" && $reviewNote === "") {
        return ["ok" => false, "message" => msg(
            "Enter a review note when rejecting a deletion request.",
            "Maglagay ng review note kapag nire-reject ang deletion request.",
            "Enter a review note when rejecting a deletion request."
        )];
    }

    $requests = read_records("delete_requests");
    $targetIndex = null;

    foreach ($requests as $index => $request) {
        if (($request["id"] ?? "") === $requestId) {
            $targetIndex = $index;
            break;
        }
    }

    if ($targetIndex === null) {
        return ["ok" => false, "message" => msg("Deletion request not found.", "Hindi nahanap ang deletion request.", "Deletion request not found.")];
    }

    $target = $requests[$targetIndex];

    if (($target["status"] ?? "Pending") !== "Pending") {
        return ["ok" => false, "message" => msg(
            "This deletion request has already been reviewed.",
            "Na-review na ang deletion request na ito.",
            "This deletion request has already been reviewed."
        )];
    }

    if ($decision === "Approved") {
        $deleteResult = delete_academic_record(
            $target["studentId"] ?? "",
            $target["recordId"] ?? "",
            true
        );

        if (empty($deleteResult["ok"])) {
            return $deleteResult;
        }
    }

    $now = date("c");
    $requests[$targetIndex]["status"] = $decision;
    $requests[$targetIndex]["reviewedBy"] = $reviewedBy;
    $requests[$targetIndex]["reviewNote"] = $reviewNote;
    $requests[$targetIndex]["reviewedAt"] = $now;
    $requests[$targetIndex]["updatedAt"] = $now;

    write_records("delete_requests", $requests);

    return [
        "ok" => true,
        "message" => $decision === "Approved"
            ? msg("Deletion request approved.", "Na-approve ang deletion request.", "Deletion request approved.")
            : msg("Deletion request rejected.", "Na-reject ang deletion request.", "Deletion request rejected.")
    ];
}

function approve_record_delete_request($requestId, $reviewedBy, $reviewNote = "") {
    return review_record_delete_request($requestId, $reviewedBy, "Approved", $reviewNote);
}

function reject_record_delete_request($requestId, $reviewedBy, $reviewNote = "") {
    return review_record_delete_request($requestId, $reviewedBy, "Rejected", $reviewNote);
}

function latest_validation_for_student_subject($studentId, $subject) {
    $validations = array_values(array_filter(read_records("validations"), function($validation) use ($studentId, $subject) {
        return ($validation["studentId"] ?? "") === $studentId
            && strtolower(trim((string)($validation["subject"] ?? ""))) === strtolower(trim((string)$subject));
    }));

    usort($validations, function($a, $b) {
        return strtotime($b["createdAt"] ?? "now") <=> strtotime($a["createdAt"] ?? "now");
    });

    return $validations[0] ?? null;
}

function validation_status_for_row($row) {
    $latest = $row["latest"] ?? null;

    if (!$latest) {
        return "Needs Review";
    }

    $validation = latest_validation_for_record($latest["id"] ?? "");

    if (!$validation) {
        $validation = latest_validation_for_student_subject($row["student"]["id"] ?? "", $latest["subject"] ?? "");
    }

    return $validation["validationStatus"] ?? "Needs Review";
}

function row_needs_validation($row) {
    $latest = $row["latest"] ?? null;

    if (!$latest) {
        return true;
    }

    if (count($row["flags"] ?? []) > 0) {
        return true;
    }

    if (($latest["requirementStatus"] ?? "") === "Incomplete Requirements") {
        return true;
    }

    if (($latest["trendStatus"] ?? "") === "Declining Performance Pattern") {
        return true;
    }

    if (($row["workload"]["lingguhangBigatIndex"] ?? "") === "Mabigat") {
        return true;
    }

    return validation_status_for_row($row) !== "Consistent";
}

function teacher_item_analysis_for_student($studentId, $subject = "") {
    $validations = array_values(array_filter(read_records_where("validations", ["studentId" => $studentId], "coalesce(data->>'createdAt', '') desc, created_at desc, id desc"), function($validation) use ($subject) {
        $sameSubject = $subject === "" || strtolower(trim((string)($validation["subject"] ?? ""))) === strtolower(trim((string)$subject));
        $hasAnalysis = trim((string)($validation["itemAnalysisNotes"] ?? "")) !== "" || trim((string)($validation["competencyArea"] ?? "")) !== "";
        return $sameSubject && $hasAnalysis;
    }));

    usort($validations, function($a, $b) {
        return strtotime($b["createdAt"] ?? "now") <=> strtotime($a["createdAt"] ?? "now");
    });

    return $validations;
}


function computed_quarterly_summaries($studentId) {
    return computed_quarterly_summaries_for_student($studentId);
}

function clamp_number($value, $min, $max) {
    $value = (float)$value;
    return max($min, min($max, $value));
}

function format_ratio($value) {
    return number_format((float)$value, 2, ".", "");
}

function format_percent($value) {
    return number_format((float)$value, 2, ".", "");
}

function format_hours($value) {
    return number_format((float)$value, 2, ".", "");
}

function display_date($date) {
    $time = strtotime($date);

    if (!$time) {
        return "--";
    }

    return date("M d, Y", $time);
}

function display_datetime($date) {
    $time = strtotime($date);

    if (!$time) {
        return "--";
    }

    return date("M d, Y g:i A", $time);
}

function role_label($role) {
    $role = strtolower((string)$role);

    if ($role === "super_admin") {
        return msg("Super Administrator", "Super Administrator", "Super Administrator");
    }

    if ($role === "it_admin") {
        return msg("IT Administrator", "IT Administrator", "IT Administrator");
    }

    if ($role === "admin") {
        return msg("Administrator", "Administrator", "Administrator");
    }

    if ($role === "teacher") {
        return msg("Teacher", "Guro", "Teacher");
    }

    if ($role === "student") {
        return msg("Student", "Mag-aaral", "Student");
    }

    return ucfirst(str_replace("_", " ", $role));
}

function status_is_flagged($status) {
    return in_array(view_state_tone($status), ["warning", "danger", "critical"], true);
}

function unique_subjects_from_records($records) {
    $subjects = [];

    foreach ($records as $record) {
        $subject = trim((string)($record["subject"] ?? ""));

        if ($subject !== "") {
            $subjects[] = $subject;
        }
    }

    $subjects = array_values(array_unique($subjects));
    sort($subjects);

    return $subjects;
}

function unique_grading_periods_from_records($records) {
    $periods = [];

    foreach ($records as $record) {
        $period = trim((string)($record["gradingPeriod"] ?? ""));

        if ($period !== "") {
            $periods[] = $period;
        }
    }

    $periods = array_values(array_unique($periods));

    usort($periods, function($a, $b) {
        return array_search($a, grading_periods(), true) <=> array_search($b, grading_periods(), true);
    });

    return $periods;
}

function academic_component_breakdown($record) {
    if (record_mode_value($record) === "assessment") {
        return [
            [
                "label" => $record["assessmentType"] ?? "Assessment",
                "score" => $record["score"] ?? 0,
                "total" => $record["totalScore"] ?? 0,
                "percentage" => $record["assessmentPercentage"] ?? compute_assessment_percentage($record)
            ]
        ];
    }

    return [
        [
            "label" => "Written Works",
            "score" => $record["writtenWorks"] ?? 0,
            "total" => $record["writtenWorksTotal"] ?? 0,
            "percentage" => $record["writtenWorksPercentage"] ?? component_percentage($record, "writtenWorks", "writtenWorksTotal")
        ],
        [
            "label" => "Performance Tasks",
            "score" => $record["performanceTasks"] ?? 0,
            "total" => $record["performanceTasksTotal"] ?? 0,
            "percentage" => $record["performanceTasksPercentage"] ?? component_percentage($record, "performanceTasks", "performanceTasksTotal")
        ],
        [
            "label" => "Quarterly Assessment",
            "score" => $record["quarterlyAssessment"] ?? 0,
            "total" => $record["quarterlyAssessmentTotal"] ?? 0,
            "percentage" => $record["quarterlyAssessmentPercentage"] ?? component_percentage($record, "quarterlyAssessment", "quarterlyAssessmentTotal")
        ]
    ];
}

function task_breakdown_summary($task) {
    $subtasks = $task["subtasks"] ?? [];
    $completed = 0;

    foreach ($subtasks as $subtask) {
        if (($subtask["status"] ?? "") === "Completed") {
            $completed++;
        }
    }

    return [
        "total" => count($subtasks),
        "completed" => $completed,
        "pending" => max(0, count($subtasks) - $completed)
    ];
}

function security_request_context() {
    $ip = trim((string)($_SERVER["REMOTE_ADDR"] ?? ""));
    $userAgent = trim((string)($_SERVER["HTTP_USER_AGENT"] ?? ""));
    $method = strtoupper(trim((string)($_SERVER["REQUEST_METHOD"] ?? "")));
    $uri = trim((string)($_SERVER["REQUEST_URI"] ?? ""));

    if (strlen($ip) > 64) {
        $ip = substr($ip, 0, 64);
    }

    if (strlen($userAgent) > 300) {
        $userAgent = substr($userAgent, 0, 300);
    }

    if (strlen($method) > 12) {
        $method = substr($method, 0, 12);
    }

    if (strlen($uri) > 500) {
        $uri = substr($uri, 0, 500);
    }

    return [
        "ipAddress" => $ip,
        "userAgent" => $userAgent,
        "requestMethod" => $method,
        "requestUri" => $uri,
        "sessionIdHash" => session_id() !== "" ? hash("sha256", session_id()) : ""
    ];
}

function audit_metadata_value($value, $depth = 0) {
    if ($depth > 3) {
        return "";
    }

    if (is_bool($value) || is_int($value) || is_float($value) || $value === null) {
        return $value;
    }

    if (is_array($value)) {
        $output = [];

        foreach (array_slice($value, 0, 30, true) as $key => $item) {
            $safeKey = preg_replace('/[^A-Za-z0-9_.-]/', '', (string)$key);

            if ($safeKey === "") {
                continue;
            }

            if (preg_match('/password|secret|token|otp|authorization|cookie|credential/i', $safeKey)) {
                $output[$safeKey] = "[REDACTED]";
                continue;
            }

            $output[$safeKey] = audit_metadata_value($item, $depth + 1);
        }

        return $output;
    }

    $value = trim(strip_tags((string)$value));

    if (strlen($value) > 700) {
        $value = substr($value, 0, 700);
    }

    return $value;
}

function audit_log($userId, $action, $details = "", $metadata = []) {
    $context = security_request_context();
    $metadata = is_array($metadata) ? audit_metadata_value($metadata) : [];
    $category = safe_text($metadata["category"] ?? "general", 60);

    if (isset($metadata["category"])) {
        unset($metadata["category"]);
    }

    $detailValue = is_array($details)
        ? audit_metadata_value($details)
        : safe_text($details, 1000);

    $record = [
        "id" => "log-" . time() . "-" . bin2hex(random_bytes(4)),
        "userId" => safe_text($userId, 100),
        "action" => safe_text($action, 120),
        "category" => $category !== "" ? $category : "general",
        "details" => $detailValue,
        "metadata" => $metadata,
        "ipAddress" => $context["ipAddress"],
        "userAgent" => $context["userAgent"],
        "requestMethod" => $context["requestMethod"],
        "requestUri" => $context["requestUri"],
        "sessionIdHash" => $context["sessionIdHash"],
        "createdAt" => date("c")
    ];

    append_record("audit_logs", $record);

    if ($record["category"] === "security" && function_exists("system_log")) {
        system_log("security", "security", $record["action"], $record["userId"], [
            "auditLogId" => $record["id"]
        ]);
    }

    return true;
}

function latest_audit_logs($limit = 20) {
    $limit = max(1, min(100, (int)$limit));
    $table = storage_table("audit_logs");

    if ($table === "") {
        return [];
    }

    try {
        $stmt = db()->prepare("select id, data from public." . $table . " order by coalesce(data->>'createdAt', '') desc, created_at desc, id desc limit " . $limit);
        $stmt->execute();
        return storage_decode_rows($stmt->fetchAll());
    } catch (Throwable $e) {
        $logs = read_records("audit_logs");

        usort($logs, function($a, $b) {
            return strtotime($b["createdAt"] ?? "now") <=> strtotime($a["createdAt"] ?? "now");
        });

        return array_slice($logs, 0, $limit);
    }
}


function system_plain_text($value, $max = 2000) {
    $value = trim(strip_tags((string)$value));
    $value = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $value);

    if (function_exists("mb_substr")) {
        return mb_substr($value, 0, $max);
    }

    return substr($value, 0, $max);
}

function system_bool_value($value, $default = false) {
    if (is_bool($value)) {
        return $value;
    }

    if (is_int($value) || is_float($value)) {
        return (int)$value === 1;
    }

    $value = strtolower(trim((string)$value));

    if (in_array($value, ["1", "true", "yes", "on", "active", "enabled"], true)) {
        return true;
    }

    if (in_array($value, ["0", "false", "no", "off", "inactive", "disabled", ""], true)) {
        return false;
    }

    return (bool)$default;
}

function system_color_value($value, $fallback) {
    $value = strtoupper(trim((string)$value));
    return preg_match('/^#[0-9A-F]{6}$/', $value) ? $value : $fallback;
}

function system_datetime_value($value) {
    $value = trim((string)$value);

    if ($value === "") {
        return "";
    }

    $time = strtotime($value);
    return $time ? date("c", $time) : "";
}

function system_settings_defaults() {
    return [
        "id" => "global",
        "systemName" => "Ka-Akbay",
        "logoUrl" => "",
        "primaryColor" => "#8B1E2D",
        "secondaryColor" => "#F5F5F5",
        "accentColor" => "#D4A017",
        "defaultTheme" => "light",
        "createdAt" => "",
        "updatedAt" => "",
        "updatedBy" => ""
    ];
}

function system_settings_record() {
    $record = find_storage_record_by_id("system_settings", "global");
    return array_merge(system_settings_defaults(), is_array($record) ? $record : []);
}

function save_system_settings($post, $updatedBy) {
    if (!user_has_any_role($updatedBy, ["super_admin"])) {
        return ["ok" => false, "message" => msg("You are not allowed to change system settings.", "Wala kang pahintulot na baguhin ang system settings.", "You are not allowed to change system settings.")];
    }

    $record = system_settings_record();
    $systemName = system_plain_text($post["systemName"] ?? ($record["systemName"] ?? "Ka-Akbay"), 80);
    $logoUrl = array_key_exists("logoUrl", $post) ? system_plain_text($post["logoUrl"], 500) : ($record["logoUrl"] ?? "");
    $defaultTheme = strtolower(trim((string)($post["defaultTheme"] ?? ($record["defaultTheme"] ?? "light"))));

    if (!in_array($defaultTheme, ["light", "dark", "system"], true)) {
        $defaultTheme = "light";
    }

    $record["id"] = "global";
    $record["systemName"] = $systemName !== "" ? $systemName : "Ka-Akbay";
    $record["logoUrl"] = $logoUrl;
    $record["primaryColor"] = system_color_value($post["primaryColor"] ?? ($record["primaryColor"] ?? ""), "#8B1E2D");
    $record["secondaryColor"] = system_color_value($post["secondaryColor"] ?? ($record["secondaryColor"] ?? ""), "#F5F5F5");
    $record["accentColor"] = system_color_value($post["accentColor"] ?? ($record["accentColor"] ?? ""), "#D4A017");
    $record["defaultTheme"] = $defaultTheme;
    $record["createdAt"] = $record["createdAt"] ?: date("c");
    $record["updatedAt"] = date("c");
    $record["updatedBy"] = $updatedBy;

    if (!update_record_by_id("system_settings", "global", $record)) {
        return ["ok" => false, "message" => msg("Unable to save system settings.", "Hindi na-save ang system settings.", "Unable to save system settings.")];
    }

    audit_log($updatedBy, "SYSTEM_SETTINGS_UPDATED", "Branding and theme settings updated.");
    return ["ok" => true, "message" => msg("System settings saved.", "Na-save ang system settings.", "System settings saved.")];
}

function system_content_defaults($contentId) {
    $contentId = trim((string)$contentId);

    if ($contentId === "login_welcome") {
        return [
            "id" => "login_welcome",
            "key" => "loginWelcome",
            "title" => "Welcome to Ka-Akbay",
            "content" => "",
            "isActive" => true,
            "createdAt" => "",
            "updatedAt" => "",
            "updatedBy" => ""
        ];
    }

    if ($contentId === "footer") {
        return [
            "id" => "footer",
            "key" => "footer",
            "title" => "",
            "content" => "Ka-Akbay",
            "isActive" => true,
            "createdAt" => "",
            "updatedAt" => "",
            "updatedBy" => ""
        ];
    }

    return [
        "id" => $contentId,
        "key" => $contentId,
        "title" => "",
        "content" => "",
        "isActive" => true,
        "createdAt" => "",
        "updatedAt" => "",
        "updatedBy" => ""
    ];
}

function system_content_record($contentId) {
    $contentId = preg_replace('/[^A-Za-z0-9_-]/', '', (string)$contentId);

    if ($contentId === "") {
        return null;
    }

    $record = find_storage_record_by_id("system_content", $contentId);
    return array_merge(system_content_defaults($contentId), is_array($record) ? $record : []);
}

function system_content_records() {
    $records = read_records("system_content");

    usort($records, function($a, $b) {
        return strcmp((string)($a["id"] ?? ""), (string)($b["id"] ?? ""));
    });

    return $records;
}

function save_system_content($contentId, $post, $updatedBy) {
    if (!user_has_any_role($updatedBy, ["super_admin"])) {
        return ["ok" => false, "message" => msg("You are not allowed to change system content.", "Wala kang pahintulot na baguhin ang system content.", "You are not allowed to change system content.")];
    }

    $contentId = preg_replace('/[^A-Za-z0-9_-]/', '', (string)$contentId);

    if ($contentId === "") {
        return ["ok" => false, "message" => msg("Invalid content item.", "Hindi wasto ang content item.", "Invalid content item.")];
    }

    $record = system_content_record($contentId);
    $record["id"] = $contentId;
    $record["key"] = system_plain_text($post["key"] ?? ($record["key"] ?? $contentId), 100);
    $record["title"] = system_plain_text($post["title"] ?? ($record["title"] ?? ""), 180);
    $record["content"] = system_plain_text($post["content"] ?? ($record["content"] ?? ""), 4000);
    $record["isActive"] = array_key_exists("isActive", $post) ? system_bool_value($post["isActive"]) : ($record["isActive"] ?? true);
    $record["createdAt"] = $record["createdAt"] ?: date("c");
    $record["updatedAt"] = date("c");
    $record["updatedBy"] = $updatedBy;

    if (!update_record_by_id("system_content", $contentId, $record)) {
        return ["ok" => false, "message" => msg("Unable to save system content.", "Hindi na-save ang system content.", "Unable to save system content.")];
    }

    audit_log($updatedBy, "SYSTEM_CONTENT_UPDATED", $contentId);
    return ["ok" => true, "message" => msg("System content saved.", "Na-save ang system content.", "System content saved.")];
}

function announcement_is_current($announcement, $role = "") {
    if (!system_bool_value($announcement["isActive"] ?? true, true)) {
        return false;
    }

    $audience = strtolower(trim((string)($announcement["audience"] ?? "all")));
    $role = strtolower(trim((string)$role));

    if ($role !== "" && $audience !== "all" && $audience !== $role) {
        return false;
    }

    $now = time();
    $start = !empty($announcement["startAt"]) ? strtotime($announcement["startAt"]) : false;
    $end = !empty($announcement["endAt"]) ? strtotime($announcement["endAt"]) : false;

    if ($start && $now < $start) {
        return false;
    }

    if ($end && $now > $end) {
        return false;
    }

    return true;
}

function announcements_list($activeOnly = false, $role = "") {
    $records = read_records("announcements");

    if ($activeOnly) {
        $records = array_values(array_filter($records, function($announcement) use ($role) {
            return announcement_is_current($announcement, $role);
        }));
    }

    usort($records, function($a, $b) {
        return strtotime($b["updatedAt"] ?? $b["createdAt"] ?? "now") <=> strtotime($a["updatedAt"] ?? $a["createdAt"] ?? "now");
    });

    return $records;
}

function save_announcement($post, $updatedBy, $announcementId = "") {
    if (!user_has_any_role($updatedBy, ["super_admin"])) {
        return ["ok" => false, "message" => msg("You are not allowed to manage announcements.", "Wala kang pahintulot na pamahalaan ang announcements.", "You are not allowed to manage announcements.")];
    }

    $title = system_plain_text($post["title"] ?? "", 180);
    $message = system_plain_text($post["message"] ?? "", 3000);
    $audience = strtolower(safe_text($post["audience"] ?? "all", 30));
    $allowedAudiences = array_merge(["all"], app_roles());

    if ($title === "" || $message === "") {
        return ["ok" => false, "message" => msg("Complete the announcement title and message.", "Kumpletuhin ang title at message ng announcement.", "Complete the announcement title and message.")];
    }

    if (!in_array($audience, $allowedAudiences, true)) {
        $audience = "all";
    }

    $startAt = system_datetime_value($post["startAt"] ?? "");
    $endAt = system_datetime_value($post["endAt"] ?? "");

    if ($startAt !== "" && $endAt !== "" && strtotime($endAt) < strtotime($startAt)) {
        return ["ok" => false, "message" => msg("Announcement end time must be after its start time.", "Dapat mas huli ang end time kaysa start time ng announcement.", "Announcement end time must be after its start time.")];
    }

    $announcementId = preg_replace('/[^A-Za-z0-9_-]/', '', (string)$announcementId);
    $existing = $announcementId !== "" ? find_storage_record_by_id("announcements", $announcementId) : null;

    if ($announcementId === "") {
        $announcementId = "ann-" . time() . "-" . bin2hex(random_bytes(3));
    }

    $record = is_array($existing) ? $existing : [];
    $record["id"] = $announcementId;
    $record["title"] = $title;
    $record["message"] = $message;
    $record["audience"] = $audience;
    $record["isActive"] = array_key_exists("isActive", $post) ? system_bool_value($post["isActive"]) : true;
    $record["startAt"] = $startAt;
    $record["endAt"] = $endAt;
    $record["createdBy"] = $record["createdBy"] ?? $updatedBy;
    $record["createdAt"] = $record["createdAt"] ?? date("c");
    $record["updatedBy"] = $updatedBy;
    $record["updatedAt"] = date("c");

    if (!update_record_by_id("announcements", $announcementId, $record)) {
        return ["ok" => false, "message" => msg("Unable to save announcement.", "Hindi na-save ang announcement.", "Unable to save announcement.")];
    }

    audit_log($updatedBy, $existing ? "ANNOUNCEMENT_UPDATED" : "ANNOUNCEMENT_CREATED", $announcementId);
    return ["ok" => true, "message" => msg("Announcement saved.", "Na-save ang announcement.", "Announcement saved."), "id" => $announcementId];
}

function delete_announcement($announcementId, $updatedBy) {
    if (!user_has_any_role($updatedBy, ["super_admin"])) {
        return false;
    }

    $announcementId = preg_replace('/[^A-Za-z0-9_-]/', '', (string)$announcementId);

    if ($announcementId === "" || !find_storage_record_by_id("announcements", $announcementId)) {
        return false;
    }

    if (!delete_record_by_id("announcements", $announcementId)) {
        return false;
    }

    audit_log($updatedBy, "ANNOUNCEMENT_DELETED", $announcementId);
    return true;
}

function system_log($level, $category, $message, $userId = "", $details = "") {
    $level = strtolower(safe_text($level, 20));
    $category = strtolower(safe_text($category, 60));
    $allowedLevels = ["info", "success", "warning", "error", "security"];

    if (!in_array($level, $allowedLevels, true)) {
        $level = "info";
    }

    if ($category === "") {
        $category = "system";
    }

    $id = "syslog-" . time() . "-" . bin2hex(random_bytes(3));
    $record = [
        "id" => $id,
        "level" => $level,
        "category" => $category,
        "message" => system_plain_text($message, 1000),
        "userId" => safe_text($userId, 100),
        "details" => is_array($details) ? $details : system_plain_text($details, 2000),
        "createdAt" => date("c")
    ];

    return update_record_by_id("system_logs", $id, $record);
}

function latest_system_logs($limit = 100, $level = "", $category = "") {
    $limit = max(1, min(500, (int)$limit));
    $level = strtolower(trim((string)$level));
    $category = strtolower(trim((string)$category));
    $records = read_records("system_logs");

    $records = array_values(array_filter($records, function($record) use ($level, $category) {
        if ($level !== "" && strtolower((string)($record["level"] ?? "")) !== $level) {
            return false;
        }

        if ($category !== "" && strtolower((string)($record["category"] ?? "")) !== $category) {
            return false;
        }

        return true;
    }));

    usort($records, function($a, $b) {
        return strtotime($b["createdAt"] ?? "now") <=> strtotime($a["createdAt"] ?? "now");
    });

    return array_slice($records, 0, $limit);
}

function backup_table_keys() {
    return [
        "users",
        "academic_records",
        "tasks",
        "schedules",
        "attendance",
        "validations",
        "delete_requests",
        "sections",
        "audit_logs",
        "system_settings",
        "system_content",
        "announcements",
        "maintenance_settings"
    ];
}

function backup_sanitize_user_security_state($user) {
    if (!is_array($user)) {
        return $user;
    }

    $stringFields = [
        "activeSessionHash",
        "sessionInvalidationReason",
        "otpHash",
        "otpPurpose",
        "otpExpiresAt",
        "otpCreatedAt",
        "otpUsedAt",
        "privilegedOtpFailureWindowStartedAt",
        "privilegedOtpLockoutUntil",
        "otpSendLastAt",
        "otpSendWindowStartedAt",
        "passwordResetTokenHash",
        "passwordResetExpiresAt",
        "passwordResetRequestedAt",
        "passwordResetUsedAt",
        "passwordResetRateLastAt",
        "passwordResetRateWindowStartedAt",
        "pendingRecoveryEmail",
        "recoveryEmailVerificationTokenHash",
        "recoveryEmailVerificationExpiresAt",
        "recoveryEmailVerificationRequestedAt",
        "recoveryEmailVerificationUsedAt",
        "recoveryEmailVerificationRateLastAt",
        "recoveryEmailVerificationRateWindowStartedAt",
        "passwordChangeChallengeHash",
        "passwordChangeChallengeExpiresAt",
        "passwordChangeOtpHash",
        "passwordChangeOtpExpiresAt",
        "passwordChangeOtpCreatedAt",
        "passwordChangeOtpUsedAt",
        "passwordChangeOtpSendLastAt",
        "passwordChangeOtpSendWindowStartedAt",
        "passwordChangeOtpFailureWindowStartedAt",
        "passwordChangeOtpLockoutUntil"
    ];

    $integerFields = [
        "otpAttempts",
        "privilegedOtpFailedAttempts",
        "otpSendCount",
        "passwordResetRateCount",
        "recoveryEmailVerificationRateCount",
        "passwordChangeOtpAttempts",
        "passwordChangeOtpSendCount",
        "passwordChangeOtpFailedAttempts",
        "failedLoginAttempts"
    ];

    foreach ($stringFields as $field) {
        $user[$field] = "";
    }

    foreach ($integerFields as $field) {
        $user[$field] = 0;
    }

    $user["lockoutUntil"] = "";
    return $user;
}

function backup_sanitize_snapshot($snapshot) {
    if (!is_array($snapshot)) {
        return [];
    }

    if (isset($snapshot["users"]) && is_array($snapshot["users"])) {
        $snapshot["users"] = array_map("backup_sanitize_user_security_state", $snapshot["users"]);
    }

    return $snapshot;
}

function system_backups($limit = 30) {
    $limit = max(1, min(100, (int)$limit));
    $records = read_records("backups");

    usort($records, function($a, $b) {
        return strtotime($b["createdAt"] ?? "now") <=> strtotime($a["createdAt"] ?? "now");
    });

    return array_slice($records, 0, $limit);
}

function create_system_backup($createdBy, $label = "", $type = "manual") {
    if (!user_has_any_role($createdBy, ["it_admin"])) {
        return ["ok" => false, "message" => msg("You are not allowed to create system backups.", "Wala kang pahintulot na gumawa ng system backup.", "You are not allowed to create system backups.")];
    }

    $type = strtolower(trim((string)$type));

    if (!in_array($type, ["manual", "pre_restore"], true)) {
        $type = "manual";
    }

    $snapshot = [];
    $recordCount = 0;

    foreach (backup_table_keys() as $key) {
        $snapshot[$key] = read_records($key);
    }

    $snapshot = backup_sanitize_snapshot($snapshot);

    foreach ($snapshot as $records) {
        if (is_array($records)) {
            $recordCount += count($records);
        }
    }

    $encodedSnapshot = json_encode($snapshot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    if ($encodedSnapshot === false) {
        return ["ok" => false, "message" => msg("Unable to prepare the backup.", "Hindi maihanda ang backup.", "Unable to prepare the backup.")];
    }

    $id = "backup-" . date("Ymd-His") . "-" . bin2hex(random_bytes(2));
    $record = [
        "id" => $id,
        "label" => system_plain_text($label, 120),
        "type" => $type,
        "status" => "Completed",
        "tableCount" => count($snapshot),
        "recordCount" => $recordCount,
        "sizeBytes" => strlen($encodedSnapshot),
        "snapshot" => $snapshot,
        "securityStateSanitized" => true,
        "createdBy" => $createdBy,
        "createdAt" => date("c")
    ];

    if (!update_record_by_id("backups", $id, $record)) {
        return ["ok" => false, "message" => msg("Unable to save the backup.", "Hindi na-save ang backup.", "Unable to save the backup.")];
    }

    audit_log($createdBy, $type === "pre_restore" ? "PRE_RESTORE_BACKUP_CREATED" : "SYSTEM_BACKUP_CREATED", $id);
    system_log("success", "backup", $type === "pre_restore" ? "Pre-restore checkpoint created." : "System backup created.", $createdBy, ["backupId" => $id, "recordCount" => $recordCount]);

    return [
        "ok" => true,
        "message" => $type === "pre_restore"
            ? msg("Pre-restore checkpoint created.", "Nagawa ang pre-restore checkpoint.", "Pre-restore checkpoint created.")
            : msg("System backup created.", "Nagawa ang system backup.", "System backup created."),
        "id" => $id,
        "type" => $type
    ];
}

function backup_restore_insert_records($pdo, $table, $records, $batchSize = 100) {
    if (!($pdo instanceof PDO) || $table === "" || !is_array($records)) {
        return false;
    }

    $batchSize = max(1, min(250, (int)$batchSize));
    $preparedRecords = [];

    foreach ($records as $record) {
        if (!is_array($record)) {
            continue;
        }

        $id = storage_record_id($record);
        $record["id"] = $id;
        $encoded = json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        if ($encoded === false) {
            throw new RuntimeException("Unable to encode backup record.");
        }

        $preparedRecords[] = [$id, $encoded];
    }

    foreach (array_chunk($preparedRecords, $batchSize) as $chunk) {
        if (!count($chunk)) {
            continue;
        }

        $rows = [];
        $params = [];

        foreach ($chunk as $item) {
            $rows[] = "(?, cast(? as jsonb), now(), now())";
            $params[] = $item[0];
            $params[] = $item[1];
        }

        $sql = "insert into public." . $table .
            " (id, data, created_at, updated_at) values " .
            implode(", ", $rows);

        $stmt = $pdo->prepare($sql);

        if (!$stmt->execute($params)) {
            return false;
        }
    }

    return true;
}

function restore_system_backup($backupId, $restoredBy) {
    if (!user_has_any_role($restoredBy, ["it_admin"])) {
        return ["ok" => false, "message" => msg("You are not allowed to restore system backups.", "Wala kang pahintulot na mag-restore ng system backup.", "You are not allowed to restore system backups.")];
    }

    if (function_exists("set_time_limit")) {
        @set_time_limit(120);
    }

    $backup = find_storage_record_by_id("backups", (string)$backupId);
    $snapshot = is_array($backup["snapshot"] ?? null) ? $backup["snapshot"] : [];

    if (!$backup || !count($snapshot)) {
        return ["ok" => false, "message" => msg("Backup data was not found.", "Hindi nakita ang backup data.", "Backup data was not found.")];
    }

    if (isset($snapshot["users"]) && is_array($snapshot["users"])) {
        $restorerExists = false;

        foreach ($snapshot["users"] as $user) {
            if (
                ($user["id"] ?? "") === $restoredBy &&
                ($user["role"] ?? "") === "it_admin" &&
                ($user["status"] ?? "Active") === "Active"
            ) {
                $restorerExists = true;
                break;
            }
        }

        if (!$restorerExists) {
            return ["ok" => false, "message" => msg("This backup cannot be restored because it does not contain the current active IT Administrator account.", "Hindi ma-restore ang backup dahil wala rito ang kasalukuyang active IT Administrator account.", "This backup cannot be restored because it does not contain the current active IT Administrator account.")];
        }
    }

    $checkpointLabel = "Pre-restore checkpoint before " . (string)$backupId;
    $checkpoint = create_system_backup($restoredBy, $checkpointLabel, "pre_restore");

    if (empty($checkpoint["ok"])) {
        audit_log($restoredBy, "SYSTEM_BACKUP_RESTORE_ABORTED", "Restore was aborted because the pre-restore checkpoint could not be created.", [
            "category" => "security",
            "backupId" => (string)$backupId
        ]);
        return [
            "ok" => false,
            "message" => msg(
                "Restore was cancelled because a pre-restore checkpoint could not be created.",
                "Kinansela ang restore dahil hindi makagawa ng pre-restore checkpoint.",
                "Restore was cancelled because a pre-restore checkpoint could not be created."
            )
        ];
    }

    $snapshot = backup_sanitize_snapshot($snapshot);
    $allowed = array_flip(backup_table_keys());
    $pdo = db();

    try {
        $pdo->beginTransaction();

        foreach ($snapshot as $key => $records) {
            if (!isset($allowed[$key]) || !is_array($records)) {
                continue;
            }

            $table = storage_table($key);

            if ($table === "") {
                continue;
            }

            $pdo->exec("delete from public." . $table);

            if (!backup_restore_insert_records($pdo, $table, $records, 100)) {
                throw new RuntimeException("Unable to restore table: " . $table);
            }
        }

        $pdo->commit();
        storage_cache_clear();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        storage_cache_clear();
        system_log("error", "backup", "System backup restore failed.", $restoredBy, [
            "backupId" => (string)$backupId,
            "checkpointId" => (string)($checkpoint["id"] ?? "")
        ]);
        return [
            "ok" => false,
            "message" => msg(
                "Unable to restore the backup. The pre-restore checkpoint was retained.",
                "Hindi ma-restore ang backup. Nananatili ang pre-restore checkpoint.",
                "Unable to restore the backup. The pre-restore checkpoint was retained."
            ),
            "checkpointId" => (string)($checkpoint["id"] ?? "")
        ];
    }

    audit_log($restoredBy, "SYSTEM_BACKUP_RESTORED", (string)$backupId, [
        "category" => "security",
        "checkpointId" => (string)($checkpoint["id"] ?? ""),
        "sessionsRevoked" => true
    ]);
    system_log("success", "backup", "System backup restored. Authentication session and token state was cleared.", $restoredBy, [
        "backupId" => (string)$backupId,
        "checkpointId" => (string)($checkpoint["id"] ?? "")
    ]);

    return [
        "ok" => true,
        "message" => msg(
            "System backup restored. A pre-restore checkpoint was created and existing sessions were revoked.",
            "Na-restore ang system backup. Gumawa ng pre-restore checkpoint at ni-revoke ang existing sessions.",
            "System backup restored. A pre-restore checkpoint was created and existing sessions were revoked."
        ),
        "checkpointId" => (string)($checkpoint["id"] ?? ""),
        "sessionsRevoked" => true
    ];
}

function delete_system_backup($backupId, $deletedBy) {
    if (!user_has_any_role($deletedBy, ["it_admin"])) {
        return false;
    }

    if (!find_storage_record_by_id("backups", (string)$backupId)) {
        return false;
    }

    if (!delete_record_by_id("backups", (string)$backupId)) {
        return false;
    }

    audit_log($deletedBy, "SYSTEM_BACKUP_DELETED", (string)$backupId);
    return true;
}

function restore_system_backup_with_confirmation($backupId, $restoredBy, $currentPassword) {
    if (!confirm_sensitive_action($restoredBy, $currentPassword, "backup_restore", 300)) {
        return ["ok" => false, "message" => msg("Current password confirmation is required to restore a backup.", "Kailangan ang current password confirmation para mag-restore ng backup.", "Current password confirmation is required to restore a backup.")];
    }

    if (!sensitive_action_is_verified($restoredBy, "backup_restore", true)) {
        return ["ok" => false, "message" => msg("Backup restore confirmation expired.", "Expired na ang backup restore confirmation.", "Backup restore confirmation expired.")];
    }

    return restore_system_backup($backupId, $restoredBy);
}

function delete_system_backup_with_confirmation($backupId, $deletedBy, $currentPassword) {
    if (!confirm_sensitive_action($deletedBy, $currentPassword, "backup_delete", 300)) {
        return ["ok" => false, "message" => msg("Current password confirmation is required to delete a backup.", "Kailangan ang current password confirmation para mag-delete ng backup.", "Current password confirmation is required to delete a backup.")];
    }

    if (!sensitive_action_is_verified($deletedBy, "backup_delete", true)) {
        return ["ok" => false, "message" => msg("Backup deletion confirmation expired.", "Expired na ang backup deletion confirmation.", "Backup deletion confirmation expired.")];
    }

    $ok = delete_system_backup($backupId, $deletedBy);

    return $ok
        ? ["ok" => true, "message" => msg("Backup deleted.", "Na-delete ang backup.", "Backup deleted.")]
        : ["ok" => false, "message" => msg("Unable to delete the backup.", "Hindi ma-delete ang backup.", "Unable to delete the backup.")];
}

function maintenance_settings_defaults() {
    return [
        "id" => "global",
        "enabled" => false,
        "message" => "Ka-Akbay is currently undergoing system maintenance.",
        "startAt" => "",
        "endAt" => "",
        "enabledBy" => "",
        "createdAt" => "",
        "updatedAt" => "",
        "updatedBy" => ""
    ];
}

function maintenance_settings_record() {
    $record = find_storage_record_by_id("maintenance_settings", "global");
    return array_merge(maintenance_settings_defaults(), is_array($record) ? $record : []);
}

function maintenance_is_active() {
    $settings = maintenance_settings_record();

    if (!system_bool_value($settings["enabled"] ?? false)) {
        return false;
    }

    $now = time();
    $start = !empty($settings["startAt"]) ? strtotime($settings["startAt"]) : false;
    $end = !empty($settings["endAt"]) ? strtotime($settings["endAt"]) : false;

    if ($start && $now < $start) {
        return false;
    }

    if ($end && $now > $end) {
        return false;
    }

    return true;
}

function save_maintenance_settings($post, $updatedBy) {
    if (!user_has_any_role($updatedBy, ["it_admin"])) {
        return ["ok" => false, "message" => msg("You are not allowed to change maintenance settings.", "Wala kang pahintulot na baguhin ang maintenance settings.", "You are not allowed to change maintenance settings.")];
    }

    $record = maintenance_settings_record();
    $enabled = array_key_exists("enabled", $post) ? system_bool_value($post["enabled"]) : false;
    $message = system_plain_text($post["message"] ?? ($record["message"] ?? ""), 1000);
    $startAt = system_datetime_value($post["startAt"] ?? ($record["startAt"] ?? ""));
    $endAt = system_datetime_value($post["endAt"] ?? ($record["endAt"] ?? ""));

    if ($startAt !== "" && $endAt !== "" && strtotime($endAt) < strtotime($startAt)) {
        return ["ok" => false, "message" => msg("Maintenance end time must be after its start time.", "Dapat mas huli ang end time kaysa start time ng maintenance.", "Maintenance end time must be after its start time.")];
    }

    $record["id"] = "global";
    $record["enabled"] = $enabled;
    $record["message"] = $message !== "" ? $message : "Ka-Akbay is currently undergoing system maintenance.";
    $record["startAt"] = $startAt;
    $record["endAt"] = $endAt;
    $record["enabledBy"] = $enabled ? $updatedBy : "";
    $record["createdAt"] = $record["createdAt"] ?: date("c");
    $record["updatedAt"] = date("c");
    $record["updatedBy"] = $updatedBy;

    if (!update_record_by_id("maintenance_settings", "global", $record)) {
        return ["ok" => false, "message" => msg("Unable to save maintenance settings.", "Hindi na-save ang maintenance settings.", "Unable to save maintenance settings.")];
    }

    audit_log($updatedBy, $enabled ? "MAINTENANCE_ENABLED" : "MAINTENANCE_DISABLED", $record["message"]);
    system_log("info", "maintenance", $enabled ? "Maintenance mode enabled." : "Maintenance mode disabled.", $updatedBy);

    return ["ok" => true, "message" => msg("Maintenance settings saved.", "Na-save ang maintenance settings.", "Maintenance settings saved.")];
}

function technical_settings_defaults() {
    return [
        "id" => "technical",
        "sessionTimeoutMinutes" => 30,
        "maxLoginAttempts" => 5,
        "lockoutMinutes" => 15,
        "passwordResetExpiryMinutes" => 15,
        "otpExpiryMinutes" => 15,
        "otpResendCooldownSeconds" => 60,
        "otpMaxSendsPerHour" => 5,
        "privilegedOtpMaxFailures" => 5,
        "privilegedOtpLockoutMinutes" => 15,
        "passwordChangeOtpMaxFailures" => 5,
        "passwordChangeOtpLockoutMinutes" => 15,
        "passwordResetCooldownSeconds" => 60,
        "passwordResetMaxRequestsPerHour" => 5,
        "recoveryVerificationCooldownSeconds" => 60,
        "recoveryVerificationMaxRequestsPerHour" => 5,
        "minPasswordLength" => 8,
        "passwordRequireUppercase" => true,
        "passwordRequireLowercase" => true,
        "passwordRequireNumber" => true,
        "passwordRequireSpecial" => true,
        "oneActiveSession" => true,
        "logRetentionDays" => 90,
        "createdAt" => "",
        "updatedAt" => "",
        "updatedBy" => ""
    ];
}

function technical_settings_record() {
    $record = find_storage_record_by_id("system_settings", "technical");
    return array_merge(technical_settings_defaults(), is_array($record) ? $record : []);
}

function save_technical_settings($post, $updatedBy) {
    if (!user_has_any_role($updatedBy, ["it_admin"])) {
        return ["ok" => false, "message" => msg("You are not allowed to change technical settings.", "Wala kang pahintulot na baguhin ang technical settings.", "You are not allowed to change technical settings.")];
    }

    $record = technical_settings_record();
    $sessionTimeout = 30;
    $maxLoginAttempts = safe_number($post["maxLoginAttempts"] ?? ($record["maxLoginAttempts"] ?? 5), 3, 10);
    $lockoutMinutes = safe_number($post["lockoutMinutes"] ?? ($record["lockoutMinutes"] ?? 15), 5, 1440);
    $passwordResetExpiry = safe_number($post["passwordResetExpiryMinutes"] ?? ($record["passwordResetExpiryMinutes"] ?? 15), 5, 120);
    $otpExpiry = safe_number($post["otpExpiryMinutes"] ?? ($record["otpExpiryMinutes"] ?? 15), 5, 60);
    $minPasswordLength = safe_number($post["minPasswordLength"] ?? ($record["minPasswordLength"] ?? 8), 8, 32);
    $logRetentionDays = safe_number($post["logRetentionDays"] ?? ($record["logRetentionDays"] ?? 90), 7, 3650);

    if (
        $maxLoginAttempts === null ||
        $lockoutMinutes === null ||
        $passwordResetExpiry === null ||
        $otpExpiry === null ||
        $minPasswordLength === null ||
        $logRetentionDays === null
    ) {
        return ["ok" => false, "message" => msg("Enter valid technical setting values.", "Maglagay ng wastong technical setting values.", "Enter valid technical setting values.")];
    }

    $record["id"] = "technical";
    $record["sessionTimeoutMinutes"] = $sessionTimeout;
    $record["maxLoginAttempts"] = (int)$maxLoginAttempts;
    $record["lockoutMinutes"] = (int)$lockoutMinutes;
    $record["passwordResetExpiryMinutes"] = (int)$passwordResetExpiry;
    $record["otpExpiryMinutes"] = (int)$otpExpiry;
    $record["minPasswordLength"] = (int)$minPasswordLength;
    $record["passwordRequireUppercase"] = array_key_exists("passwordRequireUppercase", $post)
        ? system_bool_value($post["passwordRequireUppercase"])
        : system_bool_value($record["passwordRequireUppercase"] ?? true);
    $record["passwordRequireLowercase"] = array_key_exists("passwordRequireLowercase", $post)
        ? system_bool_value($post["passwordRequireLowercase"])
        : system_bool_value($record["passwordRequireLowercase"] ?? true);
    $record["passwordRequireNumber"] = array_key_exists("passwordRequireNumber", $post)
        ? system_bool_value($post["passwordRequireNumber"])
        : system_bool_value($record["passwordRequireNumber"] ?? true);
    $record["passwordRequireSpecial"] = array_key_exists("passwordRequireSpecial", $post)
        ? system_bool_value($post["passwordRequireSpecial"])
        : system_bool_value($record["passwordRequireSpecial"] ?? true);
    $record["oneActiveSession"] = true;
    $record["logRetentionDays"] = (int)$logRetentionDays;
    $record["createdAt"] = $record["createdAt"] ?: date("c");
    $record["updatedAt"] = date("c");
    $record["updatedBy"] = $updatedBy;

    if (!update_record_by_id("system_settings", "technical", $record)) {
        return ["ok" => false, "message" => msg("Unable to save technical settings.", "Hindi na-save ang technical settings.", "Unable to save technical settings.")];
    }

    audit_log($updatedBy, "TECHNICAL_SETTINGS_UPDATED", "Session, login, password, OTP, and log-retention settings updated.", ["category" => "security"]);
    return ["ok" => true, "message" => msg("Technical settings saved.", "Na-save ang technical settings.", "Technical settings saved.")];
}

function save_maintenance_settings_with_confirmation($post, $updatedBy, $currentPassword) {
    if (!confirm_sensitive_action($updatedBy, $currentPassword, "maintenance_settings", 300)) {
        return ["ok" => false, "message" => msg("Current password confirmation is required to change maintenance mode.", "Kailangan ang current password confirmation para baguhin ang maintenance mode.", "Current password confirmation is required to change maintenance mode.")];
    }

    if (!sensitive_action_is_verified($updatedBy, "maintenance_settings", true)) {
        return ["ok" => false, "message" => msg("Maintenance confirmation expired.", "Expired na ang maintenance confirmation.", "Maintenance confirmation expired.")];
    }

    return save_maintenance_settings($post, $updatedBy);
}

function save_technical_settings_with_confirmation($post, $updatedBy, $currentPassword) {
    if (!confirm_sensitive_action($updatedBy, $currentPassword, "technical_settings", 300)) {
        return ["ok" => false, "message" => msg("Current password confirmation is required to change technical security settings.", "Kailangan ang current password confirmation para baguhin ang technical security settings.", "Current password confirmation is required to change technical security settings.")];
    }

    if (!sensitive_action_is_verified($updatedBy, "technical_settings", true)) {
        return ["ok" => false, "message" => msg("Technical settings confirmation expired.", "Expired na ang technical settings confirmation.", "Technical settings confirmation expired.")];
    }

    return save_technical_settings($post, $updatedBy);
}

function revoke_user_sessions_with_confirmation($userId, $updatedBy, $currentPassword) {
    $scope = "revoke_session_" . preg_replace('/[^A-Za-z0-9_-]/', '', (string)$userId);

    if (!confirm_sensitive_action($updatedBy, $currentPassword, $scope, 300)) {
        return ["ok" => false, "message" => msg("Current password confirmation is required to revoke user sessions.", "Kailangan ang current password confirmation para i-revoke ang user sessions.", "Current password confirmation is required to revoke user sessions.")];
    }

    if (!sensitive_action_is_verified($updatedBy, $scope, true)) {
        return ["ok" => false, "message" => msg("Session revocation confirmation expired.", "Expired na ang session revocation confirmation.", "Session revocation confirmation expired.")];
    }

    $ok = revoke_user_sessions($userId, $updatedBy);

    return $ok
        ? ["ok" => true, "message" => msg("User sessions revoked.", "Na-revoke ang user sessions.", "User sessions revoked.")]
        : ["ok" => false, "message" => msg("Unable to revoke the user sessions.", "Hindi ma-revoke ang user sessions.", "Unable to revoke the user sessions.")];
}

function revoke_all_user_sessions_with_confirmation($updatedBy, $currentPassword) {
    if (!confirm_sensitive_action($updatedBy, $currentPassword, "revoke_all_sessions", 300)) {
        return ["ok" => false, "message" => msg("Current password confirmation is required to revoke all user sessions.", "Kailangan ang current password confirmation para i-revoke ang lahat ng user sessions.", "Current password confirmation is required to revoke all user sessions.")];
    }

    if (!sensitive_action_is_verified($updatedBy, "revoke_all_sessions", true)) {
        return ["ok" => false, "message" => msg("Global session revocation confirmation expired.", "Expired na ang global session revocation confirmation.", "Global session revocation confirmation expired.")];
    }

    $ok = revoke_all_user_sessions($updatedBy);

    return $ok
        ? ["ok" => true, "message" => msg("All eligible user sessions were revoked.", "Na-revoke ang lahat ng eligible user sessions.", "All eligible user sessions were revoked.")]
        : ["ok" => false, "message" => msg("Unable to revoke all user sessions.", "Hindi ma-revoke ang lahat ng user sessions.", "Unable to revoke all user sessions.")];
}

function revoke_user_sessions($userId, $updatedBy) {
    if (!user_has_any_role($updatedBy, ["it_admin"]) || $userId === "" || $userId === $updatedBy) {
        return false;
    }

    $user = find_user_by_id((string)$userId);

    if (!$user) {
        return false;
    }

    $user["sessionVersion"] = max(1, (int)($user["sessionVersion"] ?? 1)) + 1;
    $user["activeSessionHash"] = security_hash_secret(security_random_token(32));
    $user["sessionInvalidationReason"] = "administrative_revocation";
    $user["otpHash"] = "";
    $user["otpPurpose"] = "";
    $user["otpExpiresAt"] = "";
    $user["otpAttempts"] = 0;
    password_change_clear_account_state($user, true, true);
    $user["updatedAt"] = date("c");
    $user["updatedBy"] = $updatedBy;

    if (!update_record_by_id("users", (string)$userId, $user)) {
        return false;
    }

    audit_log($updatedBy, "USER_SESSIONS_REVOKED", "User sessions revoked.", ["category" => "security", "targetUserId" => (string)$userId]);
    system_log("security", "session", "User sessions revoked.", $updatedBy, ["targetUserId" => (string)$userId]);
    return true;
}

function revoke_all_user_sessions($updatedBy) {
    if (!user_has_any_role($updatedBy, ["it_admin"])) {
        return false;
    }

    $users = read_records("users");

    foreach ($users as &$user) {
        if (($user["id"] ?? "") === $updatedBy) {
            continue;
        }

        $user["sessionVersion"] = max(1, (int)($user["sessionVersion"] ?? 1)) + 1;
        $user["activeSessionHash"] = security_hash_secret(security_random_token(32));
        $user["sessionInvalidationReason"] = "administrative_revocation";
        $user["otpHash"] = "";
        $user["otpPurpose"] = "";
        $user["otpExpiresAt"] = "";
        $user["otpAttempts"] = 0;
        password_change_clear_account_state($user, true, true);
        $user["updatedAt"] = date("c");
        $user["updatedBy"] = $updatedBy;
    }

    unset($user);

    if (!write_records("users", $users)) {
        return false;
    }

    audit_log($updatedBy, "ALL_USER_SESSIONS_REVOKED", "All sessions except the current IT Administrator were revoked.", ["category" => "security"]);
    system_log("security", "session", "All user sessions were revoked except the current IT Administrator.", $updatedBy);
    return true;
}

function system_count_records($key) {
    $table = storage_table($key);

    if ($table === "") {
        return 0;
    }

    try {
        $stmt = db()->query("select count(*) as total from public." . $table);
        $row = $stmt->fetch();
        return (int)($row["total"] ?? 0);
    } catch (Throwable $e) {
        return 0;
    }
}

function system_health_status() {
    $databaseOnline = false;

    try {
        $stmt = db()->query("select 1 as ok");
        $databaseOnline = (bool)$stmt->fetch();
    } catch (Throwable $e) {
        $databaseOnline = false;
    }

    $backups = system_backups(1);
    $latestBackup = $backups[0] ?? null;
    $today = date("Y-m-d");
    $errorCountToday = 0;

    foreach (read_records("system_logs") as $log) {
        if (($log["level"] ?? "") === "error" && substr((string)($log["createdAt"] ?? ""), 0, 10) === $today) {
            $errorCountToday++;
        }
    }

    return [
        "status" => $databaseOnline ? "Operational" : "Unavailable",
        "database" => $databaseOnline ? "Online" : "Offline",
        "userCount" => system_count_records("users"),
        "systemLogCount" => system_count_records("system_logs"),
        "backupCount" => system_count_records("backups"),
        "lastBackupAt" => $latestBackup["createdAt"] ?? "",
        "lastBackupStatus" => $latestBackup["status"] ?? "No Backup",
        "errorsToday" => $errorCountToday,
        "maintenanceMode" => maintenance_is_active(),
        "checkedAt" => date("c")
    ];
}

function dashboard_status_rank($status) {
    $status = trim((string)$status);

    $ranks = [
        "At-Risk / Failing" => 5,
        "Not Mastered / Remediation Needed" => 5,
        "Attendance Concern" => 5,
        "Mabigat" => 5,
        "Critical" => 5,
        "Declining Performance Pattern" => 4,
        "Incomplete Requirements" => 4,
        "Warning Status" => 3,
        "Warning" => 3,
        "Nearing Mastery" => 3,
        "Katamtaman" => 3,
        "Needs Review" => 3,
        "Regular" => 1,
        "Mastered" => 1,
        "Regular Attendance" => 1,
        "Complete Requirements" => 1,
        "Stable Performance Pattern" => 1,
        "Improving Performance Pattern" => 1,
        "Magaan" => 1,
        "No Record" => 0,
        "Insufficient Trend Data" => 0,
        "" => 0
    ];

    if (isset($ranks[$status])) {
        return $ranks[$status];
    }

    if (text_has($status, "At-Risk") || text_has($status, "Failing") || text_has($status, "Concern") || text_has($status, "Mabigat") || text_has($status, "Not Mastered") || text_has($status, "Remediation") || text_has($status, "Critical")) {
        return 5;
    }

    if (text_has($status, "Warning") || text_has($status, "Nearing") || text_has($status, "Katamtaman") || text_has($status, "Needs")) {
        return 3;
    }

    return 1;
}

function dashboard_worst_status($statuses, $default = "No Record") {
    $worst = $default;
    $worstRank = dashboard_status_rank($default);

    foreach ((array)$statuses as $status) {
        $status = trim((string)$status);

        if ($status === "") {
            continue;
        }

        $rank = dashboard_status_rank($status);

        if ($rank > $worstRank) {
            $worst = $status;
            $worstRank = $rank;
        }
    }

    return $worst;
}


function dashboard_task_priority_rank($priority) {
    $priority = trim((string)$priority);

    $ranks = [
        "Critical" => 5,
        "High" => 4,
        "Medium" => 3,
        "Low" => 2,
        "Completed" => 1,
        "" => 0
    ];

    return $ranks[$priority] ?? 0;
}

function dashboard_subject_tasks($studentId, $subject, $academicStatus = "", $limit = 3) {
    $subject = strtolower(trim((string)$subject));
    $tasks = array_values(array_filter(tasks_for_student($studentId), function($task) use ($subject) {
        $taskSubject = strtolower(trim((string)($task["subject"] ?? "")));
        $status = computed_task_status($task);

        return $taskSubject === $subject && $status !== "Completed";
    }));

    usort($tasks, function($a, $b) use ($academicStatus) {
        $aPriority = task_priority($a, $academicStatus);
        $bPriority = task_priority($b, $academicStatus);
        $rank = dashboard_task_priority_rank($bPriority) <=> dashboard_task_priority_rank($aPriority);

        if ($rank !== 0) {
            return $rank;
        }

        $due = task_due_timestamp($a) <=> task_due_timestamp($b);

        if ($due !== 0) {
            return $due;
        }

        return adjusted_task_score($b) <=> adjusted_task_score($a);
    });

    return array_slice($tasks, 0, $limit);
}

function dashboard_task_due_label($task) {
    $dueDate = trim((string)($task["dueDate"] ?? ""));

    if ($dueDate === "") {
        return "no due date";
    }

    $days = days_until_due($task);

    if ($days < 0) {
        return "overdue since " . $dueDate;
    }

    if ($days === 0) {
        return "due today";
    }

    if ($days === 1) {
        return "due tomorrow";
    }

    return "due in " . $days . " days";
}

function dashboard_task_routine_guidance($studentId, $record, $workload = null) {
    $subject = $record["subject"] ?? "this subject";
    $academicStatus = $record["academicStatus"] ?? "";
    $tasks = dashboard_subject_tasks($studentId, $subject, $academicStatus, 3);
    $workloadStatus = is_array($workload) ? ($workload["lingguhangBigatIndex"] ?? $workload["workloadLevel"] ?? "") : "";

    if (!count($tasks)) {
        return [
            "priorityTask" => null,
            "nextTask" => null,
            "guidance" => []
        ];
    }

    $priorityTask = $tasks[0];
    $nextTask = $tasks[1] ?? null;
    $priority = task_priority($priorityTask, $academicStatus);
    $title = $priorityTask["title"] ?? "the first pending task";
    $category = $priorityTask["category"] ?? "task";
    $duration = round((float)($priorityTask["estimatedDuration"] ?? $priorityTask["duration"] ?? 1), 1);
    $dueLabel = dashboard_task_due_label($priorityTask);
    $guidance = [];

    $guidance[] = msg(
        "Prioritize " . $title . " for " . $subject . ". It is marked " . $priority . " priority and is " . $dueLabel . ". Start this before lower-risk subjects.",
        "Unahin ang " . $title . " para sa " . $subject . ". Naka-mark ito bilang " . $priority . " priority at " . $dueLabel . ". Simulan ito bago ang mas mababang risk na subjects.",
        "Unahin ang " . $title . " for " . $subject . ". Marked ito as " . $priority . " priority and " . $dueLabel . ". Start this before lower-risk subjects."
    );

    if ($duration >= 2) {
        $guidance[] = msg(
            "Split " . $title . " into two study blocks. Use the first block for the hardest part of the " . $category . ", then use the second block for checking and completion.",
            "Hatiin ang " . $title . " sa dalawang study block. Gamitin ang unang block para sa pinakamahirap na bahagi ng " . $category . ", pagkatapos ay gamitin ang ikalawang block para sa pag-check at pagtatapos.",
            "Split " . $title . " into two study blocks. Use the first block for the hardest part ng " . $category . ", then use the second block for checking and completion."
        );
    } else {
        $guidance[] = msg(
            "Use one focused block for " . $title . ". Finish the task first, then use the remaining time for short review in " . $subject . ".",
            "Gumamit ng isang focused block para sa " . $title . ". Tapusin muna ang task, pagkatapos gamitin ang natitirang oras para sa maikling review sa " . $subject . ".",
            "Use one focused block for " . $title . ". Finish the task first, then use the remaining time for short review in " . $subject . "."
        );
    }

    if ($nextTask) {
        $nextTitle = $nextTask["title"] ?? "the next pending task";
        $guidance[] = msg(
            "After that, continue with " . $nextTitle . " only after the first priority task has progress.",
            "Pagkatapos nito, ituloy ang " . $nextTitle . " kapag may progress na ang unang priority task.",
            "After that, continue with " . $nextTitle . " only after may progress na ang first priority task."
        );
    } elseif ($workloadStatus === "Mabigat") {
        $guidance[] = msg(
            "Keep the routine light after the priority task because the weekly workload is already high.",
            "Panatilihing magaan ang routine pagkatapos ng priority task dahil mabigat na ang lingguhang workload.",
            "Keep the routine light after the priority task because mabigat na ang weekly workload."
        );
    }

    return [
        "priorityTask" => [
            "id" => $priorityTask["id"] ?? "",
            "title" => $title,
            "category" => $category,
            "priority" => $priority,
            "dueDate" => $priorityTask["dueDate"] ?? "",
            "dueLabel" => $dueLabel,
            "estimatedDuration" => $duration,
            "status" => computed_task_status($priorityTask),
            "adjustedTaskScore" => adjusted_task_score($priorityTask)
        ],
        "nextTask" => $nextTask ? [
            "id" => $nextTask["id"] ?? "",
            "title" => $nextTask["title"] ?? "",
            "category" => $nextTask["category"] ?? "",
            "priority" => task_priority($nextTask, $academicStatus),
            "dueDate" => $nextTask["dueDate"] ?? "",
            "dueLabel" => dashboard_task_due_label($nextTask),
            "estimatedDuration" => round((float)($nextTask["estimatedDuration"] ?? $nextTask["duration"] ?? 1), 1),
            "status" => computed_task_status($nextTask),
            "adjustedTaskScore" => adjusted_task_score($nextTask)
        ] : null,
        "guidance" => $guidance
    ];
}

function dashboard_subject_records($studentId) {
    $records = latest_record_by_subject($studentId);
    $items = [];

    foreach ($records as $subject => $record) {
        if (!is_array($record)) {
            continue;
        }

        $record["subject"] = trim((string)($record["subject"] ?? $subject));
        $record["computedGrade"] = round((float)($record["computedGrade"] ?? computed_grade($record)), 2);
        $record["academicStatus"] = $record["academicStatus"] ?? grade_status($record["computedGrade"]);
        $competency = compute_competency_mastery($record);
        $record["competencyMastery"] = round($competency, 2);
        $record["competencyStatus"] = $competency > 0 ? competency_status($competency) : ($record["competencyStatus"] ?? "No Record");
        $attendance = attendance_summary_for_subject_period($studentId, $record["subject"], $record["gradingPeriod"] ?? "", $record["scheduleId"] ?? "");
        $record["attendanceSummary"] = $attendance;
        $record["absenceRate"] = $attendance["absenceRate"] ?? ($record["absenceRate"] ?? 0);
        $record["consecutiveAbsences"] = $attendance["consecutiveAbsences"] ?? ($record["consecutiveAbsences"] ?? 0);
        $record["attendanceStatus"] = $attendance["attendanceStatus"] ?? ($record["attendanceStatus"] ?? "No Record");
        $record["priorityRank"] = max(
            dashboard_status_rank($record["academicStatus"] ?? ""),
            dashboard_status_rank($record["competencyStatus"] ?? ""),
            dashboard_status_rank($record["attendanceStatus"] ?? ""),
            dashboard_status_rank($record["requirementStatus"] ?? ""),
            dashboard_status_rank($record["trendStatus"] ?? "")
        );
        $items[] = $record;
    }

    usort($items, function($a, $b) {
        $rank = ($b["priorityRank"] ?? 0) <=> ($a["priorityRank"] ?? 0);

        if ($rank !== 0) {
            return $rank;
        }

        return strcmp((string)($a["subject"] ?? ""), (string)($b["subject"] ?? ""));
    });

    return $items;
}

function dashboard_latest_fallback_record($studentId) {
    $subjects = dashboard_subject_records($studentId);

    if (count($subjects)) {
        return $subjects[0];
    }

    return latest_evaluated_record_for_student($studentId);
}

function dashboard_risk_forecast($academicStatus, $competencyStatus, $attendanceStatus, $workloadStatus = "") {
    $statuses = [$academicStatus, $competencyStatus, $attendanceStatus, $workloadStatus];
    $worst = dashboard_worst_status($statuses, "No Record");

    if (dashboard_status_rank($worst) >= 5) {
        return "High Risk Forecast";
    }

    if (dashboard_status_rank($worst) >= 3) {
        return "Moderate Risk Forecast";
    }

    if ($worst === "No Record") {
        return "No Record";
    }

    return "Low Risk Forecast";
}

function dashboard_academic_summary_for_student($studentId, $workload = null) {
    $subjects = dashboard_subject_records($studentId);
    $grades = [];
    $academicStatuses = [];
    $competencyStatuses = [];
    $attendanceStatuses = [];
    $requirementStatuses = [];
    $trendStatuses = [];

    foreach ($subjects as $record) {
        if (isset($record["computedGrade"])) {
            $grades[] = (float)$record["computedGrade"];
        }

        $academicStatuses[] = $record["academicStatus"] ?? "";
        $competencyStatuses[] = $record["competencyStatus"] ?? "";
        $attendanceStatuses[] = $record["attendanceStatus"] ?? "";
        $requirementStatuses[] = $record["requirementStatus"] ?? "";
        $trendStatuses[] = $record["trendStatus"] ?? "";
    }

    $averageGrade = count($grades) ? round(array_sum($grades) / count($grades), 2) : 0;
    $academicStatus = count($subjects) ? dashboard_worst_status($academicStatuses, "No Record") : "No Record";
    $competencyStatus = count($subjects) ? dashboard_worst_status($competencyStatuses, "No Record") : "No Record";
    $attendanceStatus = count($subjects) ? dashboard_worst_status($attendanceStatuses, "No Record") : "No Record";
    $requirementStatus = count($subjects) ? dashboard_worst_status($requirementStatuses, "No Record") : "No Record";
    $trendStatus = count($subjects) ? dashboard_worst_status($trendStatuses, "No Record") : "No Record";
    $workloadStatus = is_array($workload) ? ($workload["lingguhangBigatIndex"] ?? $workload["workloadLevel"] ?? "") : "";
    $riskForecast = dashboard_risk_forecast($academicStatus, $competencyStatus, $attendanceStatus, $workloadStatus);

    return [
        "subjectCount" => count($subjects),
        "computedGrade" => $averageGrade,
        "averageGrade" => $averageGrade,
        "academicStatus" => $academicStatus,
        "competencyStatus" => $competencyStatus,
        "attendanceStatus" => $attendanceStatus,
        "requirementStatus" => $requirementStatus,
        "trendStatus" => $trendStatus,
        "workloadStatus" => $workloadStatus,
        "riskForecast" => $riskForecast,
        "subjects" => $subjects,
        "focusRecord" => $subjects[0] ?? null
    ];
}

function priority_guidance_for_subject_record($studentId, $record, $workload = null) {
    if (!is_array($record)) {
        return null;
    }

    $subject = $record["subject"] ?? "Subject";
    $gradingPeriod = $record["gradingPeriod"] ?? "";
    $grade = round((float)($record["computedGrade"] ?? computed_grade($record)), 2);
    $academicStatus = $record["academicStatus"] ?? grade_status($grade);
    $competency = round((float)($record["competencyMastery"] ?? compute_competency_mastery($record)), 2);
    $competencyStatus = $competency > 0 ? competency_status($competency) : ($record["competencyStatus"] ?? "No Record");
    $attendance = $record["attendanceSummary"] ?? attendance_summary_for_subject_period($studentId, $subject, $gradingPeriod, $record["scheduleId"] ?? "");
    $attendanceStatus = $attendance["attendanceStatus"] ?? ($record["attendanceStatus"] ?? "No Record");
    $absenceRate = $attendance["absenceRate"] ?? ($record["absenceRate"] ?? 0);
    $consecutiveAbsences = $attendance["consecutiveAbsences"] ?? ($record["consecutiveAbsences"] ?? 0);
    $warnings = [];

    if ($academicStatus === "At-Risk / Failing") {
        $warnings[] = "Computed subject grade is below 75.";
    } elseif ($academicStatus === "Warning Status") {
        $warnings[] = "Computed subject grade is within 75 to 78.";
    }

    if ($competencyStatus === "Not Mastered / Remediation Needed") {
        $warnings[] = "Competency is below 50%.";
    } elseif ($competencyStatus === "Nearing Mastery") {
        $warnings[] = "Competency is within 50% to 74%.";
    }

    if ($attendanceStatus === "Attendance Concern") {
        $warnings[] = "Attendance needs follow-up.";
    }

    if (($record["requirementStatus"] ?? "") === "Incomplete Requirements") {
        $warnings[] = "Some requirements are incomplete or missing.";
    }

    if (($record["trendStatus"] ?? "") === "Declining Performance Pattern") {
        $warnings[] = "Performance pattern is declining.";
    }

    $guidanceRecord = $record;
    $guidanceRecord["computedGrade"] = $grade;
    $guidanceRecord["academicStatus"] = $academicStatus;
    $guidanceRecord["competencyMastery"] = $competency;
    $guidanceRecord["competencyStatus"] = $competencyStatus;
    $guidanceRecord["absenceRate"] = $absenceRate;
    $guidanceRecord["consecutiveAbsences"] = $consecutiveAbsences;
    $guidanceRecord["attendanceStatus"] = $attendanceStatus;
    $taskRoutine = dashboard_task_routine_guidance($studentId, $guidanceRecord, $workload);
    $routineAdvice = $taskRoutine["guidance"] ?? [];
    $fallbackAdvice = array_values(array_filter([
        grade_guidance_output($guidanceRecord),
        $competencyStatus !== "No Record" ? competency_guidance_output($guidanceRecord) : "",
        $attendanceStatus !== "No Record" ? attendance_guidance_output($guidanceRecord) : "",
        function_exists("requirement_guidance_output") ? requirement_guidance_output($guidanceRecord) : "",
        function_exists("trend_guidance_output") ? trend_guidance_output($guidanceRecord) : ""
    ]));
    $advice = count($routineAdvice) ? array_values(array_unique(array_merge($routineAdvice, $fallbackAdvice))) : $fallbackAdvice;
    $workloadStatus = is_array($workload) ? ($workload["lingguhangBigatIndex"] ?? $workload["workloadLevel"] ?? "") : "";
    $riskForecast = dashboard_risk_forecast($academicStatus, $competencyStatus, $attendanceStatus, $workloadStatus);
    $priorityTask = $taskRoutine["priorityTask"] ?? null;
    $taskRank = $priorityTask ? dashboard_task_priority_rank($priorityTask["priority"] ?? "") : 0;
    $priorityRank = max(
        dashboard_status_rank($academicStatus),
        dashboard_status_rank($competencyStatus),
        dashboard_status_rank($attendanceStatus),
        dashboard_status_rank($record["requirementStatus"] ?? ""),
        dashboard_status_rank($record["trendStatus"] ?? ""),
        dashboard_status_rank($riskForecast),
        dashboard_status_rank($workloadStatus),
        $taskRank
    );

    return [
        "subject" => $subject,
        "gradingPeriod" => $gradingPeriod,
        "computedGrade" => $grade,
        "academicStatus" => $academicStatus,
        "competencyMastery" => $competency,
        "competencyStatus" => $competencyStatus,
        "attendanceStatus" => $attendanceStatus,
        "riskForecast" => $riskForecast,
        "absenceRate" => round((float)$absenceRate, 2),
        "consecutiveAbsences" => (int)$consecutiveAbsences,
        "requirementStatus" => $record["requirementStatus"] ?? "No Record",
        "trendStatus" => $record["trendStatus"] ?? "No Record",
        "priorityRank" => $priorityRank,
        "priorityTask" => $priorityTask,
        "nextTask" => $taskRoutine["nextTask"] ?? null,
        "warnings" => $warnings,
        "advice" => $advice
    ];
}

function priority_guidance_by_subject($studentId, $workload = null) {
    $items = [];

    foreach (dashboard_subject_records($studentId) as $record) {
        $item = priority_guidance_for_subject_record($studentId, $record, $workload);

        if ($item !== null) {
            $items[] = $item;
        }
    }

    usort($items, function($a, $b) {
        $rank = ($b["priorityRank"] ?? 0) <=> ($a["priorityRank"] ?? 0);

        if ($rank !== 0) {
            return $rank;
        }

        return strcmp((string)($a["subject"] ?? ""), (string)($b["subject"] ?? ""));
    });

    return $items;
}

function dashboard_focus_summary_for_student($studentId, $workload = null) {
    $summary = dashboard_academic_summary_for_student($studentId, $workload);
    $guidance = priority_guidance_by_subject($studentId, $workload);
    $focusSubject = $guidance[0] ?? null;
    $workloadStatus = is_array($workload) ? ($workload["lingguhangBigatIndex"] ?? $workload["workloadLevel"] ?? "") : "";
    $focusText = "No priority focus yet.";

    if ($focusSubject) {
        $subject = $focusSubject["subject"] ?? "this subject";
        $priorityTask = $focusSubject["priorityTask"] ?? null;
        $taskText = "";

        if (is_array($priorityTask) && trim((string)($priorityTask["title"] ?? "")) !== "") {
            $taskText = " Start with " . ($priorityTask["title"] ?? "the first pending task") . " because it is " . strtolower($priorityTask["priority"] ?? "priority") . " priority and " . ($priorityTask["dueLabel"] ?? "needs scheduling") . ".";
        }

        $focusText = "Focus on " . $subject . " first because it has the highest current risk based on computed subject results." . $taskText;

        if (($summary["riskForecast"] ?? "") === "High Risk Forecast") {
            $focusText = "Focus on " . $subject . " first because it has the highest current risk based on computed subject results." . $taskText;
        } elseif ($workloadStatus === "Mabigat") {
            $focusText = "Focus on " . $subject . " while reducing heavy workload pressure." . $taskText;
        }
    } elseif (($summary["riskForecast"] ?? "") === "High Risk Forecast") {
        $focusText = "Review the current high-risk indicators first.";
    } elseif ($workloadStatus === "Mabigat") {
        $focusText = "Reduce current workload pressure first.";
    }

    return [
        "summary" => $summary,
        "guidance" => $guidance,
        "focusSubject" => $focusSubject,
        "focusText" => $focusText
    ];
}


function seed_required_files_if_missing() {
    ensure_storage();
    return true;
}

ensure_storage();