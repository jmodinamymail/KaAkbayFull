<?php

require_once __DIR__ . "/functions.php";

function auth_login_policy() {
    $settings = function_exists("technical_settings_record")
        ? technical_settings_record()
        : [];

    return [
        "maxLoginAttempts" => max(1, (int)($settings["maxLoginAttempts"] ?? 5)),
        "lockoutMinutes" => max(1, (int)($settings["lockoutMinutes"] ?? 15)),
        "sessionTimeoutMinutes" => 30
    ];
}

function auth_audit($userId, $action, $details = "") {
    if (function_exists("audit_log")) {
        audit_log($userId, $action, $details);
        return;
    }

    append_record("audit_logs", [
        "id" => "log-" . time() . "-" . bin2hex(random_bytes(3)),
        "userId" => $userId,
        "action" => $action,
        "details" => $details,
        "createdAt" => date("c")
    ]);
}

function auth_clear_session() {
    unset(
        $_SESSION["user"],
        $_SESSION["active_session_token"],
        $_SESSION["last_activity"],
        $_SESSION["login_time"]
    );
}

function auth_set_login_flash_error($message) {
    $message = trim((string)$message);

    if ($message !== "" && empty($_SESSION["loginFlashError"])) {
        $_SESSION["loginFlashError"] = $message;
    }
}

function auth_session_end_message($reason) {
    $reason = strtolower(trim((string)$reason));

    if ($reason === "new_login") {
        return msg(
            "Session Ended: This account was signed in from another browser or device. Ka-Akbay allows only one active session per account. Please sign in again to continue.",
            "Natapos ang Session: Nag-sign in ang account na ito mula sa ibang browser o device. Isang active session lamang bawat account ang pinapayagan ng Ka-Akbay. Mag-sign in muli para magpatuloy.",
            "Session Ended: Nag-sign in ang account na ito from another browser or device. One active session per account lang ang allowed sa Ka-Akbay. Please sign in again to continue."
        );
    }

    if ($reason === "administrative_revocation") {
        return msg(
            "Session Ended: Your active session was ended for security or administrative reasons. Please sign in again.",
            "Natapos ang Session: Tinapos ang active session mo para sa security o administrative reasons. Mag-sign in muli.",
            "Session Ended: Your active session was ended for security or administrative reasons. Please sign in again."
        );
    }

    if ($reason === "password_reset") {
        return msg(
            "Session Ended: Your password was reset, so existing sessions were signed out. Please sign in again.",
            "Natapos ang Session: Na-reset ang password mo kaya na-sign out ang mga kasalukuyang session. Mag-sign in muli.",
            "Session Ended: Na-reset ang password mo, so existing sessions were signed out. Please sign in again."
        );
    }

    if ($reason === "role_change") {
        return msg(
            "Session Ended: Your account permissions changed, so your previous session was ended. Please sign in again.",
            "Natapos ang Session: Nagbago ang account permissions mo kaya tinapos ang nakaraang session. Mag-sign in muli.",
            "Session Ended: Nagbago ang account permissions mo, so your previous session was ended. Please sign in again."
        );
    }

    if ($reason === "account_deactivated") {
        return msg(
            "Session Ended: This session ended because the account was deactivated or became unavailable. Please sign in again.",
            "Natapos ang Session: Natapos ang session dahil na-deactivate o naging unavailable ang account. Mag-sign in muli.",
            "Session Ended: Natapos ang session dahil na-deactivate o naging unavailable ang account. Please sign in again."
        );
    }

    return msg(
        "Session Ended: This session is no longer active. Please sign in again.",
        "Natapos ang Session: Hindi na active ang session na ito. Mag-sign in muli.",
        "Session Ended: Hindi na active ang session na ito. Please sign in again."
    );
}

function auth_session_hash($token) {
    return hash("sha256", (string)$token);
}

function auth_create_session_token() {
    return bin2hex(random_bytes(32));
}

function auth_force_password_change_required($user) {
    return !empty($user["mustChangePassword"]);
}

function current_user() {
    if (empty($_SESSION["user"]) || !is_array($_SESSION["user"])) {
        return null;
    }

    $sessionUserId = trim((string)($_SESSION["user"]["id"] ?? ""));

    if ($sessionUserId === "") {
        auth_clear_session();
        return null;
    }

    $storedUser = find_user_by_id($sessionUserId);

    if (!$storedUser || ($storedUser["status"] ?? "Active") !== "Active") {
        auth_audit(
            $sessionUserId,
            "SESSION_TERMINATED",
            "Account is inactive or no longer available."
        );

        auth_set_login_flash_error(auth_session_end_message("account_deactivated"));
        auth_clear_session();
        return null;
    }

    $policy = auth_login_policy();
    $timeoutSeconds = $policy["sessionTimeoutMinutes"] * 60;
    $lastActivity = (int)($_SESSION["last_activity"] ?? 0);

    if ($lastActivity > 0 && (time() - $lastActivity) > $timeoutSeconds) {
        auth_audit(
            $sessionUserId,
            "SESSION_TIMEOUT",
            "Session ended after 30 minutes of inactivity."
        );

        auth_set_login_flash_error(msg(
            "Session Expired: Your session expired after 30 minutes of inactivity. Please sign in again.",
            "Nag-expire ang Session: Nag-expire ang session mo matapos ang 30 minutong inactivity. Mag-sign in muli.",
            "Session Expired: Nag-expire ang session mo after 30 minutes of inactivity. Please sign in again."
        ));
        auth_clear_session();
        return null;
    }

    $storedSessionHash = trim((string)($storedUser["activeSessionHash"] ?? ""));
    $sessionToken = trim((string)($_SESSION["active_session_token"] ?? ""));

    if (
        $storedSessionHash === "" ||
        $sessionToken === "" ||
        !hash_equals($storedSessionHash, auth_session_hash($sessionToken))
    ) {
        $invalidationReason = trim((string)($storedUser["sessionInvalidationReason"] ?? ""));
        $auditAction = $invalidationReason === "new_login"
            ? "SESSION_REPLACED"
            : "SESSION_REVOKED";
        $auditDetails = $invalidationReason === "new_login"
            ? "Another login replaced this active session."
            : "The active session token is no longer valid. Reason: " . ($invalidationReason !== "" ? $invalidationReason : "unspecified") . ".";

        auth_audit(
            $sessionUserId,
            $auditAction,
            $auditDetails
        );

        auth_set_login_flash_error(auth_session_end_message($invalidationReason));
        auth_clear_session();
        return null;
    }

    $_SESSION["last_activity"] = time();

    $_SESSION["user"] = [
        "id" => $storedUser["id"],
        "code" => $storedUser["code"] ?? "",
        "name" => $storedUser["name"] ?? "",
        "email" => $storedUser["email"] ?? "",
        "role" => $storedUser["role"] ?? "",
        "strand" => $storedUser["strand"] ?? "",
        "section" => $storedUser["section"] ?? "",
        "gradeLevel" => $storedUser["gradeLevel"] ?? "",
        "teacherId" => $storedUser["teacherId"] ?? "",
        "managedSections" => $storedUser["managedSections"] ?? "",
        "mustChangePassword" => !empty($storedUser["mustChangePassword"])
    ];

    return $_SESSION["user"];
}

function login_user($email, $password, &$reason = null) {
    $email = strtolower(trim((string)$email));
    $password = (string)$password;
    $reason = "invalid";

    $policy = auth_login_policy();
    $maxAttempts = $policy["maxLoginAttempts"];
    $lockoutMinutes = $policy["lockoutMinutes"];

    $users = read_records("users");
    $matchedUser = null;

    foreach ($users as $user) {
        if (strtolower($user["email"] ?? "") === $email) {
            $matchedUser = $user;
            break;
        }
    }

    if (!$matchedUser) {
        auth_audit(
            "",
            "LOGIN_FAILED",
            "Login failed for an unrecognized email address."
        );

        return false;
    }

    $userId = (string)($matchedUser["id"] ?? "");
    $failedAttempts = max(0, (int)($matchedUser["failedLoginAttempts"] ?? 0));
    $lockoutUntil = trim((string)($matchedUser["lockoutUntil"] ?? ""));

    if ($lockoutUntil !== "") {
        $lockoutTimestamp = strtotime($lockoutUntil);

        if ($lockoutTimestamp && $lockoutTimestamp > time()) {
            $reason = "locked";

            auth_audit(
                $userId,
                "LOGIN_BLOCKED",
                "Login attempt blocked because the account is temporarily locked."
            );

            return false;
        }

        $failedAttempts = 0;
        $matchedUser["failedLoginAttempts"] = 0;
        $matchedUser["lockoutUntil"] = "";
        $matchedUser["updatedAt"] = date("c");

        update_record_by_id("users", $userId, $matchedUser);
    }

    if (!password_verify($password, $matchedUser["passwordHash"] ?? "")) {
        $failedAttempts++;

        $matchedUser["failedLoginAttempts"] = $failedAttempts;
        $matchedUser["updatedAt"] = date("c");

        if ($failedAttempts >= $maxAttempts) {
            $matchedUser["lockoutUntil"] = date(
                "c",
                time() + ($lockoutMinutes * 60)
            );

            $reason = "locked";

            auth_audit(
                $userId,
                "ACCOUNT_TEMPORARILY_LOCKED",
                "Maximum failed login attempts reached."
            );
        } else {
            auth_audit(
                $userId,
                "LOGIN_FAILED",
                "Invalid password. Attempt " .
                $failedAttempts .
                " of " .
                $maxAttempts .
                "."
            );
        }

        update_record_by_id("users", $userId, $matchedUser);

        return false;
    }

    if (($matchedUser["status"] ?? "Active") !== "Active") {
        $reason = "inactive";

        auth_audit(
            $userId,
            "LOGIN_BLOCKED",
            "Login blocked because the account is inactive."
        );

        return false;
    }

    if (
        function_exists("maintenance_is_active") &&
        maintenance_is_active() &&
        !in_array(
            $matchedUser["role"] ?? "",
            ["super_admin", "it_admin"],
            true
        )
    ) {
        $reason = "maintenance";

        auth_audit(
            $userId,
            "LOGIN_BLOCKED",
            "Login blocked because maintenance mode is active."
        );

        return false;
    }

    $sessionToken = auth_create_session_token();

    $matchedUser["failedLoginAttempts"] = 0;
    $matchedUser["lockoutUntil"] = "";
    $matchedUser["activeSessionHash"] = auth_session_hash($sessionToken);
    $matchedUser["sessionInvalidationReason"] = "new_login";
    $matchedUser["lastLoginAt"] = date("c");
    $matchedUser["lastSessionStartedAt"] = date("c");
    $matchedUser["updatedAt"] = date("c");

    if (!update_record_by_id("users", $userId, $matchedUser)) {
        $reason = "error";
        return false;
    }

    session_regenerate_id(true);

    $_SESSION["active_session_token"] = $sessionToken;
    $_SESSION["last_activity"] = time();
    $_SESSION["login_time"] = time();

    $_SESSION["user"] = [
        "id" => $matchedUser["id"],
        "code" => $matchedUser["code"] ?? "",
        "name" => $matchedUser["name"] ?? "",
        "email" => $matchedUser["email"] ?? "",
        "role" => $matchedUser["role"] ?? "",
        "strand" => $matchedUser["strand"] ?? "",
        "section" => $matchedUser["section"] ?? "",
        "gradeLevel" => $matchedUser["gradeLevel"] ?? "",
        "teacherId" => $matchedUser["teacherId"] ?? "",
        "managedSections" => $matchedUser["managedSections"] ?? "",
        "mustChangePassword" => !empty($matchedUser["mustChangePassword"])
    ];

    auth_audit(
        $userId,
        "LOGIN",
        "Successful login."
    );

    $reason = "";

    return true;
}

function require_login() {
    $user = current_user();

    if (!$user) {
        header("Location: login.php");
        exit;
    }

    $currentPage = basename($_SERVER["PHP_SELF"] ?? "");

    if (
        auth_force_password_change_required($user) &&
        !in_array(
            $currentPage,
            [
                "profile.php",
                "logout.php"
            ],
            true
        )
    ) {
        header("Location: profile.php?forcePasswordChange=1");
        exit;
    }
}

function require_role($roles) {
    require_login();

    $user = current_user();

    if (!$user || !in_array($user["role"] ?? "", $roles, true)) {
        header("Location: /dashboard", true, 302);
        exit;
    }
}

function require_super_admin() {
    require_role(["super_admin"]);
}

function require_it_admin() {
    require_role(["it_admin"]);
}
