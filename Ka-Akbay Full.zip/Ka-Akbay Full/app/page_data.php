<?php
require_once __DIR__ . "/functions.php";

function get_page_data($page, $user) {
    if ($page === "dashboard") {
        return get_dashboard_data($user);
    }

    if ($page === "records") {
        return get_records_data($user);
    }

    if ($page === "tasks") {
        return get_tasks_data($user);
    }

    if ($page === "schedules") {
        return get_schedules_data($user);
    }

    if ($page === "validation") {
        return get_validation_data($user);
    }

    if ($page === "users") {
        return get_users_data($user);
    }

    if ($page === "content") {
        return get_content_data($user);
    }

    if ($page === "system") {
        return get_system_data($user);
    }

    if ($page === "profile") {
        return get_profile_data($user);
    }

    return [];
}

function get_dashboard_data($user) {
    $role = $user["role"];

    if ($role === "student") {
        $records = array_map(fn($record) => evaluate_record($record), academic_record_history_for_student($user["id"]));
        $tasks = tasks_for_student($user["id"]);
        $schedules = schedules_for_student($user["id"]);
        $latestBySubject = latest_record_by_subject($user["id"]);
        $latest = null;

        foreach ($records as $record) {
            if (($record["recordMode"] ?? "quarterly") === "quarterly") {
                $latest = evaluate_record($record, $tasks);
                break;
            }
        }

        if (!$latest && count($records)) {
            $latest = evaluate_record($records[0], $tasks);
        }

        $workload = workload_summary($records, $tasks, $user["id"]);
        $taskSummary = task_summary_for_student($user["id"]);
        $routineCapacity = routine_capacity_summary($workload["weeklyClassHours"] ?? 0);
        $weeklyPlan = dynamic_weekly_study_calendar($user["id"], $tasks, $latestBySubject);
        $monthlyPlan = dynamic_monthly_study_calendar($user["id"], $tasks, $latestBySubject);
        $attendanceRecords = function_exists("attendance_for_student") ? attendance_for_student($user["id"]) : [];
        $attendanceSummary = function_exists("student_attendance_summary") ? student_attendance_summary($user["id"]) : [];
        $recordValidationMap = record_validation_map($user["id"]);

        $flags = $latest ? array_filter([
            $latest["academicStatus"] ?? "",
            $latest["competencyStatus"] ?? "",
            $latest["attendanceStatus"] ?? "",
            $latest["requirementStatus"] ?? "",
            $latest["trendStatus"] ?? "",
            $workload["lingguhangBigatIndex"] ?? ""
        ], function($flag) {
            return !in_array($flag, ["", "No Record", "Regular", "Mastered", "Regular Attendance", "Complete Requirements", "Stable Performance Pattern", "Improving Performance Pattern", "Insufficient Trend Data", "Magaan"], true);
        }) : [];

        return [
            "role" => "student",
            "records" => $records,
            "tasks" => $tasks,
            "schedules" => $schedules,
            "attendanceRecords" => $attendanceRecords,
            "attendanceSummary" => $attendanceSummary,
            "recordValidationMap" => $recordValidationMap,
            "latest" => $latest,
            "latestBySubject" => $latestBySubject,
            "weeklyPlan" => $weeklyPlan,
            "monthlyPlan" => $monthlyPlan,
            "workload" => $workload,
            "taskSummary" => $taskSummary,
            "routineCapacity" => $routineCapacity,
            "flags" => array_values($flags),
            "flagDetails" => student_flag_details($latest, $workload, $taskSummary),
            "advice" => student_guidance_output($latest, $workload, $tasks)
        ];
    }

    if ($role === "it_admin") {
        $health = system_health_status();
        $backups = system_backups(5);
        $maintenance = maintenance_settings_record();

        return [
            "role" => "it_admin",
            "health" => $health,
            "backups" => $backups,
            "latestBackup" => $backups[0] ?? null,
            "maintenance" => $maintenance
        ];
    }

    $filters = page_filter_values();
    $allRows = evaluated_student_rows();
    $allRows = array_values(array_filter($allRows, function($row) {
        $student = $row["student"] ?? [];
        return ($student["status"] ?? "Active") === "Active";
    }));

    if (($role ?? "") === "teacher") {
        $allRows = array_values(array_filter($allRows, fn($row) => student_visible_to_user($row["student"] ?? [], $user)));
    }

    $rows = function_exists("filter_monitoring_rows") ? filter_monitoring_rows($allRows, $filters) : filter_page_monitoring_rows($allRows, $filters);
    $counts = monitoring_counts($allRows);
    $validations = read_records("validations");
    $assessmentRecords = validation_assessment_records_from_rows($allRows, $filters);
    $attendanceRecords = validation_attendance_records_from_rows($allRows, $filters);
    $deleteRequests = validation_delete_requests_from_rows($allRows, $filters);
    $flagged = array_values(array_filter($rows, fn($row) => count($row["flags"] ?? []) > 0 || (($row["followUpType"] ?? "") !== "Regular Monitoring" && ($row["followUpType"] ?? "") !== "No Record")));

    return [
        "role" => $role,
        "filters" => $filters,
        "rows" => $rows,
        "allRows" => $allRows,
        "counts" => $counts,
        "groupedSummary" => grouped_monitoring_summary($allRows),
        "validations" => $validations,
        "validationCounts" => validation_summary_counts($validations),
        "assessmentRecords" => $assessmentRecords,
        "attendanceRecords" => $attendanceRecords,
        "deleteRequests" => $deleteRequests,
        "flagged" => $flagged
    ];
}

function get_records_data($user) {
    $records = array_map(fn($record) => evaluate_record($record), academic_record_history_for_student($user["id"]));
    $editId = $_GET["edit"] ?? "";
    $editRecord = null;
    $recordValidationMap = record_validation_map($user["id"]);
    $deleteRequestMap = record_delete_request_map($user["id"]);

    foreach ($records as $record) {
        if (($record["id"] ?? "") === $editId) {
            $editRecord = $record;
            break;
        }
    }

    $assessmentRecords = array_values(array_filter($records, fn($record) => ($record["recordMode"] ?? "quarterly") === "assessment"));
    $quarterlyRecords = array_values(array_filter($records, fn($record) => ($record["recordMode"] ?? "quarterly") === "quarterly"));
    $quarterlySummaries = function_exists("computed_quarterly_summaries") ? computed_quarterly_summaries($user["id"]) : $quarterlyRecords;

    usort($assessmentRecords, function($a, $b) use ($recordValidationMap) {
        $aId = $a["id"] ?? "";
        $bId = $b["id"] ?? "";
        $aValidated = isset($recordValidationMap[$aId]) ? 1 : 0;
        $bValidated = isset($recordValidationMap[$bId]) ? 1 : 0;

        if ($aValidated !== $bValidated) {
            return $aValidated <=> $bValidated;
        }

        $aDate = $a["assessmentDate"] ?? $a["createdAt"] ?? "now";
        $bDate = $b["assessmentDate"] ?? $b["createdAt"] ?? "now";

        return strtotime($bDate) <=> strtotime($aDate);
    });

    return [
        "records" => $records,
        "assessmentRecords" => $assessmentRecords,
        "quarterlyRecords" => $quarterlyRecords,
        "quarterlySummaries" => $quarterlySummaries,
        "recordValidationMap" => $recordValidationMap,
        "deleteRequestMap" => $deleteRequestMap,
        "editId" => $editId,
        "editRecord" => $editRecord,
        "subjects" => schedule_subjects_for_student($user["id"])
    ];
}

function get_tasks_data($user) {
    $records = array_map(fn($record) => evaluate_record($record), academic_record_history_for_student($user["id"]));
    $tasks = tasks_for_student($user["id"]);
    $schedules = schedules_for_student($user["id"]);
    $subjects = schedule_subjects_for_student($user["id"]);
    $latestBySubject = latest_record_by_subject($user["id"]);
    $workload = workload_summary($records, $tasks, $user["id"]);
    $routineCapacity = routine_capacity_summary($workload["weeklyClassHours"] ?? 0);
    $weeklyPlan = dynamic_weekly_study_calendar($user["id"], $tasks, $latestBySubject);
    $monthlyPlan = dynamic_monthly_study_calendar($user["id"], $tasks, $latestBySubject);
    $editTaskId = $_GET["edit"] ?? "";
    $breakdownId = $_GET["breakdown"] ?? "";
    $moveId = $_GET["move"] ?? "";
    $editTask = null;
    $breakdownTask = null;
    $moveTask = null;

    foreach ($tasks as $task) {
        if (($task["id"] ?? "") === $editTaskId) {
            $editTask = $task;
        }

        if (($task["id"] ?? "") === $breakdownId) {
            $breakdownTask = $task;
        }

        if (($task["id"] ?? "") === $moveId) {
            $moveTask = $task;
        }
    }

    usort($tasks, function($a, $b) use ($latestBySubject) {
        $rank = ["Critical" => 1, "High" => 2, "Medium" => 3, "Low" => 4];

        $aSubject = $a["subject"] ?? "Unassigned Subject";
        $bSubject = $b["subject"] ?? "Unassigned Subject";
        $aStatus = $latestBySubject[$aSubject]["academicStatus"] ?? "";
        $bStatus = $latestBySubject[$bSubject]["academicStatus"] ?? "";
        $aPriority = task_priority($a, $aStatus);
        $bPriority = task_priority($b, $bStatus);

        if (($rank[$aPriority] ?? 9) !== ($rank[$bPriority] ?? 9)) {
            return ($rank[$aPriority] ?? 9) <=> ($rank[$bPriority] ?? 9);
        }

        return task_due_timestamp($a) <=> task_due_timestamp($b);
    });

    $focusTasks = [];
    $completedTasks = [];

    foreach ($tasks as $task) {
        $taskStatus = $task["status"] ?? "";

        if ($taskStatus === "Completed") {
            $completedTasks[] = $task;
            continue;
        }

        $taskSubject = $task["subject"] ?? "Unassigned Subject";
        $linkedStatus = $latestBySubject[$taskSubject]["academicStatus"] ?? "";
        $messages = empty($task["dismissed"]) ? task_trigger_messages($task, $linkedStatus) : [];

        if (function_exists("task_guidance_output") && empty($task["dismissed"])) {
            $messages = array_values(array_unique(array_merge($messages, task_guidance_output($task, $linkedStatus, $workload["lingguhangBigatIndex"] ?? "Magaan"))));
        }

        if (count($messages)) {
            $focusTasks[] = [
                "task" => $task,
                "messages" => $messages,
                "priority" => task_priority($task, $linkedStatus),
                "computedStatus" => computed_task_status($task)
            ];
        }
    }

    return [
        "records" => $records,
        "tasks" => $tasks,
        "schedules" => $schedules,
        "subjects" => $subjects,
        "latestBySubject" => $latestBySubject,
        "workload" => $workload,
        "routineCapacity" => $routineCapacity,
        "weeklyPlan" => $weeklyPlan,
        "monthlyPlan" => $monthlyPlan,
        "editTask" => $editTask,
        "breakdownTask" => $breakdownTask,
        "moveTask" => $moveTask,
        "focusTasks" => $focusTasks,
        "completedTasks" => $completedTasks
    ];
}

function get_schedules_data($user) {
    $schedules = schedules_for_student($user["id"]);
    $editId = $_GET["edit"] ?? "";
    $editSchedule = null;
    $weeklyClassHours = weekly_class_hours_from_schedule($user["id"]);
    $monthlyCalendar = monthly_subject_calendar($user["id"]);
    $attendanceRecords = function_exists("attendance_for_student") ? attendance_for_student($user["id"]) : [];
    $attendanceSummary = function_exists("student_attendance_summary") ? student_attendance_summary($user["id"]) : [];

    foreach ($schedules as $schedule) {
        if (($schedule["id"] ?? "") === $editId) {
            $editSchedule = $schedule;
            break;
        }
    }

    return [
        "schedules" => $schedules,
        "calendar" => schedule_calendar_grid($user["id"]),
        "monthlyCalendar" => $monthlyCalendar,
        "weeklyClassHours" => $weeklyClassHours,
        "routineCapacity" => routine_capacity_summary($weeklyClassHours),
        "attendanceRecords" => $attendanceRecords,
        "attendanceSummary" => $attendanceSummary,
        "editSchedule" => $editSchedule,
        "days" => week_days()
    ];
}

function get_validation_data($user) {
    $filters = page_filter_values();
    $rows = evaluated_student_rows();
    $rows = array_values(array_filter($rows, function($row) {
        $student = $row["student"] ?? [];
        return ($student["status"] ?? "Active") === "Active";
    }));

    if (($user["role"] ?? "") === "teacher") {
        $rows = array_values(array_filter($rows, fn($row) => student_visible_to_user($row["student"] ?? [], $user)));
    }

    $filteredRows = filter_page_monitoring_rows($rows, $filters);
    $validations = read_records("validations");
    $assessmentRecords = validation_assessment_records_from_rows($rows, $filters);
    $attendanceRecords = validation_attendance_records_from_rows($rows, $filters);
    $deleteRequests = validation_delete_requests_from_rows($rows, $filters);
    $filteredValidations = validation_history_records_from_rows($rows, $filters);

    return [
        "rows" => $filteredRows,
        "allRows" => $rows,
        "filters" => $filters,
        "validations" => $filteredValidations,
        "allValidations" => $validations,
        "validationCounts" => validation_summary_counts($validations),
        "assessmentRecords" => $assessmentRecords,
        "attendanceRecords" => $attendanceRecords,
        "deleteRequests" => $deleteRequests
    ];
}

function get_users_data($user) {
    $users = read_records("users");
    $teachers = array_values(array_filter($users, function($u) {
        return ($u["role"] ?? "") === "teacher"
            && ($u["status"] ?? "Active") === "Active";
    }));
    $sections = function_exists("active_sections_list") ? active_sections_list() : available_sections_from_users($users);
    $sectionNames = [];

    foreach ($sections as $section) {
        if (is_array($section)) {
            $name = trim((string)($section["name"] ?? $section["section"] ?? ""));
        } else {
            $name = trim((string)$section);
        }

        if ($name !== "") {
            $sectionNames[] = $name;
        }
    }

    $sectionNames = array_values(array_unique($sectionNames));
    sort($sectionNames);

    return [
        "users" => $users,
        "teachers" => $teachers,
        "sections" => $sections,
        "sectionNames" => $sectionNames
    ];
}

function get_content_data($user) {
    if (($user["role"] ?? "") !== "super_admin") {
        return [];
    }

    return [
        "settings" => system_settings_record(),
        "content" => system_content_records(),
        "announcements" => announcements_list(false)
    ];
}

function get_system_data($user) {
    if (($user["role"] ?? "") !== "it_admin") {
        return [];
    }

    return [
        "health" => system_health_status(),
        "logs" => latest_system_logs(100),
        "backups" => system_backups(30),
        "maintenance" => maintenance_settings_record()
    ];
}

function get_profile_data($user) {
    return [
        "profile" => find_user_by_id($user["id"]) ?? $user
    ];
}

if (!function_exists("page_filter_values")) {
    function page_filter_values() {
        return [
            "q" => $_GET["q"] ?? "",
            "gradeStatus" => $_GET["gradeStatus"] ?? "",
            "competencyStatus" => $_GET["competencyStatus"] ?? "",
            "attendanceStatus" => $_GET["attendanceStatus"] ?? "",
            "workloadStatus" => $_GET["workloadStatus"] ?? "",
            "requirementStatus" => $_GET["requirementStatus"] ?? "",
            "trendStatus" => $_GET["trendStatus"] ?? "",
            "followUpType" => $_GET["followUpType"] ?? "",
            "strand" => $_GET["strand"] ?? "",
            "section" => $_GET["section"] ?? "",
            "subject" => $_GET["subject"] ?? "",
            "validationStatus" => $_GET["validationStatus"] ?? "",
            "deleteRequestStatus" => $_GET["deleteRequestStatus"] ?? ""
        ];
    }
}

if (!function_exists("record_validation_map")) {
    function record_validation_map($studentId) {
        $map = [];

        $validationRows = function_exists("read_records_where") ? read_records_where("validations", ["studentId" => $studentId], "created_at asc, id asc") : read_records("validations");

        foreach ($validationRows as $validation) {
            if (($validation["studentId"] ?? "") !== $studentId) {
                continue;
            }

            $recordId = $validation["recordId"] ?? "";

            if ($recordId === "") {
                continue;
            }

            if (!isset($map[$recordId])) {
                $map[$recordId] = $validation;
                continue;
            }

            $currentTime = strtotime($map[$recordId]["createdAt"] ?? "now");
            $newTime = strtotime($validation["createdAt"] ?? "now");

            if ($newTime >= $currentTime) {
                $map[$recordId] = $validation;
            }
        }

        return $map;
    }
}

if (!function_exists("record_delete_request_map")) {
    function record_delete_request_map($studentId) {
        $studentId = trim((string)$studentId);
        $map = [];

        if ($studentId === "") {
            return $map;
        }

        if (function_exists("delete_requests_for_student")) {
            $requestRows = delete_requests_for_student($studentId);
        } elseif (function_exists("read_records_where")) {
            $requestRows = read_records_where(
                "delete_requests",
                ["studentId" => $studentId],
                "coalesce(data->>'updatedAt', data->>'createdAt', '') desc, updated_at desc, id desc"
            );
        } else {
            $requestRows = array_values(array_filter(
                read_records("delete_requests"),
                fn($request) => ($request["studentId"] ?? "") === $studentId
            ));

            usort($requestRows, function($a, $b) {
                return strtotime($b["updatedAt"] ?? $b["createdAt"] ?? "now") <=> strtotime($a["updatedAt"] ?? $a["createdAt"] ?? "now");
            });
        }

        foreach ($requestRows as $request) {
            if (($request["studentId"] ?? "") !== $studentId) {
                continue;
            }

            $recordId = trim((string)($request["recordId"] ?? ""));

            if ($recordId === "" || isset($map[$recordId])) {
                continue;
            }

            $map[$recordId] = $request;
        }

        return $map;
    }
}

if (!function_exists("page_auto_score_validation_status")) {
    function page_auto_score_validation_status($record) {
        if (function_exists("kaakbay_auto_score_validation_status")) {
            return kaakbay_auto_score_validation_status($record);
        }

        if (function_exists("system_score_validation_status")) {
            return system_score_validation_status($record);
        }

        $score = $record["score"] ?? "";
        $totalScore = $record["totalScore"] ?? "";
        $submissionStatus = $record["submissionStatus"] ?? "Submitted";

        if ($submissionStatus === "Missing") {
            return "Needs Review";
        }

        if ($score === "" || $totalScore === "" || !is_numeric($score) || !is_numeric($totalScore)) {
            return "Needs Review";
        }

        $scoreValue = (float)$score;
        $totalValue = (float)$totalScore;

        if ($totalValue <= 0 || $scoreValue < 0 || $scoreValue > $totalValue) {
            return "Not Consistent";
        }

        $percentage = ($scoreValue / $totalValue) * 100;

        if ($percentage < 75) {
            return "Needs Review";
        }

        return "Consistent";
    }
}

if (!function_exists("page_auto_output_validation_status")) {
    function page_auto_output_validation_status($latest, $workload, $taskSummary) {
        if (function_exists("kaakbay_auto_output_validation_status")) {
            return kaakbay_auto_output_validation_status($latest, $workload, $taskSummary);
        }

        if (function_exists("system_output_validation_status")) {
            return system_output_validation_status($latest, $workload, $taskSummary);
        }

        $academicStatus = $latest["academicStatus"] ?? "No Record";
        $competencyStatus = $latest["competencyStatus"] ?? "No Record";
        $attendanceStatus = $latest["attendanceStatus"] ?? "No Record";
        $requirementStatus = $latest["requirementStatus"] ?? "No Record";
        $trendStatus = $latest["trendStatus"] ?? "Insufficient Trend Data";
        $workloadStatus = $workload["lingguhangBigatIndex"] ?? "Magaan";
        $alertCount = (int)($taskSummary["alertCount"] ?? 0);

        if ($academicStatus === "No Record" && $competencyStatus === "No Record" && $attendanceStatus === "No Record") {
            return "Needs Review";
        }

        $outputText = strtolower(trim($academicStatus . " " . $competencyStatus . " " . $attendanceStatus . " " . $requirementStatus . " " . $trendStatus . " " . $workloadStatus));

        if (
            strpos($outputText, "at-risk") !== false ||
            strpos($outputText, "failing") !== false ||
            strpos($outputText, "warning") !== false ||
            strpos($outputText, "not mastered") !== false ||
            strpos($outputText, "remediation") !== false ||
            strpos($outputText, "attendance concern") !== false ||
            strpos($outputText, "incomplete") !== false ||
            strpos($outputText, "declining") !== false ||
            strpos($outputText, "mabigat") !== false ||
            $alertCount > 0
        ) {
            return "Needs Review";
        }

        return "Consistent";
    }
}

if (!function_exists("filter_page_monitoring_rows")) {
    function filter_page_monitoring_rows($rows, $filters = []) {
        $filtered = [];

        foreach ($rows as $row) {
            $student = $row["student"] ?? [];
            $latest = $row["latest"] ?? [];
            $workload = $row["workload"] ?? [];
            $taskSummary = $row["taskSummary"] ?? [];
            $academicStatus = $latest["academicStatus"] ?? "";
            $competencyStatus = $latest["competencyStatus"] ?? "";
            $attendanceStatus = $latest["attendanceStatus"] ?? "";
            $requirementStatus = $latest["requirementStatus"] ?? "";
            $trendStatus = $latest["trendStatus"] ?? "";
            $workloadStatus = $workload["lingguhangBigatIndex"] ?? "";
            $followUpType = $row["followUpType"] ?? "";
            $subject = $latest["subject"] ?? "";
            $validationStatus = page_auto_output_validation_status($latest, $workload, $taskSummary);

            $searchText = strtolower(trim(
                ($student["code"] ?? "") . " " .
                ($student["name"] ?? "") . " " .
                ($student["strand"] ?? "") . " " .
                ($student["section"] ?? "") . " " .
                $subject . " " .
                $academicStatus . " " .
                $competencyStatus . " " .
                $attendanceStatus . " " .
                $requirementStatus . " " .
                $trendStatus . " " .
                $workloadStatus . " " .
                $followUpType . " " .
                $validationStatus
            ));

            if (($filters["q"] ?? "") !== "" && strpos($searchText, strtolower(trim($filters["q"]))) === false) {
                continue;
            }

            if (($filters["gradeStatus"] ?? "") !== "" && $academicStatus !== $filters["gradeStatus"]) {
                continue;
            }

            if (($filters["competencyStatus"] ?? "") !== "" && $competencyStatus !== $filters["competencyStatus"]) {
                continue;
            }

            if (($filters["attendanceStatus"] ?? "") !== "" && $attendanceStatus !== $filters["attendanceStatus"]) {
                continue;
            }

            if (($filters["requirementStatus"] ?? "") !== "" && $requirementStatus !== $filters["requirementStatus"]) {
                continue;
            }

            if (($filters["trendStatus"] ?? "") !== "" && $trendStatus !== $filters["trendStatus"]) {
                continue;
            }

            if (($filters["workloadStatus"] ?? "") !== "" && $workloadStatus !== $filters["workloadStatus"]) {
                continue;
            }

            if (($filters["followUpType"] ?? "") !== "" && $followUpType !== $filters["followUpType"]) {
                continue;
            }

            if (($filters["validationStatus"] ?? "") !== "" && $validationStatus !== $filters["validationStatus"]) {
                continue;
            }

            if (($filters["strand"] ?? "") !== "" && stripos($student["strand"] ?? "", $filters["strand"]) === false) {
                continue;
            }

            if (($filters["section"] ?? "") !== "" && stripos($student["section"] ?? "", $filters["section"]) === false) {
                continue;
            }

            if (($filters["subject"] ?? "") !== "" && stripos($subject, $filters["subject"]) === false) {
                continue;
            }

            $row["autoValidationStatus"] = $validationStatus;
            $filtered[] = $row;
        }

        return $filtered;
    }
}

if (!function_exists("validation_assessment_records_from_rows")) {
    function validation_assessment_records_from_rows($rows, $filters = []) {
        $visibleStudentIds = [];
        $visibleStudents = [];

        foreach ($rows as $row) {
            $student = $row["student"] ?? [];

            if (!empty($student["id"])) {
                $visibleStudentIds[] = $student["id"];
                $visibleStudents[$student["id"]] = $student;
            }
        }

        $visibleStudentIds = array_values(array_unique($visibleStudentIds));
        $assessmentRecords = [];

        foreach ($visibleStudentIds as $studentId) {
            $student = $visibleStudents[$studentId] ?? find_user_by_id($studentId);
            $records = academic_record_history_for_student($studentId);

            foreach ($records as $record) {
                if (($record["recordMode"] ?? "assessment") !== "assessment") {
                    continue;
                }

                $evaluated = evaluate_record($record);
                $assessmentType = $evaluated["assessmentType"] ?? "Assessment";
                $subject = $evaluated["subject"] ?? "";
                $score = $evaluated["score"] ?? "";
                $totalScore = $evaluated["totalScore"] ?? "";
                $percentage = $evaluated["assessmentPercentage"] ?? "";
                $submissionStatus = $evaluated["submissionStatus"] ?? "Submitted";
                $validationStatus = page_auto_score_validation_status($evaluated);
                $systemOutput = trim($assessmentType . " / Score " . $score . " of " . $totalScore . " / " . $percentage . "% / " . $submissionStatus);

                $searchText = strtolower(trim(
                    ($student["code"] ?? "") . " " .
                    ($student["name"] ?? "") . " " .
                    ($student["strand"] ?? "") . " " .
                    ($student["section"] ?? "") . " " .
                    $subject . " " .
                    ($evaluated["gradingPeriod"] ?? "") . " " .
                    ($evaluated["assessmentTitle"] ?? "") . " " .
                    $assessmentType . " " .
                    $score . " " .
                    $totalScore . " " .
                    $percentage . " " .
                    $submissionStatus . " " .
                    $validationStatus
                ));

                if (($filters["q"] ?? "") !== "" && strpos($searchText, strtolower(trim($filters["q"]))) === false) {
                    continue;
                }

                if (($filters["validationStatus"] ?? "") !== "" && $validationStatus !== $filters["validationStatus"]) {
                    continue;
                }

                if (($filters["subject"] ?? "") !== "" && stripos($subject, $filters["subject"]) === false) {
                    continue;
                }

                if (($filters["strand"] ?? "") !== "" && stripos($student["strand"] ?? "", $filters["strand"]) === false) {
                    continue;
                }

                if (($filters["section"] ?? "") !== "" && stripos($student["section"] ?? "", $filters["section"]) === false) {
                    continue;
                }

                $assessmentRecords[] = [
                    "student" => $student,
                    "record" => $evaluated,
                    "systemOutput" => $systemOutput,
                    "autoValidationStatus" => $validationStatus
                ];
            }
        }

        usort($assessmentRecords, function($a, $b) {
            $aDate = $a["record"]["assessmentDate"] ?? $a["record"]["createdAt"] ?? "now";
            $bDate = $b["record"]["assessmentDate"] ?? $b["record"]["createdAt"] ?? "now";
            return strtotime($bDate) <=> strtotime($aDate);
        });

        return $assessmentRecords;
    }
}

if (!function_exists("validation_attendance_records_from_rows")) {
    function validation_attendance_records_from_rows($rows, $filters = []) {
        $visibleStudentIds = [];
        $visibleStudents = [];

        foreach ($rows as $row) {
            $student = $row["student"] ?? [];

            if (!empty($student["id"])) {
                $visibleStudentIds[] = $student["id"];
                $visibleStudents[$student["id"]] = $student;
            }
        }

        $visibleStudentIds = array_values(array_unique($visibleStudentIds));
        $attendanceRecords = [];

        $attendanceSource = function_exists("read_records_where_in") ? read_records_where_in("attendance", "studentId", $visibleStudentIds, "coalesce(data->>'date', data->>'createdAt', '') desc, created_at desc, id desc") : read_records("attendance");

        foreach ($attendanceSource as $attendance) {
            if (!in_array($attendance["studentId"] ?? "", $visibleStudentIds, true)) {
                continue;
            }

            $student = $visibleStudents[$attendance["studentId"] ?? ""] ?? find_user_by_id($attendance["studentId"] ?? "");
            $computedAttendanceStatus = ($attendance["status"] ?? "") === "Absent" ? "Attendance Concern" : "Regular Attendance";

            $searchText = strtolower(trim(
                ($student["code"] ?? "") . " " .
                ($student["name"] ?? "") . " " .
                ($student["strand"] ?? "") . " " .
                ($student["section"] ?? "") . " " .
                ($attendance["subject"] ?? "") . " " .
                ($attendance["status"] ?? "") . " " .
                ($attendance["note"] ?? "") . " " .
                ($attendance["date"] ?? "") . " " .
                $computedAttendanceStatus
            ));

            if (($filters["q"] ?? "") !== "" && strpos($searchText, strtolower(trim($filters["q"]))) === false) {
                continue;
            }

            if (($filters["subject"] ?? "") !== "" && stripos($attendance["subject"] ?? "", $filters["subject"]) === false) {
                continue;
            }

            if (($filters["attendanceStatus"] ?? "") !== "" && $computedAttendanceStatus !== $filters["attendanceStatus"]) {
                continue;
            }

            if (($filters["strand"] ?? "") !== "" && stripos($student["strand"] ?? "", $filters["strand"]) === false) {
                continue;
            }

            if (($filters["section"] ?? "") !== "" && stripos($student["section"] ?? "", $filters["section"]) === false) {
                continue;
            }

            $attendance["studentName"] = $student["name"] ?? "";
            $attendance["studentCode"] = $student["code"] ?? "";
            $attendance["studentStrand"] = $student["strand"] ?? "";
            $attendance["studentSection"] = $student["section"] ?? "";
            $attendance["computedAttendanceStatus"] = $computedAttendanceStatus;
            $attendanceRecords[] = $attendance;
        }

        usort($attendanceRecords, function($a, $b) {
            return strtotime($b["updatedAt"] ?? $b["createdAt"] ?? $b["date"] ?? "now") <=> strtotime($a["updatedAt"] ?? $a["createdAt"] ?? "now");
        });

        return $attendanceRecords;
    }
}

if (!function_exists("validation_delete_requests_from_rows")) {
    function validation_delete_requests_from_rows($rows, $filters = []) {
        $visibleStudentIds = [];
        $visibleStudents = [];

        foreach ($rows as $row) {
            $student = $row["student"] ?? [];

            if (!empty($student["id"])) {
                $visibleStudentIds[] = $student["id"];
                $visibleStudents[$student["id"]] = $student;
            }
        }

        $visibleStudentIds = array_values(array_unique($visibleStudentIds));
        $requests = [];

        if (!count($visibleStudentIds)) {
            return $requests;
        }

        $deleteRequestSource = function_exists("read_records_where_in")
            ? read_records_where_in(
                "delete_requests",
                "studentId",
                $visibleStudentIds,
                "coalesce(data->>'updatedAt', data->>'createdAt', '') desc, updated_at desc, id desc"
            )
            : read_records("delete_requests");

        foreach ($deleteRequestSource as $request) {
            $studentId = $request["studentId"] ?? "";

            if (!in_array($studentId, $visibleStudentIds, true)) {
                continue;
            }

            $student = $visibleStudents[$studentId] ?? find_user_by_id($studentId);
            $recordId = $request["recordId"] ?? "";
            $storedRecord = function_exists("find_record_by_id") ? find_record_by_id($recordId) : null;
            $snapshot = is_array($request["recordSnapshot"] ?? null) ? $request["recordSnapshot"] : [];
            $record = is_array($storedRecord) && count($storedRecord) ? $storedRecord : $snapshot;

            if (!count($record)) {
                $record = [
                    "id" => $recordId,
                    "studentId" => $studentId,
                    "subject" => $request["subject"] ?? "",
                    "assessmentType" => $request["assessmentType"] ?? "",
                    "assessmentTitle" => $request["assessmentTitle"] ?? ""
                ];
            }

            $status = $request["status"] ?? "Pending";
            $searchText = strtolower(trim(
                ($student["code"] ?? "") . " " .
                ($student["name"] ?? "") . " " .
                ($student["strand"] ?? "") . " " .
                ($student["section"] ?? "") . " " .
                ($record["subject"] ?? $request["subject"] ?? "") . " " .
                ($record["assessmentType"] ?? $request["assessmentType"] ?? "") . " " .
                ($record["assessmentTitle"] ?? $request["assessmentTitle"] ?? "") . " " .
                ($request["reason"] ?? "") . " " .
                ($request["reviewNote"] ?? "") . " " .
                $status
            ));

            if (($filters["q"] ?? "") !== "" && strpos($searchText, strtolower(trim($filters["q"]))) === false) {
                continue;
            }

            if (($filters["subject"] ?? "") !== "" && stripos($record["subject"] ?? $request["subject"] ?? "", $filters["subject"]) === false) {
                continue;
            }

            if (($filters["strand"] ?? "") !== "" && stripos($student["strand"] ?? "", $filters["strand"]) === false) {
                continue;
            }

            if (($filters["section"] ?? "") !== "" && stripos($student["section"] ?? "", $filters["section"]) === false) {
                continue;
            }

            if (($filters["deleteRequestStatus"] ?? "") !== "" && $status !== $filters["deleteRequestStatus"]) {
                continue;
            }

            $request["student"] = $student;
            $request["record"] = $record;
            $request["recordDeleted"] = !(is_array($storedRecord) && count($storedRecord));
            $requests[] = $request;
        }

        usort($requests, function($a, $b) {
            return strtotime($b["updatedAt"] ?? $b["createdAt"] ?? "now") <=> strtotime($a["updatedAt"] ?? $a["createdAt"] ?? "now");
        });

        return $requests;
    }
}

if (!function_exists("validation_history_records_from_rows")) {
    function validation_history_records_from_rows($rows, $filters = []) {
        $visibleStudentIds = [];

        foreach ($rows as $row) {
            $studentId = $row["student"]["id"] ?? "";

            if ($studentId !== "") {
                $visibleStudentIds[] = $studentId;
            }
        }

        $visibleStudentIds = array_values(array_unique($visibleStudentIds));
        $history = [];

        $validationSource = function_exists("read_records_where_in") ? read_records_where_in("validations", "studentId", $visibleStudentIds, "created_at desc, id desc") : read_records("validations");

        foreach ($validationSource as $validation) {
            if (($validation["studentId"] ?? "") !== "" && !in_array($validation["studentId"] ?? "", $visibleStudentIds, true)) {
                continue;
            }

            $student = find_user_by_id($validation["studentId"] ?? "");
            $searchText = strtolower(trim(
                ($student["code"] ?? "") . " " .
                ($student["name"] ?? "") . " " .
                ($validation["subject"] ?? "") . " " .
                ($validation["systemOutput"] ?? "") . " " .
                ($validation["validationStatus"] ?? "") . " " .
                ($validation["note"] ?? "") . " " .
                ($validation["itemAnalysisNotes"] ?? "") . " " .
                ($validation["competencyArea"] ?? "") . " " .
                ($validation["followUpPlan"] ?? "")
            ));

            if (($filters["q"] ?? "") !== "" && strpos($searchText, strtolower(trim($filters["q"]))) === false) {
                continue;
            }

            if (($filters["validationStatus"] ?? "") !== "" && (($validation["validationStatus"] ?? "") !== $filters["validationStatus"])) {
                continue;
            }

            if (($filters["subject"] ?? "") !== "" && stripos($validation["subject"] ?? "", $filters["subject"]) === false) {
                continue;
            }

            $validation["studentName"] = $student["name"] ?? "";
            $validation["studentCode"] = $student["code"] ?? "";
            $history[] = $validation;
        }

        usort($history, function($a, $b) {
            return strtotime($b["createdAt"] ?? "now") <=> strtotime($a["createdAt"] ?? "now");
        });

        return $history;
    }
}