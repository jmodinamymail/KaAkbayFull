<?php
require_once __DIR__ . "/auth.php";
require_once __DIR__ . "/functions.php";

function remove_uploaded_system_logo_file($logoUrl) {
    $logoUrl = trim((string)$logoUrl);

    if ($logoUrl === "") {
        return;
    }

    if (strpos($logoUrl, "assets/images/system-logo-") !== 0) {
        return;
    }

    $imagesDirectory = realpath(dirname(__DIR__) . "/assets/images");

    if ($imagesDirectory === false) {
        return;
    }

    $logoFile = realpath(dirname(__DIR__) . "/" . ltrim($logoUrl, "/"));

    if ($logoFile === false || !is_file($logoFile)) {
        return;
    }

    if (strpos($logoFile, $imagesDirectory . DIRECTORY_SEPARATOR) !== 0) {
        return;
    }

    @unlink($logoFile);
}


function page_action_sensitive_confirmation($userId, $password, $scope) {
    if (!function_exists("confirm_sensitive_action") || !function_exists("sensitive_action_is_verified")) {
        return [
            "ok" => false,
            "message" => msg(
                "Sensitive-action verification is not available.",
                "Hindi available ang sensitive-action verification.",
                "Sensitive-action verification is not available."
            )
        ];
    }

    if (!confirm_sensitive_action($userId, $password, $scope, 300)) {
        return [
            "ok" => false,
            "message" => msg(
                "Current password confirmation is required for this action.",
                "Kailangan ang current password confirmation para sa action na ito.",
                "Current password confirmation is required for this action."
            )
        ];
    }

    if (!sensitive_action_is_verified($userId, $scope, true)) {
        return [
            "ok" => false,
            "message" => msg(
                "Security confirmation expired. Try again.",
                "Expired na ang security confirmation. Subukan muli.",
                "Security confirmation expired. Try again."
            )
        ];
    }

    return ["ok" => true, "message" => ""];
}

function page_action_store_user_management_notice($type, $result) {
    $_SESSION["userManagementNotice"] = [
        "type" => (string)$type,
        "message" => (string)($result["message"] ?? ""),
        "targetUserId" => (string)($result["targetUserId"] ?? $result["userId"] ?? ""),
        "temporaryPassword" => (string)($result["temporaryPassword"] ?? ""),
        "createdAt" => time()
    ];
}

function page_action_prepare_security_email($type, $recipient, $token, $expiresAt, $userId = "") {
    $recipient = strtolower(trim((string)$recipient));
    $token = trim((string)$token);

    if ($recipient === "" || !filter_var($recipient, FILTER_VALIDATE_EMAIL) || $token === "") {
        return [
            "ok" => false,
            "sent" => false,
            "message" => msg(
                "Unable to prepare the verification email.",
                "Hindi maihanda ang verification email.",
                "Unable to prepare the verification email."
            )
        ];
    }

    $payload = [
        "type" => (string)$type,
        "recipient" => $recipient,
        "token" => $token,
        "expiresAt" => (string)$expiresAt,
        "userId" => (string)$userId,
        "createdAt" => date("c")
    ];

    if (function_exists("send_security_email_message")) {
        $delivery = send_security_email_message($payload);

        if (is_array($delivery)) {
            return array_merge(["ok" => false, "sent" => false, "message" => ""], $delivery);
        }

        if ($delivery === true) {
            return ["ok" => true, "sent" => true, "message" => ""];
        }

        return [
            "ok" => false,
            "sent" => false,
            "message" => msg(
                "The verification request was saved, but the email could not be sent.",
                "Nai-save ang verification request pero hindi naipadala ang email.",
                "The verification request was saved, but the email could not be sent."
            )
        ];
    }

    $_SESSION["pendingSecurityEmail"] = $payload;

    return [
        "ok" => true,
        "sent" => false,
        "queued" => true,
        "message" => ""
    ];
}

function page_action_deliver_password_change_otp($userId, $otpResult) {
    $userId = trim((string)$userId);

    if (
        $userId === "" ||
        !is_array($otpResult) ||
        empty($otpResult["ok"]) ||
        empty($otpResult["code"]) ||
        empty($otpResult["email"])
    ) {
        return [
            "ok" => false,
            "message" => msg(
                "Unable to prepare password-change verification.",
                "Hindi maihanda ang password-change verification.",
                "Unable to prepare password-change verification."
            )
        ];
    }

    $delivery = page_action_prepare_security_email(
        "password_change_otp",
        $otpResult["email"] ?? "",
        $otpResult["code"] ?? "",
        $otpResult["expiresAt"] ?? "",
        $userId
    );

    if (empty($delivery["ok"]) || empty($delivery["sent"])) {
        if (function_exists("cancel_password_change_otp")) {
            cancel_password_change_otp($userId);
        }

        if (function_exists("audit_log")) {
            audit_log(
                $userId,
                "PASSWORD_CHANGE_OTP_DELIVERY_FAILED",
                "Password-change OTP could not be delivered and the pending password-change challenge was cleared.",
                ["category" => "security"]
            );
        }

        return [
            "ok" => false,
            "message" => !empty($delivery["queued"])
                ? msg(
                    "Password-change verification cannot continue until email delivery is configured.",
                    "Hindi makakapagpatuloy ang password-change verification hangga't hindi naka-configure ang email delivery.",
                    "Password-change verification cannot continue until email delivery is configured."
                )
                : ($delivery["message"] ?? msg(
                    "The password-change verification code could not be delivered. Please try again.",
                    "Hindi maipadala ang password-change verification code. Subukan muli.",
                    "The password-change verification code could not be delivered. Please try again."
                ))
        ];
    }

    return [
        "ok" => true,
        "message" => "",
        "maskedEmail" => (string)($otpResult["maskedEmail"] ?? ""),
        "resendAfter" => max(0, (int)($otpResult["resendAfter"] ?? 0))
    ];
}

function page_action_upload_system_logo($file) {
    if (!is_array($file)) {
        return ["ok" => false, "message" => msg("Invalid logo upload.", "Hindi wasto ang logo upload.", "Invalid logo upload.")];
    }

    $uploadError = (int)($file["error"] ?? UPLOAD_ERR_NO_FILE);

    if ($uploadError !== UPLOAD_ERR_OK) {
        return ["ok" => false, "message" => msg("Logo upload failed.", "Hindi na-upload ang logo.", "Logo upload failed.")];
    }

    $fileSize = (int)($file["size"] ?? 0);

    if ($fileSize <= 0) {
        return ["ok" => false, "message" => msg("The selected logo file is empty.", "Walang laman ang napiling logo file.", "The selected logo file is empty.")];
    }

    if ($fileSize > 2 * 1024 * 1024) {
        return ["ok" => false, "message" => msg("Logo must not exceed 2 MB.", "Hindi dapat lumampas sa 2 MB ang logo.", "Logo must not exceed 2 MB.")];
    }

    $tmpName = (string)($file["tmp_name"] ?? "");

    if ($tmpName === "" || !is_uploaded_file($tmpName) || !is_file($tmpName)) {
        return ["ok" => false, "message" => msg("Invalid logo upload.", "Hindi wasto ang logo upload.", "Invalid logo upload.")];
    }

    $imageInfo = @getimagesize($tmpName);

    if (!is_array($imageInfo)) {
        return ["ok" => false, "message" => msg("The uploaded file is not a valid image.", "Hindi valid image ang na-upload na file.", "The uploaded file is not a valid image.")];
    }

    $detectedMime = strtolower(trim((string)($imageInfo["mime"] ?? "")));

    if (function_exists("finfo_open")) {
        $finfo = @finfo_open(FILEINFO_MIME_TYPE);

        if ($finfo) {
            $finfoMime = strtolower(trim((string)@finfo_file($finfo, $tmpName)));
            @finfo_close($finfo);

            if ($finfoMime !== "") {
                $detectedMime = $finfoMime;
            }
        }
    }

    $allowedTypes = [
        "image/png" => ["extension" => "png", "imageType" => IMAGETYPE_PNG],
        "image/jpeg" => ["extension" => "jpg", "imageType" => IMAGETYPE_JPEG],
        "image/webp" => ["extension" => "webp", "imageType" => IMAGETYPE_WEBP]
    ];

    if (!isset($allowedTypes[$detectedMime])) {
        return ["ok" => false, "message" => msg("Only PNG, JPG, and WEBP images are allowed.", "PNG, JPG, at WEBP images lamang ang pinapayagan.", "Only PNG, JPG, and WEBP images are allowed.")];
    }

    $actualImageType = (int)($imageInfo[2] ?? 0);

    if ($actualImageType !== (int)$allowedTypes[$detectedMime]["imageType"]) {
        return ["ok" => false, "message" => msg("The logo file type does not match its image content.", "Hindi tugma ang logo file type sa image content nito.", "The logo file type does not match its image content.")];
    }

    $width = (int)($imageInfo[0] ?? 0);
    $height = (int)($imageInfo[1] ?? 0);

    if ($width <= 0 || $height <= 0 || $width > 4096 || $height > 4096 || ($width * $height) > 16777216) {
        return ["ok" => false, "message" => msg("Logo dimensions are invalid or too large.", "Invalid o masyadong malaki ang dimensions ng logo.", "Logo dimensions are invalid or too large.")];
    }

    $uploadDirectory = dirname(__DIR__) . "/assets/images";

    if (!is_dir($uploadDirectory)) {
        if (!mkdir($uploadDirectory, 0755, true) && !is_dir($uploadDirectory)) {
            return ["ok" => false, "message" => msg("Unable to create the logo upload folder.", "Hindi magawa ang folder para sa logo upload.", "Unable to create the logo upload folder.")];
        }
    }

    $realUploadDirectory = realpath($uploadDirectory);

    if ($realUploadDirectory === false || !is_writable($realUploadDirectory)) {
        return ["ok" => false, "message" => msg("The logo upload folder is not writable.", "Hindi maaaring sulatan ang logo upload folder.", "The logo upload folder is not writable.")];
    }

    try {
        $randomName = bin2hex(random_bytes(16));
    } catch (Throwable $e) {
        return ["ok" => false, "message" => msg("Unable to generate a secure logo filename.", "Hindi makagawa ng secure na filename para sa logo.", "Unable to generate a secure logo filename.")];
    }

    $extension = $allowedTypes[$detectedMime]["extension"];
    $fileName = "system-logo-" . time() . "-" . $randomName . "." . $extension;
    $destination = $realUploadDirectory . DIRECTORY_SEPARATOR . $fileName;

    if (!move_uploaded_file($tmpName, $destination)) {
        return ["ok" => false, "message" => msg("Unable to save the uploaded logo.", "Hindi ma-save ang na-upload na logo.", "Unable to save the uploaded logo.")];
    }

    @chmod($destination, 0644);

    return [
        "ok" => true,
        "message" => "",
        "logoUrl" => "assets/images/" . $fileName
    ];
}

function page_action_records_error_redirect($message) {
    $_SESSION["recordsFlashError"] = trim((string)$message);

    $recordId = trim((string)($_POST["recordId"] ?? ""));
    $location = "records.php";

    if ($recordId !== "") {
        $location .= "?edit=" . rawurlencode($recordId);
    }

    $location .= "#assessment-entry";
    header("Location: " . $location, true, 303);
    exit;
}


function handle_page_action($page, $user) {
    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        return "";
    }

    if (!verify_csrf($_POST["csrf_token"] ?? "")) {
        $message = msg("Invalid security token.", "Hindi wasto ang security token.", "Invalid ang security token.");

        if ($page === "records") {
            page_action_records_error_redirect($message);
        }

        return $message;
    }

    $action = $_POST["action"] ?? "";

    if (in_array($page, ["dashboard", "monitor", "validation", "schedules"], true) && $action === "markAttendance") {
        if (!in_array($user["role"] ?? "", ["teacher", "admin", "super_admin"], true)) {
            return msg("You are not allowed to mark attendance.", "Hindi ka pinapayagang mag-mark ng attendance.", "Not allowed ka mag-mark ng attendance.");
        }

        if (!function_exists("save_attendance_mark")) {
            return msg("Attendance function is not available.", "Hindi available ang attendance function.", "Attendance function is not available.");
        }

        $result = save_attendance_mark($user["id"], $_POST);

        if ($result["ok"]) {
            $redirect = trim((string)($_POST["redirect"] ?? ""));
            $allowedRedirects = ["dashboard.php", "monitor.php", "validation.php", "schedules.php"];

            if ($redirect !== "" && in_array($redirect, $allowedRedirects, true)) {
                header("Location: " . $redirect);
                exit;
            }

            if ($page === "validation") {
                header("Location: validation.php");
                exit;
            }

            if ($page === "monitor") {
                header("Location: monitor.php");
                exit;
            }

            if ($page === "schedules") {
                header("Location: schedules.php");
                exit;
            }

            header("Location: dashboard.php");
            exit;
        }

        return $result["message"];
    }

    if ($page === "records") {
        $action = $_POST["action"] ?? "save";

        if ($action === "delete") {
            if (!function_exists("delete_academic_record")) {
                page_action_records_error_redirect(msg(
                    "Academic record deletion is not available.",
                    "Hindi available ang academic record deletion.",
                    "Academic record deletion is not available."
                ));
            }

            $result = delete_academic_record($user["id"], $_POST["recordId"] ?? "", false);

            if ($result["ok"]) {
                header("Location: records.php");
                exit;
            }

            page_action_records_error_redirect($result["message"] ?? msg(
                "Unable to delete the academic record.",
                "Hindi matanggal ang academic record.",
                "Unable to delete the academic record."
            ));
        }

        if ($action === "requestDelete") {
            if (!function_exists("save_record_delete_request")) {
                page_action_records_error_redirect(msg(
                    "Deletion request function is not available.",
                    "Hindi available ang deletion request function.",
                    "Deletion request function is not available."
                ));
            }

            $result = save_record_delete_request($user["id"], $_POST["recordId"] ?? "", $_POST["reason"] ?? "");

            if ($result["ok"]) {
                header("Location: records.php");
                exit;
            }

            page_action_records_error_redirect($result["message"] ?? msg(
                "Unable to submit the deletion request.",
                "Hindi ma-submit ang deletion request.",
                "Unable to submit the deletion request."
            ));
        }

        $result = save_academic_record($user["id"], $_POST);

        if ($result["ok"]) {
            header("Location: records.php");
            exit;
        }

        page_action_records_error_redirect($result["message"] ?? msg(
            "Unable to save the academic record.",
            "Hindi ma-save ang academic record.",
            "Unable to save the academic record."
        ));
    }

    if ($page === "tasks") {
        if (isset($_POST["taskAction"])) {
            $taskAction = strtolower(trim((string)($_POST["taskAction"] ?? "")));
            $taskId = (string)($_POST["taskId"] ?? "");

            if (in_array($taskAction, ["delete", "remove", "cancel", "cancelled", "canceled"], true)) {
                $result = task_remove_or_delete(
                    $taskId,
                    $user["id"],
                    $taskAction,
                    $_POST["reason"] ?? $_POST["removalReason"] ?? ""
                );

                if (empty($result["ok"])) {
                    return $result["message"] ?? msg("Unable to update the task.", "Hindi ma-update ang task.", "Unable to update the task.");
                }

                header("Location: tasks.php");
                exit;
            }

            $updated = update_task_action(
                $taskId,
                $user["id"],
                $taskAction,
                $_POST
            );

            if (!$updated) {
                return msg("Unable to update the task.", "Hindi ma-update ang task.", "Unable to update the task.");
            }

            if ($taskAction === "subtask") {
                header(
                    "Location: tasks.php?breakdown=" .
                    urlencode($taskId)
                );
                exit;
            }

            header("Location: tasks.php");
            exit;
        }

        $result = save_task($user["id"], $_POST);

        if ($result["ok"]) {
            header("Location: tasks.php");
            exit;
        }

        return $result["message"];
    }

    if ($page === "schedules") {
        $action = $_POST["action"] ?? "";

        if ($action === "delete") {
            delete_schedule(
                $user["id"],
                $_POST["scheduleId"] ?? ""
            );

            header("Location: schedules.php");
            exit;
        }

        $result = save_schedule(
            $user["id"],
            $_POST
        );

        if ($result["ok"]) {
            header("Location: schedules.php");
            exit;
        }

        return $result["message"];
    }

    if ($page === "validation") {
        if (!in_array($user["role"] ?? "", ["teacher", "admin", "super_admin"], true)) {
            return msg(
                "You are not allowed to validate records.",
                "Hindi ka pinapayagang mag-validate ng records.",
                "Not allowed ka mag-validate ng records."
            );
        }

        if (in_array($action, ["reviewDeleteRequest", "approveDeleteRequest", "rejectDeleteRequest"], true)) {
            if (!function_exists("review_record_delete_request")) {
                return msg(
                    "Deletion request review is not available.",
                    "Hindi available ang deletion request review.",
                    "Deletion request review is not available."
                );
            }

            $requestId = safe_text($_POST["requestId"] ?? "", 80);
            $decisionInput = strtolower(trim((string)($_POST["decision"] ?? "")));

            if ($action === "approveDeleteRequest") {
                $decisionInput = "approve";
            } elseif ($action === "rejectDeleteRequest") {
                $decisionInput = "reject";
            }

            $decision = $decisionInput === "approve"
                ? "Approved"
                : ($decisionInput === "reject" ? "Rejected" : "");

            if ($decision === "") {
                return msg(
                    "Select whether to approve or reject the deletion request.",
                    "Piliin kung ia-approve o ire-reject ang deletion request.",
                    "Select whether to approve or reject the deletion request."
                );
            }

            $deleteRequest = find_storage_record_by_id("delete_requests", $requestId);

            if (!$deleteRequest) {
                return msg(
                    "Deletion request not found.",
                    "Hindi nahanap ang deletion request.",
                    "Deletion request not found."
                );
            }

            $student = find_user_by_id($deleteRequest["studentId"] ?? "");
            $reviewerRole = $user["role"] ?? "";
            $canReviewRequest = in_array($reviewerRole, ["admin", "super_admin"], true);

            if ($reviewerRole === "teacher" && $student && function_exists("student_visible_to_user")) {
                $canReviewRequest = student_visible_to_user($student, $user);
            }

            if (!$canReviewRequest) {
                return msg(
                    "You are not allowed to review this student's deletion request.",
                    "Hindi ka pinapayagang i-review ang deletion request ng student na ito.",
                    "You are not allowed to review this student's deletion request."
                );
            }

            $result = review_record_delete_request(
                $requestId,
                $user["id"],
                $decision,
                $_POST["reviewNote"] ?? ""
            );

            if ($result["ok"]) {
                header("Location: validation.php");
                exit;
            }

            return $result["message"];
        }

        if (!function_exists("save_validation")) {
            return msg(
                "Validation function is not available.",
                "Hindi available ang validation function.",
                "Validation function is not available."
            );
        }

        $result = save_validation(
            $user["id"],
            $_POST
        );

        if ($result["ok"]) {
            header("Location: validation.php");
            exit;
        }

        return $result["message"];
    }

    if ($page === "users") {
        $action = $_POST["action"] ?? "";

        if (!in_array($user["role"] ?? "", ["admin", "super_admin"], true)) {
            return msg(
                "You are not allowed to manage users.",
                "Hindi ka pinapayagang mag-manage ng users.",
                "Not allowed ka mag-manage ng users."
            );
        }

        if ($action === "addSection") {
            if (!function_exists("create_section")) {
                return msg(
                    "Section function is not available.",
                    "Hindi available ang section function.",
                    "Section function is not available."
                );
            }

            $result = create_section($_POST);

            if ($result["ok"]) {
                header("Location: users.php");
                exit;
            }

            return $result["message"];
        }

        if ($action === "deleteSection") {
            if (!function_exists("delete_section")) {
                return msg(
                    "Section delete function is not available.",
                    "Hindi available ang section delete function.",
                    "Section delete function is not available."
                );
            }

            $result = delete_section(
                $_POST["sectionId"] ?? ""
            );

            if ($result["ok"]) {
                header("Location: users.php");
                exit;
            }

            return $result["message"];
        }

        if ($action === "add") {
            $newRole = strtolower(trim((string)($_POST["role"] ?? "")));

            if (in_array($newRole, ["admin", "super_admin", "it_admin"], true)) {
                $confirmation = page_action_sensitive_confirmation(
                    $user["id"],
                    $_POST["currentPassword"] ?? "",
                    "user_create_privileged"
                );

                if (!$confirmation["ok"]) {
                    return $confirmation["message"];
                }
            }

            $result = create_user_account($_POST);

            if ($result["ok"]) {
                if (!empty($result["temporaryPassword"])) {
                    page_action_store_user_management_notice("accountCreated", $result);
                }

                header("Location: users.php");
                exit;
            }

            return $result["message"];
        }

        if ($action === "status") {
            $result = toggle_user_status_with_confirmation(
                $_POST["userId"] ?? "",
                $user["id"],
                $_POST["currentPassword"] ?? ""
            );

            if (empty($result["ok"])) {
                return $result["message"] ?? msg(
                    "Unable to change this account status.",
                    "Hindi mabago ang status ng account na ito.",
                    "Unable to change this account status."
                );
            }

            header("Location: users.php");
            exit;
        }

        if ($action === "changeRole") {
            if (($user["role"] ?? "") !== "super_admin") {
                return msg(
                    "Only the Super Administrator can change account roles.",
                    "Super Administrator lamang ang maaaring magpalit ng account role.",
                    "Only the Super Administrator can change account roles."
                );
            }

            $result = change_user_role_with_confirmation(
                $_POST["userId"] ?? "",
                $_POST["role"] ?? $_POST["newRole"] ?? "",
                $user["id"],
                $_POST["currentPassword"] ?? ""
            );

            if (empty($result["ok"])) {
                return $result["message"];
            }

            header("Location: users.php?roleChanged=1");
            exit;
        }

        if ($action === "assignment") {
            $updated = update_user_assignment(
                $_POST["userId"] ?? "",
                $_POST
            );

            if (!$updated) {
                return msg(
                    "Unable to update this account assignment.",
                    "Hindi ma-update ang assignment ng account na ito.",
                    "Unable to update this account assignment."
                );
            }

            header("Location: users.php");
            exit;
        }
    }

    if ($page === "content") {
        if (($user["role"] ?? "") !== "super_admin") {
            return msg(
                "You are not allowed to manage system content.",
                "Hindi ka pinapayagang mag-manage ng system content.",
                "You are not allowed to manage system content."
            );
        }

        if ($action === "saveSystemSettings") {
            $confirmation = page_action_sensitive_confirmation(
                $user["id"],
                $_POST["currentPassword"] ?? "",
                "content_branding"
            );

            if (!$confirmation["ok"]) {
                return $confirmation["message"];
            }

            $settingsInput = $_POST;
            unset($settingsInput["currentPassword"]);
            $currentSettings = system_settings_record();
            $currentLogoUrl = trim((string)($currentSettings["logoUrl"] ?? ""));
            $logoUrl = $currentLogoUrl;
            $removeSystemLogo = ($_POST["removeSystemLogo"] ?? "") === "1";

            $hasNewLogo = isset($_FILES["systemLogo"])
                && is_array($_FILES["systemLogo"])
                && ($_FILES["systemLogo"]["error"] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;

            $newUploadedLogoUrl = "";

            if ($removeSystemLogo && !$hasNewLogo) {
                $logoUrl = "";
            }

            if ($hasNewLogo) {
                $uploadResult = page_action_upload_system_logo($_FILES["systemLogo"]);

                if (!$uploadResult["ok"]) {
                    return $uploadResult["message"];
                }

                $newUploadedLogoUrl = $uploadResult["logoUrl"];
                $logoUrl = $newUploadedLogoUrl;
            }

            $settingsInput["logoUrl"] = $logoUrl;
            unset($settingsInput["currentLogoUrl"]);

            $result = save_system_settings(
                $settingsInput,
                $user["id"]
            );

            if ($result["ok"]) {
                if ($currentLogoUrl !== "" && $currentLogoUrl !== $logoUrl) {
                    remove_uploaded_system_logo_file($currentLogoUrl);
                }

                header("Location: content.php?brandingSaved=1");
                exit;
            }

            if ($newUploadedLogoUrl !== "") {
                remove_uploaded_system_logo_file($newUploadedLogoUrl);
            }

            return $result["message"];
        }

        if ($action === "restoreBrandingDefaults") {
            $confirmation = page_action_sensitive_confirmation(
                $user["id"],
                $_POST["currentPassword"] ?? "",
                "content_branding_restore"
            );

            if (!$confirmation["ok"]) {
                return $confirmation["message"];
            }

            $currentSettings = system_settings_record();
            $currentLogoUrl = trim((string)($currentSettings["logoUrl"] ?? ""));

            $defaultSettings = [
                "systemName" => "Ka-Akbay",
                "logoUrl" => "",
                "primaryColor" => "#294FC3",
                "secondaryColor" => "#F5F5F5",
                "accentColor" => "#D4A017",
                "defaultTheme" => "light"
            ];

            $result = save_system_settings(
                $defaultSettings,
                $user["id"]
            );

            if ($result["ok"]) {
                if ($currentLogoUrl !== "") {
                    remove_uploaded_system_logo_file($currentLogoUrl);
                }

                header("Location: content.php?brandingRestored=1");
                exit;
            }

            return $result["message"];
        }

        if ($action === "saveSystemContent") {
            $result = save_system_content(
                $_POST["contentId"] ?? "",
                $_POST,
                $user["id"]
            );

            if ($result["ok"]) {
                header("Location: content.php?contentSaved=1");
                exit;
            }

            return $result["message"];
        }

        if ($action === "saveAnnouncement") {
            $result = save_announcement(
                $_POST,
                $user["id"],
                $_POST["announcementId"] ?? ""
            );

            if ($result["ok"]) {
                header("Location: content.php?announcementSaved=1");
                exit;
            }

            return $result["message"];
        }

        if ($action === "deleteAnnouncement") {
            $confirmation = page_action_sensitive_confirmation(
                $user["id"],
                $_POST["currentPassword"] ?? "",
                "delete_announcement"
            );

            if (!$confirmation["ok"]) {
                return $confirmation["message"];
            }

            $deleted = delete_announcement(
                $_POST["announcementId"] ?? "",
                $user["id"]
            );

            if (!$deleted) {
                return msg(
                    "Unable to delete this announcement.",
                    "Hindi ma-delete ang announcement na ito.",
                    "Unable to delete this announcement."
                );
            }

            header("Location: content.php?announcementDeleted=1");
            exit;
        }
    }

    if ($page === "system") {
        if (($user["role"] ?? "") !== "it_admin") {
            return msg(
                "You are not allowed to manage the system.",
                "Hindi ka pinapayagang mag-manage ng system.",
                "You are not allowed to manage the system."
            );
        }

        if ($action === "createBackup") {
            $result = create_system_backup(
                $user["id"],
                $_POST["label"] ?? ""
            );

            if ($result["ok"]) {
                header("Location: system.php");
                exit;
            }

            return $result["message"];
        }

        if ($action === "restoreBackup") {
            $result = restore_system_backup_with_confirmation(
                $_POST["backupId"] ?? "",
                $user["id"],
                $_POST["currentPassword"] ?? ""
            );

            if (!empty($result["ok"])) {
                if (!empty($result["sessionsRevoked"])) {
                    if (function_exists("auth_clear_session")) {
                        auth_clear_session();
                    } else {
                        unset(
                            $_SESSION["user"],
                            $_SESSION["active_session_token"],
                            $_SESSION["last_activity"],
                            $_SESSION["login_time"]
                        );
                    }

                    unset(
                        $_SESSION["pendingPrivilegedLogin"],
                        $_SESSION["pendingPrivilegedRecoveryEnrollment"]
                    );

                    session_regenerate_id(true);

                    $_SESSION["loginFlashNotice"] = msg(
                        "System backup restored successfully. A pre-restore checkpoint was created and existing sessions were revoked. Sign in again to continue.",
                        "Matagumpay na na-restore ang system backup. Gumawa ng pre-restore checkpoint at ni-revoke ang existing sessions. Mag-sign in muli para magpatuloy.",
                        "System backup restored successfully. A pre-restore checkpoint was created and existing sessions were revoked. Sign in again to continue."
                    );

                    header("Location: login.php");
                    exit;
                }

                header("Location: system.php?backupRestored=1");
                exit;
            }

            return $result["message"];
        }

        if ($action === "deleteBackup") {
            $result = delete_system_backup_with_confirmation(
                $_POST["backupId"] ?? "",
                $user["id"],
                $_POST["currentPassword"] ?? ""
            );

            if ($result["ok"]) {
                header("Location: system.php?backupDeleted=1");
                exit;
            }

            return $result["message"];
        }

        if ($action === "saveMaintenance") {
            $result = save_maintenance_settings_with_confirmation(
                $_POST,
                $user["id"],
                $_POST["currentPassword"] ?? ""
            );

            if (!empty($result["ok"])) {
                header("Location: system.php?maintenanceSaved=1");
                exit;
            }

            return $result["message"];
        }

        if ($action === "saveTechnicalSettings") {
            $result = save_technical_settings_with_confirmation(
                $_POST,
                $user["id"],
                $_POST["currentPassword"] ?? ""
            );

            if (!empty($result["ok"])) {
                header("Location: system.php?technicalSaved=1");
                exit;
            }

            return $result["message"];
        }

        if ($action === "revokeUserSessions") {
            $result = revoke_user_sessions_with_confirmation(
                $_POST["userId"] ?? "",
                $user["id"],
                $_POST["currentPassword"] ?? ""
            );

            if (empty($result["ok"])) {
                return $result["message"];
            }

            header("Location: system.php?sessionsRevoked=1");
            exit;
        }

        if ($action === "revokeAllUserSessions") {
            $result = revoke_all_user_sessions_with_confirmation(
                $user["id"],
                $_POST["currentPassword"] ?? ""
            );

            if (empty($result["ok"])) {
                return $result["message"];
            }

            header("Location: system.php?allSessionsRevoked=1");
            exit;
        }
    }

    if ($page === "profile") {
        $action = $_POST["action"] ?? "";
        $profilePasswordRoles = function_exists("app_roles")
            ? app_roles()
            : ["student", "teacher", "admin", "super_admin", "it_admin"];
        $profileRole = strtolower(trim((string)($user["role"] ?? "")));
        $profilePasswordActionAllowed = in_array($profileRole, $profilePasswordRoles, true);

        if ($action === "beginPasswordChangeOtp") {
            if (!$profilePasswordActionAllowed) {
                return msg(
                    "Password-change verification is not available for this account.",
                    "Hindi available ang password-change verification para sa account na ito.",
                    "Password-change verification is not available for this account."
                );
            }

            if (!function_exists("begin_password_change_otp")) {
                return msg(
                    "Password-change verification is not available.",
                    "Hindi available ang password-change verification.",
                    "Password-change verification is not available."
                );
            }

            $result = begin_password_change_otp(
                $user["id"],
                $_POST["currentPassword"] ?? ""
            );

            if (empty($result["ok"])) {
                return $result["message"] ?? msg(
                    "Unable to start password-change verification.",
                    "Hindi masimulan ang password-change verification.",
                    "Unable to start password-change verification."
                );
            }

            $delivery = page_action_deliver_password_change_otp($user["id"], $result);

            if (empty($delivery["ok"])) {
                return $delivery["message"];
            }

            header("Location: profile.php?passwordOtpSent=1");
            exit;
        }

        if ($action === "resendPasswordChangeOtp") {
            if (!$profilePasswordActionAllowed) {
                return msg(
                    "Password-change verification is not available for this account.",
                    "Hindi available ang password-change verification para sa account na ito.",
                    "Password-change verification is not available for this account."
                );
            }

            if (!function_exists("resend_password_change_otp")) {
                return msg(
                    "Password-change verification is not available.",
                    "Hindi available ang password-change verification.",
                    "Password-change verification is not available."
                );
            }

            $result = resend_password_change_otp($user["id"]);

            if (empty($result["ok"])) {
                return $result["message"] ?? msg(
                    "Unable to resend the verification code.",
                    "Hindi maipadala muli ang verification code.",
                    "Unable to resend the verification code."
                );
            }

            $delivery = page_action_deliver_password_change_otp($user["id"], $result);

            if (empty($delivery["ok"])) {
                return $delivery["message"];
            }

            header("Location: profile.php?passwordOtpResent=1");
            exit;
        }

        if ($action === "verifyPasswordChangeOtp") {
            if (!$profilePasswordActionAllowed) {
                return msg(
                    "Password-change verification is not available for this account.",
                    "Hindi available ang password-change verification para sa account na ito.",
                    "Password-change verification is not available for this account."
                );
            }

            if (!function_exists("validate_password_change_otp")) {
                return msg(
                    "Password-change verification is not available.",
                    "Hindi available ang password-change verification.",
                    "Password-change verification is not available."
                );
            }

            $result = validate_password_change_otp(
                $user["id"],
                $_POST["otpCode"] ?? $_POST["code"] ?? ""
            );

            if (empty($result["ok"])) {
                return $result["message"] ?? msg(
                    "Unable to verify the code.",
                    "Hindi ma-verify ang code.",
                    "Unable to verify the code."
                );
            }

            header("Location: profile.php?passwordOtpVerified=1");
            exit;
        }

        if ($action === "cancelPasswordChangeOtp") {
            if (!$profilePasswordActionAllowed) {
                return msg(
                    "Password-change verification is not available for this account.",
                    "Hindi available ang password-change verification para sa account na ito.",
                    "Password-change verification is not available for this account."
                );
            }

            if (!function_exists("cancel_password_change_otp") || !cancel_password_change_otp($user["id"])) {
                return msg(
                    "Unable to cancel password-change verification.",
                    "Hindi ma-cancel ang password-change verification.",
                    "Unable to cancel password-change verification."
                );
            }

            header("Location: profile.php?passwordOtpCancelled=1");
            exit;
        }

        if ($action === "changePassword") {
            if (!$profilePasswordActionAllowed) {
                return msg(
                    "You are not allowed to change the password from this account.",
                    "Hindi pinapayagan ang account na ito na magpalit ng password dito.",
                    "This account is not allowed to change the password here."
                );
            }

            if (!function_exists("change_user_password")) {
                return msg(
                    "Password change function is not available.",
                    "Hindi available ang password change function.",
                    "Password change function is not available."
                );
            }

            $result = change_user_password(
                $user["id"],
                $_POST
            );

            if (!empty($result["ok"])) {
                header("Location: profile.php?passwordChanged=1");
                exit;
            }

            return $result["message"] ?? msg(
                "Unable to change password.",
                "Hindi napalitan ang password.",
                "Unable to change password."
            );
        }

        if (in_array($action, ["setRecoveryEmail", "changeRecoveryEmail", "requestRecoveryEmailVerification"], true)) {
            $result = begin_recovery_email_verification(
                $user["id"],
                $_POST["recoveryEmail"] ?? "",
                $_POST["currentPassword"] ?? ""
            );

            if (!$result["ok"]) {
                return $result["message"];
            }

            $delivery = page_action_prepare_security_email(
                "recovery_email_verification",
                $result["email"] ?? "",
                $result["token"] ?? "",
                $result["expiresAt"] ?? "",
                $user["id"]
            );

            if (empty($delivery["ok"]) || empty($delivery["sent"])) {
                cancel_pending_recovery_email($user["id"]);

                if (function_exists("audit_log")) {
                    audit_log(
                        $user["id"],
                        "RECOVERY_EMAIL_DELIVERY_FAILED",
                        "Recovery email verification could not be delivered and the pending verification token was cleared.",
                        ["category" => "security"]
                    );
                }

                return !empty($delivery["queued"])
                    ? msg(
                        "Recovery email verification cannot continue until email delivery is configured.",
                        "Hindi makakapagpatuloy ang recovery email verification hangga't hindi naka-configure ang email delivery.",
                        "Recovery email verification cannot continue until email delivery is configured."
                    )
                    : ($delivery["message"] ?? msg(
                        "The recovery email verification message could not be delivered. Please try again.",
                        "Hindi maipadala ang recovery email verification message. Subukan muli.",
                        "The recovery email verification message could not be delivered. Please try again."
                    ));
            }

            header("Location: profile.php?recoveryVerificationPending=1");
            exit;
        }

        if ($action === "cancelRecoveryEmailVerification") {
            if (!cancel_pending_recovery_email($user["id"])) {
                return msg(
                    "Unable to cancel the pending recovery email change.",
                    "Hindi ma-cancel ang pending recovery email change.",
                    "Unable to cancel the pending recovery email change."
                );
            }

            header("Location: profile.php?recoveryVerificationCancelled=1");
            exit;
        }

        if ($action === "removeRecoveryEmail") {
            $result = remove_recovery_email(
                $user["id"],
                $_POST["currentPassword"] ?? ""
            );

            if (!$result["ok"]) {
                return $result["message"];
            }

            header("Location: profile.php?recoveryEmailRemoved=1");
            exit;
        }

        if ($action === "confirmRecoveryEmail") {
            $result = confirm_recovery_email($_POST["token"] ?? "");

            if (!$result["ok"]) {
                return $result["message"];
            }

            unset($_SESSION["pendingSecurityEmail"]);
            header("Location: profile.php?recoveryEmailVerified=1");
            exit;
        }
        $result = update_profile(
            $user["id"],
            $_POST
        );

        if ($result["ok"]) {
            header("Location: profile.php");
            exit;
        }

        return $result["message"];
    }

    return "";
}