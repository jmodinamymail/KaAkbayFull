<?php

require_once __DIR__ . "/config.php";

ini_set("session.use_only_cookies", "1");
ini_set("session.use_strict_mode", "1");
ini_set("session.use_trans_sid", "0");
ini_set("session.cookie_httponly", "1");
ini_set("session.gc_maxlifetime", "28800");

session_name(SESSION_NAME);

$isHttps = false;

if (
    !empty($_SERVER["HTTPS"]) &&
    strtolower((string)$_SERVER["HTTPS"]) !== "off"
) {
    $isHttps = true;
}

if (
    !$isHttps &&
    !empty($_SERVER["HTTP_X_FORWARDED_PROTO"]) &&
    strtolower(trim((string)$_SERVER["HTTP_X_FORWARDED_PROTO"])) === "https"
) {
    $isHttps = true;
}

session_set_cookie_params([
    "lifetime" => 7200,
    "path" => "/",
    "domain" => "",
    "secure" => $isHttps,
    "httponly" => true,
    "samesite" => "Lax"
]);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (!headers_sent()) {
    header("X-Frame-Options: SAMEORIGIN");
    header("X-Content-Type-Options: nosniff");
    header("Referrer-Policy: strict-origin-when-cross-origin");
    header("Permissions-Policy: geolocation=(), microphone=(), camera=()");
    header("X-Permitted-Cross-Domain-Policies: none");
    header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
    header("Pragma: no-cache");
    header(
        "Content-Security-Policy: " .
        "object-src 'none'; " .
        "base-uri 'self'; " .
        "frame-ancestors 'self'; " .
        "form-action 'self';"
    );

    if ($isHttps) {
        header(
            "Strict-Transport-Security: max-age=31536000; includeSubDomains"
        );
    }
}

function e($value) {
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        "UTF-8"
    );
}

function csrf_token() {
    if (
        empty($_SESSION["csrf_token"]) ||
        !is_string($_SESSION["csrf_token"])
    ) {
        $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
    }

    return $_SESSION["csrf_token"];
}

function regenerate_csrf_token() {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
    return $_SESSION["csrf_token"];
}

function verify_csrf($token) {
    if (
        empty($_SESSION["csrf_token"]) ||
        !is_string($_SESSION["csrf_token"])
    ) {
        return false;
    }

    $token = (string)$token;

    if ($token === "") {
        return false;
    }

    return hash_equals($_SESSION["csrf_token"], $token);
}

function safe_text($value, $max = 120) {
    $value = trim((string)$value);

    $value = preg_replace(
        "/[^\p{L}\p{N}\s\.\,\-\_\@\(\)\/\:\!\?]/u",
        "",
        $value
    );

    if (function_exists("mb_substr")) {
        return mb_substr($value, 0, $max);
    }

    return substr($value, 0, $max);
}

function safe_number($value, $min, $max) {
    if (!is_numeric($value)) {
        return null;
    }

    $num = (float)$value;

    if ($num < $min || $num > $max) {
        return null;
    }

    return $num;
}

function text_has($text, $needle) {
    return strpos(
        (string)$text,
        (string)$needle
    ) !== false;
}