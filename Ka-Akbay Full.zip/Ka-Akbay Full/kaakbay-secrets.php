<?php
return [
    "APP_ENV" => "production",
    "APP_URL" => "https://ka-akbay.site",
    "DB_HOST" => "aws-1-ap-northeast-1.pooler.supabase.com",
    "DB_PORT" => "5432",
    "DB_NAME" => "postgres",
    "DB_USER" => "postgres.esgjqevbtlsgojditomu",
    "DB_PASS" => "kaakbay1234@",
    "DB_SSLMODE" => "require",
    "MAIL_ENABLED" => "1",
    "MAIL_HOST" => "smtp.hostinger.com",
    "MAIL_PORT" => "587",
    "MAIL_USERNAME" => "noreply@ka-akbay.site",
    "MAIL_PASSWORD" => "Kaakbay1234@@@",
    "MAIL_ENCRYPTION" => "tls",
    "MAIL_FROM_ADDRESS" => "noreply@ka-akbay.site",
    "MAIL_FROM_NAME" => "Ka-Akbay",
    "MAIL_TIMEOUT" => "15"
];
