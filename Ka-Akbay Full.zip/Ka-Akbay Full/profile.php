<?php
require_once __DIR__ . "/app/security.php";
require_once __DIR__ . "/app/auth.php";
require_once __DIR__ . "/app/page_actions.php";
require_once __DIR__ . "/app/page_data.php";
require_once __DIR__ . "/app/layout.php";

require_login();

$user = current_user();
$storedAccount = function_exists("find_user_by_id")
    ? find_user_by_id($user["id"] ?? "")
    : null;

if (!$storedAccount) {
    $storedAccount = $user;
}

$mustChangePassword = !empty($storedAccount["mustChangePassword"]);
$error = "";

if (
    $mustChangePassword &&
    $_SERVER["REQUEST_METHOD"] === "POST" &&
    (string)($_POST["action"] ?? "") !== "changePassword"
) {
    $error = msg(
        "Change the temporary password before updating other account settings.",
        "Palitan muna ang temporary password bago mag-update ng ibang account settings.",
        "Change the temporary password before updating other account settings."
    );
} else {
    $error = handle_page_action("profile", $user);
}

$user = current_user() ?: $user;
$storedAccount = function_exists("find_user_by_id")
    ? find_user_by_id($user["id"] ?? "")
    : null;

if (!$storedAccount) {
    $storedAccount = $user;
}

$data = get_page_data("profile", $user);
$profile = $data["profile"] ?? $storedAccount;

$profileRole = strtolower(trim((string)($profile["role"] ?? $storedAccount["role"] ?? "")));
$canChangePassword = in_array($profileRole, ["student", "teacher", "admin", "super_admin", "it_admin"], true);
$profileRoleLabel = function_exists("role_label")
    ? role_label($profileRole)
    : ucfirst(str_replace("_", " ", $profileRole));

$mustChangePassword = !empty($storedAccount["mustChangePassword"]);
$passwordChanged = isset($_GET["passwordChanged"]) && $_GET["passwordChanged"] === "1";
$passwordOtpSent = isset($_GET["passwordOtpSent"]) && $_GET["passwordOtpSent"] === "1";
$passwordOtpResent = isset($_GET["passwordOtpResent"]) && $_GET["passwordOtpResent"] === "1";
$passwordOtpVerified = isset($_GET["passwordOtpVerified"]) && $_GET["passwordOtpVerified"] === "1";
$passwordOtpCancelled = isset($_GET["passwordOtpCancelled"]) && $_GET["passwordOtpCancelled"] === "1";
$recoveryVerificationPending = isset($_GET["recoveryVerificationPending"]) && $_GET["recoveryVerificationPending"] === "1";
$recoveryVerificationCancelled = isset($_GET["recoveryVerificationCancelled"]) && $_GET["recoveryVerificationCancelled"] === "1";
$recoveryEmailRemoved = isset($_GET["recoveryEmailRemoved"]) && $_GET["recoveryEmailRemoved"] === "1";
$recoveryEmailVerified = isset($_GET["recoveryEmailVerified"]) && $_GET["recoveryEmailVerified"] === "1";

$passwordChangeOtpState = function_exists("password_change_otp_state")
    ? password_change_otp_state($storedAccount)
    : [
        "required" => false,
        "bootstrapBypass" => false,
        "recoveryAvailable" => false,
        "maskedRecoveryEmail" => "",
        "pending" => false,
        "verified" => false,
        "locked" => false,
        "failedAttempts" => 0,
        "remainingAttempts" => 0,
        "lockoutUntil" => "",
        "secondsRemaining" => 0,
        "sendCount" => 0,
        "sendRemaining" => 0,
        "sendRetryAfter" => 0,
        "otpExpiresAt" => "",
        "otpSecondsRemaining" => 0,
        "verificationSecondsRemaining" => 0
    ];

$passwordChangeOtpRequired = $canChangePassword
    && !$mustChangePassword
    && !empty($passwordChangeOtpState["required"]);

$passwordChangeOtpRecoveryAvailable = !empty($passwordChangeOtpState["recoveryAvailable"]);
$passwordChangeOtpPending = !empty($passwordChangeOtpState["pending"]);
$passwordChangeOtpVerifiedState = !empty($passwordChangeOtpState["verified"]);
$passwordChangeOtpLocked = !empty($passwordChangeOtpState["locked"]);
$passwordChangeOtpRetryAfter = max(0, (int)($passwordChangeOtpState["sendRetryAfter"] ?? 0));

$recoveryStatus = function_exists("recovery_email_status")
    ? recovery_email_status($storedAccount)
    : [
        "configured" => false,
        "verified" => false,
        "email" => "",
        "maskedEmail" => "",
        "pendingEmail" => "",
        "maskedPendingEmail" => "",
        "verifiedAt" => ""
    ];

$passwordPolicy = function_exists("security_password_policy")
    ? security_password_policy()
    : [
        "minLength" => 8,
        "maxLength" => 128,
        "requireUppercase" => true,
        "requireLowercase" => true,
        "requireNumber" => true,
        "requireSpecial" => true
    ];

$passwordMinLength = max(8, (int)($passwordPolicy["minLength"] ?? 8));
$passwordMaxLength = max($passwordMinLength, (int)($passwordPolicy["maxLength"] ?? 128));
$todayDate = date("Y-m-d");
$passwordRequirementParts = [
    msg(
        "at least " . $passwordMinLength . " characters",
        "hindi bababa sa " . $passwordMinLength . " character",
        "at least " . $passwordMinLength . " characters"
    )
];

if (!empty($passwordPolicy["requireUppercase"])) {
    $passwordRequirementParts[] = msg("one uppercase letter", "isang uppercase na letra", "one uppercase letter");
}

if (!empty($passwordPolicy["requireLowercase"])) {
    $passwordRequirementParts[] = msg("one lowercase letter", "isang lowercase na letra", "one lowercase letter");
}

if (!empty($passwordPolicy["requireNumber"])) {
    $passwordRequirementParts[] = msg("one number", "isang numero", "one number");
}

if (!empty($passwordPolicy["requireSpecial"])) {
    $passwordRequirementParts[] = msg("one special character", "isang special character", "one special character");
}

$passwordRequirementsText = ucfirst(implode(", ", $passwordRequirementParts)) . ". " . msg(
    "Avoid using easily guessed account information.",
    "Iwasang gamitin ang madaling hulaan na account information.",
    "Avoid using easily guessed account information."
);

page_head(msg("Profile Settings", "Profile Settings", "Profile Settings"));
sidebar("profile", $user);
?>

<main class="main page-enter profile-page">
    <section class="topbar">
        <div>
            <h1><?= e(msg("Profile Settings", "Profile Settings", "Profile Settings")) ?></h1>
        </div>

        <div class="date">
            <?= e($profileRoleLabel) ?>
        </div>
    </section>

    <div class="error <?= $error ? "show" : "" ?>">
        <?= e($error) ?>
    </div>

    <?php if ($mustChangePassword): ?>
        <div class="password-change-success">
            <?= e(msg(
                "Your account is using a temporary password. Change it below before continuing to other account settings.",
                "Temporary password ang gamit ng account. Palitan muna ito sa ibaba bago magpatuloy sa ibang account settings.",
                "Your account is using a temporary password. Change it below before continuing to other account settings."
            )) ?>
        </div>
    <?php endif; ?>

    <?php if ($passwordChanged): ?>
        <div class="password-change-success">
            <?= e(msg(
                "Your password has been changed successfully.",
                "Matagumpay na napalitan ang iyong password.",
                "Your password has been changed successfully."
            )) ?>
        </div>
    <?php endif; ?>

    <?php if ($passwordOtpSent): ?>
        <div class="password-change-success">
            <?= e(msg(
                "A 6-digit verification code was sent to your verified recovery email. If you do not see it in your inbox, check your Spam or Junk folder.",
                "Nagpadala ng 6-digit verification code sa verified recovery email mo. Kung wala ito sa inbox, tingnan ang Spam o Junk folder.",
                "A 6-digit verification code was sent to your verified recovery email. If wala sa inbox, check your Spam or Junk folder."
            )) ?>
        </div>
    <?php endif; ?>

    <?php if ($passwordOtpResent): ?>
        <div class="password-change-success">
            <?= e(msg(
                "A new verification code was sent to your verified recovery email. If you do not see it in your inbox, check your Spam or Junk folder.",
                "Nagpadala ng bagong verification code sa verified recovery email mo. Kung wala ito sa inbox, tingnan ang Spam o Junk folder.",
                "A new verification code was sent to your verified recovery email. If wala sa inbox, check your Spam or Junk folder."
            )) ?>
        </div>
    <?php endif; ?>

    <?php if ($passwordOtpVerified): ?>
        <div class="password-change-success">
            <?= e(msg(
                "Verification successful. Enter your new password below.",
                "Matagumpay ang verification. Ilagay ang bagong password sa ibaba.",
                "Verification successful. Enter your new password below."
            )) ?>
        </div>
    <?php endif; ?>

    <?php if ($passwordOtpCancelled): ?>
        <div class="password-change-success">
            <?= e(msg(
                "Password-change verification was cancelled.",
                "Na-cancel ang password-change verification.",
                "Password-change verification was cancelled."
            )) ?>
        </div>
    <?php endif; ?>

    <?php if ($recoveryVerificationPending): ?>
        <div class="password-change-success">
            <?= e(msg(
                "Recovery email verification is pending. Check the new recovery address for the verification message. If you do not see it in your inbox, check your Spam or Junk folder.",
                "Pending ang recovery email verification. Tingnan ang bagong recovery address para sa verification message. Kung wala ito sa inbox, tingnan ang Spam o Junk folder.",
                "Recovery email verification is pending. Check the new recovery address for the verification message. If wala sa inbox, check your Spam or Junk folder."
            )) ?>
        </div>
    <?php endif; ?>

    <?php if ($recoveryVerificationCancelled): ?>
        <div class="password-change-success">
            <?= e(msg(
                "The pending recovery email change was cancelled.",
                "Na-cancel ang pending recovery email change.",
                "The pending recovery email change was cancelled."
            )) ?>
        </div>
    <?php endif; ?>

    <?php if ($recoveryEmailRemoved): ?>
        <div class="password-change-success">
            <?= e(msg(
                "The recovery email was removed.",
                "Na-remove ang recovery email.",
                "The recovery email was removed."
            )) ?>
        </div>
    <?php endif; ?>

    <?php if ($recoveryEmailVerified): ?>
        <div class="password-change-success">
            <?= e(msg(
                "Your recovery email has been verified successfully.",
                "Matagumpay na na-verify ang recovery email.",
                "Your recovery email has been verified successfully."
            )) ?>
        </div>
    <?php endif; ?>

    <section class="student-overview-card">
        <div class="student-overview-main">
            <span><?= e(msg("PROFILE", "PROFILE", "PROFILE")) ?></span>

            <h2>
                <?= e($profile["name"] ?? msg("User", "User", "User")) ?>
            </h2>

            <p>
                <?= e(($profile["code"] ?? "--") . " · " . ($storedAccount["email"] ?? $profile["email"] ?? "--")) ?>
            </p>
        </div>

        <div class="student-overview-status">
            <small><?= e(msg("Role", "Role", "Role")) ?></small>

            <strong>
                <?= e($profileRoleLabel) ?>
            </strong>

            <?= badge($profile["status"] ?? $storedAccount["status"] ?? "Active") ?>
        </div>
    </section>

    <?php if (!$mustChangePassword): ?>
        <section class="card section-space">
            <div class="card-head">
                <h2>
                    <?= e(msg(
                        "Personal Details",
                        "Personal Details",
                        "Personal Details"
                    )) ?>
                </h2>

                <p>
                    <?= e(msg(
                        "Review and update your personal account information.",
                        "Suriin at i-update ang iyong personal na impormasyon.",
                        "Review and update your personal account information."
                    )) ?>
                </p>
            </div>

            <form method="POST" class="forms" autocomplete="off">
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e(csrf_token()) ?>"
                >

                <input
                    type="hidden"
                    name="action"
                    value="updateProfile"
                >

                <div class="field">
                    <label>
                        <?= e(msg(
                            "Full Name",
                            "Buong Pangalan",
                            "Full Name"
                        )) ?>
                    </label>

                    <input
                        value="<?= e($profile["name"] ?? "") ?>"
                        readonly
                    >

                    <input
                        type="hidden"
                        name="name"
                        value="<?= e($profile["name"] ?? "") ?>"
                    >
                </div>

                <div class="field">
                    <label>
                        <?= e(msg(
                            "Login Email",
                            "Login Email",
                            "Login Email"
                        )) ?>
                    </label>

                    <input
                        type="email"
                        name="email"
                        value="<?= e($storedAccount["email"] ?? $profile["email"] ?? "") ?>"
                        autocomplete="email"
                        readonly
                    >
                </div>

                <div class="field">
                    <label>
                        <?= e(msg(
                            "Birth Date",
                            "Petsa ng Kapanganakan",
                            "Birth Date"
                        )) ?>
                    </label>

                    <input
                        type="date"
                        name="birthDate"
                        value="<?= e($profile["birthDate"] ?? "") ?>"
                        max="<?= e($todayDate) ?>"
                    >
                </div>

                <div class="field">
                    <label>
                        <?= e(msg(
                            "Contact Number",
                            "Contact Number",
                            "Contact Number"
                        )) ?>
                    </label>

                    <input
                        type="tel"
                        name="contactNumber"
                        value="<?= e($profile["contactNumber"] ?? "") ?>"
                        autocomplete="tel"
                        inputmode="tel"
                        maxlength="13"
                        pattern="(?:09[0-9]{9}|\+639[0-9]{9})"
                        placeholder="09XXXXXXXXX or +639XXXXXXXXX"
                    >
                </div>

                <div class="field">
                    <label>
                        <?= e(msg(
                            "Strand",
                            "Strand",
                            "Strand"
                        )) ?>
                    </label>

                    <input
                        value="<?= e($profile["strand"] ?? "") ?>"
                        readonly
                    >

                    <input
                        type="hidden"
                        name="strand"
                        value="<?= e($profile["strand"] ?? "") ?>"
                    >
                </div>

                <div class="field">
                    <label>
                        <?= e(msg(
                            "Section",
                            "Section",
                            "Section"
                        )) ?>
                    </label>

                    <input
                        value="<?= e($profile["section"] ?? "") ?>"
                        readonly
                    >

                    <input
                        type="hidden"
                        name="section"
                        value="<?= e($profile["section"] ?? "") ?>"
                    >
                </div>

                <div class="field full">
                    <label>
                        <?= e(msg(
                            "Relevant Details",
                            "Relevant Details",
                            "Relevant Details"
                        )) ?>
                    </label>

                    <textarea name="details" maxlength="700"><?= e($profile["details"] ?? "") ?></textarea>
                </div>

                <?php if ($profileRole === "teacher"): ?>
                    <div class="field full">
                        <label>
                            <?= e(msg(
                                "Managed Sections",
                                "Handled Sections",
                                "Managed Sections"
                            )) ?>
                        </label>

                        <input
                            name="managedSections"
                            value="<?= e($profile["managedSections"] ?? "") ?>"
                            placeholder="<?= e(msg(
                                "Example: 12-A, 12-B",
                                "Halimbawa: 12-A, 12-B",
                                "Example: 12-A, 12-B"
                            )) ?>"
                        >
                    </div>
                <?php endif; ?>

                <div class="button-row full">
                    <button
                        class="btn btn-primary"
                        type="submit"
                    >
                        <?= e(msg(
                            "Save Profile",
                            "I-save ang Profile",
                            "Save Profile"
                        )) ?>
                    </button>

                    <a
                        class="btn btn-ghost"
                        href="dashboard.php"
                    >
                        <?= e(msg(
                            "Cancel",
                            "Kanselahin",
                            "Cancel"
                        )) ?>
                    </a>
                </div>
            </form>
        </section>

        <section id="recovery-email-security" class="card section-space profile-security-card">
            <div class="card-head">
                <h2>
                    <?= e(msg(
                        "Recovery Email",
                        "Recovery Email",
                        "Recovery Email"
                    )) ?>
                </h2>

                <p>
                    <?= e(msg(
                        "Use a personal email address that is different from your login email for password recovery and security verification.",
                        "Gumamit ng personal email address na iba sa login email para sa password recovery at security verification.",
                        "Use a personal email address that is different from your login email for password recovery and security verification."
                    )) ?>
                </p>
            </div>

            <div class="profile-security-layout">
                <div class="profile-security-info">
                    <div class="security-info-item">
                        <span>
                            <?= e(msg(
                                "Recovery Status",
                                "Recovery Status",
                                "Recovery Status"
                            )) ?>
                        </span>

                        <strong>
                            <?php if (!empty($recoveryStatus["verified"])): ?>
                                <?= e(msg("Verified", "Verified", "Verified")) ?>
                            <?php else: ?>
                                <?= e(msg("Not Configured", "Not Configured", "Not Configured")) ?>
                            <?php endif; ?>
                        </strong>
                    </div>

                    <?php if (!empty($recoveryStatus["verified"]) && ($recoveryStatus["maskedEmail"] ?? "") !== ""): ?>
                        <div class="security-info-item">
                            <span>
                                <?= e(msg(
                                    "Verified Recovery Email",
                                    "Verified Recovery Email",
                                    "Verified Recovery Email"
                                )) ?>
                            </span>

                            <strong>
                                <?= e($recoveryStatus["maskedEmail"]) ?>
                            </strong>
                        </div>
                    <?php endif; ?>

                    <?php if (($recoveryStatus["maskedPendingEmail"] ?? "") !== ""): ?>
                        <div class="security-info-item">
                            <span>
                                <?= e(msg(
                                    "Pending Verification",
                                    "Pending Verification",
                                    "Pending Verification"
                                )) ?>
                            </span>

                            <strong>
                                <?= e($recoveryStatus["maskedPendingEmail"]) ?>
                            </strong>
                        </div>
                    <?php endif; ?>

                    <div class="security-info-item">
                        <span>
                            <?= e(msg(
                                "Password Recovery",
                                "Password Recovery",
                                "Password Recovery"
                            )) ?>
                        </span>

                        <strong>
                            <?php if (!empty($recoveryStatus["verified"])): ?>
                                <?= e(msg(
                                    "Available through the verified recovery email.",
                                    "Available sa verified recovery email.",
                                    "Available through the verified recovery email."
                                )) ?>
                            <?php else: ?>
                                <?= e(msg(
                                    "Unavailable until a recovery email is verified.",
                                    "Unavailable hanggang ma-verify ang recovery email.",
                                    "Unavailable until a recovery email is verified."
                                )) ?>
                            <?php endif; ?>
                        </strong>
                    </div>

                    <?php if (($recoveryStatus["maskedPendingEmail"] ?? "") !== ""): ?>
                        <div class="password-requirements">
                            <strong>
                                <?= e(msg(
                                    "Cannot Find the Verification Email?",
                                    "Hindi Makita ang Verification Email?",
                                    "Cannot Find the Verification Email?"
                                )) ?>
                            </strong>

                            <span>
                                <?= e(msg(
                                    "Check your Spam or Junk folder if the verification message is not in your inbox.",
                                    "Tingnan ang Spam o Junk folder kung wala sa inbox ang verification message.",
                                    "Check your Spam or Junk folder if wala sa inbox ang verification message."
                                )) ?>
                            </span>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($recoveryStatus["verified"]) && ($recoveryStatus["maskedPendingEmail"] ?? "") !== ""): ?>
                        <div class="password-requirements">
                            <strong>
                                <?= e(msg(
                                    "Current Recovery Remains Active",
                                    "Active Pa Rin ang Current Recovery",
                                    "Current Recovery Remains Active"
                                )) ?>
                            </strong>

                            <span>
                                <?= e(msg(
                                    "The existing verified recovery email remains active until the pending replacement is successfully verified.",
                                    "Mananatiling active ang kasalukuyang verified recovery email hanggang matagumpay na ma-verify ang kapalit.",
                                    "The existing verified recovery email remains active until the pending replacement is successfully verified."
                                )) ?>
                            </span>
                        </div>
                    <?php endif; ?>
                </div>

                <form
                    method="POST"
                    class="profile-security-form"
                    autocomplete="off"
                >
                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= e(csrf_token()) ?>"
                    >

                    <input
                        type="hidden"
                        name="action"
                        value="requestRecoveryEmailVerification"
                    >

                    <div class="field full">
                        <label for="recoveryEmail">
                            <?= e(msg(
                                !empty($recoveryStatus["verified"]) ? "New Recovery Email" : "Recovery Email",
                                !empty($recoveryStatus["verified"]) ? "Bagong Recovery Email" : "Recovery Email",
                                !empty($recoveryStatus["verified"]) ? "New Recovery Email" : "Recovery Email"
                            )) ?>
                        </label>

                        <input
                            id="recoveryEmail"
                            type="email"
                            name="recoveryEmail"
                            autocomplete="email"
                            maxlength="254"
                            placeholder="<?= e(msg(
                                "Personal email address",
                                "Personal email address",
                                "Personal email address"
                            )) ?>"
                            required
                        >
                    </div>

                    <div class="field full">
                        <label for="recoveryCurrentPassword">
                            <?= e(msg(
                                "Current Password",
                                "Kasalukuyang Password",
                                "Current Password"
                            )) ?>
                        </label>

                        <input
                            id="recoveryCurrentPassword"
                            type="password"
                            name="currentPassword"
                            maxlength="<?= e((string)$passwordMaxLength) ?>"
                            autocomplete="current-password"
                            required
                        >
                    </div>

                    <div class="security-actions full">
                        <button
                            class="btn btn-primary"
                            type="submit"
                        >
                            <?= e(msg(
                                ($recoveryStatus["maskedPendingEmail"] ?? "") !== ""
                                    ? "Send New Verification"
                                    : (!empty($recoveryStatus["verified"]) ? "Change Recovery Email" : "Add Recovery Email"),
                                ($recoveryStatus["maskedPendingEmail"] ?? "") !== ""
                                    ? "Magpadala ng Bagong Verification"
                                    : (!empty($recoveryStatus["verified"]) ? "Palitan ang Recovery Email" : "Magdagdag ng Recovery Email"),
                                ($recoveryStatus["maskedPendingEmail"] ?? "") !== ""
                                    ? "Send New Verification"
                                    : (!empty($recoveryStatus["verified"]) ? "Change Recovery Email" : "Add Recovery Email")
                            )) ?>
                        </button>
                    </div>
                </form>
            </div>

            <?php if (($recoveryStatus["maskedPendingEmail"] ?? "") !== ""): ?>
                <form method="POST" class="forms" autocomplete="off">
                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= e(csrf_token()) ?>"
                    >

                    <input
                        type="hidden"
                        name="action"
                        value="cancelRecoveryEmailVerification"
                    >

                    <div class="button-row full">
                        <button
                            class="btn btn-ghost"
                            type="submit"
                        >
                            <?= e(msg(
                                "Cancel Pending Recovery Change",
                                "I-cancel ang Pending Recovery Change",
                                "Cancel Pending Recovery Change"
                            )) ?>
                        </button>
                    </div>
                </form>
            <?php endif; ?>

            <?php if (!empty($recoveryStatus["verified"])): ?>
                <form method="POST" class="forms profile-remove-recovery-form" autocomplete="off">
                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= e(csrf_token()) ?>"
                    >

                    <input
                        type="hidden"
                        name="action"
                        value="removeRecoveryEmail"
                    >

                    <div class="field profile-remove-password-field">
                        <label for="removeRecoveryCurrentPassword">
                            <?= e(msg(
                                "Current Password to Remove Recovery Email",
                                "Kasalukuyang Password para Alisin ang Recovery Email",
                                "Current Password to Remove Recovery Email"
                            )) ?>
                        </label>

                        <input
                            id="removeRecoveryCurrentPassword"
                            type="password"
                            name="currentPassword"
                            maxlength="<?= e((string)$passwordMaxLength) ?>"
                            autocomplete="current-password"
                            required
                        >
                    </div>

                    <div class="button-row profile-remove-recovery-actions">
                        <button
                            class="btn btn-danger profile-remove-recovery-btn"
                            type="submit"
                        >
                            <?= e(msg(
                                "Remove Recovery Email",
                                "Alisin ang Recovery Email",
                                "Remove Recovery Email"
                            )) ?>
                        </button>
                    </div>
                </form>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <?php if ($canChangePassword): ?>
        <section class="card section-space profile-security-card">
            <div class="card-head">
                <h2>
                    <?= e(msg(
                        "Account Security",
                        "Seguridad ng Account",
                        "Account Security"
                    )) ?>
                </h2>

                <p>
                    <?php if ($mustChangePassword): ?>
                        <?= e(msg(
                            "Change the temporary password before continuing to other account settings.",
                            "Palitan muna ang temporary password bago magpatuloy sa ibang account settings.",
                            "Change the temporary password before continuing to other account settings."
                        )) ?>
                    <?php elseif ($passwordChangeOtpRequired): ?>
                        <?= e(msg(
                            "Password changes require your current password and a verification code sent to your verified recovery email.",
                            "Ang password change ay nangangailangan ng current password at verification code na ipapadala sa verified recovery email.",
                            "Password changes require your current password and a verification code sent to your verified recovery email."
                        )) ?>
                    <?php else: ?>
                        <?= e(msg(
                            "Change your password by confirming your current password first.",
                            "Palitan ang iyong password matapos kumpirmahin ang kasalukuyang password.",
                            "Change your password by confirming your current password first."
                        )) ?>
                    <?php endif; ?>
                </p>
            </div>

            <div class="profile-security-layout">
                <div class="profile-security-info">
                    <div class="security-info-item">
                        <span>
                            <?= e(msg(
                                "Password Access",
                                "Password Access",
                                "Password Access"
                            )) ?>
                        </span>

                        <strong>
                            <?= e(msg(
                                "Only you can change your password.",
                                "Ikaw lamang ang maaaring magpalit ng iyong password.",
                                "Only you can change your password."
                            )) ?>
                        </strong>
                    </div>

                    <?php if ($passwordChangeOtpRequired): ?>
                        <div class="security-info-item">
                            <span>
                                <?= e(msg(
                                    "Recovery Verification",
                                    "Recovery Verification",
                                    "Recovery Verification"
                                )) ?>
                            </span>

                            <strong>
                                <?php if ($passwordChangeOtpRecoveryAvailable): ?>
                                    <?= e($passwordChangeOtpState["maskedRecoveryEmail"] ?? "") ?>
                                <?php else: ?>
                                    <?= e(msg(
                                        "Verified recovery email required.",
                                        "Kailangan ng verified recovery email.",
                                        "Verified recovery email required."
                                    )) ?>
                                <?php endif; ?>
                            </strong>
                        </div>

                        <div class="security-info-item">
                            <span>
                                <?= e(msg(
                                    "Verification Status",
                                    "Verification Status",
                                    "Verification Status"
                                )) ?>
                            </span>

                            <strong>
                                <?php if ($passwordChangeOtpLocked): ?>
                                    <?= e(msg(
                                        "Temporarily Locked",
                                        "Pansamantalang Naka-lock",
                                        "Temporarily Locked"
                                    )) ?>
                                <?php elseif ($passwordChangeOtpVerifiedState): ?>
                                    <?= e(msg(
                                        "Code Verified",
                                        "Verified ang Code",
                                        "Code Verified"
                                    )) ?>
                                <?php elseif ($passwordChangeOtpPending): ?>
                                    <?= e(msg(
                                        "Verification Pending",
                                        "Pending ang Verification",
                                        "Verification Pending"
                                    )) ?>
                                <?php else: ?>
                                    <?= e(msg(
                                        "Ready",
                                        "Ready",
                                        "Ready"
                                    )) ?>
                                <?php endif; ?>
                            </strong>
                        </div>
                    <?php else: ?>
                        <div class="security-info-item">
                            <span>
                                <?= e(msg(
                                    $mustChangePassword ? "Temporary Password Required" : "Current Password Required",
                                    $mustChangePassword ? "Kailangan ang Temporary Password" : "Kailangan ang Kasalukuyang Password",
                                    $mustChangePassword ? "Temporary Password Required" : "Current Password Required"
                                )) ?>
                            </span>

                            <strong>
                                <?= e(msg(
                                    $mustChangePassword
                                        ? "Verify the temporary password before saving the new password."
                                        : "Your existing password must be verified before the change is saved.",
                                    $mustChangePassword
                                        ? "I-verify muna ang temporary password bago i-save ang bagong password."
                                        : "Kailangang ma-verify muna ang kasalukuyang password bago ma-save ang pagbabago.",
                                    $mustChangePassword
                                        ? "Verify the temporary password before saving the new password."
                                        : "Your existing password must be verified before the change is saved."
                                )) ?>
                            </strong>
                        </div>
                    <?php endif; ?>

                    <div class="password-requirements">
                        <strong>
                            <?= e(msg(
                                "Password Requirements",
                                "Password Requirements",
                                "Password Requirements"
                            )) ?>
                        </strong>

                        <span>
                            <?= e($passwordRequirementsText) ?>
                        </span>
                    </div>
                </div>

                <?php if ($passwordChangeOtpRequired): ?>
                    <div class="profile-security-form">
                        <?php if (!$passwordChangeOtpRecoveryAvailable): ?>
                            <div class="password-requirements">
                                <strong>
                                    <?= e(msg(
                                        "Recovery Email Required",
                                        "Kailangan ang Recovery Email",
                                        "Recovery Email Required"
                                    )) ?>
                                </strong>

                                <span>
                                    <?= e(msg(
                                        "Add and verify a personal recovery email before changing your password.",
                                        "Magdagdag at mag-verify muna ng personal recovery email bago magpalit ng password.",
                                        "Add and verify a personal recovery email before changing your password."
                                    )) ?>
                                </span>
                            </div>

                            <div class="security-actions full">
                                <a class="btn btn-primary" href="#recovery-email-security">
                                    <?= e(msg(
                                        "Set Up Recovery Email",
                                        "I-set Up ang Recovery Email",
                                        "Set Up Recovery Email"
                                    )) ?>
                                </a>
                            </div>
                        <?php elseif ($passwordChangeOtpLocked): ?>
                            <div class="password-requirements">
                                <strong>
                                    <?= e(msg(
                                        "Verification Temporarily Locked",
                                        "Pansamantalang Naka-lock ang Verification",
                                        "Verification Temporarily Locked"
                                    )) ?>
                                </strong>

                                <span>
                                    <?= e(msg(
                                        "Too many incorrect codes were entered. Try again after the temporary lockout expires.",
                                        "Masyadong maraming maling code ang nailagay. Subukan muli pagkatapos ng temporary lockout.",
                                        "Too many incorrect codes were entered. Try again after the temporary lockout expires."
                                    )) ?>
                                </span>
                            </div>
                        <?php elseif ($passwordChangeOtpVerifiedState): ?>
                            <form method="POST" class="forms" autocomplete="off">
                                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="action" value="changePassword">

                                <div class="field full">
                                    <label for="newPassword">
                                        <?= e(msg(
                                            "New Password",
                                            "Bagong Password",
                                            "New Password"
                                        )) ?>
                                    </label>

                                    <input
                                        id="newPassword"
                                        type="password"
                                        name="newPassword"
                                        minlength="<?= e((string)$passwordMinLength) ?>"
                                        maxlength="<?= e((string)$passwordMaxLength) ?>"
                                        autocomplete="new-password"
                                        required
                                    >
                                </div>

                                <div class="field full">
                                    <label for="confirmNewPassword">
                                        <?= e(msg(
                                            "Confirm New Password",
                                            "Kumpirmahin ang Bagong Password",
                                            "Confirm New Password"
                                        )) ?>
                                    </label>

                                    <input
                                        id="confirmNewPassword"
                                        type="password"
                                        name="confirmNewPassword"
                                        minlength="<?= e((string)$passwordMinLength) ?>"
                                        maxlength="<?= e((string)$passwordMaxLength) ?>"
                                        autocomplete="new-password"
                                        required
                                    >
                                </div>

                                <div class="security-actions full">
                                    <button class="btn btn-primary" type="submit">
                                        <?= e(msg(
                                            "Change Password",
                                            "Palitan ang Password",
                                            "Change Password"
                                        )) ?>
                                    </button>
                                </div>
                            </form>
                        <?php elseif ($passwordChangeOtpPending): ?>
                            <div class="password-requirements">
                                <strong>
                                    <?= e(msg(
                                        "Cannot Find the Verification Code?",
                                        "Hindi Makita ang Verification Code?",
                                        "Cannot Find the Verification Code?"
                                    )) ?>
                                </strong>

                                <span>
                                    <?= e(msg(
                                        "Check your Spam or Junk folder if the verification code is not in your inbox.",
                                        "Tingnan ang Spam o Junk folder kung wala sa inbox ang verification code.",
                                        "Check your Spam or Junk folder if wala sa inbox ang verification code."
                                    )) ?>
                                </span>
                            </div>

                            <form method="POST" class="forms" autocomplete="off">
                                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="action" value="verifyPasswordChangeOtp">

                                <div class="field full">
                                    <label for="passwordChangeOtpCode">
                                        <?= e(msg(
                                            "6-Digit Verification Code",
                                            "6-Digit Verification Code",
                                            "6-Digit Verification Code"
                                        )) ?>
                                    </label>

                                    <input
                                        id="passwordChangeOtpCode"
                                        type="text"
                                        name="otpCode"
                                        inputmode="numeric"
                                        autocomplete="one-time-code"
                                        pattern="[0-9]{6}"
                                        minlength="6"
                                        maxlength="6"
                                        placeholder="000000"
                                        required
                                    >
                                </div>

                                <div class="security-actions full">
                                    <button class="btn btn-primary" type="submit">
                                        <?= e(msg(
                                            "Verify Code",
                                            "I-verify ang Code",
                                            "Verify Code"
                                        )) ?>
                                    </button>
                                </div>
                            </form>

                            <form method="POST" class="forms" autocomplete="off">
                                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="action" value="resendPasswordChangeOtp">

                                <div class="security-actions full">
                                    <button
                                        class="btn btn-ghost"
                                        type="submit"
                                        data-otp-resend-button
                                        data-otp-resend-seconds="<?= e((string)$passwordChangeOtpRetryAfter) ?>"
                                        <?= $passwordChangeOtpRetryAfter > 0 ? "disabled" : "" ?>
                                    >
                                        <?= e(msg(
                                            "Resend Code",
                                            "Ipadala Muli ang Code",
                                            "Resend Code"
                                        )) ?>
                                        <span data-otp-resend-countdown></span>
                                    </button>
                                </div>
                            </form>

                            <form method="POST" class="forms" autocomplete="off">
                                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="action" value="cancelPasswordChangeOtp">

                                <div class="security-actions full">
                                    <button class="btn btn-ghost" type="submit">
                                        <?= e(msg(
                                            "Cancel Verification",
                                            "I-cancel ang Verification",
                                            "Cancel Verification"
                                        )) ?>
                                    </button>
                                </div>
                            </form>
                        <?php else: ?>
                            <form method="POST" class="forms" autocomplete="off">
                                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="action" value="beginPasswordChangeOtp">

                                <div class="field full">
                                    <label for="passwordChangeCurrentPassword">
                                        <?= e(msg(
                                            "Current Password",
                                            "Kasalukuyang Password",
                                            "Current Password"
                                        )) ?>
                                    </label>

                                    <input
                                        id="passwordChangeCurrentPassword"
                                        type="password"
                                        name="currentPassword"
                                        maxlength="<?= e((string)$passwordMaxLength) ?>"
                                        autocomplete="current-password"
                                        required
                                    >
                                </div>

                                <div class="security-actions full">
                                    <button class="btn btn-primary" type="submit">
                                        <?= e(msg(
                                            "Send Verification Code",
                                            "Ipadala ang Verification Code",
                                            "Send Verification Code"
                                        )) ?>
                                    </button>
                                </div>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <form
                        method="POST"
                        class="profile-security-form"
                        autocomplete="off"
                    >
                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= e(csrf_token()) ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="changePassword"
                        >

                        <div class="field full">
                            <label for="currentPassword">
                                <?= e(msg(
                                    $mustChangePassword ? "Temporary Password" : "Current Password",
                                    $mustChangePassword ? "Temporary Password" : "Kasalukuyang Password",
                                    $mustChangePassword ? "Temporary Password" : "Current Password"
                                )) ?>
                            </label>

                            <input
                                id="currentPassword"
                                type="password"
                                name="currentPassword"
                                maxlength="<?= e((string)$passwordMaxLength) ?>"
                                autocomplete="current-password"
                                required
                            >
                        </div>

                        <div class="field full">
                            <label for="newPassword">
                                <?= e(msg(
                                    "New Password",
                                    "Bagong Password",
                                    "New Password"
                                )) ?>
                            </label>

                            <input
                                id="newPassword"
                                type="password"
                                name="newPassword"
                                minlength="<?= e((string)$passwordMinLength) ?>"
                                maxlength="<?= e((string)$passwordMaxLength) ?>"
                                autocomplete="new-password"
                                required
                            >
                        </div>

                        <div class="field full">
                            <label for="confirmNewPassword">
                                <?= e(msg(
                                    "Confirm New Password",
                                    "Kumpirmahin ang Bagong Password",
                                    "Confirm New Password"
                                )) ?>
                            </label>

                            <input
                                id="confirmNewPassword"
                                type="password"
                                name="confirmNewPassword"
                                minlength="<?= e((string)$passwordMinLength) ?>"
                                maxlength="<?= e((string)$passwordMaxLength) ?>"
                                autocomplete="new-password"
                                required
                            >
                        </div>

                        <div class="security-actions full">
                            <button
                                class="btn btn-primary"
                                type="submit"
                            >
                                <?= e(msg(
                                    "Change Password",
                                    "Palitan ang Password",
                                    "Change Password"
                                )) ?>
                            </button>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>
</main>

<?php page_foot(); ?>
