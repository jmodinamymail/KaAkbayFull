<?php
require_once __DIR__ . "/app/security.php";
require_once __DIR__ . "/app/auth.php";
require_once __DIR__ . "/app/page_actions.php";
require_once __DIR__ . "/app/functions.php";
require_once __DIR__ . "/app/layout.php";

require_role(["teacher", "admin", "super_admin"]);

$user = current_user();
$error = handle_page_action("monitor", $user);

$filters = [
    "q" => trim($_GET["q"] ?? ""),
    "gradeStatus" => $_GET["gradeStatus"] ?? "",
    "competencyStatus" => $_GET["competencyStatus"] ?? "",
    "attendanceStatus" => $_GET["attendanceStatus"] ?? "",
    "workloadStatus" => $_GET["workloadStatus"] ?? "",
    "requirementStatus" => $_GET["requirementStatus"] ?? "",
    "trendStatus" => $_GET["trendStatus"] ?? "",
    "followUpType" => $_GET["followUpType"] ?? "",
    "strand" => $_GET["strand"] ?? "",
    "section" => $_GET["section"] ?? "",
    "subject" => $_GET["subject"] ?? ""
];

$allRows = evaluated_student_rows();

if (($user["role"] ?? "") === "teacher") {
    $allRows = array_values(array_filter($allRows, fn($row) => student_visible_to_user($row["student"] ?? [], $user)));
}

$filteredRows = function_exists("filter_monitoring_rows") ? filter_monitoring_rows($allRows, $filters) : $allRows;
$counts = monitoring_counts($allRows);
$groupedSummary = grouped_monitoring_summary($allRows);
$activeFilterCount = function_exists("active_filter_count") ? active_filter_count($filters) : 0;

page_head(msg("Monitoring", "Pagsubaybay", "Monitoring"));
sidebar("monitoring", $user);
?>

<main class="main page-enter monitor-page">
    <section class="topbar">
        <div>
            <h1><?= e(msg("Monitoring", "Pagsubaybay", "Monitoring")) ?></h1>
        </div>
        <div class="date"><?= e(date("M d, Y")) ?></div>
    </section>

    <div class="error <?= $error ? "show" : "" ?>"><?= e($error) ?></div>

    <section class="simple-summary-grid">
        <div class="simple-summary-card">
            <span><?= e(msg("Total", "Kabuuan", "Total")) ?></span>
            <strong><?= e($counts["total"] ?? 0) ?></strong>
        </div>

        <div class="simple-summary-card">
            <span><?= e(msg("Regular", "Regular", "Regular")) ?></span>
            <strong><?= e($counts["regular"] ?? 0) ?></strong>
        </div>

        <div class="simple-summary-card warning">
            <span><?= e(msg("Warning", "Babala", "Warning")) ?></span>
            <strong><?= e($counts["warning"] ?? 0) ?></strong>
        </div>

        <div class="simple-summary-card danger">
            <span><?= e(msg("At-Risk", "Nanganganib", "At-Risk")) ?></span>
            <strong><?= e($counts["atRisk"] ?? $counts["risk"] ?? 0) ?></strong>
        </div>

        <div class="simple-summary-card danger">
            <span><?= e(msg("Remediation", "Remediation", "Remediation")) ?></span>
            <strong><?= e($counts["remediation"] ?? 0) ?></strong>
        </div>

        <div class="simple-summary-card warning">
            <span><?= e(msg("Attendance Concern", "Concern sa Attendance", "Attendance Concern")) ?></span>
            <strong><?= e($counts["attendanceConcern"] ?? 0) ?></strong>
        </div>

        <div class="simple-summary-card warning">
            <span><?= e(msg("Mabigat", "Mabigat", "Mabigat")) ?></span>
            <strong><?= e($counts["mabigat"] ?? $counts["workloadHigh"] ?? 0) ?></strong>
        </div>

        <div class="simple-summary-card warning">
            <span><?= e(msg("Incomplete", "Hindi Kumpleto", "Incomplete")) ?></span>
            <strong><?= e($counts["incompleteRequirements"] ?? 0) ?></strong>
        </div>
    </section>

    <section class="card clean-panel section-space">
        <div class="clean-panel-head">
            <div>
                <h2><?= e(msg("Search and Filters", "Search at Filters", "Search and Filters")) ?></h2>
            </div>
        </div>

        <form method="GET" class="validation-filter-form">
            <div class="validation-search-row">
                <div class="field validation-search-field">
                    <label><?= e(msg("Search", "Hanapin", "Search")) ?></label>
                    <input name="q" value="<?= e($filters["q"] ?? "") ?>" placeholder="<?= e(msg("Student, subject, status, strand, section", "Mag-aaral, asignatura, status, strand, section", "Student, subject, status, strand, section")) ?>">
                </div>

                <div class="field">
                    <label><?= e(msg("Grade", "Marka", "Grade")) ?></label>
                    <select name="gradeStatus">
                        <option value=""><?= e(msg("All", "Lahat", "All")) ?></option>
                        <?php foreach (["Regular", "Warning Status", "At-Risk / Failing"] as $status): ?>
                            <option value="<?= e($status) ?>" <?= (($filters["gradeStatus"] ?? "") === $status) ? "selected" : "" ?>><?= e(function_exists("tv") ? tv($status) : $status) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="field">
                    <label><?= e(msg("Attendance", "Attendance", "Attendance")) ?></label>
                    <select name="attendanceStatus">
                        <option value=""><?= e(msg("All", "Lahat", "All")) ?></option>
                        <?php foreach (["Regular Attendance", "Attendance Concern"] as $status): ?>
                            <option value="<?= e($status) ?>" <?= (($filters["attendanceStatus"] ?? "") === $status) ? "selected" : "" ?>><?= e(function_exists("tv") ? tv($status) : $status) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="field">
                    <label><?= e(msg("Workload", "Bigat ng Gawain", "Workload")) ?></label>
                    <select name="workloadStatus">
                        <option value=""><?= e(msg("All", "Lahat", "All")) ?></option>
                        <?php foreach (["Magaan", "Katamtaman", "Mabigat"] as $status): ?>
                            <option value="<?= e($status) ?>" <?= (($filters["workloadStatus"] ?? "") === $status) ? "selected" : "" ?>><?= e($status) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="validation-filter-actions">
                    <button class="btn btn-primary" type="submit"><?= e(msg("Search", "Hanapin", "Search")) ?></button>
                    <a class="btn btn-ghost" href="monitor.php"><?= e(msg("Clear", "I-clear", "Clear")) ?></a>
                </div>
            </div>

            <details class="validation-advanced-filter" <?= $activeFilterCount > 4 ? "open" : "" ?>>
                <summary>
                    <span><?= e(msg("More Filters", "Karagdagang Filters", "More Filters")) ?></span>
                    <strong><?= e($activeFilterCount) ?> <?= e(msg("active", "active", "active")) ?></strong>
                </summary>

                <div class="forms">
                    <div class="field">
                        <label><?= e(msg("Competency", "Kakayahan", "Competency")) ?></label>
                        <select name="competencyStatus">
                            <option value=""><?= e(msg("All", "Lahat", "All")) ?></option>
                            <?php foreach (["Mastered", "Nearing Mastery", "Not Mastered / Remediation Needed"] as $status): ?>
                                <option value="<?= e($status) ?>" <?= (($filters["competencyStatus"] ?? "") === $status) ? "selected" : "" ?>><?= e(function_exists("tv") ? tv($status) : $status) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="field">
                        <label><?= e(msg("Requirement", "Requirement", "Requirement")) ?></label>
                        <select name="requirementStatus">
                            <option value=""><?= e(msg("All", "Lahat", "All")) ?></option>
                            <?php foreach (["Complete Requirements", "Incomplete Requirements"] as $status): ?>
                                <option value="<?= e($status) ?>" <?= (($filters["requirementStatus"] ?? "") === $status) ? "selected" : "" ?>><?= e(function_exists("tv") ? tv($status) : $status) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="field">
                        <label><?= e(msg("Trend", "Pattern", "Trend")) ?></label>
                        <select name="trendStatus">
                            <option value=""><?= e(msg("All", "Lahat", "All")) ?></option>
                            <?php foreach (["Insufficient Trend Data", "Stable Performance Pattern", "Improving Performance Pattern", "Declining Performance Pattern"] as $status): ?>
                                <option value="<?= e($status) ?>" <?= (($filters["trendStatus"] ?? "") === $status) ? "selected" : "" ?>><?= e(function_exists("tv") ? tv($status) : $status) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="field">
                        <label><?= e(msg("Follow-up", "Follow-up", "Follow-up")) ?></label>
                        <select name="followUpType">
                            <option value=""><?= e(msg("All", "Lahat", "All")) ?></option>
                            <?php foreach (["Regular Monitoring", "Monitoring", "Remediation", "Requirement Follow-up", "Performance Monitoring", "Attendance Follow-up", "Workload Follow-up"] as $type): ?>
                                <option value="<?= e($type) ?>" <?= (($filters["followUpType"] ?? "") === $type) ? "selected" : "" ?>><?= e(function_exists("tv") ? tv($type) : $type) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="field">
                        <label><?= e(msg("Strand", "Strand", "Strand")) ?></label>
                        <input name="strand" value="<?= e($filters["strand"] ?? "") ?>">
                    </div>

                    <div class="field">
                        <label><?= e(msg("Section", "Section", "Section")) ?></label>
                        <input name="section" value="<?= e($filters["section"] ?? "") ?>">
                    </div>

                    <div class="field">
                        <label><?= e(msg("Subject", "Asignatura", "Subject")) ?></label>
                        <input name="subject" value="<?= e($filters["subject"] ?? "") ?>">
                    </div>
                </div>
            </details>
        </form>
    </section>

    <section class="card clean-panel section-space">
        <div class="clean-panel-head">
            <div>
                <h2><?= e(msg("Grouped Monitoring Summary", "Pinangkat na Buod ng Monitoring", "Grouped Monitoring Summary")) ?></h2>
            </div>
        </div>

        <div class="compact-task-list">
            <?php foreach ($groupedSummary as $group): ?>
                <div class="compact-task-item grouped-summary-item">
                    <div>
                        <strong><?= e($group["label"] ?? "") ?></strong>
                        <span><?= e($group["students"] ?? 0) ?> <?= e(msg("students", "mag-aaral", "students")) ?></span>
                    </div>

                    <div class="group-summary-metrics">
                        <div>
                            <span><?= e(msg("Regular", "Regular", "Regular")) ?></span>
                            <strong><?= e($group["regular"] ?? 0) ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Warning", "Babala", "Warning")) ?></span>
                            <strong><?= e($group["warning"] ?? 0) ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("At-Risk", "Nanganganib", "At-Risk")) ?></span>
                            <strong><?= e($group["atRisk"] ?? $group["risk"] ?? 0) ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Remediation", "Remediation", "Remediation")) ?></span>
                            <strong><?= e($group["remediation"] ?? 0) ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Attendance", "Attendance", "Attendance")) ?></span>
                            <strong><?= e($group["attendanceConcern"] ?? 0) ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Mabigat", "Mabigat", "Mabigat")) ?></span>
                            <strong><?= e($group["mabigat"] ?? $group["workloadHigh"] ?? 0) ?></strong>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>

            <?php if (!count($groupedSummary)): ?>
                <div class="compact-empty">
                    <strong><?= e(msg("No grouped data", "Walang grouped data", "No grouped data")) ?></strong>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <section class="monitoring-board section-space">
        <div class="clean-panel-head">
            <div>
                <h2><?= e(msg("Monitoring Records", "Mga Tala ng Pagsubaybay", "Monitoring Records")) ?></h2>
            </div>
        </div>

        <div class="monitoring-grid">
            <?php foreach ($filteredRows as $index => $row): ?>
                <?php
                    $student = $row["student"] ?? [];
                    $latest = $row["latest"] ?? [];
                    $workload = $row["workload"] ?? [];
                    $taskSummary = $row["taskSummary"] ?? [];
                    $flags = $row["flags"] ?? [];
                    $followUpType = $row["followUpType"] ?? "No Record";
                    $academicStatus = $latest["academicStatus"] ?? "No Record";
                    $competencyStatus = $latest["competencyStatus"] ?? "No Record";
                    $attendanceStatus = $latest["attendanceStatus"] ?? "No Record";
                    $requirementStatus = $latest["requirementStatus"] ?? "No Record";
                    $trendStatus = $latest["trendStatus"] ?? "No Record";
                    $workloadStatus = $workload["lingguhangBigatIndex"] ?? "Magaan";
                    $systemOutput = trim($academicStatus . " / " . $competencyStatus . " / " . $attendanceStatus . " / " . $requirementStatus . " / " . $trendStatus . " / " . $workloadStatus);
                    $guidance = $latest["guidanceOutput"] ?? null;
                    $schedules = schedules_for_student($student["id"] ?? "");
                    $attendanceLookup = function_exists("attendance_update_lookup_for_student") ? attendance_update_lookup_for_student($student["id"] ?? "") : [];
                    $teacherAnalysis = function_exists("teacher_item_analysis_for_student") ? teacher_item_analysis_for_student($student["id"] ?? "", $latest["subject"] ?? "") : [];
                ?>

                <div class="monitor-card <?= e(view_state_class($systemOutput)) ?>">
                    <div class="monitor-card-top">
                        <div>
                            <span><?= e($student["code"] ?? "") ?></span>
                            <h3><?= e($student["name"] ?? msg("Student", "Mag-aaral", "Student")) ?></h3>
                            <p><?= e(($student["strand"] ?? msg("Unassigned", "Hindi Nakatalaga", "Unassigned")) . " · " . ($student["section"] ?? msg("Unassigned", "Hindi Nakatalaga", "Unassigned"))) ?></p>
                        </div>
                        <button class="dot-action" type="button" data-menu-button="monitor-<?= e($index) ?>">•••</button>
                        <div class="popup-menu" data-menu="monitor-<?= e($index) ?>">
                            <button type="button" data-modal-open="monitor-detail-<?= e($index) ?>"><?= e(msg("View Details", "Tingnan ang Detalye", "View Details")) ?></button>
                            <button type="button" data-modal-open="attendance-<?= e($index) ?>"><?= e(msg("Mark Attendance", "Magmarka ng Attendance", "Mark Attendance")) ?></button>
                            <a href="validation.php"><?= e(msg("Validate Output", "I-validate ang Output", "Validate Output")) ?></a>
                        </div>
                    </div>

                    <div class="monitor-status-row">
                        <?= badge($academicStatus) ?>
                        <?= badge($competencyStatus) ?>
                        <?= badge($attendanceStatus) ?>
                        <?= badge($requirementStatus) ?>
                        <?= badge($trendStatus) ?>
                        <?= badge($workloadStatus) ?>
                    </div>

                    <div class="monitor-mini-grid">
                        <div>
                            <span><?= e(msg("Subject", "Asignatura", "Subject")) ?></span>
                            <strong><?= e($latest["subject"] ?? msg("No Record", "Walang Tala", "No Record")) ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Grade", "Marka", "Grade")) ?></span>
                            <strong><?= e($latest["computedGrade"] ?? "--") ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Mastery", "Mastery", "Mastery")) ?></span>
                            <strong><?= e(($latest["competencyMastery"] ?? 0) > 0 ? ($latest["competencyMastery"] . "%") : "--") ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Absence", "Pagliban", "Absence")) ?></span>
                            <strong><?= e($latest["absenceRate"] ?? "--") ?>%</strong>
                        </div>
                        <div>
                            <span><?= e(msg("Ratio", "Ratio", "Ratio")) ?></span>
                            <strong><?= e($workload["workloadRatio"] ?? 0) ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Weekly Score", "Lingguhang Score", "Weekly Score")) ?></span>
                            <strong><?= e($workload["weeklyWorkloadScore"] ?? 0) ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Overdue", "Lampas Deadline", "Overdue")) ?></span>
                            <strong><?= e($taskSummary["overdue"] ?? 0) ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Alerts", "Babala", "Alerts")) ?></span>
                            <strong><?= e($taskSummary["alertCount"] ?? 0) ?></strong>
                        </div>
                    </div>

                    <?php if ($guidance): ?>
                        <div class="record-guidance-strip">
                            <div><strong><?= e(msg("Status", "Kalagayan", "Status")) ?></strong><br><?= e($guidance["status"] ?? "") ?></div>
                            <div><strong><?= e(msg("Advisory", "Paalaala", "Advisory")) ?></strong><br><?= e($guidance["advisory"] ?? "") ?></div>
                            <div><strong><?= e(msg("Guidance", "Gabay", "Guidance")) ?></strong><br><?= e($guidance["guidance"] ?? "") ?></div>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($latest["missingRequirements"])): ?>
                        <div class="notice warning"><?= e(msg("Missing / Incomplete", "Kulang / Hindi Kumpleto", "Missing / Incomplete")) ?>: <?= e(implode(", ", $latest["missingRequirements"])) ?></div>
                    <?php endif; ?>

                    <?php if (count($flags)): ?>
                        <div class="monitor-status-row">
                            <?php foreach ($flags as $flag): ?>
                                <?= badge($flag) ?>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <div class="monitor-foot">
                        <span><?= e(function_exists("tv") ? tv($followUpType) : $followUpType) ?></span>
                    </div>
                </div>

                <div class="modal-shell" data-modal="monitor-detail-<?= e($index) ?>">
                    <div class="modal-card large">
                        <div class="modal-head">
                            <h3><?= e(($student["code"] ?? "") . " " . msg("Monitoring Details", "Detalye ng Pagsubaybay", "Monitoring Details")) ?></h3>
                            <button type="button" data-modal-close>×</button>
                        </div>

                        <div class="modal-body">
                            <div class="modal-grid">
                                <div>
                                    <span><?= e(msg("Student", "Mag-aaral", "Student")) ?></span>
                                    <strong><?= e($student["name"] ?? "") ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Subject", "Asignatura", "Subject")) ?></span>
                                    <strong><?= e($latest["subject"] ?? msg("No Record", "Walang Tala", "No Record")) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Academic Status", "Kalagayang Akademiko", "Academic Status")) ?></span>
                                    <strong><?= e(function_exists("tv") ? tv($academicStatus) : $academicStatus) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Competency", "Kakayahan", "Competency")) ?></span>
                                    <strong><?= e(function_exists("tv") ? tv($competencyStatus) : $competencyStatus) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Attendance", "Attendance", "Attendance")) ?></span>
                                    <strong><?= e(function_exists("tv") ? tv($attendanceStatus) : $attendanceStatus) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Absence Rate", "Bahagdan ng Pagliban", "Absence Rate")) ?></span>
                                    <strong><?= e($latest["absenceRate"] ?? "--") ?>%</strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Consecutive Absences", "Sunod-sunod na Pagliban", "Consecutive Absences")) ?></span>
                                    <strong><?= e($latest["consecutiveAbsences"] ?? "--") ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Requirements", "Requirements", "Requirements")) ?></span>
                                    <strong><?= e(function_exists("tv") ? tv($requirementStatus) : $requirementStatus) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Trend", "Pattern", "Trend")) ?></span>
                                    <strong><?= e(function_exists("tv") ? tv($trendStatus) : $trendStatus) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Workload", "Bigat ng Gawain", "Workload")) ?></span>
                                    <strong><?= e($workloadStatus) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Workload Score", "Workload Score", "Workload Score")) ?></span>
                                    <strong><?= e($workload["weeklyWorkloadScore"] ?? 0) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Available Study Time", "Available Study Time", "Available Study Time")) ?></span>
                                    <strong><?= e($workload["availableStudyTime"] ?? 0) ?>h</strong>
                                </div>
                            </div>

                            <?php if ($guidance): ?>
                                <div class="record-guidance-strip">
                                    <div><strong><?= e(msg("Status", "Kalagayan", "Status")) ?></strong><br><?= e($guidance["status"] ?? "") ?></div>
                                    <div><strong><?= e(msg("Advisory", "Paalaala", "Advisory")) ?></strong><br><?= e($guidance["advisory"] ?? "") ?></div>
                                    <div><strong><?= e(msg("Guidance", "Gabay", "Guidance")) ?></strong><br><?= e($guidance["guidance"] ?? "") ?></div>
                                </div>
                            <?php endif; ?>

                            <?php if (count($teacherAnalysis)): ?>
                                <div class="subtask-box">
                                    <?php foreach (array_slice($teacherAnalysis, 0, 3) as $analysis): ?>
                                        <div class="subtask-item">
                                            <span><?= e(($analysis["competencyArea"] ?? "") ?: msg("Item Analysis", "Item Analysis", "Item Analysis")) ?></span>
                                            <strong><?= e($analysis["itemAnalysisNotes"] ?? "") ?></strong>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($latest["missingRequirements"])): ?>
                                <div class="notice warning"><?= e(msg("Missing / Incomplete", "Kulang / Hindi Kumpleto", "Missing / Incomplete")) ?>: <?= e(implode(", ", $latest["missingRequirements"])) ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="modal-shell" data-modal="attendance-<?= e($index) ?>">
                    <div class="modal-card large">
                        <div class="modal-head">
                            <h3><?= e(msg("Mark Attendance", "Magmarka ng Attendance", "Mark Attendance")) ?></h3>
                            <button type="button" data-modal-close>×</button>
                        </div>

                        <form
                            method="POST"
                            class="modal-body forms attendance-entry-form"
                            data-attendance-records="<?= e(json_encode($attendanceLookup, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?>"
                        >
                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                            <input type="hidden" name="action" value="markAttendance">
                            <input type="hidden" name="studentId" value="<?= e($student["id"] ?? "") ?>">
                            <input type="hidden" name="confirmAttendanceUpdate" value="0">
                            <input type="hidden" name="confirmedAttendanceId" value="">

                            <div class="field full">
                                <label><?= e(msg("Student", "Mag-aaral", "Student")) ?></label>
                                <input value="<?= e(($student["code"] ?? "") . " · " . ($student["name"] ?? "")) ?>" readonly>
                            </div>

                            <div class="field">
                                <label><?= e(msg("Subject Schedule", "Iskedyul ng Asignatura", "Subject Schedule")) ?></label>
                                <select name="scheduleId" required>
                                    <option value=""><?= e(msg("Select Schedule", "Pumili ng Iskedyul", "Select Schedule")) ?></option>
                                    <?php foreach ($schedules as $schedule): ?>
                                        <option value="<?= e($schedule["id"] ?? "") ?>"><?= e(($schedule["subject"] ?? "") . " · " . (function_exists("tv") ? tv($schedule["day"] ?? "") : ($schedule["day"] ?? "")) . " · " . ($schedule["startTime"] ?? "") . " - " . ($schedule["endTime"] ?? "")) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="field">
                                <label><?= e(msg("Date", "Petsa", "Date")) ?></label>
                                <input type="date" name="date" value="<?= e(date("Y-m-d")) ?>" required>
                            </div>

                            <div class="field">
                                <label><?= e(msg("Status", "Kalagayan", "Status")) ?></label>
                                <select name="status" required>
                                    <?php foreach (["Present", "Absent", "Excused"] as $status): ?>
                                        <option value="<?= e($status) ?>"><?= e(function_exists("tv") ? tv($status) : $status) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="field full">
                                <label><?= e(msg("Note", "Tala", "Note")) ?></label>
                                <textarea name="note"></textarea>
                            </div>

                            <div class="button-row full">
                                <button class="btn btn-primary" type="submit"><?= e(msg("Save Attendance", "I-save ang Attendance", "Save Attendance")) ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>

            <?php if (!count($filteredRows)): ?>
                <div class="compact-empty">
                    <strong><?= e(msg("No monitoring records available", "Walang monitoring records na available", "No monitoring records available")) ?></strong>
                </div>
            <?php endif; ?>
        </div>
    </section>
</main>


<div class="attendance-update-confirm" data-attendance-update-confirm hidden>
    <button
        type="button"
        class="attendance-update-confirm-backdrop"
        data-attendance-confirm-cancel
        aria-label="<?= e(msg("Close attendance confirmation", "Isara ang attendance confirmation", "Close attendance confirmation")) ?>"
    ></button>

    <div
        class="attendance-update-confirm-card"
        role="dialog"
        aria-modal="true"
        aria-labelledby="attendance-update-confirm-title"
    >
        <div class="attendance-update-confirm-head">
            <div class="attendance-update-confirm-mark">!</div>
            <div>
                <span><?= e(msg("EXISTING RECORD", "MAY EXISTING RECORD", "EXISTING RECORD")) ?></span>
                <h3 id="attendance-update-confirm-title"><?= e(msg("Attendance Already Recorded", "May Naka-record nang Attendance", "May Existing Attendance na")) ?></h3>
            </div>
        </div>

        <p class="attendance-update-confirm-copy">
            <?= e(msg(
                "An attendance record already exists for this student, schedule, and date. Review the current value before replacing it.",
                "May attendance record na para sa student, schedule, at petsang ito. Suriin muna ang kasalukuyang value bago ito palitan.",
                "May attendance record na para sa student, schedule, at date na ito. Review the current value bago ito palitan."
            )) ?>
        </p>

        <div class="attendance-update-confirm-context">
            <div>
                <span><?= e(msg("Student", "Mag-aaral", "Student")) ?></span>
                <strong data-attendance-confirm-student>--</strong>
            </div>
            <div>
                <span><?= e(msg("Subject / Schedule", "Asignatura / Iskedyul", "Subject / Schedule")) ?></span>
                <strong data-attendance-confirm-subject>--</strong>
            </div>
            <div>
                <span><?= e(msg("Date", "Petsa", "Date")) ?></span>
                <strong data-attendance-confirm-date>--</strong>
            </div>
        </div>

        <div class="attendance-update-confirm-compare">
            <div class="attendance-update-confirm-state">
                <span><?= e(msg("CURRENT RECORD", "KASALUKUYANG RECORD", "CURRENT RECORD")) ?></span>
                <strong data-attendance-confirm-old-status>--</strong>
                <p data-attendance-confirm-old-note>--</p>
            </div>

            <div class="attendance-update-confirm-arrow" aria-hidden="true">→</div>

            <div class="attendance-update-confirm-state proposed">
                <span><?= e(msg("NEW VALUE", "BAGONG VALUE", "NEW VALUE")) ?></span>
                <strong data-attendance-confirm-new-status>--</strong>
                <p data-attendance-confirm-new-note>--</p>
            </div>
        </div>

        <div class="attendance-update-confirm-actions">
            <button type="button" class="btn btn-ghost" data-attendance-confirm-cancel>
                <?= e(msg("Cancel", "Kanselahin", "Cancel")) ?>
            </button>
            <button type="button" class="btn btn-primary" data-attendance-confirm-update>
                <?= e(msg("Update Attendance", "I-update ang Attendance", "Update Attendance")) ?>
            </button>
        </div>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const confirmation = document.querySelector("[data-attendance-update-confirm]");

    if (!confirmation) {
        return;
    }

    let pendingForm = null;

    const studentTarget = confirmation.querySelector("[data-attendance-confirm-student]");
    const subjectTarget = confirmation.querySelector("[data-attendance-confirm-subject]");
    const dateTarget = confirmation.querySelector("[data-attendance-confirm-date]");
    const oldStatusTarget = confirmation.querySelector("[data-attendance-confirm-old-status]");
    const oldNoteTarget = confirmation.querySelector("[data-attendance-confirm-old-note]");
    const newStatusTarget = confirmation.querySelector("[data-attendance-confirm-new-status]");
    const newNoteTarget = confirmation.querySelector("[data-attendance-confirm-new-note]");
    const updateButton = confirmation.querySelector("[data-attendance-confirm-update]");
    const cancelButtons = confirmation.querySelectorAll("[data-attendance-confirm-cancel]");

    const displayNote = function(value) {
        const note = String(value || "").trim();
        return note !== "" ? note : "No note";
    };

    const displayDate = function(value) {
        if (!value) {
            return "--";
        }

        const date = new Date(value + "T00:00:00");

        if (Number.isNaN(date.getTime())) {
            return value;
        }

        return date.toLocaleDateString(undefined, {
            year: "numeric",
            month: "short",
            day: "numeric"
        });
    };

    const closeConfirmation = function() {
        confirmation.hidden = true;
        document.body.classList.remove("attendance-confirm-open");
        pendingForm = null;
    };

    document.querySelectorAll(".attendance-entry-form").forEach(function(form) {
        form.addEventListener("submit", function(event) {
            const confirmationInput = form.querySelector('input[name="confirmAttendanceUpdate"]');
            const confirmedIdInput = form.querySelector('input[name="confirmedAttendanceId"]');

            if (confirmationInput && confirmationInput.value === "1") {
                return;
            }

            let records = {};

            try {
                records = JSON.parse(form.dataset.attendanceRecords || "{}");
            } catch (error) {
                records = {};
            }

            const scheduleSelect = form.querySelector('select[name="scheduleId"]');
            const dateInput = form.querySelector('input[name="date"]');
            const statusSelect = form.querySelector('select[name="status"]');
            const noteInput = form.querySelector('textarea[name="note"]');
            const studentInput = form.querySelector('.field.full input[readonly]');

            const scheduleId = scheduleSelect ? scheduleSelect.value : "";
            const date = dateInput ? dateInput.value : "";

            if (!scheduleId || !date) {
                return;
            }

            const existing = records[scheduleId + "|" + date];

            if (!existing || !existing.id) {
                return;
            }

            event.preventDefault();
            pendingForm = form;

            if (confirmationInput) {
                confirmationInput.value = "0";
            }

            if (confirmedIdInput) {
                confirmedIdInput.value = existing.id;
            }

            const selectedScheduleText = scheduleSelect && scheduleSelect.selectedIndex >= 0
                ? scheduleSelect.options[scheduleSelect.selectedIndex].textContent.trim()
                : "";

            studentTarget.textContent = studentInput ? studentInput.value : "--";
            subjectTarget.textContent = existing.subject || selectedScheduleText || "--";
            dateTarget.textContent = displayDate(date);
            oldStatusTarget.textContent = existing.status || "--";
            oldNoteTarget.textContent = displayNote(existing.note);
            newStatusTarget.textContent = statusSelect ? statusSelect.value : "--";
            newNoteTarget.textContent = displayNote(noteInput ? noteInput.value : "");

            confirmation.hidden = false;
            document.body.classList.add("attendance-confirm-open");

            if (updateButton) {
                updateButton.focus();
            }
        });
    });

    cancelButtons.forEach(function(button) {
        button.addEventListener("click", closeConfirmation);
    });

    if (updateButton) {
        updateButton.addEventListener("click", function() {
            if (!pendingForm) {
                closeConfirmation();
                return;
            }

            const formToSubmit = pendingForm;
            const confirmationInput = formToSubmit.querySelector('input[name="confirmAttendanceUpdate"]');

            if (confirmationInput) {
                confirmationInput.value = "1";
            }

            confirmation.hidden = true;
            document.body.classList.remove("attendance-confirm-open");
            pendingForm = null;
            formToSubmit.submit();
        });
    }

    document.addEventListener("keydown", function(event) {
        if (event.key === "Escape" && !confirmation.hidden) {
            closeConfirmation();
        }
    });
});
</script>

<?php page_foot(); ?>