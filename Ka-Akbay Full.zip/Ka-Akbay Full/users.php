<?php
require_once __DIR__ . "/app/security.php";
require_once __DIR__ . "/app/auth.php";
require_once __DIR__ . "/app/page_actions.php";
require_once __DIR__ . "/app/page_data.php";
require_once __DIR__ . "/app/layout.php";

require_role(["admin", "super_admin"]);

$user = current_user();
$error = handle_page_action("users", $user);
$data = get_page_data("users", $user);
$users = $data["users"] ?? [];
$teachers = $data["teachers"] ?? [];
$sections = $data["sections"] ?? [];
$sectionNames = $data["sectionNames"] ?? [];

$currentUserRole = strtolower(trim((string)($user["role"] ?? "")));
$isSuperAdmin = $currentUserRole === "super_admin";

$accountLockouts = $isSuperAdmin && function_exists("account_lockouts_for_super_admin")
    ? account_lockouts_for_super_admin($user["id"])
    : [];

$accountLoginSecurity = [];

if ($isSuperAdmin && function_exists("security_login_lockout_state")) {
    foreach ($users as $account) {
        $accountId = trim((string)($account["id"] ?? ""));

        if ($accountId === "") {
            continue;
        }

        $accountLoginSecurity[$accountId] = security_login_lockout_state($account);
    }
}

$lockedAccountCount = $isSuperAdmin
    ? count(array_filter($accountLockouts, fn($row) => !empty($row["locked"])))
    : 0;

$failedLoginAccountCount = $isSuperAdmin
    ? count(array_filter($accountLockouts, fn($row) => (int)($row["failedAttempts"] ?? 0) > 0))
    : 0;

$userManagementNotice = $_SESSION["userManagementNotice"] ?? null;
unset($_SESSION["userManagementNotice"]);

if (
    !is_array($userManagementNotice) ||
    (int)($userManagementNotice["createdAt"] ?? 0) < (time() - 300)
) {
    $userManagementNotice = null;
}

$noticeTarget = null;

if ($userManagementNotice) {
    $noticeTargetId = trim((string)($userManagementNotice["targetUserId"] ?? ""));

    if ($noticeTargetId !== "") {
        $noticeTarget = find_user_by_id($noticeTargetId);
    }
}

$activeUserCount = 0;
$inactiveUserCount = 0;
$privilegedRoles = ["super_admin", "it_admin"];

foreach ($users as $account) {
    if (($account["status"] ?? "Active") === "Active") {
        $activeUserCount++;
    } else {
        $inactiveUserCount++;
    }
}

$activeTeachers = array_values(array_filter($teachers, function($teacher) {
    return ($teacher["status"] ?? "Active") === "Active";
}));

if (!count($sectionNames)) {
    foreach ($sections as $section) {
        if (is_array($section)) {
            $name = trim((string)($section["name"] ?? $section["section"] ?? ""));

            if ($name !== "") {
                $sectionNames[] = $name;
            }
        } else {
            $name = trim((string)$section);

            if ($name !== "") {
                $sectionNames[] = $name;
            }
        }
    }

    $sectionNames = array_values(array_unique($sectionNames));
    sort($sectionNames);
}

$strandOptions = ["ABM", "HUMSS", "STEM", "GAS", "TVL", "Arts and Design", "Sports"];
$gradeOptions = ["Grade 11", "Grade 12"];

function kaakbay_users_datetime($value) {
    $value = trim((string)$value);

    if ($value === "") {
        return "--";
    }

    $time = strtotime($value);

    if (!$time) {
        return "--";
    }

    return date("M d, Y g:i A", $time);
}

page_head(msg("User Access", "Access ng User", "User Access"));
sidebar("users", $user);
?>

<main class="main page-enter users-page">
    <section class="topbar">
        <div>
            <h1><?= e(msg("User Access", "Access ng User", "User Access")) ?></h1>
        </div>

        <div class="date">
            <?= e(count($users)) ?> <?= e(msg("users", "users", "users")) ?>
        </div>
    </section>

    <div class="error <?= $error ? "show" : "" ?>">
        <?= e($error) ?>
    </div>

    <?php if ($userManagementNotice): ?>
        <section class="card section-space">
            <div class="card-head">
                <h2>
                    <?= e(
                        msg("Account Created", "Nagawa ang Account", "Account Created")
                    ) ?>
                </h2>
            </div>

            <div class="compact-empty">
                <strong>
                    <?= e(
                        ($noticeTarget["name"] ?? "") !== ""
                            ? (($noticeTarget["name"] ?? "") . " · " . ($noticeTarget["code"] ?? ""))
                            : msg("User account", "User account", "User account")
                    ) ?>
                </strong>

                <?php if (trim((string)($userManagementNotice["temporaryPassword"] ?? "")) !== ""): ?>
                    <p>
                        <?= e(msg(
                            "Temporary password:",
                            "Temporary password:",
                            "Temporary password:"
                        )) ?>
                        <strong><?= e($userManagementNotice["temporaryPassword"]) ?></strong>
                    </p>

                    <p>
                        <?= e(msg(
                            "Copy this password now. It is shown only once. The user must change it on the next login.",
                            "Kopyahin ang password na ito ngayon. Isang beses lamang ito ipinapakita. Kailangang palitan ito ng user sa susunod na login.",
                            "Copy this password now. It is shown only once. The user must change it on the next login."
                        )) ?>
                    </p>
                <?php else: ?>
                    <p><?= e($userManagementNotice["message"] ?? "") ?></p>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <section class="student-overview-card">
        <div class="student-overview-main">
            <span><?= e(msg("ACCESS MANAGEMENT", "ACCESS MANAGEMENT", "ACCESS MANAGEMENT")) ?></span>

            <h2>
                <?= e(msg(
                    "Role-based account and section assignment",
                    "Role-based account at section assignment",
                    "Role-based account and section assignment"
                )) ?>
            </h2>
        </div>

        <div class="student-overview-status">
            <small><?= e(msg("Total Users", "Kabuuang Users", "Total Users")) ?></small>

            <strong><?= e(count($users)) ?></strong>

            <div class="user-status-summary">
                <span>
                    <?= e(msg("Active", "Aktibo", "Active")) ?>:
                    <?= e($activeUserCount) ?>
                </span>

                <span>
                    <?= e(msg("Inactive", "Hindi Aktibo", "Inactive")) ?>:
                    <?= e($inactiveUserCount) ?>
                </span>
            </div>
        </div>
    </section>

    <?php if ($isSuperAdmin): ?>
        <section class="card clean-panel section-space">
            <div class="clean-panel-head">
                <div>
                    <h2>
                        <?= e(msg(
                            "Account Login Security",
                            "Account Login Security",
                            "Account Login Security"
                        )) ?>
                    </h2>
                </div>

                <?= badge(
                    $lockedAccountCount . " " .
                    msg(
                        "Locked",
                        "Locked",
                        "Locked"
                    )
                ) ?>
            </div>

            <div class="notice full">
                <?= e(msg(
                    "This section tracks password sign-in failures and temporary account lockouts. Only the Super Administrator can view this account lockout information. Privileged OTP failures are monitored separately by the IT Administrator.",
                    "Sinusubaybayan ng section na ito ang password sign-in failures at temporary account lockouts. Super Administrator lamang ang maaaring makakita ng account lockout information na ito. Hiwalay na mino-monitor ng IT Administrator ang privileged OTP failures.",
                    "This section tracks password sign-in failures and temporary account lockouts. Only the Super Administrator can view this account lockout information. Privileged OTP failures are monitored separately by the IT Administrator."
                )) ?>
            </div>

            <section class="simple-summary-grid section-space">
                <div class="simple-summary-card <?= $lockedAccountCount > 0 ? "danger" : "good" ?>">
                    <span><?= e(msg("Currently Locked", "Currently Locked", "Currently Locked")) ?></span>
                    <strong><?= e($lockedAccountCount) ?></strong>
                </div>

                <div class="simple-summary-card <?= $failedLoginAccountCount > 0 ? "warning" : "good" ?>">
                    <span><?= e(msg("Accounts with Failed Attempts", "Accounts with Failed Attempts", "Accounts with Failed Attempts")) ?></span>
                    <strong><?= e($failedLoginAccountCount) ?></strong>
                </div>
            </section>

            <div style="overflow-x:auto" class="section-space">
                <table class="table">
                    <thead>
                        <tr>
                            <th><?= e(msg("ACCOUNT", "ACCOUNT", "ACCOUNT")) ?></th>
                            <th><?= e(msg("ROLE", "ROLE", "ROLE")) ?></th>
                            <th><?= e(msg("FAILED ATTEMPTS", "FAILED ATTEMPTS", "FAILED ATTEMPTS")) ?></th>
                            <th><?= e(msg("REMAINING", "REMAINING", "REMAINING")) ?></th>
                            <th><?= e(msg("STATUS", "STATUS", "STATUS")) ?></th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php foreach ($accountLockouts as $lockout): ?>
                            <?php
                                $isLocked = !empty($lockout["locked"]);
                                $secondsRemaining = max(0, (int)($lockout["secondsRemaining"] ?? 0));
                            ?>
                            <tr>
                                <td>
                                    <strong><?= e($lockout["name"] ?? "User") ?></strong>
                                    <br>
                                    <small>
                                        <?= e(
                                            trim(
                                                (string)($lockout["code"] ?? "") .
                                                (
                                                    !empty($lockout["email"])
                                                        ? " · " . (string)$lockout["email"]
                                                        : ""
                                                )
                                            )
                                        ) ?>
                                    </small>
                                </td>

                                <td>
                                    <?= e(
                                        function_exists("role_label")
                                            ? role_label($lockout["role"] ?? "")
                                            : ucfirst(str_replace("_", " ", (string)($lockout["role"] ?? "")))
                                    ) ?>
                                </td>

                                <td><?= e(max(0, (int)($lockout["failedAttempts"] ?? 0))) ?></td>
                                <td><?= e(max(0, (int)($lockout["remainingAttempts"] ?? 0))) ?></td>

                                <td>
                                    <?php if ($isLocked): ?>
                                        <span class="status danger">
                                            <?= e(msg("Temporarily Locked", "Temporarily Locked", "Temporarily Locked")) ?>
                                        </span>
                                        <br>
                                        <small>
                                            <?= e(
                                                msg(
                                                    "Until " . kaakbay_users_datetime($lockout["lockoutUntil"] ?? ""),
                                                    "Hanggang " . kaakbay_users_datetime($lockout["lockoutUntil"] ?? ""),
                                                    "Until " . kaakbay_users_datetime($lockout["lockoutUntil"] ?? "")
                                                )
                                            ) ?>
                                        </small>

                                        <?php if ($secondsRemaining > 0 && function_exists("security_retry_text")): ?>
                                            <br>
                                            <small>
                                                <?= e(
                                                    msg(
                                                        "Retry in " . security_retry_text($secondsRemaining),
                                                        "Retry in " . security_retry_text($secondsRemaining),
                                                        "Retry in " . security_retry_text($secondsRemaining)
                                                    )
                                                ) ?>
                                            </small>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="status warning">
                                            <?= e(msg("Failed Attempts Recorded", "Failed Attempts Recorded", "Failed Attempts Recorded")) ?>
                                        </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                        <?php if (!count($accountLockouts)): ?>
                            <tr>
                                <td colspan="5">
                                    <?= e(msg(
                                        "No active account lockouts or failed password sign-in attempts are currently recorded.",
                                        "Walang kasalukuyang active account lockouts o failed password sign-in attempts na naka-record.",
                                        "No active account lockouts or failed password sign-in attempts are currently recorded."
                                    )) ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    <?php endif; ?>

    <section class="dashboard-focus-grid">
        <div class="card clean-panel">
            <div class="clean-panel-head">
                <div>
                    <h2><?= e(msg("Add User", "Magdagdag ng User", "Add User")) ?></h2>
                </div>
            </div>

            <form method="POST" class="forms" data-role-form>
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="action" value="add">

                <div class="field">
                    <label><?= e(msg("Name", "Pangalan", "Name")) ?></label>
                    <input name="name" required>
                </div>

                <div class="field">
                    <label><?= e(msg("Email", "Email", "Email")) ?></label>
                    <input type="email" name="email" required>
                </div>

                <input type="hidden" name="password" value="">

                <div class="field">
                    <label><?= e(msg("Initial Password", "Initial Password", "Initial Password")) ?></label>
                    <input
                        value="<?= e(msg(
                            "Generated automatically",
                            "Awtomatikong ginagawa",
                            "Generated automatically"
                        )) ?>"
                        readonly
                    >
                </div>

                <div class="field">
                    <label><?= e(msg("Role", "Role", "Role")) ?></label>

                    <select name="role" required data-role-select>
                        <option value="student">
                            <?= e(msg("Student", "Mag-aaral", "Student")) ?>
                        </option>

                        <option value="teacher">
                            <?= e(msg("Teacher", "Guro", "Teacher")) ?>
                        </option>

                        <option value="admin">
                            <?= e(msg("Administrator", "Administrator", "Administrator")) ?>
                        </option>

                        <?php if ($isSuperAdmin): ?>
                            <option value="super_admin">
                                <?= e(msg("Super Administrator", "Super Administrator", "Super Administrator")) ?>
                            </option>

                            <option value="it_admin">
                                <?= e(msg("IT Administrator", "IT Administrator", "IT Administrator")) ?>
                            </option>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="field" data-role-field="student">
                    <label><?= e(msg("Strand", "Strand", "Strand")) ?></label>

                    <select name="strand">
                        <?php foreach ($strandOptions as $strand): ?>
                            <option value="<?= e($strand) ?>">
                                <?= e($strand) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="field" data-role-field="student">
                    <label><?= e(msg("Section", "Section", "Section")) ?></label>

                    <select name="section">
                        <option value="">
                            <?= e(msg("Select Section", "Pumili ng Section", "Select Section")) ?>
                        </option>

                        <?php foreach ($sectionNames as $sectionName): ?>
                            <option value="<?= e($sectionName) ?>">
                                <?= e($sectionName) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="field" data-role-field="student">
                    <label><?= e(msg("Grade Level", "Baitang", "Grade Level")) ?></label>

                    <select name="gradeLevel">
                        <?php foreach ($gradeOptions as $gradeLevel): ?>
                            <option value="<?= e($gradeLevel) ?>">
                                <?= e($gradeLevel) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="field" data-role-field="student">
                    <label><?= e(msg("Assigned Teacher", "Naka-assign na Guro", "Assigned Teacher")) ?></label>

                    <select name="teacherId">
                        <option value="">
                            <?= e(msg("None", "Wala", "None")) ?>
                        </option>

                        <?php foreach ($activeTeachers as $teacher): ?>
                            <option value="<?= e($teacher["id"]) ?>">
                                <?= e($teacher["name"]) ?> · <?= e($teacher["code"]) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="field" data-role-field="teacher">
                    <label><?= e(msg("Managed Sections", "Handled Sections", "Managed Sections")) ?></label>

                    <select name="managedSections">
                        <option value="">
                            <?= e(msg("None", "Wala", "None")) ?>
                        </option>

                        <?php foreach ($sectionNames as $sectionName): ?>
                            <option value="<?= e($sectionName) ?>">
                                <?= e($sectionName) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="field full">
                    <label><?= e(msg(
                        "Your Current Password",
                        "Iyong Kasalukuyang Password",
                        "Your Current Password"
                    )) ?></label>

                    <input
                        type="password"
                        name="currentPassword"
                        autocomplete="current-password"
                        placeholder="<?= e(msg(
                            "Required when creating an administrative account",
                            "Kailangan kapag gumagawa ng administrative account",
                            "Required when creating an administrative account"
                        )) ?>"
                    >
                </div>

                <div class="button-row full">
                    <button class="btn btn-primary" type="submit">
                        <?= e(msg("Add User", "Magdagdag ng User", "Add User")) ?>
                    </button>
                </div>
            </form>
        </div>

        <div class="card clean-panel">
            <div class="clean-panel-head">
                <div>
                    <h2><?= e(msg("Section Management", "Section Management", "Section Management")) ?></h2>
                </div>
            </div>

            <form method="POST" class="forms">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="action" value="addSection">

                <div class="field">
                    <label><?= e(msg("Section", "Section", "Section")) ?></label>
                    <input name="name" placeholder="12-A" required>
                </div>

                <div class="field">
                    <label><?= e(msg("Strand", "Strand", "Strand")) ?></label>

                    <select name="strand">
                        <?php foreach ($strandOptions as $strand): ?>
                            <option value="<?= e($strand) ?>">
                                <?= e($strand) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="field">
                    <label><?= e(msg("Grade Level", "Baitang", "Grade Level")) ?></label>

                    <select name="gradeLevel">
                        <?php foreach ($gradeOptions as $gradeLevel): ?>
                            <option value="<?= e($gradeLevel) ?>">
                                <?= e($gradeLevel) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="button-row full">
                    <button class="btn btn-primary" type="submit">
                        <?= e(msg("Add Section", "Magdagdag ng Section", "Add Section")) ?>
                    </button>
                </div>
            </form>

            <div class="flag-pill-list section-space-sm">
                <?php foreach ($sections as $section): ?>
                    <?php
                        $sectionData = is_array($section)
                            ? $section
                            : ["id" => "", "name" => (string)$section];

                        $sectionId = $sectionData["id"] ?? "";
                        $sectionName = $sectionData["name"] ?? $sectionData["section"] ?? "";
                        $sectionStrand = $sectionData["strand"] ?? "";
                        $sectionGradeLevel = $sectionData["gradeLevel"] ?? "";
                    ?>

                    <span class="flag-pill">
                        <?= e(trim(
                            $sectionName .
                            " " .
                            ($sectionStrand ? "· " . $sectionStrand : "") .
                            " " .
                            ($sectionGradeLevel ? "· " . $sectionGradeLevel : "")
                        )) ?>
                    </span>

                    <?php if ($sectionId !== ""): ?>
                        <form method="POST" class="inline-form">
                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                            <input type="hidden" name="action" value="deleteSection">
                            <input type="hidden" name="sectionId" value="<?= e($sectionId) ?>">

                            <button class="btn btn-ghost btn-small" type="submit">
                                <?= e(msg("Delete", "Burahin", "Delete")) ?>
                            </button>
                        </form>
                    <?php endif; ?>
                <?php endforeach; ?>

                <?php if (!count($sections)): ?>
                    <span class="flag-pill good">
                        <?= e(msg("No sections yet", "Wala pang sections", "No sections yet")) ?>
                    </span>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section class="card clean-panel section-space">
        <div class="clean-panel-head">
            <div>
                <h2><?= e(msg("User List", "Listahan ng Users", "User List")) ?></h2>
            </div>

            <div class="user-list-counts">
                <span>
                    <?= e(msg("Active", "Aktibo", "Active")) ?>:
                    <?= e($activeUserCount) ?>
                </span>

                <span>
                    <?= e(msg("Inactive", "Hindi Aktibo", "Inactive")) ?>:
                    <?= e($inactiveUserCount) ?>
                </span>
            </div>
        </div>

        <div class="monitoring-grid user-grid">
            <?php foreach ($users as $account): ?>
                <?php
                    $accountRole = $account["role"] ?? "";
                    $accountStatus = $account["status"] ?? "Active";
                    $isCurrentAccount = ($account["id"] ?? "") === ($user["id"] ?? "");
                    $isPrivilegedAccount = in_array($accountRole, $privilegedRoles, true);
                    $canManageAccount = !$isCurrentAccount && (!$isPrivilegedAccount || $isSuperAdmin);
                    $assignedTeacher = find_user_by_id($account["teacherId"] ?? "");

                    $roleDisplay = function_exists("role_label")
                        ? role_label($accountRole)
                        : ucfirst(str_replace("_", " ", $accountRole));
                ?>

                <div class="monitor-card <?= e($accountStatus === "Active" ? "good" : "danger") ?>">
                    <div class="monitor-card-top">
                        <div>
                            <span><?= e($account["code"] ?? "") ?></span>
                            <h3><?= e($account["name"] ?? "") ?></h3>
                            <p><?= e($account["email"] ?? "") ?></p>
                        </div>

                        <?php if ($canManageAccount): ?>
                            <button
                                class="dot-action"
                                type="button"
                                data-menu-button="user-<?= e($account["id"]) ?>"
                            >
                                •••
                            </button>

                            <div
                                class="popup-menu"
                                data-menu="user-<?= e($account["id"]) ?>"
                            >
                                <?php if (!$isPrivilegedAccount): ?>
                                    <button
                                        type="button"
                                        data-modal-open="assign-<?= e($account["id"]) ?>"
                                    >
                                        <?= e(msg(
                                            "Manage assignment",
                                            "I-manage ang assignment",
                                            "Manage assignment"
                                        )) ?>
                                    </button>
                                <?php endif; ?>

                                <button
                                    type="button"
                                    data-modal-open="security-<?= e($account["id"]) ?>"
                                >
                                    <?= e(msg(
                                        "Account security",
                                        "Account security",
                                        "Account security"
                                    )) ?>
                                </button>

                                <?php if ($isSuperAdmin): ?>
                                    <button
                                        type="button"
                                        data-modal-open="role-<?= e($account["id"]) ?>"
                                    >
                                        <?= e(msg(
                                            "Change role",
                                            "Palitan ang role",
                                            "Change role"
                                        )) ?>
                                    </button>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="monitor-status-row">
                        <?= badge($roleDisplay) ?>
                        <?= badge($accountStatus) ?>

                        <?php if (!empty($account["mustChangePassword"])): ?>
                            <?= badge(msg(
                                "Password Change Required",
                                "Kailangang Palitan ang Password",
                                "Password Change Required"
                            )) ?>
                        <?php endif; ?>

                        <?php if ($isSuperAdmin): ?>
                            <?php
                                $cardLoginState = $accountLoginSecurity[(string)($account["id"] ?? "")] ?? [];
                                $cardFailedAttempts = max(0, (int)($cardLoginState["failedAttempts"] ?? 0));
                            ?>

                            <?php if (!empty($cardLoginState["locked"])): ?>
                                <span class="status danger">
                                    <?= e(msg("Login Locked", "Login Locked", "Login Locked")) ?>
                                </span>
                            <?php elseif ($cardFailedAttempts > 0): ?>
                                <span class="status warning">
                                    <?= e(
                                        msg(
                                            $cardFailedAttempts . " Failed Login Attempt" . ($cardFailedAttempts === 1 ? "" : "s"),
                                            $cardFailedAttempts . " Failed Login Attempt" . ($cardFailedAttempts === 1 ? "" : "s"),
                                            $cardFailedAttempts . " Failed Login Attempt" . ($cardFailedAttempts === 1 ? "" : "s")
                                        )
                                    ) ?>
                                </span>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>

                    <div class="monitor-mini-grid">
                        <?php if ($accountRole === "student"): ?>
                            <div>
                                <span><?= e(msg("Strand", "Strand", "Strand")) ?></span>
                                <strong><?= e($account["strand"] ?? "--") ?></strong>
                            </div>

                            <div>
                                <span><?= e(msg("Section", "Section", "Section")) ?></span>
                                <strong><?= e($account["section"] ?? "--") ?></strong>
                            </div>

                            <div>
                                <span><?= e(msg("Grade Level", "Baitang", "Grade Level")) ?></span>
                                <strong><?= e($account["gradeLevel"] ?? "--") ?></strong>
                            </div>

                            <div>
                                <span><?= e(msg("Teacher", "Guro", "Teacher")) ?></span>
                                <strong><?= e(($assignedTeacher["name"] ?? "") ?: "--") ?></strong>
                            </div>

                        <?php elseif ($accountRole === "teacher"): ?>

                            <div>
                                <span><?= e(msg(
                                    "Managed Sections",
                                    "Handled Sections",
                                    "Managed Sections"
                                )) ?></span>

                                <strong>
                                    <?= e($account["managedSections"] ?? "--") ?>
                                </strong>
                            </div>

                        <?php else: ?>

                            <div>
                                <span><?= e(msg("Access", "Access", "Access")) ?></span>

                                <strong>
                                    <?= e(msg(
                                        "System Administration",
                                        "System Administration",
                                        "System Administration"
                                    )) ?>
                                </strong>
                            </div>

                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>

            <?php if (!count($users)): ?>
                <div class="compact-empty">
                    <strong>
                        <?= e(msg(
                            "No users found",
                            "Walang users na nahanap",
                            "No users found"
                        )) ?>
                    </strong>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <?php foreach ($users as $account): ?>
        <?php
            $accountRole = $account["role"] ?? "";

            if (in_array($accountRole, $privilegedRoles, true)) {
                continue;
            }
        ?>

        <div
            class="modal-shell"
            data-modal="assign-<?= e($account["id"]) ?>"
        >
            <div class="modal-card large">
                <div class="modal-head">
                    <h3>
                        <?= e(msg(
                            "Manage Assignment",
                            "I-manage ang Assignment",
                            "Manage Assignment"
                        )) ?>
                    </h3>

                    <button type="button" data-modal-close>×</button>
                </div>

                <form
                    method="POST"
                    class="modal-body forms"
                    data-role-form
                >
                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= e(csrf_token()) ?>"
                    >

                    <input
                        type="hidden"
                        name="action"
                        value="assignment"
                    >

                    <input
                        type="hidden"
                        name="userId"
                        value="<?= e($account["id"]) ?>"
                    >

                    <div class="field">
                        <label><?= e(msg("Role", "Role", "Role")) ?></label>

                        <input
                            value="<?= e(
                                function_exists("role_label")
                                    ? role_label($accountRole)
                                    : ucfirst(str_replace("_", " ", $accountRole))
                            ) ?>"
                            readonly
                        >

                        <input
                            type="hidden"
                            name="role"
                            value="<?= e($accountRole) ?>"
                            data-role-select
                        >
                    </div>

                    <?php if ($accountRole === "student"): ?>
                        <div class="field" data-role-field="student">
                            <label><?= e(msg("Strand", "Strand", "Strand")) ?></label>

                            <select name="strand">
                                <?php foreach ($strandOptions as $strand): ?>
                                    <option
                                        value="<?= e($strand) ?>"
                                        <?= (($account["strand"] ?? "") === $strand) ? "selected" : "" ?>
                                    >
                                        <?= e($strand) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="field" data-role-field="student">
                            <label><?= e(msg("Section", "Section", "Section")) ?></label>

                            <select name="section">
                                <option value="">
                                    <?= e(msg(
                                        "Select Section",
                                        "Pumili ng Section",
                                        "Select Section"
                                    )) ?>
                                </option>

                                <?php foreach ($sectionNames as $sectionName): ?>
                                    <option
                                        value="<?= e($sectionName) ?>"
                                        <?= (($account["section"] ?? "") === $sectionName) ? "selected" : "" ?>
                                    >
                                        <?= e($sectionName) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="field" data-role-field="student">
                            <label>
                                <?= e(msg(
                                    "Grade Level",
                                    "Baitang",
                                    "Grade Level"
                                )) ?>
                            </label>

                            <select name="gradeLevel">
                                <?php foreach ($gradeOptions as $gradeLevel): ?>
                                    <option
                                        value="<?= e($gradeLevel) ?>"
                                        <?= (($account["gradeLevel"] ?? "") === $gradeLevel) ? "selected" : "" ?>
                                    >
                                        <?= e($gradeLevel) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="field" data-role-field="student">
                            <label>
                                <?= e(msg(
                                    "Assigned Teacher",
                                    "Naka-assign na Guro",
                                    "Assigned Teacher"
                                )) ?>
                            </label>

                            <select name="teacherId">
                                <option value="">
                                    <?= e(msg("None", "Wala", "None")) ?>
                                </option>

                                <?php foreach ($activeTeachers as $teacher): ?>
                                    <option
                                        value="<?= e($teacher["id"]) ?>"
                                        <?= (($account["teacherId"] ?? "") === $teacher["id"]) ? "selected" : "" ?>
                                    >
                                        <?= e($teacher["name"]) ?> · <?= e($teacher["code"]) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endif; ?>

                    <?php if ($accountRole === "teacher"): ?>
                        <div class="field full" data-role-field="teacher">
                            <label>
                                <?= e(msg(
                                    "Managed Sections",
                                    "Handled Sections",
                                    "Managed Sections"
                                )) ?>
                            </label>

                            <select name="managedSections">
                                <option value="">
                                    <?= e(msg("None", "Wala", "None")) ?>
                                </option>

                                <?php foreach ($sectionNames as $sectionName): ?>
                                    <option
                                        value="<?= e($sectionName) ?>"
                                        <?= (($account["managedSections"] ?? "") === $sectionName) ? "selected" : "" ?>
                                    >
                                        <?= e($sectionName) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endif; ?>

                    <?php if ($accountRole === "admin"): ?>
                        <div class="compact-empty full">
                            <strong>
                                <?= e(msg(
                                    "Administrator account",
                                    "Administrator account",
                                    "Administrator account"
                                )) ?>
                            </strong>
                        </div>
                    <?php endif; ?>

                    <div class="button-row full">
                        <button class="btn btn-primary" type="submit">
                            <?= e(msg(
                                "Save Assignment",
                                "I-save ang Assignment",
                                "Save Assignment"
                            )) ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    <?php endforeach; ?>

    <?php foreach ($users as $account): ?>
        <?php
            $accountId = $account["id"] ?? "";
            $accountRole = $account["role"] ?? "";
            $accountStatus = $account["status"] ?? "Active";
            $isCurrentAccount = $accountId === ($user["id"] ?? "");
            $isPrivilegedAccount = in_array($accountRole, $privilegedRoles, true);
            $canManageAccount = !$isCurrentAccount && (!$isPrivilegedAccount || $isSuperAdmin);

            if (!$canManageAccount) {
                continue;
            }
        ?>

        <div
            class="modal-shell"
            data-modal="security-<?= e($accountId) ?>"
        >
            <div class="modal-card large">
                <div class="modal-head">
                    <h3>
                        <?= e(msg(
                            "Account Security",
                            "Account Security",
                            "Account Security"
                        )) ?>
                    </h3>

                    <button type="button" data-modal-close>×</button>
                </div>

                <div class="modal-body forms">
                    <div class="compact-empty full">
                        <strong><?= e($account["name"] ?? "") ?></strong>
                        <span><?= e(($account["code"] ?? "") . " · " . ($account["email"] ?? "")) ?></span>
                    </div>

                    <?php if ($isSuperAdmin): ?>
                        <?php
                            $modalLoginState = $accountLoginSecurity[(string)$accountId] ?? [];
                            $modalFailedAttempts = max(0, (int)($modalLoginState["failedAttempts"] ?? 0));
                            $modalRemainingAttempts = max(0, (int)($modalLoginState["remainingAttempts"] ?? 0));
                            $modalLocked = !empty($modalLoginState["locked"]);
                            $modalSecondsRemaining = max(0, (int)($modalLoginState["secondsRemaining"] ?? 0));
                        ?>

                        <div class="mini-stat-list vertical full">
                            <div>
                                <span><?= e(msg("Failed Password Sign-In Attempts", "Failed Password Sign-In Attempts", "Failed Password Sign-In Attempts")) ?></span>
                                <strong><?= e($modalFailedAttempts) ?></strong>
                            </div>

                            <div>
                                <span><?= e(msg("Remaining Attempts", "Remaining Attempts", "Remaining Attempts")) ?></span>
                                <strong><?= e($modalRemainingAttempts) ?></strong>
                            </div>

                            <div>
                                <span><?= e(msg("Login Lockout", "Login Lockout", "Login Lockout")) ?></span>
                                <strong>
                                    <?= e(
                                        $modalLocked
                                            ? msg("Temporarily Locked", "Temporarily Locked", "Temporarily Locked")
                                            : msg("Not Locked", "Not Locked", "Not Locked")
                                    ) ?>
                                </strong>
                            </div>

                            <?php if ($modalLocked): ?>
                                <div>
                                    <span><?= e(msg("Locked Until", "Locked Until", "Locked Until")) ?></span>
                                    <strong><?= e(kaakbay_users_datetime($modalLoginState["lockoutUntil"] ?? "")) ?></strong>
                                </div>

                                <?php if ($modalSecondsRemaining > 0 && function_exists("security_retry_text")): ?>
                                    <div>
                                        <span><?= e(msg("Remaining Lockout Time", "Remaining Lockout Time", "Remaining Lockout Time")) ?></span>
                                        <strong><?= e(security_retry_text($modalSecondsRemaining)) ?></strong>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                        <div class="notice full">
                            <?= e(msg(
                                "Account login lockouts expire automatically. This page does not provide a manual unlock control.",
                                "Awtomatikong nag-e-expire ang account login lockouts. Walang manual unlock control sa page na ito.",
                                "Account login lockouts expire automatically. This page does not provide a manual unlock control."
                            )) ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" class="forms full" autocomplete="off">
                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                        <input type="hidden" name="action" value="status">
                        <input type="hidden" name="userId" value="<?= e($accountId) ?>">

                        <div class="field full">
                            <label>
                                <?= e(
                                    $accountStatus === "Active"
                                        ? msg(
                                            "Confirm Your Password to Deactivate",
                                            "Kumpirmahin ang Iyong Password para Mag-deactivate",
                                            "Confirm Your Password to Deactivate"
                                        )
                                        : msg(
                                            "Confirm Your Password to Activate",
                                            "Kumpirmahin ang Iyong Password para Mag-activate",
                                            "Confirm Your Password to Activate"
                                        )
                                ) ?>
                            </label>

                            <input
                                type="password"
                                name="currentPassword"
                                autocomplete="current-password"
                                required
                            >
                        </div>

                        <div class="button-row full">
                            <button class="btn btn-ghost" type="submit">
                                <?= e(
                                    $accountStatus === "Active"
                                        ? msg("Deactivate Account", "I-deactivate ang Account", "Deactivate Account")
                                        : msg("Activate Account", "I-activate ang Account", "Activate Account")
                                ) ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <?php if ($isSuperAdmin): ?>
            <div
                class="modal-shell"
                data-modal="role-<?= e($accountId) ?>"
            >
                <div class="modal-card large">
                    <div class="modal-head">
                        <h3>
                            <?= e(msg(
                                "Change Account Role",
                                "Palitan ang Account Role",
                                "Change Account Role"
                            )) ?>
                        </h3>

                        <button type="button" data-modal-close>×</button>
                    </div>

                    <form method="POST" class="modal-body forms" autocomplete="off">
                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                        <input type="hidden" name="action" value="changeRole">
                        <input type="hidden" name="userId" value="<?= e($accountId) ?>">

                        <div class="field full">
                            <label><?= e(msg("Role", "Role", "Role")) ?></label>

                            <select name="role" required>
                                <?php foreach (app_roles() as $roleOption): ?>
                                    <option
                                        value="<?= e($roleOption) ?>"
                                        <?= $accountRole === $roleOption ? "selected" : "" ?>
                                    >
                                        <?= e(
                                            function_exists("role_label")
                                                ? role_label($roleOption)
                                                : ucfirst(str_replace("_", " ", $roleOption))
                                        ) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="field full">
                            <label>
                                <?= e(msg(
                                    "Confirm Your Password to Change Role",
                                    "Kumpirmahin ang Iyong Password para Palitan ang Role",
                                    "Confirm Your Password to Change Role"
                                )) ?>
                            </label>

                            <input
                                type="password"
                                name="currentPassword"
                                autocomplete="current-password"
                                required
                            >
                        </div>

                        <div class="button-row full">
                            <button class="btn btn-primary" type="submit">
                                <?= e(msg(
                                    "Change Role",
                                    "Palitan ang Role",
                                    "Change Role"
                                )) ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>
</main>

<?php page_foot(); ?>