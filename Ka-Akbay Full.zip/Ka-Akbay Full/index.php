<?php
require_once __DIR__ . "/app/security.php";
require_once __DIR__ . "/app/auth.php";

if (current_user()) {
    header("Location: dashboard.php");
    exit;
}

header("Location: login.php");
exit;