<?php
require_once __DIR__ . "/app/security.php";
require_once __DIR__ . "/app/auth.php";
require_once __DIR__ . "/app/page_actions.php";
require_once __DIR__ . "/app/page_data.php";
require_once __DIR__ . "/app/layout.php";

require_super_admin();

$user = current_user();
$error = handle_page_action("content", $user);
$data = get_page_data("content", $user);

$settings = $data["settings"] ?? system_settings_record();
$contentRecords = $data["content"] ?? [];
$announcements = $data["announcements"] ?? [];

$contentMap = [];

foreach ($contentRecords as $contentRecord) {
    if (!is_array($contentRecord)) {
        continue;
    }

    $contentId = trim((string)($contentRecord["id"] ?? ""));

    if ($contentId !== "") {
        $contentMap[$contentId] = $contentRecord;
    }
}

$loginWelcome = $contentMap["login_welcome"]
    ?? system_content_record("login_welcome");

$footerContent = $contentMap["footer"]
    ?? system_content_record("footer");

$brandingSaved = (($_GET["brandingSaved"] ?? "") === "1");
$brandingRestored = (($_GET["brandingRestored"] ?? "") === "1");
$contentSaved = (($_GET["contentSaved"] ?? "") === "1");
$announcementSaved = (($_GET["announcementSaved"] ?? "") === "1");
$announcementDeleted = (($_GET["announcementDeleted"] ?? "") === "1");

function content_datetime_local($value) {
    $value = trim((string)$value);

    if ($value === "") {
        return "";
    }

    $time = strtotime($value);

    if (!$time) {
        return "";
    }

    return date("Y-m-d\TH:i", $time);
}

function content_audience_label($audience) {
    $audience = strtolower(trim((string)$audience));

    if ($audience === "all") {
        return "All Users";
    }

    if (function_exists("role_label")) {
        return role_label($audience);
    }

    return ucwords(str_replace("_", " ", $audience));
}

page_head(
    msg(
        "Content Management",
        "Content Management",
        "Content Management"
    )
);

sidebar("content", $user);
?>

<main class="main page-enter">
    <section class="topbar">
        <div>
            <h1>
                <?= e(msg(
                    "Content Management",
                    "Content Management",
                    "Content Management"
                )) ?>
            </h1>
        </div>

        <div class="date">
            <?= e(msg(
                "Super Admin",
                "Super Admin",
                "Super Admin"
            )) ?>
        </div>
    </section>

    <div class="error <?= $error ? "show" : "" ?>">
        <?= e($error) ?>
    </div>

    <?php if ($brandingSaved): ?>
        <div class="password-change-success">
            <?= e(msg(
                "Branding and theme settings were updated successfully.",
                "Matagumpay na na-update ang branding at theme settings.",
                "Branding and theme settings were updated successfully."
            )) ?>
        </div>
    <?php endif; ?>

    <?php if ($brandingRestored): ?>
        <div class="password-change-success">
            <?= e(msg(
                "Default branding settings were restored successfully.",
                "Matagumpay na na-restore ang default branding settings.",
                "Default branding settings were restored successfully."
            )) ?>
        </div>
    <?php endif; ?>

    <?php if ($contentSaved): ?>
        <div class="password-change-success">
            <?= e(msg(
                "System content was saved successfully.",
                "Matagumpay na na-save ang system content.",
                "System content was saved successfully."
            )) ?>
        </div>
    <?php endif; ?>

    <?php if ($announcementSaved): ?>
        <div class="password-change-success">
            <?= e(msg(
                "Announcement was saved successfully.",
                "Matagumpay na na-save ang announcement.",
                "Announcement was saved successfully."
            )) ?>
        </div>
    <?php endif; ?>

    <?php if ($announcementDeleted): ?>
        <div class="password-change-success">
            <?= e(msg(
                "Announcement was deleted successfully.",
                "Matagumpay na na-delete ang announcement.",
                "Announcement was deleted successfully."
            )) ?>
        </div>
    <?php endif; ?>

    <section class="student-overview-card">
        <div class="student-overview-main">
            <span>
                <?= e(msg(
                    "SYSTEM CONTENT",
                    "SYSTEM CONTENT",
                    "SYSTEM CONTENT"
                )) ?>
            </span>

            <h2>
                <?= e($settings["systemName"] ?? "Ka-Akbay") ?>
            </h2>

            <p>
                <?= e(msg(
                    "Manage system branding, interface content, and announcements.",
                    "Manage system branding, interface content, and announcements.",
                    "Manage system branding, interface content, and announcements."
                )) ?>
            </p>
        </div>

        <div class="student-overview-status">
            <small>
                <?= e(msg(
                    "Announcements",
                    "Announcements",
                    "Announcements"
                )) ?>
            </small>

            <strong>
                <?= e(count($announcements)) ?>
            </strong>

            <?= badge(msg(
                "Super Administrator",
                "Super Administrator",
                "Super Administrator"
            )) ?>
        </div>
    </section>

    <section class="dashboard-focus-grid">
        <div class="card clean-panel">
            <div class="clean-panel-head">
                <div>
                    <h2>
                        <?= e(msg(
                            "Branding & Theme",
                            "Branding & Theme",
                            "Branding & Theme"
                        )) ?>
                    </h2>
                </div>
            </div>

            <form method="POST" class="forms" enctype="multipart/form-data">
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e(csrf_token()) ?>"
                >

                <input
                    type="hidden"
                    name="action"
                    value="saveSystemSettings"
                >

                <div class="field full">
                    <label>
                        <?= e(msg(
                            "System Name",
                            "System Name",
                            "System Name"
                        )) ?>
                    </label>

                    <input
                        name="systemName"
                        maxlength="80"
                        value="<?= e($settings["systemName"] ?? "Ka-Akbay") ?>"
                        required
                    >
                </div>

                <div class="field full">
                    <label>
                        <?= e(msg(
                            "System Logo",
                            "System Logo",
                            "System Logo"
                        )) ?>
                    </label>

                    <input
                        type="file"
                        name="systemLogo"
                        accept=".png,.jpg,.jpeg,.webp,image/png,image/jpeg,image/webp"
                    >
                </div>

                <div class="field full">
                    <div class="notice">
                        <?= e(msg(
                            "PNG, JPG, or WEBP only. Maximum 2 MB and up to 4096 × 4096 pixels. The server validates the actual image content before saving it.",
                            "PNG, JPG, o WEBP lamang. Maximum na 2 MB at hanggang 4096 × 4096 pixels. Vine-verify ng server ang aktuwal na image content bago ito i-save.",
                            "PNG, JPG, or WEBP only. Maximum 2 MB and up to 4096 × 4096 pixels. The server validates the actual image content before saving it."
                        )) ?>
                    </div>
                </div>

                <?php if (!empty($settings["logoUrl"])): ?>
                    <div class="field full">
                        <label>
                            <input
                                type="checkbox"
                                name="removeSystemLogo"
                                value="1"
                            >

                            <?= e(msg(
                                "Remove current logo",
                                "Remove current logo",
                                "Remove current logo"
                            )) ?>
                        </label>
                    </div>
                <?php endif; ?>

                <div class="field">
                    <label>
                        <?= e(msg(
                            "Primary Color",
                            "Primary Color",
                            "Primary Color"
                        )) ?>
                    </label>

                    <input
                        type="color"
                        name="primaryColor"
                        value="<?= e($settings["primaryColor"] ?? "#294FC3") ?>"
                    >
                </div>

                <div class="field">
                    <label>
                        <?= e(msg(
                            "Secondary Color",
                            "Secondary Color",
                            "Secondary Color"
                        )) ?>
                    </label>

                    <input
                        type="color"
                        name="secondaryColor"
                        value="<?= e($settings["secondaryColor"] ?? "#F5F5F5") ?>"
                    >
                </div>

                <div class="field">
                    <label>
                        <?= e(msg(
                            "Accent Color",
                            "Accent Color",
                            "Accent Color"
                        )) ?>
                    </label>

                    <input
                        type="color"
                        name="accentColor"
                        value="<?= e($settings["accentColor"] ?? "#D4A017") ?>"
                    >
                </div>

                <div class="field">
                    <label>
                        <?= e(msg(
                            "Default Theme",
                            "Default Theme",
                            "Default Theme"
                        )) ?>
                    </label>

                    <select name="defaultTheme">
                        <?php foreach (["light", "dark", "system"] as $theme): ?>
                            <option
                                value="<?= e($theme) ?>"
                                <?= (($settings["defaultTheme"] ?? "light") === $theme) ? "selected" : "" ?>
                            >
                                <?= e(ucfirst($theme)) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="field full">
                    <label>
                        <?= e(msg(
                            "Confirm Current Password",
                            "Kumpirmahin ang Kasalukuyang Password",
                            "Confirm Current Password"
                        )) ?>
                    </label>

                    <input
                        type="password"
                        name="currentPassword"
                        autocomplete="current-password"
                        required
                    >
                </div>

                <div class="button-row full">
                    <button
                        class="btn btn-primary"
                        type="submit"
                    >
                        <?= e(msg(
                            "Save Branding",
                            "Save Branding",
                            "Save Branding"
                        )) ?>
                    </button>
                </div>
            </form>

            <form method="POST" class="forms restore-branding-form" autocomplete="off" data-restore-branding-form>
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="action" value="restoreBrandingDefaults">

                <div class="field full">
                    <div class="notice">
                        <?= e(msg(
                            "Restoring defaults will replace the current system name, logo, colors, and default theme.",
                            "Papalitan ng restore defaults ang kasalukuyang system name, logo, colors, at default theme.",
                            "Restoring defaults will replace the current system name, logo, colors, and default theme."
                        )) ?>
                    </div>
                </div>

                <div class="button-row full" data-restore-branding-start>
                    <button class="btn btn-ghost" type="button" data-restore-branding-trigger>
                        <?= e(msg("Restore Default", "Restore Default", "Restore Default")) ?>
                    </button>
                </div>

                <div class="restore-branding-confirmation full" data-restore-branding-confirmation hidden>
                    <div class="field full">
                        <label><?= e(msg("Confirm Current Password", "Kumpirmahin ang Kasalukuyang Password", "Confirm Current Password")) ?></label>
                        <input type="password" name="currentPassword" autocomplete="current-password" disabled data-restore-branding-password>
                    </div>
                    <div class="button-row full">
                        <button class="btn btn-danger" type="submit"><?= e(msg("Confirm Restore", "Kumpirmahin ang Restore", "Confirm Restore")) ?></button>
                        <button class="btn btn-ghost" type="button" data-restore-branding-cancel><?= e(msg("Cancel", "Kanselahin", "Cancel")) ?></button>
                    </div>
                </div>
            </form>
        </div>

        <div class="card clean-panel">
            <div class="clean-panel-head">
                <div>
                    <h2>
                        <?= e(msg(
                            "Login Page",
                            "Login Page",
                            "Login Page"
                        )) ?>
                    </h2>
                </div>
            </div>

            <form method="POST" class="forms">
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e(csrf_token()) ?>"
                >

                <input
                    type="hidden"
                    name="action"
                    value="saveSystemContent"
                >

                <input
                    type="hidden"
                    name="contentId"
                    value="login_welcome"
                >

                <input
                    type="hidden"
                    name="key"
                    value="<?= e($loginWelcome["key"] ?? "loginWelcome") ?>"
                >

                <div class="field full">
                    <label>
                        <?= e(msg(
                            "Welcome Title",
                            "Welcome Title",
                            "Welcome Title"
                        )) ?>
                    </label>

                    <input
                        name="title"
                        maxlength="180"
                        value="<?= e($loginWelcome["title"] ?? "") ?>"
                    >
                </div>

                <div class="field full">
                    <label>
                        <?= e(msg(
                            "Welcome Message",
                            "Welcome Message",
                            "Welcome Message"
                        )) ?>
                    </label>

                    <textarea
                        name="content"
                        maxlength="4000"
                    ><?= e($loginWelcome["content"] ?? "") ?></textarea>
                </div>

                <input
                    type="hidden"
                    name="isActive"
                    value="0"
                >

                <div class="field full">
                    <label>
                        <input
                            type="checkbox"
                            name="isActive"
                            value="1"
                            <?= !empty($loginWelcome["isActive"]) ? "checked" : "" ?>
                        >

                        <?= e(msg(
                            "Show login welcome content",
                            "Show login welcome content",
                            "Show login welcome content"
                        )) ?>
                    </label>
                </div>

                <div class="button-row full">
                    <button
                        class="btn btn-primary"
                        type="submit"
                    >
                        <?= e(msg(
                            "Save Login Content",
                            "Save Login Content",
                            "Save Login Content"
                        )) ?>
                    </button>
                </div>
            </form>
        </div>
    </section>

    <section class="card clean-panel section-space">
        <div class="clean-panel-head">
            <div>
                <h2>
                    <?= e(msg(
                        "Footer Content",
                        "Footer Content",
                        "Footer Content"
                    )) ?>
                </h2>
            </div>
        </div>

        <form method="POST" class="forms">
            <input
                type="hidden"
                name="csrf_token"
                value="<?= e(csrf_token()) ?>"
            >

            <input
                type="hidden"
                name="action"
                value="saveSystemContent"
            >

            <input
                type="hidden"
                name="contentId"
                value="footer"
            >

            <input
                type="hidden"
                name="key"
                value="<?= e($footerContent["key"] ?? "footer") ?>"
            >

            <input
                type="hidden"
                name="title"
                value="<?= e($footerContent["title"] ?? "") ?>"
            >

            <div class="field full">
                <label>
                    <?= e(msg(
                        "Footer Text",
                        "Footer Text",
                        "Footer Text"
                    )) ?>
                </label>

                <textarea
                    name="content"
                    maxlength="4000"
                ><?= e($footerContent["content"] ?? "") ?></textarea>
            </div>

            <input
                type="hidden"
                name="isActive"
                value="0"
            >

            <div class="field full">
                <label>
                    <input
                        type="checkbox"
                        name="isActive"
                        value="1"
                        <?= !empty($footerContent["isActive"]) ? "checked" : "" ?>
                    >

                    <?= e(msg(
                        "Show footer content",
                        "Show footer content",
                        "Show footer content"
                    )) ?>
                </label>
            </div>

            <div class="button-row full">
                <button
                    class="btn btn-primary"
                    type="submit"
                >
                    <?= e(msg(
                        "Save Footer",
                        "Save Footer",
                        "Save Footer"
                    )) ?>
                </button>
            </div>
        </form>
    </section>

    <section class="dashboard-focus-grid section-space">
        <div class="card clean-panel">
            <div class="clean-panel-head">
                <div>
                    <h2>
                        <?= e(msg(
                            "Create Announcement",
                            "Create Announcement",
                            "Create Announcement"
                        )) ?>
                    </h2>
                </div>
            </div>

            <form method="POST" class="forms">
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e(csrf_token()) ?>"
                >

                <input
                    type="hidden"
                    name="action"
                    value="saveAnnouncement"
                >

                <div class="field full">
                    <label>
                        <?= e(msg(
                            "Title",
                            "Title",
                            "Title"
                        )) ?>
                    </label>

                    <input
                        name="title"
                        maxlength="180"
                        required
                    >
                </div>

                <div class="field full">
                    <label>
                        <?= e(msg(
                            "Message",
                            "Message",
                            "Message"
                        )) ?>
                    </label>

                    <textarea
                        name="message"
                        maxlength="3000"
                        required
                    ></textarea>
                </div>

                <div class="field">
                    <label>
                        <?= e(msg(
                            "Audience",
                            "Audience",
                            "Audience"
                        )) ?>
                    </label>

                    <select name="audience">
                        <option value="all">
                            <?= e(msg(
                                "All Users",
                                "All Users",
                                "All Users"
                            )) ?>
                        </option>

                        <option value="student">
                            <?= e(msg(
                                "Students",
                                "Students",
                                "Students"
                            )) ?>
                        </option>

                        <option value="teacher">
                            <?= e(msg(
                                "Teachers",
                                "Teachers",
                                "Teachers"
                            )) ?>
                        </option>

                        <option value="admin">
                            <?= e(msg(
                                "Administrators",
                                "Administrators",
                                "Administrators"
                            )) ?>
                        </option>

                        <option value="super_admin">
                            <?= e(msg(
                                "Super Administrators",
                                "Super Administrators",
                                "Super Administrators"
                            )) ?>
                        </option>

                        <option value="it_admin">
                            <?= e(msg(
                                "IT Administrators",
                                "IT Administrators",
                                "IT Administrators"
                            )) ?>
                        </option>
                    </select>
                </div>

                <div class="field">
                    <label>
                        <?= e(msg(
                            "Start",
                            "Start",
                            "Start"
                        )) ?>
                    </label>

                    <input
                        type="datetime-local"
                        name="startAt"
                    >
                </div>

                <div class="field">
                    <label>
                        <?= e(msg(
                            "End",
                            "End",
                            "End"
                        )) ?>
                    </label>

                    <input
                        type="datetime-local"
                        name="endAt"
                    >
                </div>

                <input
                    type="hidden"
                    name="isActive"
                    value="0"
                >

                <div class="field">
                    <label>
                        <input
                            type="checkbox"
                            name="isActive"
                            value="1"
                            checked
                        >

                        <?= e(msg(
                            "Active",
                            "Active",
                            "Active"
                        )) ?>
                    </label>
                </div>

                <div class="button-row full">
                    <button
                        class="btn btn-primary"
                        type="submit"
                    >
                        <?= e(msg(
                            "Publish Announcement",
                            "Publish Announcement",
                            "Publish Announcement"
                        )) ?>
                    </button>
                </div>
            </form>
        </div>

        <div class="card clean-panel">
            <div class="clean-panel-head">
                <div>
                    <h2>
                        <?= e(msg(
                            "Announcement Summary",
                            "Announcement Summary",
                            "Announcement Summary"
                        )) ?>
                    </h2>
                </div>
            </div>

            <?php
                $activeAnnouncementCount = 0;
                $inactiveAnnouncementCount = 0;

                foreach ($announcements as $announcement) {
                    if (!empty($announcement["isActive"])) {
                        $activeAnnouncementCount++;
                    } else {
                        $inactiveAnnouncementCount++;
                    }
                }
            ?>

            <div class="mini-stat-list vertical">
                <div>
                    <span>
                        <?= e(msg(
                            "Total",
                            "Total",
                            "Total"
                        )) ?>
                    </span>

                    <strong>
                        <?= e(count($announcements)) ?>
                    </strong>
                </div>

                <div>
                    <span>
                        <?= e(msg(
                            "Active",
                            "Active",
                            "Active"
                        )) ?>
                    </span>

                    <strong>
                        <?= e($activeAnnouncementCount) ?>
                    </strong>
                </div>

                <div>
                    <span>
                        <?= e(msg(
                            "Inactive",
                            "Inactive",
                            "Inactive"
                        )) ?>
                    </span>

                    <strong>
                        <?= e($inactiveAnnouncementCount) ?>
                    </strong>
                </div>
            </div>
        </div>
    </section>

    <section class="card clean-panel section-space">
        <div class="clean-panel-head">
            <div>
                <h2>
                    <?= e(msg(
                        "Announcements",
                        "Announcements",
                        "Announcements"
                    )) ?>
                </h2>
            </div>
        </div>

        <div class="monitoring-grid">
            <?php foreach ($announcements as $index => $announcement): ?>
                <?php
                    $announcementId = $announcement["id"] ?? "";
                    $isActive = !empty($announcement["isActive"]);
                    $audience = $announcement["audience"] ?? "all";
                    $startAt = $announcement["startAt"] ?? "";
                    $endAt = $announcement["endAt"] ?? "";
                ?>

                <div class="monitor-card <?= $isActive ? "good" : "" ?>">
                    <div class="monitor-card-top">
                        <div>
                            <span>
                                <?= e(content_audience_label($audience)) ?>
                            </span>

                            <h3>
                                <?= e($announcement["title"] ?? "") ?>
                            </h3>

                            <p>
                                <?= e($announcement["message"] ?? "") ?>
                            </p>
                        </div>

                        <button
                            class="dot-action"
                            type="button"
                            data-menu-button="announcement-<?= e($index) ?>"
                        >
                            •••
                        </button>

                        <div
                            class="popup-menu"
                            data-menu="announcement-<?= e($index) ?>"
                        >
                            <button
                                type="button"
                                data-modal-open="announcement-edit-<?= e($index) ?>"
                            >
                                <?= e(msg(
                                    "Edit",
                                    "Edit",
                                    "Edit"
                                )) ?>
                            </button>

                            <button
                                type="button"
                                data-modal-open="announcement-delete-<?= e($index) ?>"
                            >
                                <?= e(msg(
                                    "Delete",
                                    "Delete",
                                    "Delete"
                                )) ?>
                            </button>
                        </div>
                    </div>

                    <div class="monitor-status-row">
                        <?= badge(
                            $isActive
                                ? msg("Active", "Active", "Active")
                                : msg("Inactive", "Inactive", "Inactive")
                        ) ?>

                        <?= badge(content_audience_label($audience)) ?>
                    </div>

                    <div class="monitor-mini-grid">
                        <div>
                            <span>
                                <?= e(msg(
                                    "Starts",
                                    "Starts",
                                    "Starts"
                                )) ?>
                            </span>

                            <strong>
                                <?= e(
                                    $startAt !== ""
                                        ? date("M d, Y g:i A", strtotime($startAt))
                                        : msg("Immediately", "Immediately", "Immediately")
                                ) ?>
                            </strong>
                        </div>

                        <div>
                            <span>
                                <?= e(msg(
                                    "Ends",
                                    "Ends",
                                    "Ends"
                                )) ?>
                            </span>

                            <strong>
                                <?= e(
                                    $endAt !== ""
                                        ? date("M d, Y g:i A", strtotime($endAt))
                                        : msg("No End Date", "No End Date", "No End Date")
                                ) ?>
                            </strong>
                        </div>
                    </div>
                </div>

                <div
                    class="modal-shell"
                    data-modal="announcement-delete-<?= e($index) ?>"
                >
                    <div class="modal-card">
                        <div class="modal-head">
                            <h3>
                                <?= e(msg(
                                    "Delete Announcement",
                                    "Delete Announcement",
                                    "Delete Announcement"
                                )) ?>
                            </h3>

                            <button
                                type="button"
                                data-modal-close
                            >
                                ×
                            </button>
                        </div>

                        <form method="POST" class="modal-body forms" autocomplete="off">
                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= e(csrf_token()) ?>"
                            >

                            <input
                                type="hidden"
                                name="action"
                                value="deleteAnnouncement"
                            >

                            <input
                                type="hidden"
                                name="announcementId"
                                value="<?= e($announcementId) ?>"
                            >

                            <div class="field full">
                                <div class="notice">
                                    <?= e(msg(
                                        "This permanently deletes the selected announcement. Confirm your current password to continue.",
                                        "Permanenteng ide-delete nito ang napiling announcement. Kumpirmahin ang kasalukuyang password para magpatuloy.",
                                        "This permanently deletes the selected announcement. Confirm your current password to continue."
                                    )) ?>
                                </div>
                            </div>

                            <div class="field full">
                                <label>
                                    <?= e(msg(
                                        "Current Password",
                                        "Kasalukuyang Password",
                                        "Current Password"
                                    )) ?>
                                </label>

                                <input
                                    type="password"
                                    name="currentPassword"
                                    autocomplete="current-password"
                                    required
                                >
                            </div>

                            <div class="button-row full">
                                <button
                                    class="btn btn-danger"
                                    type="submit"
                                >
                                    <?= e(msg(
                                        "Delete Announcement",
                                        "Delete Announcement",
                                        "Delete Announcement"
                                    )) ?>
                                </button>

                                <button
                                    class="btn btn-ghost"
                                    type="button"
                                    data-modal-close
                                >
                                    <?= e(msg(
                                        "Cancel",
                                        "Cancel",
                                        "Cancel"
                                    )) ?>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <div
                    class="modal-shell"
                    data-modal="announcement-edit-<?= e($index) ?>"
                >
                    <div class="modal-card large">
                        <div class="modal-head">
                            <h3>
                                <?= e(msg(
                                    "Edit Announcement",
                                    "Edit Announcement",
                                    "Edit Announcement"
                                )) ?>
                            </h3>

                            <button
                                type="button"
                                data-modal-close
                            >
                                ×
                            </button>
                        </div>

                        <form method="POST" class="modal-body forms">
                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= e(csrf_token()) ?>"
                            >

                            <input
                                type="hidden"
                                name="action"
                                value="saveAnnouncement"
                            >

                            <input
                                type="hidden"
                                name="announcementId"
                                value="<?= e($announcementId) ?>"
                            >

                            <div class="field full">
                                <label>
                                    <?= e(msg(
                                        "Title",
                                        "Title",
                                        "Title"
                                    )) ?>
                                </label>

                                <input
                                    name="title"
                                    maxlength="180"
                                    value="<?= e($announcement["title"] ?? "") ?>"
                                    required
                                >
                            </div>

                            <div class="field full">
                                <label>
                                    <?= e(msg(
                                        "Message",
                                        "Message",
                                        "Message"
                                    )) ?>
                                </label>

                                <textarea
                                    name="message"
                                    maxlength="3000"
                                    required
                                ><?= e($announcement["message"] ?? "") ?></textarea>
                            </div>

                            <div class="field">
                                <label>
                                    <?= e(msg(
                                        "Audience",
                                        "Audience",
                                        "Audience"
                                    )) ?>
                                </label>

                                <select name="audience">
                                    <?php
                                        $audienceOptions = [
                                            "all" => "All Users",
                                            "student" => "Students",
                                            "teacher" => "Teachers",
                                            "admin" => "Administrators",
                                            "super_admin" => "Super Administrators",
                                            "it_admin" => "IT Administrators"
                                        ];
                                    ?>

                                    <?php foreach ($audienceOptions as $value => $label): ?>
                                        <option
                                            value="<?= e($value) ?>"
                                            <?= ($audience === $value) ? "selected" : "" ?>
                                        >
                                            <?= e($label) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="field">
                                <label>
                                    <?= e(msg(
                                        "Start",
                                        "Start",
                                        "Start"
                                    )) ?>
                                </label>

                                <input
                                    type="datetime-local"
                                    name="startAt"
                                    value="<?= e(content_datetime_local($startAt)) ?>"
                                >
                            </div>

                            <div class="field">
                                <label>
                                    <?= e(msg(
                                        "End",
                                        "End",
                                        "End"
                                    )) ?>
                                </label>

                                <input
                                    type="datetime-local"
                                    name="endAt"
                                    value="<?= e(content_datetime_local($endAt)) ?>"
                                >
                            </div>

                            <input
                                type="hidden"
                                name="isActive"
                                value="0"
                            >

                            <div class="field">
                                <label>
                                    <input
                                        type="checkbox"
                                        name="isActive"
                                        value="1"
                                        <?= $isActive ? "checked" : "" ?>
                                    >

                                    <?= e(msg(
                                        "Active",
                                        "Active",
                                        "Active"
                                    )) ?>
                                </label>
                            </div>

                            <div class="button-row full">
                                <button
                                    class="btn btn-primary"
                                    type="submit"
                                >
                                    <?= e(msg(
                                        "Save Announcement",
                                        "Save Announcement",
                                        "Save Announcement"
                                    )) ?>
                                </button>

                                <button
                                    class="btn btn-ghost"
                                    type="button"
                                    data-modal-close
                                >
                                    <?= e(msg(
                                        "Cancel",
                                        "Cancel",
                                        "Cancel"
                                    )) ?>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>

            <?php if (!count($announcements)): ?>
                <div class="compact-empty">
                    <strong>
                        <?= e(msg(
                            "No announcements yet",
                            "No announcements yet",
                            "No announcements yet"
                        )) ?>
                    </strong>
                </div>
            <?php endif; ?>
        </div>
    </section>
</main>

<?php page_foot(); ?>