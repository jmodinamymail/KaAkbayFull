<?php
require_once __DIR__ . "/app/security.php";
require_once __DIR__ . "/app/auth.php";
require_once __DIR__ . "/app/page_actions.php";
require_once __DIR__ . "/app/page_data.php";
require_once __DIR__ . "/app/layout.php";

require_role(["teacher", "admin", "super_admin"]);

if (!function_exists("kaakbay_auto_score_validation_status")) {
    function kaakbay_auto_score_validation_status($record) {
        $score = $record["score"] ?? "";
        $totalScore = $record["totalScore"] ?? "";
        $submissionStatus = $record["submissionStatus"] ?? "Submitted";

        if ($score === "" || $totalScore === "" || !is_numeric($score) || !is_numeric($totalScore)) {
            return "Needs Review";
        }

        $scoreValue = (float)$score;
        $totalValue = (float)$totalScore;

        if ($totalValue <= 0 || $scoreValue < 0 || $scoreValue > $totalValue) {
            return "Not Consistent";
        }

        if ($submissionStatus === "Missing") {
            return "Needs Review";
        }

        $percentage = round(($scoreValue / $totalValue) * 100, 2);

        if ($percentage < 75) {
            return "Needs Review";
        }

        return "Consistent";
    }
}

if (!function_exists("kaakbay_auto_output_validation_status")) {
    function kaakbay_auto_output_validation_status($latest, $workload, $taskSummary) {
        $academicStatus = $latest["academicStatus"] ?? "No Record";
        $competencyStatus = $latest["competencyStatus"] ?? "No Record";
        $attendanceStatus = $latest["attendanceStatus"] ?? "No Record";
        $requirementStatus = $latest["requirementStatus"] ?? "No Record";
        $trendStatus = $latest["trendStatus"] ?? "Insufficient Trend Data";
        $workloadStatus = $workload["lingguhangBigatIndex"] ?? "Magaan";
        $alertCount = (int)($taskSummary["alertCount"] ?? 0);

        $outputText = strtolower(trim(
            $academicStatus . " " .
            $competencyStatus . " " .
            $attendanceStatus . " " .
            $requirementStatus . " " .
            $trendStatus . " " .
            $workloadStatus
        ));

        if ($academicStatus === "No Record" && $competencyStatus === "No Record" && $attendanceStatus === "No Record") {
            return "Needs Review";
        }

        if (
            text_has($outputText, "at-risk") ||
            text_has($outputText, "failing") ||
            text_has($outputText, "warning") ||
            text_has($outputText, "not mastered") ||
            text_has($outputText, "remediation") ||
            text_has($outputText, "attendance concern") ||
            text_has($outputText, "incomplete") ||
            text_has($outputText, "declining") ||
            text_has($outputText, "mabigat") ||
            $alertCount > 0
        ) {
            return "Needs Review";
        }

        return "Consistent";
    }
}

if (!function_exists("kaakbay_validation_basis")) {
    function kaakbay_validation_basis($status) {
        if ($status === "Not Consistent") {
            return msg("The encoded values contain an invalid or conflicting score condition.", "May hindi tugma o mali sa na-encode na score condition.", "The encoded values contain an invalid or conflicting score condition.");
        }

        if ($status === "Needs Review") {
            return msg("The system detected a low score, academic concern, competency concern, attendance concern, requirement concern, trend concern, or workload condition that requires teacher review.", "May nakita ang system na mababang score, academic concern, competency concern, attendance concern, requirement concern, trend concern, o workload condition na kailangan ng teacher review.", "The system detected a low score, academic concern, competency concern, attendance concern, requirement concern, trend concern, or workload condition that requires teacher review.");
        }

        return msg("The encoded data and computed output are consistent with the rule-based checks.", "Tugma ang encoded data at computed output sa rule-based checks.", "The encoded data and computed output are consistent with the rule-based checks.");
    }
}

if (!function_exists("kaakbay_validation_find_record")) {
    function kaakbay_validation_find_record($recordId) {
        foreach (read_records("academic_records") as $record) {
            if (($record["id"] ?? "") === $recordId) {
                return $record;
            }
        }

        return null;
    }
}

$user = current_user();
$error = handle_page_action("validation", $user);
$data = get_page_data("validation", $user);
$rows = $data["rows"] ?? [];
$validations = $data["validations"] ?? [];
$counts = $data["validationCounts"] ?? [];

$filters = [
    "q" => trim($_GET["q"] ?? ""),
    "validationStatus" => $_GET["validationStatus"] ?? "",
    "gradeStatus" => $_GET["gradeStatus"] ?? "",
    "competencyStatus" => $_GET["competencyStatus"] ?? "",
    "attendanceStatus" => $_GET["attendanceStatus"] ?? "",
    "requirementStatus" => $_GET["requirementStatus"] ?? "",
    "trendStatus" => $_GET["trendStatus"] ?? "",
    "workloadStatus" => $_GET["workloadStatus"] ?? "",
    "followUpType" => $_GET["followUpType"] ?? "",
    "strand" => $_GET["strand"] ?? "",
    "section" => $_GET["section"] ?? "",
    "subject" => $_GET["subject"] ?? ""
];

$filteredRows = [];

foreach ($rows as $row) {
    $student = $row["student"] ?? [];
    $latest = $row["latest"] ?? [];
    $workload = $row["workload"] ?? [];
    $taskSummary = $row["taskSummary"] ?? [];
    $followUpType = $row["followUpType"] ?? "";

    $academicStatus = $latest["academicStatus"] ?? "";
    $competencyStatus = $latest["competencyStatus"] ?? "";
    $attendanceStatus = $latest["attendanceStatus"] ?? "";
    $requirementStatus = $latest["requirementStatus"] ?? "";
    $trendStatus = $latest["trendStatus"] ?? "";
    $workloadStatus = $workload["lingguhangBigatIndex"] ?? "";
    $subject = $latest["subject"] ?? "";
    $autoValidationStatus = kaakbay_auto_output_validation_status($latest, $workload, $taskSummary);

    $searchText = strtolower(trim(
        ($student["code"] ?? "") . " " .
        ($student["name"] ?? "") . " " .
        ($student["strand"] ?? "") . " " .
        ($student["section"] ?? "") . " " .
        $subject . " " .
        $academicStatus . " " .
        $competencyStatus . " " .
        $attendanceStatus . " " .
        $requirementStatus . " " .
        $trendStatus . " " .
        $workloadStatus . " " .
        $followUpType . " " .
        $autoValidationStatus
    ));

    if (($filters["q"] ?? "") !== "" && strpos($searchText, strtolower($filters["q"])) === false) {
        continue;
    }

    if (($filters["validationStatus"] ?? "") !== "" && $autoValidationStatus !== $filters["validationStatus"]) {
        continue;
    }

    if (($filters["gradeStatus"] ?? "") !== "" && $academicStatus !== $filters["gradeStatus"]) {
        continue;
    }

    if (($filters["competencyStatus"] ?? "") !== "" && $competencyStatus !== $filters["competencyStatus"]) {
        continue;
    }

    if (($filters["attendanceStatus"] ?? "") !== "" && $attendanceStatus !== $filters["attendanceStatus"]) {
        continue;
    }

    if (($filters["requirementStatus"] ?? "") !== "" && $requirementStatus !== $filters["requirementStatus"]) {
        continue;
    }

    if (($filters["trendStatus"] ?? "") !== "" && $trendStatus !== $filters["trendStatus"]) {
        continue;
    }

    if (($filters["workloadStatus"] ?? "") !== "" && $workloadStatus !== $filters["workloadStatus"]) {
        continue;
    }

    if (($filters["followUpType"] ?? "") !== "" && $followUpType !== $filters["followUpType"]) {
        continue;
    }

    if (($filters["strand"] ?? "") !== "" && stripos($student["strand"] ?? "", $filters["strand"]) === false) {
        continue;
    }

    if (($filters["section"] ?? "") !== "" && stripos($student["section"] ?? "", $filters["section"]) === false) {
        continue;
    }

    if (($filters["subject"] ?? "") !== "" && stripos($subject, $filters["subject"]) === false) {
        continue;
    }

    $row["autoValidationStatus"] = $autoValidationStatus;
    $filteredRows[] = $row;
}

$visibleStudentIds = [];
$visibleStudents = [];

foreach ($rows as $row) {
    $student = $row["student"] ?? [];

    if (!empty($student["id"])) {
        $visibleStudentIds[] = $student["id"];
        $visibleStudents[$student["id"]] = $student;
    }
}

$visibleStudentIds = array_values(array_unique($visibleStudentIds));
$validationRecordMap = [];

foreach ($validations as $validation) {
    $recordId = $validation["recordId"] ?? "";

    if ($recordId === "") {
        continue;
    }

    if (!isset($validationRecordMap[$recordId])) {
        $validationRecordMap[$recordId] = $validation;
        continue;
    }

    $currentTime = strtotime($validationRecordMap[$recordId]["createdAt"] ?? "now");
    $newTime = strtotime($validation["createdAt"] ?? "now");

    if ($newTime >= $currentTime) {
        $validationRecordMap[$recordId] = $validation;
    }
}

$scoreRecords = [];

foreach ($visibleStudentIds as $studentId) {
    $student = $visibleStudents[$studentId] ?? find_user_by_id($studentId);
    $studentRecords = academic_record_history_for_student($studentId);

    foreach ($studentRecords as $record) {
        if (($record["recordMode"] ?? "assessment") !== "assessment") {
            continue;
        }

        $evaluated = evaluate_record($record);
        $assessmentType = $evaluated["assessmentType"] ?? "Assessment";
        $subject = $evaluated["subject"] ?? "";
        $score = $evaluated["score"] ?? "";
        $totalScore = $evaluated["totalScore"] ?? "";
        $percentage = $evaluated["assessmentPercentage"] ?? "";
        $submissionStatus = $evaluated["submissionStatus"] ?? "Submitted";
        $autoValidationStatus = kaakbay_auto_score_validation_status($evaluated);
        $systemOutput = trim($assessmentType . " / Score " . $score . " of " . $totalScore . " / " . $percentage . "% / " . $submissionStatus);

        $scoreSearchText = strtolower(trim(
            ($student["code"] ?? "") . " " .
            ($student["name"] ?? "") . " " .
            ($student["strand"] ?? "") . " " .
            ($student["section"] ?? "") . " " .
            $subject . " " .
            ($evaluated["gradingPeriod"] ?? "") . " " .
            ($evaluated["assessmentTitle"] ?? "") . " " .
            $assessmentType . " " .
            $score . " " .
            $totalScore . " " .
            $percentage . " " .
            $submissionStatus . " " .
            $autoValidationStatus
        ));

        if (($filters["q"] ?? "") !== "" && strpos($scoreSearchText, strtolower($filters["q"])) === false) {
            continue;
        }

        if (($filters["validationStatus"] ?? "") !== "" && $autoValidationStatus !== $filters["validationStatus"]) {
            continue;
        }

        if (($filters["subject"] ?? "") !== "" && stripos($subject, $filters["subject"]) === false) {
            continue;
        }

        if (($filters["strand"] ?? "") !== "" && stripos($student["strand"] ?? "", $filters["strand"]) === false) {
            continue;
        }

        if (($filters["section"] ?? "") !== "" && stripos($student["section"] ?? "", $filters["section"]) === false) {
            continue;
        }

        $teacherValidation = $validationRecordMap[$evaluated["id"] ?? ""] ?? null;

        $scoreRecords[] = [
            "student" => $student,
            "record" => $evaluated,
            "systemOutput" => $systemOutput,
            "autoValidationStatus" => $autoValidationStatus,
            "teacherValidation" => $teacherValidation,
            "teacherValidationStatus" => $teacherValidation["validationStatus"] ?? "",
            "teacherValidatedAt" => $teacherValidation["createdAt"] ?? ""
        ];
    }
}

usort($scoreRecords, function($a, $b) {
    $aDate = $a["record"]["assessmentDate"] ?? $a["record"]["createdAt"] ?? "now";
    $bDate = $b["record"]["assessmentDate"] ?? $b["record"]["createdAt"] ?? "now";
    return strtotime($bDate) <=> strtotime($aDate);
});

$autoCounts = [
    "consistent" => 0,
    "needsReview" => 0,
    "notConsistent" => 0
];

foreach ($scoreRecords as $scoreRecord) {
    $status = $scoreRecord["teacherValidationStatus"] !== "" ? $scoreRecord["teacherValidationStatus"] : ($scoreRecord["autoValidationStatus"] ?? "");

    if ($status === "Consistent") {
        $autoCounts["consistent"]++;
    } elseif ($status === "Needs Review") {
        $autoCounts["needsReview"]++;
    } elseif ($status === "Not Consistent") {
        $autoCounts["notConsistent"]++;
    }
}

foreach ($filteredRows as $row) {
    $status = $row["autoValidationStatus"] ?? "";

    if ($status === "Consistent") {
        $autoCounts["consistent"]++;
    } elseif ($status === "Needs Review") {
        $autoCounts["needsReview"]++;
    } elseif ($status === "Not Consistent") {
        $autoCounts["notConsistent"]++;
    }
}

$filteredValidations = [];

foreach ($validations as $validation) {
    $student = find_user_by_id($validation["studentId"] ?? "");
    $historySearchText = strtolower(trim(
        ($student["code"] ?? "") . " " .
        ($student["name"] ?? "") . " " .
        ($validation["subject"] ?? "") . " " .
        ($validation["systemOutput"] ?? "") . " " .
        ($validation["validationStatus"] ?? "") . " " .
        ($validation["note"] ?? "") . " " .
        ($validation["itemAnalysisNotes"] ?? "") . " " .
        ($validation["competencyArea"] ?? "") . " " .
        ($validation["followUpPlan"] ?? "")
    ));

    if (($filters["q"] ?? "") !== "" && strpos($historySearchText, strtolower($filters["q"])) === false) {
        continue;
    }

    if (($filters["validationStatus"] ?? "") !== "" && (($validation["validationStatus"] ?? "") !== $filters["validationStatus"])) {
        continue;
    }

    if (($filters["subject"] ?? "") !== "" && stripos($validation["subject"] ?? "", $filters["subject"]) === false) {
        continue;
    }

    if (($validation["studentId"] ?? "") !== "" && !in_array($validation["studentId"] ?? "", $visibleStudentIds, true)) {
        continue;
    }

    $validation["studentName"] = $student["name"] ?? "";
    $validation["studentCode"] = $student["code"] ?? "";
    $filteredValidations[] = $validation;
}

$attendanceHistory = [];

foreach (read_records("attendance") as $attendance) {
    if (!in_array($attendance["studentId"] ?? "", $visibleStudentIds, true)) {
        continue;
    }

    $student = find_user_by_id($attendance["studentId"] ?? "");
    $attendanceSearchText = strtolower(trim(
        ($student["code"] ?? "") . " " .
        ($student["name"] ?? "") . " " .
        ($student["strand"] ?? "") . " " .
        ($student["section"] ?? "") . " " .
        ($attendance["subject"] ?? "") . " " .
        ($attendance["status"] ?? "") . " " .
        ($attendance["note"] ?? "") . " " .
        ($attendance["date"] ?? "")
    ));

    if (($filters["q"] ?? "") !== "" && strpos($attendanceSearchText, strtolower($filters["q"])) === false) {
        continue;
    }

    if (($filters["subject"] ?? "") !== "" && stripos($attendance["subject"] ?? "", $filters["subject"]) === false) {
        continue;
    }

    if (($filters["attendanceStatus"] ?? "") !== "") {
        $computedAttendanceStatus = ($attendance["status"] ?? "") === "Absent" ? "Attendance Concern" : "Regular Attendance";

        if ($computedAttendanceStatus !== $filters["attendanceStatus"]) {
            continue;
        }
    }

    if (($filters["strand"] ?? "") !== "" && stripos($student["strand"] ?? "", $filters["strand"]) === false) {
        continue;
    }

    if (($filters["section"] ?? "") !== "" && stripos($student["section"] ?? "", $filters["section"]) === false) {
        continue;
    }

    $attendance["studentName"] = $student["name"] ?? "";
    $attendance["studentCode"] = $student["code"] ?? "";
    $attendance["studentStrand"] = $student["strand"] ?? "";
    $attendance["studentSection"] = $student["section"] ?? "";
    $attendanceHistory[] = $attendance;
}

usort($attendanceHistory, function($a, $b) {
    return strtotime($b["updatedAt"] ?? $b["createdAt"] ?? $b["date"] ?? "now") <=> strtotime($a["updatedAt"] ?? $a["createdAt"] ?? $a["date"] ?? "now");
});

$deleteRequests = [];

foreach (read_records("delete_requests") as $request) {
    if (($request["studentId"] ?? "") !== "" && !in_array($request["studentId"] ?? "", $visibleStudentIds, true)) {
        continue;
    }

    $student = find_user_by_id($request["studentId"] ?? "");
    $record = kaakbay_validation_find_record($request["recordId"] ?? "");

    if (!$record && is_array($request["recordSnapshot"] ?? null)) {
        $record = $request["recordSnapshot"];
    }

    $requestSearchText = strtolower(trim(
        ($student["code"] ?? "") . " " .
        ($student["name"] ?? "") . " " .
        ($student["strand"] ?? "") . " " .
        ($student["section"] ?? "") . " " .
        ($record["subject"] ?? "") . " " .
        ($record["assessmentTitle"] ?? "") . " " .
        ($record["assessmentType"] ?? "") . " " .
        ($request["status"] ?? "") . " " .
        ($request["reason"] ?? "")
    ));

    if (($filters["q"] ?? "") !== "" && strpos($requestSearchText, strtolower($filters["q"])) === false) {
        continue;
    }

    if (($filters["subject"] ?? "") !== "" && stripos($record["subject"] ?? "", $filters["subject"]) === false) {
        continue;
    }

    if (($filters["strand"] ?? "") !== "" && stripos($student["strand"] ?? "", $filters["strand"]) === false) {
        continue;
    }

    if (($filters["section"] ?? "") !== "" && stripos($student["section"] ?? "", $filters["section"]) === false) {
        continue;
    }

    $request["studentName"] = $student["name"] ?? "";
    $request["studentCode"] = $student["code"] ?? "";
    $request["studentStrand"] = $student["strand"] ?? "";
    $request["studentSection"] = $student["section"] ?? "";
    $request["record"] = $record;
    $deleteRequests[] = $request;
}

usort($deleteRequests, function($a, $b) {
    return strtotime($b["createdAt"] ?? "now") <=> strtotime($a["createdAt"] ?? "now");
});

$activeFilterCount = 0;

foreach ($filters as $value) {
    if (trim((string)$value) !== "") {
        $activeFilterCount++;
    }
}

$totalHistoryCount = count($filteredValidations) + count($attendanceHistory) + count($deleteRequests);

page_head(msg("Teacher Validation", "Validation ng Guro", "Teacher Validation"));
sidebar("validation", $user);
?>

<main class="main page-enter validation-page">
    <section class="topbar">
        <div>
            <h1><?= e(msg("Teacher Validation", "Validation ng Guro", "Teacher Validation")) ?></h1>
        </div>
        <div class="date"><?= e(date("M d, Y")) ?></div>
    </section>

    <div class="error <?= $error ? "show" : "" ?>"><?= e($error) ?></div>

    <section class="validation-compact-summary">
        <div class="validation-summary-title">
            <h2><?= e(msg("Review Outputs", "Suriin ang Outputs", "Review Outputs")) ?></h2>
            <?= badge("Needs Review") ?>
        </div>

        <div class="validation-summary-grid">
            <div>
                <span><?= e(msg("Scores", "Scores", "Scores")) ?></span>
                <strong><?= e(count($scoreRecords)) ?></strong>
            </div>

            <div>
                <span><?= e(msg("Students", "Mag-aaral", "Students")) ?></span>
                <strong><?= e(count($filteredRows)) ?></strong>
            </div>

            <div>
                <span><?= e(msg("History", "Kasaysayan", "History")) ?></span>
                <strong><?= e($totalHistoryCount) ?></strong>
            </div>

            <div>
                <span><?= e(msg("Consistent", "Consistent", "Consistent")) ?></span>
                <strong><?= e($autoCounts["consistent"] ?? 0) ?></strong>
            </div>

            <div>
                <span><?= e(msg("Needs Review", "Kailangan ng Review", "Needs Review")) ?></span>
                <strong><?= e($autoCounts["needsReview"] ?? 0) ?></strong>
            </div>

            <div>
                <span><?= e(msg("Attendance", "Attendance", "Attendance")) ?></span>
                <strong><?= e(count($attendanceHistory)) ?></strong>
            </div>

            <div>
                <span><?= e(msg("Delete Requests", "Delete Requests", "Delete Requests")) ?></span>
                <strong><?= e(count($deleteRequests)) ?></strong>
            </div>
        </div>
    </section>

    <section class="card clean-panel validation-search-panel">
        <form method="GET" class="validation-filter-form">
            <div class="validation-search-row">
                <div class="field validation-search-field">
                    <label><?= e(msg("Search", "Hanapin", "Search")) ?></label>
                    <input name="q" value="<?= e($filters["q"] ?? "") ?>" placeholder="<?= e(msg("Student, subject, score, status, strand, section", "Mag-aaral, asignatura, score, status, strand, section", "Student, subject, score, status, strand, section")) ?>">
                </div>

                <div class="field">
                    <label><?= e(msg("Validation", "Validation", "Validation")) ?></label>
                    <select name="validationStatus">
                        <option value=""><?= e(msg("All", "Lahat", "All")) ?></option>
                        <?php foreach (["Consistent", "Needs Review", "Not Consistent"] as $status): ?>
                            <option value="<?= e($status) ?>" <?= (($filters["validationStatus"] ?? "") === $status) ? "selected" : "" ?>><?= e(function_exists("tv") ? tv($status) : $status) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="field">
                    <label><?= e(msg("Grade", "Marka", "Grade")) ?></label>
                    <select name="gradeStatus">
                        <option value=""><?= e(msg("All", "Lahat", "All")) ?></option>
                        <?php foreach (["Regular", "Warning Status", "At-Risk / Failing"] as $status): ?>
                            <option value="<?= e($status) ?>" <?= (($filters["gradeStatus"] ?? "") === $status) ? "selected" : "" ?>><?= e(function_exists("tv") ? tv($status) : $status) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="field">
                    <label><?= e(msg("Workload", "Bigat ng Gawain", "Workload")) ?></label>
                    <select name="workloadStatus">
                        <option value=""><?= e(msg("All", "Lahat", "All")) ?></option>
                        <?php foreach (["Magaan", "Katamtaman", "Mabigat"] as $status): ?>
                            <option value="<?= e($status) ?>" <?= (($filters["workloadStatus"] ?? "") === $status) ? "selected" : "" ?>><?= e($status) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="validation-filter-actions">
                    <button class="btn btn-primary" type="submit"><?= e(msg("Search", "Hanapin", "Search")) ?></button>
                    <a class="btn btn-ghost" href="validation.php"><?= e(msg("Clear", "I-clear", "Clear")) ?></a>
                </div>
            </div>

            <details class="validation-advanced-filter" <?= $activeFilterCount > 4 ? "open" : "" ?>>
                <summary>
                    <span><?= e(msg("More Filters", "Karagdagang Filters", "More Filters")) ?></span>
                    <strong><?= e($activeFilterCount) ?> <?= e(msg("active", "active", "active")) ?></strong>
                </summary>

                <div class="forms">
                    <div class="field">
                        <label><?= e(msg("Competency Status", "Kalagayan ng Kakayahan", "Competency Status")) ?></label>
                        <select name="competencyStatus">
                            <option value=""><?= e(msg("All", "Lahat", "All")) ?></option>
                            <?php foreach (["Mastered", "Nearing Mastery", "Not Mastered / Remediation Needed"] as $status): ?>
                                <option value="<?= e($status) ?>" <?= (($filters["competencyStatus"] ?? "") === $status) ? "selected" : "" ?>><?= e(function_exists("tv") ? tv($status) : $status) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="field">
                        <label><?= e(msg("Attendance Status", "Kalagayan ng Pagpasok", "Attendance Status")) ?></label>
                        <select name="attendanceStatus">
                            <option value=""><?= e(msg("All", "Lahat", "All")) ?></option>
                            <?php foreach (["Regular Attendance", "Attendance Concern"] as $status): ?>
                                <option value="<?= e($status) ?>" <?= (($filters["attendanceStatus"] ?? "") === $status) ? "selected" : "" ?>><?= e(function_exists("tv") ? tv($status) : $status) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="field">
                        <label><?= e(msg("Requirement Status", "Kalagayan ng Requirement", "Requirement Status")) ?></label>
                        <select name="requirementStatus">
                            <option value=""><?= e(msg("All", "Lahat", "All")) ?></option>
                            <?php foreach (["Complete Requirements", "Incomplete Requirements"] as $status): ?>
                                <option value="<?= e($status) ?>" <?= (($filters["requirementStatus"] ?? "") === $status) ? "selected" : "" ?>><?= e(function_exists("tv") ? tv($status) : $status) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="field">
                        <label><?= e(msg("Trend Status", "Kalagayan ng Pattern", "Trend Status")) ?></label>
                        <select name="trendStatus">
                            <option value=""><?= e(msg("All", "Lahat", "All")) ?></option>
                            <?php foreach (["Insufficient Trend Data", "Stable Performance Pattern", "Improving Performance Pattern", "Declining Performance Pattern"] as $status): ?>
                                <option value="<?= e($status) ?>" <?= (($filters["trendStatus"] ?? "") === $status) ? "selected" : "" ?>><?= e(function_exists("tv") ? tv($status) : $status) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="field">
                        <label><?= e(msg("Follow-up Type", "Uri ng Follow-up", "Follow-up Type")) ?></label>
                        <select name="followUpType">
                            <option value=""><?= e(msg("All", "Lahat", "All")) ?></option>
                            <?php foreach (["Regular Monitoring", "Monitoring", "Remediation", "Requirement Follow-up", "Performance Monitoring", "Attendance Follow-up", "Workload Follow-up"] as $type): ?>
                                <option value="<?= e($type) ?>" <?= (($filters["followUpType"] ?? "") === $type) ? "selected" : "" ?>><?= e(function_exists("tv") ? tv($type) : $type) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="field">
                        <label><?= e(msg("Strand", "Strand", "Strand")) ?></label>
                        <input name="strand" value="<?= e($filters["strand"] ?? "") ?>">
                    </div>

                    <div class="field">
                        <label><?= e(msg("Section", "Section", "Section")) ?></label>
                        <input name="section" value="<?= e($filters["section"] ?? "") ?>">
                    </div>

                    <div class="field">
                        <label><?= e(msg("Subject", "Asignatura", "Subject")) ?></label>
                        <input name="subject" value="<?= e($filters["subject"] ?? "") ?>">
                    </div>
                </div>
            </details>
        </form>
    </section>

    <section class="monitoring-board section-space">
        <div class="clean-panel-head">
            <div>
                <h2><?= e(msg("Student Score Records for Validation", "Student Score Records para sa Validation", "Student Score Records for Validation")) ?></h2>
            </div>
        </div>

        <div class="monitoring-grid">
            <?php foreach ($scoreRecords as $index => $item): ?>
                <?php
                    $student = $item["student"] ?? [];
                    $record = $item["record"] ?? [];
                    $systemOutput = $item["systemOutput"] ?? "";
                    $autoValidationStatus = $item["autoValidationStatus"] ?? "Needs Review";
                    $assessmentType = $record["assessmentType"] ?? "Assessment";
                    $score = $record["score"] ?? "--";
                    $totalScore = $record["totalScore"] ?? "--";
                    $percentage = $record["assessmentPercentage"] ?? "--";
                    $submissionStatus = $record["submissionStatus"] ?? "Submitted";
                    $competencyStatus = $record["competencyStatus"] ?? "No Record";
                    $isCompetencyCheck = $assessmentType === "Competency Check";
                    $validationBasis = kaakbay_validation_basis($autoValidationStatus);
                    $teacherValidation = $item["teacherValidation"] ?? null;
                    $teacherValidationStatus = $item["teacherValidationStatus"] ?? "";
                    $effectiveValidationStatus = $teacherValidationStatus !== "" ? $teacherValidationStatus : $autoValidationStatus;
                ?>

                <div class="monitor-card <?= e(view_state_class($submissionStatus . " " . $competencyStatus . " " . $effectiveValidationStatus)) ?>">
                    <div class="monitor-card-top">
                        <div>
                            <span><?= e($student["code"] ?? "") ?></span>
                            <h3><?= e($student["name"] ?? "") ?></h3>
                            <p><?= e(($student["strand"] ?? "") . " · " . ($student["section"] ?? "")) ?></p>
                        </div>
                        <button class="dot-action" type="button" data-menu-button="score-<?= e($index) ?>">•••</button>
                        <div class="popup-menu" data-menu="score-<?= e($index) ?>">
                            <button type="button" data-modal-open="score-validate-<?= e($index) ?>"><?= e(msg("Check Score", "I-check ang Score", "Check Score")) ?></button>
                            <button type="button" data-modal-open="score-detail-<?= e($index) ?>"><?= e(msg("View Details", "Tingnan ang Detalye", "View Details")) ?></button>
                        </div>
                    </div>

                    <div class="monitor-status-row">
                        <?= badge($assessmentType) ?>
                        <?= badge($submissionStatus) ?>
                        <?= badge($autoValidationStatus) ?>
                        <?php if ($teacherValidation): ?>
                            <?= badge(msg("Checked by Teacher", "Na-check ng Guro", "Checked by Teacher")) ?>
                        <?php endif; ?>
                        <?php if ($isCompetencyCheck): ?>
                            <?= badge($competencyStatus) ?>
                        <?php endif; ?>
                    </div>

                    <div class="monitor-mini-grid">
                        <div>
                            <span><?= e(msg("Subject", "Asignatura", "Subject")) ?></span>
                            <strong><?= e($record["subject"] ?? "--") ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Title", "Pamagat", "Title")) ?></span>
                            <strong><?= e($record["assessmentTitle"] ?? "--") ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Score", "Iskor", "Score")) ?></span>
                            <strong><?= e($score) ?> / <?= e($totalScore) ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Percent", "Porsyento", "Percent")) ?></span>
                            <strong><?= e($percentage) ?>%</strong>
                        </div>
                        <div>
                            <span><?= e(msg("Period", "Markahan", "Period")) ?></span>
                            <strong><?= e($record["gradingPeriod"] ?? "--") ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("System Check", "System Check", "System Check")) ?></span>
                            <strong><?= e(function_exists("tv") ? tv($autoValidationStatus) : $autoValidationStatus) ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Teacher Check", "Check ng Guro", "Teacher Check")) ?></span>
                            <strong><?= e($teacherValidation ? msg("Checked", "Na-check", "Checked") : msg("Pending", "Pending", "Pending")) ?></strong>
                        </div>
                    </div>
                </div>

                <div class="modal-shell" data-modal="score-validate-<?= e($index) ?>">
                    <div class="modal-card large">
                        <div class="modal-head">
                            <h3><?= e(msg("Check Student Score", "I-check ang Score ng Mag-aaral", "Check Student Score")) ?></h3>
                            <button type="button" data-modal-close>×</button>
                        </div>

                        <form method="POST" class="modal-body forms">
                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                            <input type="hidden" name="studentId" value="<?= e($student["id"] ?? "") ?>">
                            <input type="hidden" name="recordId" value="<?= e($record["id"] ?? "") ?>">
                            <input type="hidden" name="validationType" value="score">
                            <input type="hidden" name="subject" value="<?= e($record["subject"] ?? "") ?>">
                            <input type="hidden" name="systemOutput" value="<?= e($systemOutput) ?>">
                            <input type="hidden" name="validationStatus" value="<?= e($autoValidationStatus) ?>">

                            <div class="field">
                                <label><?= e(msg("Student", "Mag-aaral", "Student")) ?></label>
                                <input value="<?= e(($student["code"] ?? "") . " · " . ($student["name"] ?? "")) ?>" readonly>
                            </div>

                            <div class="field">
                                <label><?= e(msg("Score Output", "Score Output", "Score Output")) ?></label>
                                <input value="<?= e($systemOutput) ?>" readonly>
                            </div>

                            <div class="field">
                                <label><?= e(msg("System Check", "System Check", "System Check")) ?></label>
                                <input value="<?= e(function_exists("tv") ? tv($autoValidationStatus) : $autoValidationStatus) ?>" readonly>
                            </div>

                            <div class="field full">
                                <label><?= e(msg("Rule Basis", "Batayan ng Rule", "Rule Basis")) ?></label>
                                <input value="<?= e($validationBasis) ?>" readonly>
                            </div>

                            <input type="hidden" name="competencyArea" value="<?= e($teacherValidation["competencyArea"] ?? ($record["competencyName"] ?? "")) ?>">

                            <div class="field full">
                                <label><?= e(msg("Score Checking Notes", "Tala sa Pag-check ng Score", "Score Checking Notes")) ?></label>
                                <textarea name="itemAnalysisNotes"><?= e($teacherValidation["itemAnalysisNotes"] ?? "") ?></textarea>
                            </div>

                            <div class="field full">
                                <label><?= e(msg("Teacher Note", "Tala ng Guro", "Teacher Note")) ?></label>
                                <textarea name="note"><?= e($teacherValidation["note"] ?? "") ?></textarea>
                            </div>

                            <div class="field full">
                                <label><?= e(msg("Follow-up Plan", "Plano ng Follow-up", "Follow-up Plan")) ?></label>
                                <textarea name="followUpPlan"><?= e($teacherValidation["followUpPlan"] ?? "") ?></textarea>
                            </div>

                            <div class="button-row full">
                                <button class="btn btn-primary" type="submit"><?= e(msg("Mark as Checked", "Markahan bilang Na-check", "Mark as Checked")) ?></button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="modal-shell" data-modal="score-detail-<?= e($index) ?>">
                    <div class="modal-card large">
                        <div class="modal-head">
                            <h3><?= e(msg("Score Record Details", "Detalye ng Score Record", "Score Record Details")) ?></h3>
                            <button type="button" data-modal-close>×</button>
                        </div>

                        <div class="modal-body">
                            <div class="modal-grid">
                                <div>
                                    <span><?= e(msg("Student", "Mag-aaral", "Student")) ?></span>
                                    <strong><?= e($student["name"] ?? "") ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Subject", "Asignatura", "Subject")) ?></span>
                                    <strong><?= e($record["subject"] ?? "--") ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Assessment Type", "Uri ng Pagtataya", "Assessment Type")) ?></span>
                                    <strong><?= e(function_exists("tv") ? tv($assessmentType) : $assessmentType) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Assessment Title", "Pamagat ng Pagtataya", "Assessment Title")) ?></span>
                                    <strong><?= e($record["assessmentTitle"] ?? "--") ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Score", "Iskor", "Score")) ?></span>
                                    <strong><?= e($score) ?> / <?= e($totalScore) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Percent", "Porsyento", "Percent")) ?></span>
                                    <strong><?= e($percentage) ?>%</strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Submission", "Pagpapasa", "Submission")) ?></span>
                                    <strong><?= e(function_exists("tv") ? tv($submissionStatus) : $submissionStatus) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("System Check", "System Check", "System Check")) ?></span>
                                    <strong><?= e(function_exists("tv") ? tv($autoValidationStatus) : $autoValidationStatus) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Teacher Check", "Check ng Guro", "Teacher Check")) ?></span>
                                    <strong><?= e($teacherValidation ? msg("Checked", "Na-check", "Checked") : msg("Pending", "Pending", "Pending")) ?></strong>
                                </div>
                                <?php if ($isCompetencyCheck): ?>
                                    <div>
                                        <span><?= e(msg("Competency", "Kakayahan", "Competency")) ?></span>
                                        <strong><?= e($record["competencyName"] ?? "--") ?></strong>
                                    </div>
                                    <div>
                                        <span><?= e(msg("Mastery", "Mastery", "Mastery")) ?></span>
                                        <strong><?= e($record["competencyMastery"] ?? "--") ?>%</strong>
                                    </div>
                                    <div>
                                        <span><?= e(msg("Competency Status", "Kalagayan ng Kakayahan", "Competency Status")) ?></span>
                                        <strong><?= e(function_exists("tv") ? tv($competencyStatus) : $competencyStatus) ?></strong>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>

            <?php if (!count($scoreRecords)): ?>
                <div class="compact-empty">
                    <strong><?= e(msg("No student score records available", "Walang student score records na available", "No student score records available")) ?></strong>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <section class="monitoring-board section-space">
        <div class="clean-panel-head">
            <div>
                <h2><?= e(msg("Computed Outputs for Validation", "Computed Outputs para sa Validation", "Computed Outputs for Validation")) ?></h2>
            </div>
        </div>

        <div class="monitoring-grid">
            <?php foreach ($filteredRows as $index => $row): ?>
                <?php
                    $student = $row["student"] ?? [];
                    $latest = $row["latest"] ?? [];
                    $workload = $row["workload"] ?? [];
                    $taskSummary = $row["taskSummary"] ?? [];
                    $recordId = $latest["id"] ?? "";
                    $subject = $latest["subject"] ?? "No Record";
                    $systemOutput = trim(($latest["academicStatus"] ?? "No Record") . " / " . ($latest["competencyStatus"] ?? "No Record") . " / " . ($latest["attendanceStatus"] ?? "No Record") . " / " . ($latest["requirementStatus"] ?? "No Record") . " / " . ($latest["trendStatus"] ?? "No Record") . " / " . ($workload["lingguhangBigatIndex"] ?? "Magaan"));
                    $autoValidationStatus = $row["autoValidationStatus"] ?? kaakbay_auto_output_validation_status($latest, $workload, $taskSummary);
                    $validationBasis = kaakbay_validation_basis($autoValidationStatus);
                    $guidanceOutput = $latest["guidanceOutput"] ?? [
                        "status" => msg("No status available.", "Walang status na available.", "No status available."),
                        "advisory" => msg("No advisory available.", "Walang advisory na available.", "No advisory available."),
                        "guidance" => msg("No guidance available.", "Walang guidance na available.", "No guidance available.")
                    ];
                    $schedules = schedules_for_student($student["id"] ?? "");
                    $attendanceLookup = function_exists("attendance_update_lookup_for_student") ? attendance_update_lookup_for_student($student["id"] ?? "") : [];
                    $teacherAnalysis = function_exists("teacher_item_analysis_for_student") ? teacher_item_analysis_for_student($student["id"] ?? "", $subject) : [];
                ?>

                <div class="monitor-card <?= e(view_state_class($systemOutput . " " . $autoValidationStatus)) ?>">
                    <div class="monitor-card-top">
                        <div>
                            <span><?= e($student["code"] ?? "") ?></span>
                            <h3><?= e($student["name"] ?? "") ?></h3>
                            <p><?= e(($student["strand"] ?? "") . " · " . ($student["section"] ?? "")) ?></p>
                        </div>
                        <button class="dot-action" type="button" data-menu-button="validation-<?= e($index) ?>">•••</button>
                        <div class="popup-menu" data-menu="validation-<?= e($index) ?>">
                            <button type="button" data-modal-open="validate-<?= e($index) ?>"><?= e(msg("Review Output", "Suriin ang Output", "Review Output")) ?></button>
                            <button type="button" data-modal-open="attendance-<?= e($index) ?>"><?= e(msg("Mark Attendance", "Magmarka ng Attendance", "Mark Attendance")) ?></button>
                            <button type="button" data-modal-open="validate-detail-<?= e($index) ?>"><?= e(msg("View Details", "Tingnan ang Detalye", "View Details")) ?></button>
                        </div>
                    </div>

                    <div class="monitor-status-row">
                        <?= badge($latest["academicStatus"] ?? "No Record") ?>
                        <?= badge($latest["competencyStatus"] ?? "No Record") ?>
                        <?= badge($latest["attendanceStatus"] ?? "No Record") ?>
                        <?= badge($latest["requirementStatus"] ?? "No Record") ?>
                        <?= badge($latest["trendStatus"] ?? "No Record") ?>
                        <?= badge($workload["lingguhangBigatIndex"] ?? "Magaan") ?>
                        <?= badge($autoValidationStatus) ?>
                    </div>

                    <div class="monitor-mini-grid">
                        <div>
                            <span><?= e(msg("Subject", "Asignatura", "Subject")) ?></span>
                            <strong><?= e($subject) ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Grade", "Marka", "Grade")) ?></span>
                            <strong><?= e($latest["computedGrade"] ?? "--") ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Mastery", "Mastery", "Mastery")) ?></span>
                            <strong><?= e(($latest["competencyMastery"] ?? 0) > 0 ? ($latest["competencyMastery"] . "%") : "--") ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Absence", "Pagliban", "Absence")) ?></span>
                            <strong><?= e($latest["absenceRate"] ?? "--") ?>%</strong>
                        </div>
                        <div>
                            <span><?= e(msg("Ratio", "Ratio", "Ratio")) ?></span>
                            <strong><?= e($workload["workloadRatio"] ?? 0) ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("System Check", "System Check", "System Check")) ?></span>
                            <strong><?= e(function_exists("tv") ? tv($autoValidationStatus) : $autoValidationStatus) ?></strong>
                        </div>
                    </div>

                    <div class="record-guidance-strip">
                        <div><strong><?= e(msg("Status", "Kalagayan", "Status")) ?></strong><br><?= e($guidanceOutput["status"] ?? "") ?></div>
                        <div><strong><?= e(msg("Advisory", "Paalaala", "Advisory")) ?></strong><br><?= e($guidanceOutput["advisory"] ?? "") ?></div>
                        <div><strong><?= e(msg("Guidance", "Gabay", "Guidance")) ?></strong><br><?= e($guidanceOutput["guidance"] ?? "") ?></div>
                    </div>
                </div>

                <div class="modal-shell" data-modal="validate-<?= e($index) ?>">
                    <div class="modal-card large">
                        <div class="modal-head">
                            <h3><?= e(msg("Review Output", "Suriin ang Output", "Review Output")) ?></h3>
                            <button type="button" data-modal-close>×</button>
                        </div>

                        <form method="POST" class="modal-body forms">
                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                            <input type="hidden" name="studentId" value="<?= e($student["id"] ?? "") ?>">
                            <input type="hidden" name="recordId" value="<?= e($recordId) ?>">
                            <input type="hidden" name="validationType" value="output">
                            <input type="hidden" name="subject" value="<?= e($subject) ?>">
                            <input type="hidden" name="systemOutput" value="<?= e($systemOutput) ?>">
                            <input type="hidden" name="validationStatus" value="<?= e($autoValidationStatus) ?>">

                            <div class="field">
                                <label><?= e(msg("Student", "Mag-aaral", "Student")) ?></label>
                                <input value="<?= e(($student["code"] ?? "") . " · " . ($student["name"] ?? "")) ?>" readonly>
                            </div>

                            <div class="field">
                                <label><?= e(msg("System Output", "System Output", "System Output")) ?></label>
                                <input value="<?= e($systemOutput) ?>" readonly>
                            </div>

                            <div class="field">
                                <label><?= e(msg("System Validation", "System Validation", "System Validation")) ?></label>
                                <input value="<?= e(function_exists("tv") ? tv($autoValidationStatus) : $autoValidationStatus) ?>" readonly>
                            </div>

                            <div class="field">
                                <label><?= e(msg("Rule Basis", "Batayan ng Rule", "Rule Basis")) ?></label>
                                <input value="<?= e($validationBasis) ?>" readonly>
                            </div>

                            <div class="field">
                                <label><?= e(msg("Competency Area", "Bahagi ng Kakayahan", "Competency Area")) ?></label>
                                <input name="competencyArea">
                            </div>

                            <div class="field full">
                                <label><?= e(msg("Item Analysis Notes", "Tala sa Item Analysis", "Item Analysis Notes")) ?></label>
                                <textarea name="itemAnalysisNotes"></textarea>
                            </div>

                            <div class="field full">
                                <label><?= e(msg("Teacher Note", "Tala ng Guro", "Teacher Note")) ?></label>
                                <textarea name="note"></textarea>
                            </div>

                            <div class="field full">
                                <label><?= e(msg("Follow-up Plan", "Plano ng Follow-up", "Follow-up Plan")) ?></label>
                                <textarea name="followUpPlan"></textarea>
                            </div>

                            <div class="button-row full">
                                <button class="btn btn-primary" type="submit"><?= e(msg("Save Review", "I-save ang Review", "Save Review")) ?></button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="modal-shell" data-modal="attendance-<?= e($index) ?>">
                    <div class="modal-card large">
                        <div class="modal-head">
                            <h3><?= e(msg("Mark Attendance", "Magmarka ng Attendance", "Mark Attendance")) ?></h3>
                            <button type="button" data-modal-close>×</button>
                        </div>

                        <form
                            method="POST"
                            class="modal-body forms attendance-entry-form"
                            data-attendance-records="<?= e(json_encode($attendanceLookup, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?>"
                        >
                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                            <input type="hidden" name="action" value="markAttendance">
                            <input type="hidden" name="studentId" value="<?= e($student["id"] ?? "") ?>">
                            <input type="hidden" name="confirmAttendanceUpdate" value="0">
                            <input type="hidden" name="confirmedAttendanceId" value="">
                            <input type="hidden" name="redirect" value="validation.php">

                            <div class="field full">
                                <label><?= e(msg("Student", "Mag-aaral", "Student")) ?></label>
                                <input value="<?= e(($student["code"] ?? "") . " · " . ($student["name"] ?? "")) ?>" readonly>
                            </div>

                            <div class="field">
                                <label><?= e(msg("Subject Schedule", "Iskedyul ng Asignatura", "Subject Schedule")) ?></label>
                                <select name="scheduleId" required>
                                    <option value=""><?= e(msg("Select Schedule", "Pumili ng Iskedyul", "Select Schedule")) ?></option>
                                    <?php foreach ($schedules as $schedule): ?>
                                        <option value="<?= e($schedule["id"] ?? "") ?>"><?= e(($schedule["subject"] ?? "") . " · " . (function_exists("tv") ? tv($schedule["day"] ?? "") : ($schedule["day"] ?? "")) . " · " . ($schedule["startTime"] ?? "") . " - " . ($schedule["endTime"] ?? "")) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="field">
                                <label><?= e(msg("Date", "Petsa", "Date")) ?></label>
                                <input type="date" name="date" value="<?= e(date("Y-m-d")) ?>" required>
                            </div>

                            <div class="field">
                                <label><?= e(msg("Status", "Kalagayan", "Status")) ?></label>
                                <select name="status" required>
                                    <?php foreach (["Present", "Absent", "Excused"] as $status): ?>
                                        <option value="<?= e($status) ?>"><?= e(function_exists("tv") ? tv($status) : $status) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="field full">
                                <label><?= e(msg("Note", "Tala", "Note")) ?></label>
                                <textarea name="note"></textarea>
                            </div>

                            <div class="button-row full">
                                <button class="btn btn-primary" type="submit"><?= e(msg("Save Attendance", "I-save ang Attendance", "Save Attendance")) ?></button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="modal-shell" data-modal="validate-detail-<?= e($index) ?>">
                    <div class="modal-card large">
                        <div class="modal-head">
                            <h3><?= e(msg("Monitoring Details", "Detalye ng Pagsubaybay", "Monitoring Details")) ?></h3>
                            <button type="button" data-modal-close>×</button>
                        </div>

                        <div class="modal-body">
                            <div class="modal-grid">
                                <div>
                                    <span><?= e(msg("Academic Status", "Kalagayang Akademiko", "Academic Status")) ?></span>
                                    <strong><?= e(function_exists("tv") ? tv($latest["academicStatus"] ?? "No Record") : ($latest["academicStatus"] ?? "No Record")) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Competency", "Kakayahan", "Competency")) ?></span>
                                    <strong><?= e(function_exists("tv") ? tv($latest["competencyStatus"] ?? "No Record") : ($latest["competencyStatus"] ?? "No Record")) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Attendance", "Pagpasok", "Attendance")) ?></span>
                                    <strong><?= e(function_exists("tv") ? tv($latest["attendanceStatus"] ?? "No Record") : ($latest["attendanceStatus"] ?? "No Record")) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Absence Rate", "Bahagdan ng Pagliban", "Absence Rate")) ?></span>
                                    <strong><?= e($latest["absenceRate"] ?? "--") ?>%</strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Absence Streak", "Sunod-sunod na Pagliban", "Absence Streak")) ?></span>
                                    <strong><?= e($latest["consecutiveAbsences"] ?? "--") ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Requirements", "Requirements", "Requirements")) ?></span>
                                    <strong><?= e(function_exists("tv") ? tv($latest["requirementStatus"] ?? "No Record") : ($latest["requirementStatus"] ?? "No Record")) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Trend", "Pattern", "Trend")) ?></span>
                                    <strong><?= e(function_exists("tv") ? tv($latest["trendStatus"] ?? "No Record") : ($latest["trendStatus"] ?? "No Record")) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Workload", "Bigat ng Gawain", "Workload")) ?></span>
                                    <strong><?= e($workload["lingguhangBigatIndex"] ?? "Magaan") ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("System Validation", "System Validation", "System Validation")) ?></span>
                                    <strong><?= e(function_exists("tv") ? tv($autoValidationStatus) : $autoValidationStatus) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Available Study Time", "Available Study Time", "Available Study Time")) ?></span>
                                    <strong><?= e($workload["availableStudyTime"] ?? 0) ?>h</strong>
                                </div>
                            </div>

                            <div class="record-guidance-strip">
                                <div><strong><?= e(msg("Status", "Kalagayan", "Status")) ?></strong><br><?= e($guidanceOutput["status"] ?? "") ?></div>
                                <div><strong><?= e(msg("Advisory", "Paalaala", "Advisory")) ?></strong><br><?= e($guidanceOutput["advisory"] ?? "") ?></div>
                                <div><strong><?= e(msg("Guidance", "Gabay", "Guidance")) ?></strong><br><?= e($guidanceOutput["guidance"] ?? "") ?></div>
                            </div>

                            <?php if (count($teacherAnalysis)): ?>
                                <div class="subtask-box">
                                    <?php foreach (array_slice($teacherAnalysis, 0, 3) as $analysis): ?>
                                        <div class="subtask-item">
                                            <span><?= e(($analysis["competencyArea"] ?? "") ?: msg("Item Analysis", "Item Analysis", "Item Analysis")) ?></span>
                                            <strong><?= e($analysis["itemAnalysisNotes"] ?? "") ?></strong>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($latest["missingRequirements"])): ?>
                                <div class="notice warning"><?= e(msg("Missing / Incomplete", "Kulang / Hindi Kumpleto", "Missing / Incomplete")) ?>: <?= e(implode(", ", $latest["missingRequirements"])) ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>

            <?php if (!count($filteredRows)): ?>
                <div class="compact-empty">
                    <strong><?= e(msg("No computed outputs available", "Walang computed outputs na available", "No computed outputs available")) ?></strong>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <section class="card clean-panel section-space">
        <div class="clean-panel-head">
            <div>
                <h2><?= e(msg("Record Deletion Requests", "Record Deletion Requests", "Record Deletion Requests")) ?></h2>
            </div>
        </div>

        <table class="table">
            <thead>
                <tr>
                    <th><?= e(msg("STUDENT", "MAG-AARAL", "STUDENT")) ?></th>
                    <th><?= e(msg("RECORD", "TALA", "RECORD")) ?></th>
                    <th><?= e(msg("SCORE", "ISKOR", "SCORE")) ?></th>
                    <th><?= e(msg("REASON", "DAHILAN", "REASON")) ?></th>
                    <th><?= e(msg("STATUS", "KALAGAYAN", "STATUS")) ?></th>
                    <th><?= e(msg("DATE", "PETSA", "DATE")) ?></th>
                    <th><?= e(msg("ACTIONS", "AKSYON", "ACTIONS")) ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($deleteRequests as $request): ?>
                    <?php
                        $record = $request["record"] ?? [];
                        $requestStatus = $request["status"] ?? "Pending";
                    ?>
                    <tr>
                        <td><?= e(trim(($request["studentCode"] ?? "") . " · " . ($request["studentName"] ?? ""), " ·")) ?></td>
                        <td>
                            <div>
                                <div><?= e(($record["subject"] ?? "--") . " · " . ($record["assessmentType"] ?? "Assessment")) ?></div>
                                <small><?= e(($record["assessmentTitle"] ?? "--") . " · " . ($record["gradingPeriod"] ?? "--")) ?></small>
                            </div>
                        </td>
                        <td><?= e(($record["score"] ?? "--") . " / " . ($record["totalScore"] ?? "--")) ?></td>
                        <td><?= e($request["reason"] ?? "--") ?></td>
                        <td><?= badge($requestStatus) ?></td>
                        <td><?= e(date("M d, Y", strtotime($request["createdAt"] ?? "now"))) ?></td>
                        <td>
                            <?php if ($requestStatus === "Pending"): ?>
                                <form method="POST" class="forms compact-request-form">
                                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                    <input type="hidden" name="action" value="reviewDeleteRequest">
                                    <input type="hidden" name="requestId" value="<?= e($request["id"] ?? "") ?>">

                                    <div class="field full">
                                        <label><?= e(msg("Review Note", "Review Note", "Review Note")) ?></label>
                                        <textarea name="reviewNote" maxlength="700" placeholder="<?= e(msg("Optional for approval, required for rejection", "Optional sa approval, required sa rejection", "Optional for approval, required for rejection")) ?>"></textarea>
                                    </div>

                                    <div class="button-row full">
                                        <button class="btn btn-primary" type="submit" name="decision" value="approve"><?= e(msg("Approve", "Approve", "Approve")) ?></button>
                                        <button class="btn btn-danger" type="submit" name="decision" value="reject"><?= e(msg("Reject", "Reject", "Reject")) ?></button>
                                    </div>
                                </form>
                            <?php else: ?>
                                <div>
                                    <span><?= e(msg("Reviewed", "Reviewed", "Reviewed")) ?></span>
                                    <?php if (($request["reviewNote"] ?? "") !== ""): ?>
                                        <small><?= e($request["reviewNote"]) ?></small>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>

                <?php if (!count($deleteRequests)): ?>
                    <tr>
                        <td colspan="7"><?= e(msg("No record deletion requests yet.", "Wala pang record deletion requests.", "No record deletion requests yet.")) ?></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </section>

    <section class="card clean-panel section-space">
        <div class="clean-panel-head">
            <div>
                <h2><?= e(msg("Validation and Attendance History", "Kasaysayan ng Validation at Attendance", "Validation and Attendance History")) ?></h2>
            </div>
        </div>

        <table class="table">
            <thead>
                <tr>
                    <th><?= e(msg("SUBJECT", "ASIGNATURA", "SUBJECT")) ?></th>
                    <th><?= e(msg("SYSTEM OUTPUT", "SYSTEM OUTPUT", "SYSTEM OUTPUT")) ?></th>
                    <th><?= e(msg("STATUS", "KALAGAYAN", "STATUS")) ?></th>
                    <th><?= e(msg("STUDENT / COMPETENCY", "MAG-AARAL / KAKAYAHAN", "STUDENT / COMPETENCY")) ?></th>
                    <th><?= e(msg("ITEM ANALYSIS", "ITEM ANALYSIS", "ITEM ANALYSIS")) ?></th>
                    <th><?= e(msg("NOTE", "TALA", "NOTE")) ?></th>
                    <th><?= e(msg("DATE", "PETSA", "DATE")) ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach (array_reverse($filteredValidations) as $validation): ?>
                    <tr>
                        <td><?= e($validation["subject"] ?? "") ?></td>
                        <td><?= e($validation["systemOutput"] ?? "") ?></td>
                        <td><?= badge($validation["validationStatus"] ?? "") ?></td>
                        <td><?= e(trim(($validation["studentCode"] ?? "") . " · " . ($validation["studentName"] ?? ""), " ·") ?: ($validation["competencyArea"] ?? "--")) ?></td>
                        <td><?= e($validation["itemAnalysisNotes"] ?? "--") ?></td>
                        <td><?= e($validation["note"] ?? "") ?></td>
                        <td><?= e(date("M d, Y", strtotime($validation["createdAt"] ?? "now"))) ?></td>
                    </tr>
                <?php endforeach; ?>

                <?php foreach ($attendanceHistory as $attendance): ?>
                    <tr>
                        <td><?= e($attendance["subject"] ?? "") ?></td>
                        <td><?= e(msg("Attendance Mark", "Attendance Mark", "Attendance Mark")) ?></td>
                        <td><?= badge($attendance["status"] ?? "") ?></td>
                        <td><?= e(trim(($attendance["studentCode"] ?? "") . " · " . ($attendance["studentName"] ?? ""), " ·")) ?></td>
                        <td><?= e(msg("Attendance record", "Attendance record", "Attendance record")) ?></td>
                        <td><?= e(($attendance["note"] ?? "") !== "" ? $attendance["note"] : "--") ?></td>
                        <td><?= e(date("M d, Y", strtotime($attendance["date"] ?? $attendance["createdAt"] ?? "now"))) ?></td>
                    </tr>
                <?php endforeach; ?>

                <?php if (!count($filteredValidations) && !count($attendanceHistory)): ?>
                    <tr>
                        <td colspan="7"><?= e(msg("No validation or attendance records yet.", "Wala pang validation o attendance records.", "No validation or attendance records yet.")) ?></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </section>
</main>


<div class="attendance-update-confirm" data-attendance-update-confirm hidden>
    <button
        type="button"
        class="attendance-update-confirm-backdrop"
        data-attendance-confirm-cancel
        aria-label="<?= e(msg("Close attendance confirmation", "Isara ang attendance confirmation", "Close attendance confirmation")) ?>"
    ></button>

    <div
        class="attendance-update-confirm-card"
        role="dialog"
        aria-modal="true"
        aria-labelledby="attendance-update-confirm-title"
    >
        <div class="attendance-update-confirm-head">
            <div class="attendance-update-confirm-mark">!</div>
            <div>
                <span><?= e(msg("EXISTING RECORD", "MAY EXISTING RECORD", "EXISTING RECORD")) ?></span>
                <h3 id="attendance-update-confirm-title"><?= e(msg("Attendance Already Recorded", "May Naka-record nang Attendance", "May Existing Attendance na")) ?></h3>
            </div>
        </div>

        <p class="attendance-update-confirm-copy">
            <?= e(msg(
                "An attendance record already exists for this student, schedule, and date. Review the current value before replacing it.",
                "May attendance record na para sa student, schedule, at petsang ito. Suriin muna ang kasalukuyang value bago ito palitan.",
                "May attendance record na para sa student, schedule, at date na ito. Review the current value bago ito palitan."
            )) ?>
        </p>

        <div class="attendance-update-confirm-context">
            <div>
                <span><?= e(msg("Student", "Mag-aaral", "Student")) ?></span>
                <strong data-attendance-confirm-student>--</strong>
            </div>
            <div>
                <span><?= e(msg("Subject / Schedule", "Asignatura / Iskedyul", "Subject / Schedule")) ?></span>
                <strong data-attendance-confirm-subject>--</strong>
            </div>
            <div>
                <span><?= e(msg("Date", "Petsa", "Date")) ?></span>
                <strong data-attendance-confirm-date>--</strong>
            </div>
        </div>

        <div class="attendance-update-confirm-compare">
            <div class="attendance-update-confirm-state">
                <span><?= e(msg("CURRENT RECORD", "KASALUKUYANG RECORD", "CURRENT RECORD")) ?></span>
                <strong data-attendance-confirm-old-status>--</strong>
                <p data-attendance-confirm-old-note>--</p>
            </div>

            <div class="attendance-update-confirm-arrow" aria-hidden="true">→</div>

            <div class="attendance-update-confirm-state proposed">
                <span><?= e(msg("NEW VALUE", "BAGONG VALUE", "NEW VALUE")) ?></span>
                <strong data-attendance-confirm-new-status>--</strong>
                <p data-attendance-confirm-new-note>--</p>
            </div>
        </div>

        <div class="attendance-update-confirm-actions">
            <button type="button" class="btn btn-ghost" data-attendance-confirm-cancel>
                <?= e(msg("Cancel", "Kanselahin", "Cancel")) ?>
            </button>
            <button type="button" class="btn btn-primary" data-attendance-confirm-update>
                <?= e(msg("Update Attendance", "I-update ang Attendance", "Update Attendance")) ?>
            </button>
        </div>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const confirmation = document.querySelector("[data-attendance-update-confirm]");

    if (!confirmation) {
        return;
    }

    let pendingForm = null;

    const studentTarget = confirmation.querySelector("[data-attendance-confirm-student]");
    const subjectTarget = confirmation.querySelector("[data-attendance-confirm-subject]");
    const dateTarget = confirmation.querySelector("[data-attendance-confirm-date]");
    const oldStatusTarget = confirmation.querySelector("[data-attendance-confirm-old-status]");
    const oldNoteTarget = confirmation.querySelector("[data-attendance-confirm-old-note]");
    const newStatusTarget = confirmation.querySelector("[data-attendance-confirm-new-status]");
    const newNoteTarget = confirmation.querySelector("[data-attendance-confirm-new-note]");
    const updateButton = confirmation.querySelector("[data-attendance-confirm-update]");
    const cancelButtons = confirmation.querySelectorAll("[data-attendance-confirm-cancel]");

    const displayNote = function(value) {
        const note = String(value || "").trim();
        return note !== "" ? note : "No note";
    };

    const displayDate = function(value) {
        if (!value) {
            return "--";
        }

        const date = new Date(value + "T00:00:00");

        if (Number.isNaN(date.getTime())) {
            return value;
        }

        return date.toLocaleDateString(undefined, {
            year: "numeric",
            month: "short",
            day: "numeric"
        });
    };

    const closeConfirmation = function() {
        confirmation.hidden = true;
        document.body.classList.remove("attendance-confirm-open");
        pendingForm = null;
    };

    document.querySelectorAll(".attendance-entry-form").forEach(function(form) {
        form.addEventListener("submit", function(event) {
            const confirmationInput = form.querySelector('input[name="confirmAttendanceUpdate"]');
            const confirmedIdInput = form.querySelector('input[name="confirmedAttendanceId"]');

            if (confirmationInput && confirmationInput.value === "1") {
                return;
            }

            let records = {};

            try {
                records = JSON.parse(form.dataset.attendanceRecords || "{}");
            } catch (error) {
                records = {};
            }

            const scheduleSelect = form.querySelector('select[name="scheduleId"]');
            const dateInput = form.querySelector('input[name="date"]');
            const statusSelect = form.querySelector('select[name="status"]');
            const noteInput = form.querySelector('textarea[name="note"]');
            const studentInput = form.querySelector('.field.full input[readonly]');

            const scheduleId = scheduleSelect ? scheduleSelect.value : "";
            const date = dateInput ? dateInput.value : "";

            if (!scheduleId || !date) {
                return;
            }

            const existing = records[scheduleId + "|" + date];

            if (!existing || !existing.id) {
                return;
            }

            event.preventDefault();
            pendingForm = form;

            if (confirmationInput) {
                confirmationInput.value = "0";
            }

            if (confirmedIdInput) {
                confirmedIdInput.value = existing.id;
            }

            const selectedScheduleText = scheduleSelect && scheduleSelect.selectedIndex >= 0
                ? scheduleSelect.options[scheduleSelect.selectedIndex].textContent.trim()
                : "";

            studentTarget.textContent = studentInput ? studentInput.value : "--";
            subjectTarget.textContent = existing.subject || selectedScheduleText || "--";
            dateTarget.textContent = displayDate(date);
            oldStatusTarget.textContent = existing.status || "--";
            oldNoteTarget.textContent = displayNote(existing.note);
            newStatusTarget.textContent = statusSelect ? statusSelect.value : "--";
            newNoteTarget.textContent = displayNote(noteInput ? noteInput.value : "");

            confirmation.hidden = false;
            document.body.classList.add("attendance-confirm-open");

            if (updateButton) {
                updateButton.focus();
            }
        });
    });

    cancelButtons.forEach(function(button) {
        button.addEventListener("click", closeConfirmation);
    });

    if (updateButton) {
        updateButton.addEventListener("click", function() {
            if (!pendingForm) {
                closeConfirmation();
                return;
            }

            const formToSubmit = pendingForm;
            const confirmationInput = formToSubmit.querySelector('input[name="confirmAttendanceUpdate"]');

            if (confirmationInput) {
                confirmationInput.value = "1";
            }

            confirmation.hidden = true;
            document.body.classList.remove("attendance-confirm-open");
            pendingForm = null;
            formToSubmit.submit();
        });
    }

    document.addEventListener("keydown", function(event) {
        if (event.key === "Escape" && !confirmation.hidden) {
            closeConfirmation();
        }
    });
});
</script>

<?php page_foot(); ?>