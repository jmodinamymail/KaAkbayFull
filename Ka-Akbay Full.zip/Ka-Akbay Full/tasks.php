<?php
require_once __DIR__ . "/app/security.php";
require_once __DIR__ . "/app/auth.php";
require_once __DIR__ . "/app/page_actions.php";
require_once __DIR__ . "/app/page_data.php";
require_once __DIR__ . "/app/layout.php";

require_role(["student"]);

$user = current_user();
$error = handle_page_action("tasks", $user);
$data = get_page_data("tasks", $user);

$subjects = $data["subjects"] ?? [];
$tasks = $data["tasks"] ?? [];
$workload = $data["workload"] ?? [];
$routine = $data["routineCapacity"] ?? [];
$editTask = $data["editTask"] ?? null;
$breakdownTask = $data["breakdownTask"] ?? null;
$moveTask = $data["moveTask"] ?? null;
$weeklyPlan = $data["weeklyPlan"] ?? ["days" => [], "unscheduled" => []];
$monthlyPlan = $data["monthlyPlan"] ?? ["month" => date("F Y"), "days" => []];
$latestBySubject = $data["latestBySubject"] ?? [];
$removedTasks = function_exists("removed_tasks_for_student")
    ? removed_tasks_for_student($user["id"])
    : [];
$taskHistory = function_exists("task_history_for_student")
    ? task_history_for_student($user["id"])
    : [];
$removedTaskCount = count($removedTasks);
$taskHistoryCount = count($taskHistory);

$activeTasks = array_values(array_filter($tasks, fn($task) => ($task["status"] ?? "") !== "Completed"));
$overdueCount = count(array_filter($activeTasks, fn($task) => computed_task_status($task) === "Overdue"));
$highPriorityCount = 0;
$alertCount = 0;

foreach ($activeTasks as $task) {
    $linkedStatus = $latestBySubject[$task["subject"] ?? ""]["academicStatus"] ?? "";
    $priority = task_priority($task, $linkedStatus);
    $messages = function_exists("task_guidance_output") ? task_guidance_output($task, $linkedStatus, $workload["lingguhangBigatIndex"] ?? "Magaan") : task_trigger_messages($task, $linkedStatus);

    if (in_array($priority, ["Critical", "High"], true)) {
        $highPriorityCount++;
    }

    if (count($messages) > 0 && empty($task["dismissed"])) {
        $alertCount++;
    }
}

$showTaskEntry = $editTask || (($_GET["add"] ?? "") === "1");
$defaultCategory = $editTask["category"] ?? (task_categories()[0] ?? "Other Requirement");
$defaultWeight = function_exists("task_category_weight") ? task_category_weight($defaultCategory) : ($editTask["weightFactor"] ?? 1);

$todayDate = date("Y-m-d");
$maxTaskDate = date("Y-m-d", strtotime("+1 year", strtotime($todayDate)));
$taskStartValue = trim((string)($editTask["startDate"] ?? $todayDate));
$taskDueValue = trim((string)($editTask["dueDate"] ?? ""));
$taskStartMin = $todayDate;

if ($editTask && preg_match('/^\d{4}-\d{2}-\d{2}$/', $taskStartValue) && $taskStartValue < $todayDate) {
    $taskStartMin = $taskStartValue;
}

$taskDueMin = $taskStartValue !== "" ? $taskStartValue : $todayDate;

page_head(msg("Smart Task Board", "Smart Task Board", "Smart Task Board"));
sidebar("tasks", $user);
?>

<main class="main page-enter task-page">
    <section class="topbar">
        <div>
            <h1><?= e(msg("Smart Task Board", "Smart Task Board", "Smart Task Board")) ?></h1>
        </div>
        <div class="date"><?= e(date("M d, Y")) ?></div>
    </section>

    <div class="error <?= $error ? "show" : "" ?>"><?= e($error) ?></div>

    <section class="task-workload-overview">
        <div class="task-workload-main">
            <div>
                <span><?= e("Lingguhang Bigat") ?></span>
                <h2><?= e($workload["lingguhangBigatIndex"] ?? "Magaan") ?></h2>
            </div>
            <div class="task-workload-ratio">
                <small><?= e(msg("Ratio", "Ratio", "Ratio")) ?></small>
                <strong><?= e($workload["workloadRatio"] ?? 0) ?></strong>
            </div>
        </div>

        <div class="task-workload-grid">
            <div>
                <span><?= e(msg("Weekly Score", "Lingguhang Score", "Weekly Score")) ?></span>
                <strong><?= e($workload["weeklyWorkloadScore"] ?? 0) ?></strong>
            </div>
            <div>
                <span><?= e(msg("Study Time", "Oras ng Pag-aaral", "Study Time")) ?></span>
                <strong><?= e($workload["availableStudyTime"] ?? 0) ?>h</strong>
            </div>
            <div>
                <span><?= e(msg("Deadline Clusters", "Dikit-dikit na Deadline", "Deadline Clusters")) ?></span>
                <strong><?= e($workload["deadlineClusters"] ?? 0) ?></strong>
            </div>
            <div>
                <span><?= e(msg("Cluster Adjustment", "Cluster Adjustment", "Cluster Adjustment")) ?></span>
                <strong><?= e($workload["deadlineClusterAdjustment"] ?? 0) ?></strong>
            </div>
            <div>
                <span><?= e(msg("Pending", "Nakabinbin", "Pending")) ?></span>
                <strong><?= e(count($activeTasks)) ?></strong>
            </div>
            <div>
                <span><?= e(msg("Overdue", "Lampas Deadline", "Overdue")) ?></span>
                <strong><?= e($overdueCount) ?></strong>
            </div>
            <div>
                <span><?= e(msg("High Priority", "Mataas na Priority", "High Priority")) ?></span>
                <strong><?= e($highPriorityCount) ?></strong>
            </div>
            <div>
                <span><?= e(msg("Alerts", "Babala", "Alerts")) ?></span>
                <strong><?= e($alertCount) ?></strong>
            </div>
        </div>
    </section>

    <details class="card clean-panel section-space routine-collapse task-entry-collapse" id="task-form" <?= $showTaskEntry ? "open" : "" ?>>
        <summary>
            <span><?= e($editTask ? msg("Edit Task", "I-edit ang Task", "Edit Task") : msg("Add Task", "Magdagdag ng Task", "Add Task")) ?></span>
            <strong><?= e($editTask ? msg("Editing", "Ini-edit", "Editing") : msg("Open Form", "Buksan ang Form", "Open Form")) ?></strong>
        </summary>

        <div class="routine-collapse-body">
            <div class="clean-panel-head">
                <div>
                    <h2><?= e(msg("Task Entry", "Tala ng Task", "Task Entry")) ?></h2>
                </div>
                <div class="tab-buttons">
                    <button class="tab-button active" type="button" data-tab-group="task-entry" data-tab-target="task-details"><?= e(msg("Task Details", "Detalye ng Task", "Task Details")) ?></button>
                    <button class="tab-button" type="button" data-tab-group="task-entry" data-tab-target="capacity-basis"><?= e(msg("Capacity Basis", "Batayan ng Capacity", "Capacity Basis")) ?></button>
                </div>
            </div>

            <div class="tab-panel active" data-tab-panel-group="task-entry" data-tab-panel="task-details">
                <form method="POST" class="forms task-simple-form">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="taskId" value="<?= e($editTask["id"] ?? "") ?>">
                    <input type="hidden" name="weightFactor" data-task-weight-hidden value="<?= e($defaultWeight) ?>">

                    <div class="field">
                        <label><?= e(msg("Task Title", "Pamagat ng Task", "Task Title")) ?></label>
                        <input name="title" value="<?= e($editTask["title"] ?? "") ?>" maxlength="120" required>
                    </div>

                    <div class="field">
                        <label><?= e(msg("Subject", "Asignatura", "Subject")) ?></label>
                        <select name="subject" required>
                            <option value=""><?= e(msg("Select Subject", "Pumili ng Asignatura", "Select Subject")) ?></option>
                            <?php foreach ($subjects as $subject): ?>
                                <option value="<?= e($subject) ?>" <?= (($editTask["subject"] ?? "") === $subject) ? "selected" : "" ?>><?= e($subject) ?></option>
                            <?php endforeach; ?>
                            <?php if (!count($subjects)): ?>
                                <option value="Unassigned Subject"><?= e(msg("Unassigned Subject", "Walang Subject", "Unassigned Subject")) ?></option>
                            <?php endif; ?>
                        </select>
                    </div>

                    <div class="field">
                        <label><?= e(msg("Task Category", "Kategorya ng Task", "Task Category")) ?></label>
                        <select name="category" required data-task-category-select>
                            <?php foreach (task_categories() as $category): ?>
                                <?php $categoryWeight = function_exists("task_category_weight") ? task_category_weight($category) : 1; ?>
                                <option value="<?= e($category) ?>" data-weight="<?= e($categoryWeight) ?>" <?= (($editTask["category"] ?? "") === $category) ? "selected" : "" ?>><?= e(function_exists("tv") ? tv($category) : $category) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="field">
                        <label><?= e(msg("Difficulty Level", "Antas ng Hirap", "Difficulty Level")) ?></label>
                        <select name="difficulty" required>
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <option value="<?= e($i) ?>" <?= ((string)($editTask["difficulty"] ?? "1") === (string)$i) ? "selected" : "" ?>><?= e($i) ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div class="field">
                        <label><?= e(msg("Estimated Duration (Hours)", "Tinatayang Tagal (Oras)", "Estimated Duration (Hours)")) ?></label>
                        <input type="number" step="0.25" min="0.25" max="12" name="estimatedDuration" value="<?= e($editTask["estimatedDuration"] ?? "1") ?>" inputmode="decimal" required>
                    </div>

                    <div class="field task-weight-field">
                        <label><?= e(msg("Task Weight", "Bigat ng Task", "Task Weight")) ?></label>
                        <input value="<?= e($defaultWeight) ?>" data-task-weight-display readonly>
                    </div>

                    <div class="field full task-weight-basis">
                        <label><?= e(msg("Weight Basis", "Batayan ng Bigat", "Weight Basis")) ?></label>
                        <div class="notice">
                            <?= e(msg("The system assigns the task weight based on the selected category. Students cannot manually change this value.", "Ang system ang nag-aassign ng task weight batay sa napiling category. Hindi ito manu-manong binabago ng mag-aaral.", "The system assigns the task weight based on the selected category. Students cannot manually change this value.")) ?>
                        </div>
                    </div>

                    <div class="field">
                        <label><?= e(msg("Start Date", "Petsa ng Simula", "Start Date")) ?></label>
                        <input type="date" name="startDate" value="<?= e($taskStartValue) ?>" min="<?= e($taskStartMin) ?>" max="<?= e($maxTaskDate) ?>" required>
                    </div>

                    <div class="field">
                        <label><?= e(msg("Due Date", "Deadline", "Due Date")) ?></label>
                        <input type="date" name="dueDate" value="<?= e($taskDueValue) ?>" min="<?= e($taskDueMin) ?>" max="<?= e($maxTaskDate) ?>" required>
                    </div>

                    <div class="field">
                        <label><?= e(msg("Status", "Kalagayan", "Status")) ?></label>
                        <select name="status" required>
                            <?php foreach (["Not Started", "In Progress", "Rescheduled", "Completed"] as $status): ?>
                                <option value="<?= e($status) ?>" <?= (($editTask["status"] ?? "Not Started") === $status) ? "selected" : "" ?>><?= e(function_exists("tv") ? tv($status) : $status) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="field full">
                        <label><?= e(msg("Notes", "Tala", "Notes")) ?></label>
                        <textarea name="notes" maxlength="500"><?= e($editTask["notes"] ?? "") ?></textarea>
                    </div>

                    <div class="button-row full">
                        <button class="btn btn-primary" type="submit"><?= e($editTask ? msg("Save Changes", "I-save ang Pagbabago", "Save Changes") : msg("Add Task", "Magdagdag ng Task", "Add Task")) ?></button>
                        <a class="btn btn-ghost" href="tasks.php"><?= e(msg("Cancel", "Kanselahin", "Cancel")) ?></a>
                    </div>
                </form>
            </div>

            <div class="tab-panel" data-tab-panel-group="task-entry" data-tab-panel="capacity-basis">
                <div class="task-capacity-grid">
                    <div>
                        <span><?= e(msg("Weekly Hours", "Lingguhang Oras", "Weekly Hours")) ?></span>
                        <strong><?= e($routine["weeklyHours"] ?? 168) ?></strong>
                    </div>
                    <div>
                        <span><?= e(msg("Class Hours", "Oras sa Klase", "Class Hours")) ?></span>
                        <strong><?= e($routine["weeklyClassHours"] ?? 0) ?></strong>
                    </div>
                    <div>
                        <span><?= e(msg("Sleep Buffer", "Sleep Buffer", "Sleep Buffer")) ?></span>
                        <strong><?= e($routine["sleepHours"] ?? 56) ?></strong>
                    </div>
                    <div>
                        <span><?= e(msg("Personal Care", "Personal Care", "Personal Care")) ?></span>
                        <strong><?= e($routine["personalCareHours"] ?? 14) ?></strong>
                    </div>
                    <div>
                        <span><?= e(msg("Routine Buffer", "Routine Buffer", "Routine Buffer")) ?></span>
                        <strong><?= e($routine["nonAcademicBuffer"] ?? 70) ?></strong>
                    </div>
                    <div>
                        <span><?= e(msg("Available Study Time", "Available Study Time", "Available Study Time")) ?></span>
                        <strong><?= e($routine["availableStudyTime"] ?? 98) ?></strong>
                    </div>
                </div>
            </div>
        </div>
    </details>

    <?php if ($breakdownTask || $moveTask): ?>
        <section class="card clean-panel section-space">
            <div class="clean-panel-head">
                <div>
                    <h2><?= e($breakdownTask ? msg("Split Task", "Hatiin ang Task", "Split Task") : msg("Move Date", "Ilipat ang Petsa", "Move Date")) ?></h2>
                </div>
            </div>

            <?php if ($breakdownTask): ?>
                <form method="POST" class="forms">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="taskId" value="<?= e($breakdownTask["id"]) ?>">

                    <div class="field full">
                        <label><?= e(msg("Selected Task", "Napiling Task", "Selected Task")) ?></label>
                        <input value="<?= e($breakdownTask["title"]) ?>" readonly>
                    </div>

                    <div class="field">
                        <label><?= e(msg("Subtask", "Subtask", "Subtask")) ?></label>
                        <input name="subtaskTitle" maxlength="120" required>
                    </div>

                    <div class="field">
                        <label><?= e(msg("Duration", "Tagal", "Duration")) ?></label>
                        <input type="number" step="0.25" min="0.25" max="8" name="subtaskDuration" value="1" inputmode="decimal" required>
                    </div>

                    <div class="button-row full">
                        <button class="btn btn-primary" name="taskAction" value="subtask" type="submit"><?= e(msg("Add Subtask", "Magdagdag ng Subtask", "Add Subtask")) ?></button>
                        <a class="btn btn-ghost" href="tasks.php"><?= e(msg("Cancel", "Kanselahin", "Cancel")) ?></a>
                    </div>
                </form>
            <?php endif; ?>

            <?php if ($moveTask): ?>
                <form method="POST" class="forms">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="taskId" value="<?= e($moveTask["id"]) ?>">

                    <div class="field full">
                        <label><?= e(msg("Selected Task", "Napiling Task", "Selected Task")) ?></label>
                        <input value="<?= e($moveTask["title"]) ?>" readonly>
                    </div>

                    <div class="field full">
                        <label><?= e(msg("New Due Date", "Bagong Deadline", "New Due Date")) ?></label>
                        <input type="date" name="newDueDate" min="<?= e($todayDate) ?>" max="<?= e($maxTaskDate) ?>" required>
                    </div>

                    <div class="button-row full">
                        <button class="btn btn-primary" name="taskAction" value="move" type="submit"><?= e(msg("Move Date", "Ilipat ang Petsa", "Move Date")) ?></button>
                        <a class="btn btn-ghost" href="tasks.php"><?= e(msg("Cancel", "Kanselahin", "Cancel")) ?></a>
                    </div>
                </form>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <section class="card clean-panel section-space">
        <div class="clean-panel-head">
            <div>
                <h2><?= e(msg("Task List", "Listahan ng Tasks", "Task List")) ?></h2>
            </div>
            <div class="task-filter-tabs">
                <a class="btn btn-primary" href="tasks.php?add=1#task-form"><?= e(msg("Add Task", "Magdagdag ng Task", "Add Task")) ?></a>
                <button class="task-filter active" type="button" data-task-filter="all"><?= e(msg("All", "Lahat", "All")) ?></button>
                <button class="task-filter" type="button" data-task-filter="active"><?= e(msg("Active", "Active", "Active")) ?></button>
                <button class="task-filter" type="button" data-task-filter="completed"><?= e(msg("Completed", "Tapos", "Completed")) ?></button>
                <button class="task-filter" type="button" data-task-filter="priority"><?= e(msg("Priority", "Priority", "Priority")) ?></button>
                <button class="task-filter" type="button" data-task-filter="overdue"><?= e(msg("Overdue", "Lampas Deadline", "Overdue")) ?></button>
            </div>
        </div>

        <div class="compact-task-board">
            <?php foreach ($tasks as $index => $task): ?>
                <?php
                    $linkedStatus = $latestBySubject[$task["subject"] ?? ""]["academicStatus"] ?? "";
                    $priority = task_priority($task, $linkedStatus);
                    $score = adjusted_task_score($task);
                    $computedStatus = computed_task_status($task);
                    $guidanceMessages = function_exists("task_guidance_output") ? task_guidance_output($task, $linkedStatus, $workload["lingguhangBigatIndex"] ?? "Magaan") : task_trigger_messages($task, $linkedStatus);
                    $filterStatus = ($task["status"] ?? "") === "Completed" ? "completed" : "active";
                    $isPriority = in_array($priority, ["Critical", "High"], true) ? "priority" : "";
                    $isOverdue = $computedStatus === "Overdue" ? "overdue" : "";
                    $isFocus = count($guidanceMessages) > 0 && ($task["status"] ?? "") !== "Completed" && empty($task["dismissed"]);
                    $storedCategory = $task["category"] ?? "Other Requirement";
                    $storedWeight = function_exists("task_category_weight") ? task_category_weight($storedCategory) : ($task["weightFactor"] ?? 1);
                    $actionFormId = "task-action-form-" . $index;
                    $removeModalId = "task-remove-" . $index;
                    $canDeleteTask = function_exists("task_can_be_deleted")
                        ? task_can_be_deleted($task)
                        : false;
                    $deleteDeadline = function_exists("task_delete_deadline")
                        ? task_delete_deadline($task)
                        : "";
                    $deleteDeadlineTimestamp = $deleteDeadline !== "" ? strtotime($deleteDeadline) : false;
                    $deleteDeadlineLabel = $deleteDeadlineTimestamp
                        ? date("M d, Y h:i A", $deleteDeadlineTimestamp)
                        : "";
                ?>

                <article class="compact-task-card <?= e(strtolower($priority)) ?> <?= $isFocus ? "focus-task" : "" ?>" data-task-card data-task-status="<?= e(trim($filterStatus . " " . $isPriority . " " . $isOverdue)) ?>">
                    <div class="compact-task-main">
                        <div>
                            <span><?= e($task["subject"] ?? msg("Unassigned Subject", "Walang Subject", "Unassigned Subject")) ?></span>
                            <h3><?= e($task["title"] ?? msg("Untitled Task", "Walang Pamagat na Task", "Untitled Task")) ?></h3>
                        </div>

                        <div class="compact-task-badges">
                            <?php if ($isFocus): ?>
                                <?= badge(msg("Today’s Focus", "Focus Ngayon", "Today’s Focus")) ?>
                            <?php endif; ?>
                            <?= badge($priority) ?>
                            <?= badge($computedStatus) ?>
                        </div>
                    </div>

                    <div class="compact-task-meta">
                        <div>
                            <span><?= e(msg("Due", "Deadline", "Due")) ?></span>
                            <strong><?= e($task["dueDate"] ?? "--") ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Score", "Score", "Score")) ?></span>
                            <strong><?= e($score) ?></strong>
                        </div>
                        <div>
                            <span><?= e(msg("Duration", "Tagal", "Duration")) ?></span>
                            <strong><?= e($task["estimatedDuration"] ?? 0) ?>h</strong>
                        </div>
                    </div>

                    <?php if ($isFocus): ?>
                        <div class="task-focus-note compact-focus-note">
                            <?php foreach (array_slice($guidanceMessages, 0, 2) as $message): ?>
                                <div><?= e($message) ?></div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" id="<?= e($actionFormId) ?>" class="compact-task-action-form">
                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                        <input type="hidden" name="taskId" value="<?= e($task["id"]) ?>">
                    </form>

                    <div class="compact-task-actions">
                        <button class="btn btn-outline compact-action-btn" type="button" data-modal-open="task-detail-<?= e($index) ?>"><?= e(msg("Details", "Detalye", "Details")) ?></button>
                        <a class="btn btn-ghost compact-action-btn" href="tasks.php?edit=<?= e($task["id"]) ?>#task-form"><?= e(msg("Edit", "I-edit", "Edit")) ?></a>
                        <a class="btn btn-outline compact-action-btn" href="tasks.php?breakdown=<?= e($task["id"]) ?>"><?= e(msg("Split", "Hatiin", "Split")) ?></a>
                        <a class="btn btn-ghost compact-action-btn" href="tasks.php?move=<?= e($task["id"]) ?>"><?= e(msg("Move", "Ilipat", "Move")) ?></a>

                        <?php if (($task["status"] ?? "") !== "Completed"): ?>
                            <button class="btn btn-ghost compact-action-btn" form="<?= e($actionFormId) ?>" name="taskAction" value="start" type="submit"><?= e(msg("Start", "Simulan", "Start")) ?></button>
                            <button class="btn btn-primary compact-action-btn" form="<?= e($actionFormId) ?>" name="taskAction" value="done" type="submit"><?= e(msg("Done", "Tapos", "Done")) ?></button>
                            <?php if ($isFocus): ?>
                                <button class="btn btn-ghost compact-action-btn" form="<?= e($actionFormId) ?>" name="taskAction" value="dismiss" type="submit"><?= e(msg("Hide", "Itago", "Hide")) ?></button>
                            <?php endif; ?>
                        <?php endif; ?>

                        <?php if ($canDeleteTask): ?>
                            <button
                                class="btn btn-danger compact-action-btn"
                                form="<?= e($actionFormId) ?>"
                                name="taskAction"
                                value="delete"
                                type="submit"
                                title="<?= e($deleteDeadlineLabel !== "" ? msg("Permanent delete available until ", "Permanent delete available hanggang ", "Permanent delete available until ") . $deleteDeadlineLabel : "") ?>"
                            >
                                <?= e(msg("Delete", "Tanggalin", "Delete")) ?>
                            </button>
                        <?php else: ?>
                            <button
                                class="btn btn-danger compact-action-btn"
                                type="button"
                                data-modal-open="<?= e($removeModalId) ?>"
                            >
                                <?= e(msg("Remove / Cancel", "Remove / Cancel", "Remove / Cancel")) ?>
                            </button>
                        <?php endif; ?>
                    </div>
                </article>

                <div class="modal-shell" data-modal="task-detail-<?= e($index) ?>">
                    <div class="modal-card large">
                        <div class="modal-head">
                            <h3><?= e($task["title"] ?? msg("Untitled Task", "Walang Pamagat na Task", "Untitled Task")) ?></h3>
                            <button type="button" data-modal-close>×</button>
                        </div>

                        <div class="modal-body">
                            <div class="modal-grid">
                                <div>
                                    <span><?= e(msg("Subject", "Asignatura", "Subject")) ?></span>
                                    <strong><?= e($task["subject"] ?? msg("Unassigned Subject", "Walang Subject", "Unassigned Subject")) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Category", "Kategorya", "Category")) ?></span>
                                    <strong><?= e(function_exists("tv") ? tv($storedCategory) : $storedCategory) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Difficulty", "Hirap", "Difficulty")) ?></span>
                                    <strong><?= e($task["difficulty"] ?? 0) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Duration", "Tagal", "Duration")) ?></span>
                                    <strong><?= e($task["estimatedDuration"] ?? 0) ?>h</strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Weight", "Bigat", "Weight")) ?></span>
                                    <strong><?= e($storedWeight) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Score", "Score", "Score")) ?></span>
                                    <strong><?= e($score) ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Start Date", "Petsa ng Simula", "Start Date")) ?></span>
                                    <strong><?= e($task["startDate"] ?? "--") ?></strong>
                                </div>
                                <div>
                                    <span><?= e(msg("Due Date", "Deadline", "Due Date")) ?></span>
                                    <strong><?= e($task["dueDate"] ?? "--") ?></strong>
                                </div>
                            </div>

                            <div class="record-guidance-strip">
                                <?php foreach (array_slice($guidanceMessages, 0, 4) as $message): ?>
                                    <div><?= e($message) ?></div>
                                <?php endforeach; ?>
                            </div>

                            <?php if (!empty($task["notes"])): ?>
                                <div class="notice"><?= e($task["notes"]) ?></div>
                            <?php endif; ?>

                            <?php if (!empty($task["subtasks"])): ?>
                                <div class="subtask-box">
                                    <?php foreach ($task["subtasks"] as $subtask): ?>
                                        <div class="subtask-item">
                                            <span><?= e($subtask["title"] ?? "") ?></span>
                                            <?= badge($subtask["status"] ?? "Pending") ?>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>

                            <div class="button-row">
                                <a class="btn btn-outline" href="tasks.php?breakdown=<?= e($task["id"]) ?>"><?= e(msg("Split Task", "Hatiin ang Task", "Split Task")) ?></a>
                                <a class="btn btn-outline" href="tasks.php?move=<?= e($task["id"]) ?>"><?= e(msg("Move Date", "Ilipat ang Petsa", "Move Date")) ?></a>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if (!$canDeleteTask): ?>
                    <div class="modal-shell" data-modal="<?= e($removeModalId) ?>">
                        <div class="modal-card large">
                            <div class="modal-head">
                                <h3><?= e(msg("Remove or Cancel Task", "Remove o Cancel Task", "Remove or Cancel Task")) ?></h3>
                                <button type="button" data-modal-close>×</button>
                            </div>

                            <form method="POST" class="modal-body forms">
                                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="taskId" value="<?= e($task["id"]) ?>">

                                <div class="field full">
                                    <label><?= e(msg("Selected Task", "Napiling Task", "Selected Task")) ?></label>
                                    <input value="<?= e($task["title"] ?? "") ?>" readonly>
                                </div>

                                <div class="notice full">
                                    <?= e(msg(
                                        "The permanent delete period has ended. Removing or cancelling this task keeps it in Task History and excludes it from active workload calculations.",
                                        "Tapos na ang permanent delete period. Mananatili sa Task History ang task kapag ni-remove o kinansela at hindi na ito isasama sa active workload calculations.",
                                        "The permanent delete period has ended. Removing or cancelling this task keeps it in Task History and excludes it from active workload calculations."
                                    )) ?>
                                </div>

                                <div class="field full">
                                    <label for="taskRemovalReason-<?= e($index) ?>">
                                        <?= e(msg("Reason", "Dahilan", "Reason")) ?>
                                    </label>
                                    <textarea
                                        id="taskRemovalReason-<?= e($index) ?>"
                                        name="reason"
                                        maxlength="500"
                                        required
                                    ></textarea>
                                </div>

                                <div class="button-row full">
                                    <button class="btn btn-danger" name="taskAction" value="remove" type="submit">
                                        <?= e(msg("Remove Task", "I-remove ang Task", "Remove Task")) ?>
                                    </button>
                                    <button class="btn btn-outline" name="taskAction" value="cancel" type="submit">
                                        <?= e(msg("Cancel Task", "I-cancel ang Task", "Cancel Task")) ?>
                                    </button>
                                    <button class="btn btn-ghost" type="button" data-modal-close>
                                        <?= e(msg("Close", "Isara", "Close")) ?>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>

            <?php if (!count($tasks)): ?>
                <div class="compact-empty">
                    <strong><?= e(msg("No tasks yet", "Wala pang tasks", "No tasks yet")) ?></strong>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <details class="card clean-panel section-space routine-collapse" id="task-history">
        <summary>
            <span><?= e(msg("Task History", "Task History", "Task History")) ?></span>
            <strong><?= e($removedTaskCount) ?> <?= e(msg("removed/cancelled", "removed/cancelled", "removed/cancelled")) ?> · <?= e($taskHistoryCount) ?> <?= e(msg("activities", "activities", "activities")) ?></strong>
        </summary>

        <div class="routine-collapse-body">
            <div class="clean-panel-head">
                <div>
                    <h2><?= e(msg("Removed and Cancelled Tasks", "Removed at Cancelled Tasks", "Removed and Cancelled Tasks")) ?></h2>
                </div>
            </div>

            <div class="compact-task-board">
                <?php foreach ($removedTasks as $historyTask): ?>
                    <?php
                        $historyStatus = $historyTask["status"] ?? "Removed";
                        $historyMode = strtolower(trim((string)($historyTask["removalMode"] ?? $historyStatus)));
                        $isCancelledHistory = in_array($historyMode, ["cancel", "cancelled", "canceled"], true)
                            || in_array(strtolower(trim((string)$historyStatus)), ["cancelled", "canceled"], true);
                        $historyTimestampLabel = $isCancelledHistory
                            ? msg("Cancelled At", "Kinansela Noong", "Cancelled At")
                            : msg("Removed At", "Tinanggal Noong", "Removed At");
                        $historyRemovedAt = trim((string)($historyTask["removedAt"] ?? ""));
                        $historyRemovedTimestamp = $historyRemovedAt !== "" ? strtotime($historyRemovedAt) : false;
                        $historyRemovedLabel = $historyRemovedTimestamp
                            ? date("M d, Y h:i A", $historyRemovedTimestamp)
                            : "--";
                    ?>
                    <article class="compact-task-card">
                        <div class="compact-task-main">
                            <div>
                                <span><?= e($historyTask["subject"] ?? msg("Unassigned Subject", "Walang Subject", "Unassigned Subject")) ?></span>
                                <h3><?= e($historyTask["title"] ?? msg("Untitled Task", "Walang Pamagat na Task", "Untitled Task")) ?></h3>
                            </div>
                            <div class="compact-task-badges">
                                <?= badge($historyStatus) ?>
                            </div>
                        </div>

                        <div class="compact-task-meta">
                            <div>
                                <span><?= e($historyTimestampLabel) ?></span>
                                <strong><?= e($historyRemovedLabel) ?></strong>
                            </div>
                            <div>
                                <span><?= e(msg("Previous Status", "Dating Status", "Previous Status")) ?></span>
                                <strong><?= e($historyTask["statusBeforeRemoval"] ?? "--") ?></strong>
                            </div>
                            <div>
                                <span><?= e(msg("Mode", "Mode", "Mode")) ?></span>
                                <strong><?= e($isCancelledHistory ? msg("Cancelled", "Kinansela", "Cancelled") : msg("Removed", "Tinanggal", "Removed")) ?></strong>
                            </div>
                        </div>

                        <div class="notice task-history-reason">
                            <div class="task-history-reason-copy">
                                <strong><?= e(msg("Reason", "Dahilan", "Reason")) ?>:</strong>
                                <span><?= e(($historyTask["removalReason"] ?? "") !== "" ? $historyTask["removalReason"] : "--") ?></span>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>

                <?php if (!count($removedTasks)): ?>
                    <div class="compact-empty">
                        <strong><?= e(msg("No removed or cancelled tasks yet", "Wala pang removed o cancelled na tasks", "No removed or cancelled tasks yet")) ?></strong>
                    </div>
                <?php endif; ?>
            </div>

            <div class="clean-panel-head section-space">
                <div>
                    <h2><?= e(msg("Activity History", "Activity History", "Activity History")) ?></h2>
                </div>
            </div>

            <div class="record-guidance-strip">
                <?php foreach ($taskHistory as $historyEntry): ?>
                    <?php
                        $historyDetails = is_array($historyEntry["details"] ?? null)
                            ? $historyEntry["details"]
                            : [];
                        $historyCreatedAt = trim((string)($historyEntry["createdAt"] ?? ""));
                        $historyCreatedTimestamp = $historyCreatedAt !== "" ? strtotime($historyCreatedAt) : false;
                        $historyCreatedLabel = $historyCreatedTimestamp
                            ? date("M d, Y h:i A", $historyCreatedTimestamp)
                            : "--";
                        $historyActionLabel = ucwords(str_replace(["_", "-"], " ", (string)($historyEntry["action"] ?? "Updated")));
                    ?>
                    <div>
                        <strong><?= e($historyEntry["taskTitle"] ?? msg("Task", "Task", "Task")) ?></strong>
                        <span><?= e($historyActionLabel) ?> · <?= e($historyCreatedLabel) ?></span>
                        <?php if (!empty($historyDetails["reason"])): ?>
                            <small><?= e(msg("Reason", "Dahilan", "Reason")) ?>: <?= e($historyDetails["reason"]) ?></small>
                        <?php elseif (!empty($historyDetails["newDueDate"])): ?>
                            <small><?= e(msg("New Due Date", "Bagong Deadline", "New Due Date")) ?>: <?= e($historyDetails["newDueDate"]) ?></small>
                        <?php elseif (!empty($historyDetails["subtaskTitle"])): ?>
                            <small><?= e(msg("Subtask", "Subtask", "Subtask")) ?>: <?= e($historyDetails["subtaskTitle"]) ?></small>
                        <?php elseif (!empty($historyDetails["status"])): ?>
                            <small><?= e(msg("Status", "Status", "Status")) ?>: <?= e($historyDetails["status"]) ?></small>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>

                <?php if (!count($taskHistory)): ?>
                    <div><?= e(msg("No task activity history yet.", "Wala pang task activity history.", "No task activity history yet.")) ?></div>
                <?php endif; ?>
            </div>
        </div>
    </details>

    <details class="card clean-panel section-space routine-collapse" id="routine-plan">
        <summary>
            <span><?= e(msg("Suggested Routine", "Iminungkahing Routine", "Suggested Routine")) ?></span>
            <strong><?= e(msg("Weekly / Monthly", "Lingguhan / Buwanan", "Weekly / Monthly")) ?></strong>
        </summary>

        <div class="routine-collapse-body">
            <div class="tab-buttons">
                <button class="tab-button active" type="button" data-tab-group="task-routine" data-tab-target="task-week"><?= e(msg("Weekly", "Lingguhan", "Weekly")) ?></button>
                <button class="tab-button" type="button" data-tab-group="task-routine" data-tab-target="task-month"><?= e(msg("Monthly", "Buwanan", "Monthly")) ?></button>
            </div>

            <div class="tab-panel active" data-tab-panel-group="task-routine" data-tab-panel="task-week">
                <div class="weekly-calendar-grid">
                    <?php foreach ($weeklyPlan["days"] as $day): ?>
                        <div class="weekly-day-card">
                            <div class="weekly-day-head">
                                <div>
                                    <strong><?= e($day["shortDay"]) ?></strong>
                                    <span><?= e(date("M d", strtotime($day["date"]))) ?></span>
                                </div>
                                <small><?= e(round(($day["totalStudyMinutes"] ?? 0) / 60, 1)) ?>h <?= e(msg("planned", "nakaplano", "planned")) ?></small>
                            </div>

                            <div class="weekly-day-body">
                                <?php foreach ($day["classBlocks"] as $block): ?>
                                    <div class="weekly-block class-block">
                                        <span><?= e($block["startLabel"]) ?> - <?= e($block["endLabel"]) ?></span>
                                        <strong><?= e($block["subject"]) ?></strong>
                                        <small><?= e($block["room"] ?: msg("Class schedule", "Iskedyul ng Klase", "Class schedule")) ?></small>
                                    </div>
                                <?php endforeach; ?>

                                <?php foreach ($day["studyBlocks"] as $block): ?>
                                    <div class="weekly-block study-block">
                                        <span><?= e($block["startLabel"]) ?> - <?= e($block["endLabel"]) ?></span>
                                        <strong><?= e($block["subject"]) ?></strong>
                                        <p><?= e($block["title"]) ?></p>
                                        <small><?= e($block["reason"]) ?> · <?= e(round($block["durationMinutes"] / 60, 1)) ?>h</small>
                                    </div>
                                <?php endforeach; ?>

                                <?php if (!count($day["classBlocks"]) && !count($day["studyBlocks"])): ?>
                                    <div class="weekly-empty"><?= e(msg("Open rest or review day", "Araw para sa pahinga o review", "Open rest or review day")) ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <?php if (count($weeklyPlan["unscheduled"])): ?>
                    <div class="weekly-unscheduled">
                        <strong><?= e(msg("Needs adjustment", "Kailangang ayusin", "Needs adjustment")) ?></strong>

                        <div class="weekly-unscheduled-list">
                            <?php foreach ($weeklyPlan["unscheduled"] as $item): ?>
                                <div>
                                    <span><?= e($item["subject"]) ?></span>
                                    <strong><?= e($item["title"]) ?></strong>
                                    <small><?= e(round($item["remainingMinutes"] / 60, 1)) ?>h <?= e(msg("remaining", "natitira", "remaining")) ?> · <?= e(msg("Due", "Deadline", "Due")) ?> <?= e($item["dueDate"] ?: msg("not set", "hindi nakatakda", "not set")) ?></small>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="tab-panel" data-tab-panel-group="task-routine" data-tab-panel="task-month">
                <div class="month-calendar-head">
                    <strong><?= e($monthlyPlan["month"] ?? date("F Y")) ?></strong>
                    <span><?= e(msg("Task pressure by due date", "Bigat ng tasks batay sa deadline", "Task pressure by due date")) ?></span>
                </div>

                <div class="month-calendar-grid">
                    <?php foreach ($monthlyPlan["days"] as $day): ?>
                        <div class="month-day-card <?= ($day["score"] ?? 0) >= 20 ? "busy" : "" ?>">
                            <span><?= e(date("j", strtotime($day["date"]))) ?></span>
                            <small><?= e($day["day"]) ?></small>

                            <?php foreach (array_slice($day["tasks"] ?? [], 0, 2) as $task): ?>
                                <div class="month-task-dot">
                                    <strong><?= e($task["subject"]) ?></strong>
                                    <em><?= e($task["title"]) ?></em>
                                </div>
                            <?php endforeach; ?>

                            <?php if (count($day["tasks"] ?? []) > 2): ?>
                                <p>+<?= e(count($day["tasks"]) - 2) ?> <?= e(msg("more", "pa", "more")) ?></p>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </details>
</main>

<?php page_foot(); ?>